package com.example.transport

import android.content.Context
import com.example.crypto.CryptoEngine
import com.example.data.model.MeshPacket
import com.example.data.model.MeshPeer
import com.example.data.model.PacketType
import com.example.data.model.TransportProtocol
import com.example.transport.ble.BleTransport
import com.example.transport.lan.LocalNetworkTransport
import com.example.transport.wifi.WifiAwareTransport
import com.example.transport.wifi.WifiDirectTransport
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * 100% Real Hardware Multi-Radio Transport Manager.
 * Combines Local Wi-Fi/Hotspot/LAN (UDP Broadcast + TCP Sockets),
 * Wi-Fi Direct (P2P), Wi-Fi Aware (NAN Service), and Bluetooth Low Energy.
 */
class TransportManager(
    private val context: Context,
    private val cryptoEngine: CryptoEngine
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val localNetworkTransport = LocalNetworkTransport(context, cryptoEngine)
    val wifiDirectTransport = WifiDirectTransport(context, cryptoEngine)
    val wifiAwareTransport = WifiAwareTransport(context, cryptoEngine)
    val bleTransport = BleTransport(context, cryptoEngine)

    private val _incomingPackets = MutableSharedFlow<MeshPacket>(extraBufferCapacity = 128)

    val allDiscoveredPeers: StateFlow<List<MeshPeer>> = combine(
        localNetworkTransport.discoveredPeers,
        wifiDirectTransport.discoveredPeers,
        wifiAwareTransport.discoveredPeers,
        bleTransport.discoveredPeers
    ) { lan, p2p, aware, ble ->
        (lan + p2p + aware + ble).distinctBy { it.nodeId }
    }.stateIn(scope, SharingStarted.Eagerly, emptyList())

    init {
        // Aggregate incoming packet streams from all physical radio transports
        scope.launch {
            localNetworkTransport.observeIncomingPackets().collect { packet ->
                _incomingPackets.emit(packet)
            }
        }
        scope.launch {
            wifiDirectTransport.observeIncomingPackets().collect { packet ->
                _incomingPackets.emit(packet)
            }
        }
        scope.launch {
            wifiAwareTransport.observeIncomingPackets().collect { packet ->
                _incomingPackets.emit(packet)
            }
        }
        scope.launch {
            bleTransport.observeIncomingPackets().collect { packet ->
                _incomingPackets.emit(packet)
            }
        }
    }

    suspend fun startAllTransports() {
        localNetworkTransport.start()
        wifiDirectTransport.start()
        wifiAwareTransport.start()
        bleTransport.start()
        broadcastPresenceAnnounce()
    }

    suspend fun stopAllTransports() {
        localNetworkTransport.stop()
        wifiDirectTransport.stop()
        wifiAwareTransport.stop()
        bleTransport.stop()
    }

    suspend fun discoverAllPeers() {
        localNetworkTransport.discoverPeers()
        wifiDirectTransport.discoverPeers()
        wifiAwareTransport.discoverPeers()
        bleTransport.discoverPeers()
        broadcastPresenceAnnounce()
    }

    /**
     * Announces local node's display name and public key over all active radios.
     */
    suspend fun broadcastPresenceAnnounce() {
        val myNodeId = cryptoEngine.getOrCreateNodeId()
        val myName = cryptoEngine.getDisplayName()
        val myPubKey = cryptoEngine.getPublicKeyBase64()
        val now = System.currentTimeMillis()

        val announcePacket = MeshPacket(
            packetId = "ann_" + UUID.randomUUID().toString().take(12),
            type = PacketType.NODE_ANNOUNCE,
            senderNodeId = myNodeId,
            senderDisplayName = myName,
            recipientNodeId = MeshPacket.BROADCAST_RECIPIENT,
            senderEphemeralPubKey = myPubKey,
            timestamp = now,
            hopCount = 1,
            maxTtl = 2,
            signature = cryptoEngine.signPacketData(myNodeId + myName + myPubKey + now),
            routeTrace = listOf(myNodeId)
        )

        broadcastPacket(announcePacket)
    }

    /**
     * Broadcasts an encrypted mesh packet across all physical hardware radios.
     */
    suspend fun broadcastPacket(packet: MeshPacket): Result<Int> {
        var totalReached = 0
        totalReached += localNetworkTransport.broadcastPacket(packet).getOrDefault(0)
        totalReached += wifiDirectTransport.broadcastPacket(packet).getOrDefault(0)
        totalReached += wifiAwareTransport.broadcastPacket(packet).getOrDefault(0)
        totalReached += bleTransport.broadcastPacket(packet).getOrDefault(0)
        return Result.success(totalReached)
    }

    fun observeIncomingPackets(): Flow<MeshPacket> {
        return _incomingPackets.asSharedFlow()
    }
}
