package com.example.transport.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattServer
import android.bluetooth.BluetoothGattServerCallback
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.BluetoothLeAdvertiser
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Build
import android.os.ParcelUuid
import com.example.crypto.CryptoEngine
import com.example.data.model.MeshPacket
import com.example.data.model.MeshPeer
import com.example.data.model.PacketType
import com.example.data.model.TransportProtocol
import com.example.mesh.PacketCodec
import com.example.transport.MeshTransport
import com.example.transport.RadioStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * 100% Offline Hardware Bluetooth Low Energy (BLE) Mesh Transport.
 *
 * Operates purely peer-to-peer between Android devices:
 * - NO Wi-Fi router needed
 * - NO Internet needed
 * - Works even if Wi-Fi is turned off completely!
 *
 * Uses BLE Advertising + Scanning for auto-discovery and BLE GATT Server & Client
 * with chunked streaming for bidirectional end-to-end encrypted packet exchange.
 */
@SuppressLint("MissingPermission")
class BleTransport(
    private val context: Context,
    private val cryptoEngine: CryptoEngine
) : MeshTransport {

    companion object {
        val MESH_SERVICE_UUID: UUID = UUID.fromString("0000FEAA-0000-1000-8000-00805F9B34FB")
        val PACKET_CHAR_UUID: UUID = UUID.fromString("0000FEAB-0000-1000-8000-00805F9B34FB")
        private const val BLE_CHUNK_SIZE = 160
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override val protocol: TransportProtocol = TransportProtocol.BLE

    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    override val isSupportedOnDevice: Boolean = bluetoothAdapter != null

    private val _radioStatus = MutableStateFlow<RadioStatus>(RadioStatus.Disabled)
    override val radioStatus: StateFlow<RadioStatus> = _radioStatus.asStateFlow()

    private val _discoveredPeers = MutableStateFlow<List<MeshPeer>>(emptyList())
    override val discoveredPeers: StateFlow<List<MeshPeer>> = _discoveredPeers.asStateFlow()

    private val _incomingPackets = MutableSharedFlow<MeshPacket>(extraBufferCapacity = 128)

    private var advertiser: BluetoothLeAdvertiser? = null
    private var scanner: BluetoothLeScanner? = null
    private var gattServer: BluetoothGattServer? = null

    // Track active GATT client connections to other devices
    private val discoveredDevices = ConcurrentHashMap<String, BluetoothDevice>()
    private val activeGattClients = ConcurrentHashMap<String, BluetoothGatt>()

    // Incomplete stream buffers per device address
    private val incomingStreamBuffers = ConcurrentHashMap<String, ByteArrayOutputStream>()

    // Connected devices to our GATT server
    private val serverConnectedDevices = ConcurrentHashMap<String, BluetoothDevice>()

    private val gattServerCallback = object : BluetoothGattServerCallback() {
        override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) {
            val devAddress = device.address ?: return
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                serverConnectedDevices[devAddress] = device
                _radioStatus.value = RadioStatus.Active(connectedPeersCount = serverConnectedDevices.size + activeGattClients.size)
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                serverConnectedDevices.remove(devAddress)
                incomingStreamBuffers.remove(devAddress)
                _radioStatus.value = RadioStatus.Active(connectedPeersCount = serverConnectedDevices.size + activeGattClients.size)
            }
        }

        override fun onCharacteristicWriteRequest(
            device: BluetoothDevice,
            requestId: Int,
            characteristic: BluetoothGattCharacteristic,
            preparedWrite: Boolean,
            responseNeeded: Boolean,
            offset: Int,
            value: ByteArray?
        ) {
            if (responseNeeded) {
                try {
                    gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, value)
                } catch (_: Exception) {}
            }

            if (characteristic.uuid == PACKET_CHAR_UUID && value != null && value.isNotEmpty()) {
                val devAddress = device.address ?: return
                handleIncomingChunk(devAddress, value)
            }
        }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device ?: return
            val devAddress = device.address ?: return
            discoveredDevices[devAddress] = device

            val scanRecord = result.scanRecord
            val serviceData = scanRecord?.getServiceData(ParcelUuid(MESH_SERVICE_UUID))

            val peerNodeId = if (serviceData != null && serviceData.isNotEmpty()) {
                String(serviceData, Charsets.UTF_8).trim()
            } else {
                "node_ble_" + devAddress.replace(":", "").takeLast(8)
            }

            val peerName = device.name ?: ("BLE Peer " + devAddress.takeLast(5))

            val peer = MeshPeer(
                nodeId = peerNodeId,
                displayName = peerName,
                publicKeyBase64 = "",
                transport = TransportProtocol.BLE,
                address = devAddress,
                rssi = result.rssi,
                isConnected = true,
                hopDistance = 1
            )

            val current = _discoveredPeers.value.toMutableList()
            val existingIndex = current.indexOfFirst { it.nodeId == peerNodeId || it.address == devAddress }
            if (existingIndex >= 0) {
                current[existingIndex] = peer
            } else {
                current.add(peer)
            }
            _discoveredPeers.value = current

            // Auto-connect GATT client in background to establish mesh link
            scope.launch {
                ensureGattClientConnected(device)
            }
        }
    }

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
            _radioStatus.value = RadioStatus.Active(connectedPeersCount = serverConnectedDevices.size + activeGattClients.size)
        }

        override fun onStartFailure(errorCode: Int) {
            _radioStatus.value = RadioStatus.Error("BLE Advertise code $errorCode")
        }
    }

    override suspend fun start() {
        if (!isSupportedOnDevice || bluetoothAdapter?.isEnabled != true) {
            _radioStatus.value = RadioStatus.Disabled
            return
        }

        startGattServer()

        advertiser = bluetoothAdapter.bluetoothLeAdvertiser
        scanner = bluetoothAdapter.bluetoothLeScanner

        startAdvertising()
        discoverPeers()
        _radioStatus.value = RadioStatus.Ready
    }

    private fun startGattServer() {
        try {
            val server = bluetoothManager?.openGattServer(context, gattServerCallback) ?: return
            gattServer = server

            val meshService = BluetoothGattService(MESH_SERVICE_UUID, BluetoothGattService.SERVICE_TYPE_PRIMARY)
            val packetChar = BluetoothGattCharacteristic(
                PACKET_CHAR_UUID,
                BluetoothGattCharacteristic.PROPERTY_READ or
                        BluetoothGattCharacteristic.PROPERTY_WRITE or
                        BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE or
                        BluetoothGattCharacteristic.PROPERTY_NOTIFY,
                BluetoothGattCharacteristic.PERMISSION_READ or BluetoothGattCharacteristic.PERMISSION_WRITE
            )
            meshService.addCharacteristic(packetChar)
            server.addService(meshService)
        } catch (_: Exception) {}
    }

    private fun startAdvertising() {
        val adv = advertiser ?: return
        val myNodeId = cryptoEngine.getOrCreateNodeId().take(12)

        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setConnectable(true)
            .setTimeout(0)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
            .build()

        val data = AdvertiseData.Builder()
            .addServiceUuid(ParcelUuid(MESH_SERVICE_UUID))
            .addServiceData(ParcelUuid(MESH_SERVICE_UUID), myNodeId.toByteArray(Charsets.UTF_8))
            .setIncludeDeviceName(true)
            .build()

        try {
            adv.startAdvertising(settings, data, advertiseCallback)
        } catch (_: Exception) {}
    }

    override suspend fun stop() {
        try {
            advertiser?.stopAdvertising(advertiseCallback)
            scanner?.stopScan(scanCallback)
            activeGattClients.values.forEach { it.close() }
            activeGattClients.clear()
            gattServer?.close()
            gattServer = null
        } catch (_: Exception) {}
        _radioStatus.value = RadioStatus.Disabled
    }

    override suspend fun discoverPeers() {
        val scn = scanner ?: return
        val filter = ScanFilter.Builder()
            .setServiceUuid(ParcelUuid(MESH_SERVICE_UUID))
            .build()

        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        try {
            scn.startScan(listOf(filter), settings, scanCallback)
        } catch (_: Exception) {
            // Fallback scan without filter if hardware filtering fails
            try {
                scn.startScan(scanCallback)
            } catch (_: Exception) {}
        }
    }

    private fun ensureGattClientConnected(device: BluetoothDevice) {
        val devAddress = device.address ?: return
        if (activeGattClients.containsKey(devAddress)) return

        try {
            val gatt = device.connectGatt(context, false, object : BluetoothGattCallback() {
                override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
                    if (newState == BluetoothProfile.STATE_CONNECTED) {
                        activeGattClients[devAddress] = gatt
                        gatt.requestMtu(512)
                        gatt.discoverServices()
                        _radioStatus.value = RadioStatus.Active(connectedPeersCount = serverConnectedDevices.size + activeGattClients.size)
                    } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                        activeGattClients.remove(devAddress)?.close()
                        _radioStatus.value = RadioStatus.Active(connectedPeersCount = serverConnectedDevices.size + activeGattClients.size)
                    }
                }

                override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
                    // Services discovered, ready to transmit
                }

                override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
                    val value = characteristic.value ?: return
                    handleIncomingChunk(devAddress, value)
                }
            })
            activeGattClients[devAddress] = gatt
        } catch (_: Exception) {}
    }

    private fun handleIncomingChunk(devAddress: String, chunk: ByteArray) {
        val buffer = incomingStreamBuffers.getOrPut(devAddress) { ByteArrayOutputStream() }
        synchronized(buffer) {
            buffer.write(chunk)
            val currentBytes = buffer.toByteArray()
            val text = String(currentBytes, Charsets.UTF_8)

            if (text.contains("\n")) {
                val lines = text.split("\n")
                // All completed lines except the last trailing partial piece
                for (i in 0 until lines.size - 1) {
                    val completeLine = lines[i].trim()
                    if (completeLine.isNotBlank()) {
                        val packet = PacketCodec.deserialize(completeLine)
                        if (packet != null && packet.senderNodeId != cryptoEngine.getOrCreateNodeId()) {
                            _incomingPackets.tryEmit(packet)
                            registerPeerFromPacket(packet, devAddress)
                        }
                    }
                }
                // Retain remaining partial segment
                buffer.reset()
                val remainder = lines.last()
                if (remainder.isNotEmpty()) {
                    buffer.write(remainder.toByteArray(Charsets.UTF_8))
                }
            }
        }
    }

    private fun registerPeerFromPacket(packet: MeshPacket, devAddress: String) {
        val peer = MeshPeer(
            nodeId = packet.senderNodeId,
            displayName = packet.senderDisplayName.ifBlank { "BLE Node " + packet.senderNodeId.takeLast(4) },
            publicKeyBase64 = packet.senderEphemeralPubKey,
            transport = TransportProtocol.BLE,
            address = devAddress,
            isConnected = true,
            hopDistance = packet.hopCount
        )

        val current = _discoveredPeers.value.toMutableList()
        val idx = current.indexOfFirst { it.nodeId == packet.senderNodeId || it.address == devAddress }
        if (idx >= 0) {
            current[idx] = peer
        } else {
            current.add(peer)
        }
        _discoveredPeers.value = current
    }

    override suspend fun connectToPeer(peer: MeshPeer): Result<Unit> = withContext(Dispatchers.IO) {
        val device = discoveredDevices[peer.address] ?: bluetoothAdapter?.getRemoteDevice(peer.address)
        if (device != null) {
            ensureGattClientConnected(device)
            Result.success(Unit)
        } else {
            Result.failure(Exception("Bluetooth device not found for address ${peer.address}"))
        }
    }

    override suspend fun disconnectFromPeer(peer: MeshPeer) {
        activeGattClients.remove(peer.address)?.close()
    }

    override suspend fun broadcastPacket(packet: MeshPacket): Result<Int> = withContext(Dispatchers.IO) {
        val serializedLine = PacketCodec.serialize(packet) + "\n"
        val bytes = serializedLine.toByteArray(Charsets.UTF_8)
        var deliveredCount = 0

        // 1. Send to all active GATT client connections
        val targetClients = activeGattClients.values.toList()
        for (gatt in targetClients) {
            try {
                val service = gatt.getService(MESH_SERVICE_UUID)
                val characteristic = service?.getCharacteristic(PACKET_CHAR_UUID)
                if (characteristic != null) {
                    var offset = 0
                    while (offset < bytes.size) {
                        val chunkSize = minOf(BLE_CHUNK_SIZE, bytes.size - offset)
                        val chunk = bytes.copyOfRange(offset, offset + chunkSize)
                        characteristic.value = chunk
                        characteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                        gatt.writeCharacteristic(characteristic)
                        offset += chunkSize
                        delay(25) // Allow BLE controller queue to process
                    }
                    deliveredCount++
                }
            } catch (_: Exception) {}
        }

        // 2. Also notify connected GATT server devices
        val server = gattServer
        val service = server?.getService(MESH_SERVICE_UUID)
        val characteristic = service?.getCharacteristic(PACKET_CHAR_UUID)
        if (server != null && characteristic != null) {
            for (dev in serverConnectedDevices.values) {
                try {
                    var offset = 0
                    while (offset < bytes.size) {
                        val chunkSize = minOf(BLE_CHUNK_SIZE, bytes.size - offset)
                        val chunk = bytes.copyOfRange(offset, offset + chunkSize)
                        characteristic.value = chunk
                        server.notifyCharacteristicChanged(dev, characteristic, false)
                        offset += chunkSize
                        delay(25)
                    }
                    deliveredCount++
                } catch (_: Exception) {}
            }
        }

        Result.success(deliveredCount)
    }

    override fun observeIncomingPackets(): Flow<MeshPacket> {
        return _incomingPackets.asSharedFlow()
    }
}
