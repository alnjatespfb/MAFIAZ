package com.example.transport.lan

import android.content.Context
import android.net.wifi.WifiManager
import com.example.crypto.CryptoEngine
import com.example.data.model.MeshPacket
import com.example.data.model.MeshPeer
import com.example.data.model.PacketType
import com.example.data.model.TransportProtocol
import com.example.mesh.PacketCodec
import com.example.transport.MeshTransport
import com.example.transport.RadioStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap

/**
 * High-reliability Local Wi-Fi / Hotspot / LAN Mesh Transport.
 *
 * Works in 100% offline environments when:
 * 1. Phones are connected to any Wi-Fi Access Point (even with no internet).
 * 2. One phone turns on Wi-Fi Hotspot (no SIM/data needed) and the other connects to it.
 * 3. Both devices are on the same local subnet / Wi-Fi network.
 *
 * Uses:
 * - Dynamic Subnet Broadcast & Multicast on port 8989 for automatic zero-touch peer discovery.
 * - Dual TCP / UDP pipeline for guaranteed instantaneous packet transmission.
 */
class LocalNetworkTransport(
    private val context: Context,
    private val cryptoEngine: CryptoEngine
) : MeshTransport {

    companion object {
        const val TCP_PORT = 8988
        const val UDP_DISCOVERY_PORT = 8989
        const val MULTICAST_GROUP_IP = "224.0.0.251"
        private const val SOCKET_TIMEOUT_MS = 3500
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override val protocol: TransportProtocol = TransportProtocol.WIFI_DIRECT

    override val isSupportedOnDevice: Boolean = true

    private val _radioStatus = MutableStateFlow<RadioStatus>(RadioStatus.Disabled)
    override val radioStatus: StateFlow<RadioStatus> = _radioStatus.asStateFlow()

    private val _discoveredPeers = MutableStateFlow<List<MeshPeer>>(emptyList())
    override val discoveredPeers: StateFlow<List<MeshPeer>> = _discoveredPeers.asStateFlow()

    private val _incomingPackets = MutableSharedFlow<MeshPacket>(extraBufferCapacity = 256)

    private var tcpServerSocket: ServerSocket? = null
    private var udpSocket: DatagramSocket? = null
    private var multicastLock: WifiManager.MulticastLock? = null

    // Known peer Node ID / IP -> Peer Node details
    private val peerAddressMap = ConcurrentHashMap<String, MeshPeer>()
    private val activeTcpSockets = ConcurrentHashMap<String, Socket>()

    override suspend fun start() {
        acquireMulticastLock()
        startTcpServer()
        startUdpDiscoveryListener()
        startPeriodicDiscoveryBeacon()
        _radioStatus.value = RadioStatus.Ready
        discoverPeers()
    }

    override suspend fun stop() {
        try {
            multicastLock?.release()
        } catch (_: Exception) {}

        try {
            tcpServerSocket?.close()
            udpSocket?.close()
            activeTcpSockets.values.forEach { it.close() }
            activeTcpSockets.clear()
        } catch (_: Exception) {}

        _radioStatus.value = RadioStatus.Disabled
    }

    private fun acquireMulticastLock() {
        try {
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            multicastLock = wifiManager?.createMulticastLock("MeshTalkMulticastLock")?.apply {
                setReferenceCounted(true)
                acquire()
            }
        } catch (_: Exception) {}
    }

    private fun startTcpServer() {
        scope.launch {
            try {
                tcpServerSocket = ServerSocket(TCP_PORT).apply {
                    reuseAddress = true
                }
                _radioStatus.value = RadioStatus.Active(connectedPeersCount = peerAddressMap.size)

                while (isActive && tcpServerSocket?.isClosed == false) {
                    val clientSocket = tcpServerSocket?.accept() ?: break
                    val clientIp = clientSocket.inetAddress?.hostAddress ?: continue
                    activeTcpSockets[clientIp] = clientSocket

                    scope.launch {
                        handleIncomingTcpStream(clientSocket, clientIp)
                    }
                }
            } catch (_: Exception) {
                // Server socket closed
            }
        }
    }

    private suspend fun handleIncomingTcpStream(socket: Socket, peerIp: String) = withContext(Dispatchers.IO) {
        try {
            val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
            while (isActive && socket.isConnected && !socket.isClosed) {
                val line = reader.readLine() ?: break
                val packet = PacketCodec.deserialize(line)
                if (packet != null) {
                    registerPeerFromPacket(packet, peerIp)
                    _incomingPackets.emit(packet)
                }
            }
        } catch (_: Exception) {
            // Socket disconnected
        } finally {
            activeTcpSockets.remove(peerIp)
        }
    }

    private fun startUdpDiscoveryListener() {
        scope.launch {
            try {
                udpSocket = DatagramSocket(null).apply {
                    reuseAddress = true
                    bind(InetSocketAddress(UDP_DISCOVERY_PORT))
                    broadcast = true
                }
                val buffer = ByteArray(8192)

                while (isActive && udpSocket?.isClosed == false) {
                    val datagram = DatagramPacket(buffer, buffer.size)
                    udpSocket?.receive(datagram)

                    val senderIp = datagram.address?.hostAddress ?: continue
                    val myIps = getAllLocalIpAddresses()
                    if (myIps.contains(senderIp)) continue // Ignore own loopback datagrams

                    val jsonStr = String(datagram.data, 0, datagram.length, Charsets.UTF_8)
                    val packet = PacketCodec.deserialize(jsonStr)
                    if (packet != null) {
                        registerPeerFromPacket(packet, senderIp)
                        _incomingPackets.emit(packet)

                        // Attempt asynchronous TCP connection back to sender for dual-link
                        scope.launch {
                            connectToIp(senderIp)
                        }
                    }
                }
            } catch (_: Exception) {
                // UDP socket closed
            }
        }
    }

    private fun startPeriodicDiscoveryBeacon() {
        scope.launch {
            while (isActive) {
                discoverPeers()
                delay(3000) // Broadcast discovery presence every 3 seconds
            }
        }
    }

    private fun registerPeerFromPacket(packet: MeshPacket, peerIp: String) {
        val myNodeId = cryptoEngine.getOrCreateNodeId()
        if (packet.senderNodeId == myNodeId) return

        val peer = MeshPeer(
            nodeId = packet.senderNodeId,
            displayName = packet.senderDisplayName.ifBlank { "Node " + packet.senderNodeId.takeLast(4) },
            publicKeyBase64 = packet.senderEphemeralPubKey,
            transport = TransportProtocol.WIFI_DIRECT,
            address = peerIp,
            port = TCP_PORT,
            isConnected = true,
            hopDistance = packet.hopCount
        )

        peerAddressMap[packet.senderNodeId] = peer
        peerAddressMap[peerIp] = peer

        _discoveredPeers.value = peerAddressMap.values.distinctBy { it.nodeId }
        _radioStatus.value = RadioStatus.Active(connectedPeersCount = _discoveredPeers.value.size)
    }

    override suspend fun discoverPeers() = withContext(Dispatchers.IO) {
        val myNodeId = cryptoEngine.getOrCreateNodeId()
        val myName = cryptoEngine.getDisplayName()
        val myPubKey = cryptoEngine.getPublicKeyBase64()

        val announcePacket = MeshPacket(
            senderNodeId = myNodeId,
            senderDisplayName = myName,
            recipientNodeId = MeshPacket.BROADCAST_RECIPIENT,
            type = PacketType.NODE_ANNOUNCE,
            senderEphemeralPubKey = myPubKey,
            hopCount = 1,
            maxTtl = 2,
            routeTrace = listOf(myNodeId)
        )

        val jsonBytes = PacketCodec.serialize(announcePacket).toByteArray(Charsets.UTF_8)
        val broadcastAddresses = getAllBroadcastAddresses()

        for (addr in broadcastAddresses) {
            try {
                val s = DatagramSocket()
                s.broadcast = true
                val packet = DatagramPacket(jsonBytes, jsonBytes.size, addr, UDP_DISCOVERY_PORT)
                s.send(packet)
                s.close()
            } catch (_: Exception) {}
        }
    }

    override suspend fun connectToPeer(peer: MeshPeer): Result<Unit> = withContext(Dispatchers.IO) {
        if (peer.address.isBlank()) return@withContext Result.failure(Exception("Peer IP unknown"))
        connectToIp(peer.address)
    }

    suspend fun connectToIp(ip: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            if (activeTcpSockets.containsKey(ip)) {
                return@withContext Result.success(Unit)
            }
            val socket = Socket()
            socket.connect(InetSocketAddress(ip, TCP_PORT), SOCKET_TIMEOUT_MS)
            activeTcpSockets[ip] = socket

            scope.launch {
                handleIncomingTcpStream(socket, ip)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun disconnectFromPeer(peer: MeshPeer) {
        activeTcpSockets.remove(peer.address)?.close()
    }

    override suspend fun broadcastPacket(packet: MeshPacket): Result<Int> = withContext(Dispatchers.IO) {
        val serialized = PacketCodec.serialize(packet)
        val bytes = serialized.toByteArray(Charsets.UTF_8)
        var count = 0

        // 1. Send via TCP to all active sockets and registered peer IPs
        val targetIps = mutableSetOf<String>()
        activeTcpSockets.keys.forEach { targetIps.add(it) }
        peerAddressMap.values.forEach { if (it.address.isNotBlank()) targetIps.add(it.address) }

        for (ip in targetIps) {
            try {
                var socket = activeTcpSockets[ip]
                if (socket == null || socket.isClosed || !socket.isConnected) {
                    socket = Socket()
                    socket.connect(InetSocketAddress(ip, TCP_PORT), SOCKET_TIMEOUT_MS)
                    activeTcpSockets[ip] = socket
                    val connectedSocket = socket
                    scope.launch {
                        handleIncomingTcpStream(connectedSocket, ip)
                    }
                }
                val writer = PrintWriter(socket.getOutputStream(), true)
                writer.println(serialized)
                count++
            } catch (_: Exception) {
                activeTcpSockets.remove(ip)
            }
        }

        // 2. Dual Broadcast via UDP to all active subnet broadcast addresses
        val broadcastAddresses = getAllBroadcastAddresses()
        for (addr in broadcastAddresses) {
            try {
                val s = DatagramSocket()
                s.broadcast = true
                val udpPkt = DatagramPacket(bytes, bytes.size, addr, UDP_DISCOVERY_PORT)
                s.send(udpPkt)
                s.close()
                count++
            } catch (_: Exception) {}
        }

        Result.success(count)
    }

    override fun observeIncomingPackets(): Flow<MeshPacket> {
        return _incomingPackets.asSharedFlow()
    }

    /**
     * Resolves all broadcast targets dynamically from all active network interfaces.
     */
    private fun getAllBroadcastAddresses(): Set<InetAddress> {
        val addresses = mutableSetOf<InetAddress>()
        try {
            // Global standard broadcast
            addresses.add(InetAddress.getByName("255.255.255.255"))
            addresses.add(InetAddress.getByName(MULTICAST_GROUP_IP))
            // Common default hotspots & subnets
            addresses.add(InetAddress.getByName("192.168.43.255")) // Android AP
            addresses.add(InetAddress.getByName("192.168.49.255")) // Wi-Fi Direct
            addresses.add(InetAddress.getByName("172.20.10.255"))  // Hotspot AP
            addresses.add(InetAddress.getByName("192.168.1.255"))
            addresses.add(InetAddress.getByName("192.168.0.255"))
            addresses.add(InetAddress.getByName("10.0.0.255"))

            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                if (networkInterface.isLoopback || !networkInterface.isUp) continue

                for (interfaceAddress in networkInterface.interfaceAddresses) {
                    val broadcast = interfaceAddress.broadcast
                    if (broadcast != null) {
                        addresses.add(broadcast)
                    }
                }
            }
        } catch (_: Exception) {}
        return addresses
    }

    fun getPrimaryLocalIpAddress(): String {
        return getAllLocalIpAddresses().firstOrNull() ?: "127.0.0.1"
    }

    private fun getAllLocalIpAddresses(): Set<String> {
        val ips = mutableSetOf<String>()
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                if (networkInterface.isLoopback || !networkInterface.isUp) continue

                val addrs = networkInterface.inetAddresses
                while (addrs.hasMoreElements()) {
                    val addr = addrs.nextElement()
                    if (!addr.isLoopbackAddress && addr.hostAddress != null) {
                        val host = addr.hostAddress ?: continue
                        if (!host.contains(":")) { // IPv4
                            ips.add(host)
                        }
                    }
                }
            }
        } catch (_: Exception) {}
        return ips
    }
}
