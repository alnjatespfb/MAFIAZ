package com.example.ui.screens.main

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.crypto.CryptoEngine
import com.example.data.model.Conversation
import com.example.data.model.DeviceIdentity
import com.example.data.model.MeshPeer
import com.example.mesh.MeshRouter
import com.example.transport.RadioStatus
import com.example.transport.TransportManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class MainNavTab {
    PEERS,
    CHATS,
    SETTINGS
}

data class MainScreenUiState(
    val currentTab: MainNavTab = MainNavTab.PEERS,
    val isScanning: Boolean = false,
    val searchQuery: String = "",
    val isAddDirectPeerDialogOpen: Boolean = false,
    val isDirectIpDialogOpen: Boolean = false,
    val selectedPeerForAction: MeshPeer? = null
)

class MainViewModel(
    private val cryptoEngine: CryptoEngine,
    private val transportManager: TransportManager,
    private val meshRouter: MeshRouter
) : ViewModel() {

    private val _uiState = MutableStateFlow(MainScreenUiState())
    val uiState: StateFlow<MainScreenUiState> = _uiState.asStateFlow()

    val discoveredPeers: StateFlow<List<MeshPeer>> = transportManager.allDiscoveredPeers
    val conversations: StateFlow<List<Conversation>> = meshRouter.getAllConversations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingOutboxCount: StateFlow<Int> = meshRouter.getPendingOutboxCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val wifiDirectStatus: StateFlow<RadioStatus> = transportManager.wifiDirectTransport.radioStatus
    val wifiAwareStatus: StateFlow<RadioStatus> = transportManager.wifiAwareTransport.radioStatus
    val bleStatus: StateFlow<RadioStatus> = transportManager.bleTransport.radioStatus

    fun selectTab(tab: MainNavTab) {
        _uiState.update { it.copy(currentTab = tab) }
        if (tab == MainNavTab.PEERS) {
            discoverPeers()
        }
    }

    fun discoverPeers() {
        _uiState.update { it.copy(isScanning = true) }
        viewModelScope.launch {
            transportManager.discoverAllPeers()
            kotlinx.coroutines.delay(1200)
            _uiState.update { it.copy(isScanning = false) }
        }
    }

    fun connectToPeer(peer: MeshPeer) {
        viewModelScope.launch {
            transportManager.localNetworkTransport.connectToPeer(peer)
            transportManager.wifiDirectTransport.connectToPeer(peer)
        }
    }

    fun connectToDirectIp(ip: String, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch {
            val result = transportManager.localNetworkTransport.connectToIp(ip.trim())
            transportManager.broadcastPresenceAnnounce()
            onComplete(result.isSuccess)
        }
    }

    fun openChatWithPeer(peer: MeshPeer, onOpened: (String) -> Unit) {
        viewModelScope.launch {
            val conv = meshRouter.getOrCreateConversation(
                peerNodeId = peer.nodeId,
                peerDisplayName = peer.displayName,
                peerPublicKeyBase64 = peer.publicKeyBase64
            )
            onOpened(conv.id)
        }
    }

    fun startDirectChat(nodeIdOrHandle: String, displayName: String, onOpened: (String) -> Unit) {
        viewModelScope.launch {
            val cleanId = nodeIdOrHandle.trim().removePrefix("@")
            val cleanName = displayName.trim().ifBlank { cleanId }

            // Check if this peer was already discovered on network
            val knownPeer = discoveredPeers.value.firstOrNull {
                it.nodeId.equals(cleanId, ignoreCase = true) ||
                it.displayName.equals(cleanId, ignoreCase = true)
            }

            val conv = meshRouter.getOrCreateConversation(
                peerNodeId = knownPeer?.nodeId ?: cleanId,
                peerDisplayName = knownPeer?.displayName ?: cleanName,
                peerPublicKeyBase64 = knownPeer?.publicKeyBase64 ?: ""
            )
            _uiState.update { it.copy(isAddDirectPeerDialogOpen = false) }
            onOpened(conv.id)
        }
    }

    fun setAddDirectPeerDialogVisible(visible: Boolean) {
        _uiState.update { it.copy(isAddDirectPeerDialogOpen = visible) }
    }

    fun setDirectIpDialogVisible(visible: Boolean) {
        _uiState.update { it.copy(isDirectIpDialogOpen = visible) }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun deleteConversation(conversationId: String) {
        viewModelScope.launch {
            meshRouter.deleteConversation(conversationId)
        }
    }

    fun getLocalDeviceIdentity(): DeviceIdentity {
        val id = cryptoEngine.getOrCreateNodeId()
        val name = cryptoEngine.getDisplayName()
        val pubKey = cryptoEngine.getPublicKeyBase64()
        val fp = cryptoEngine.computeKeyFingerprint(pubKey)
        return DeviceIdentity(
            nodeId = id,
            displayName = name,
            publicKeyBase64 = pubKey,
            keyFingerprint = fp
        )
    }

    fun getPrimaryLocalIpAddress(): String {
        return transportManager.localNetworkTransport.getPrimaryLocalIpAddress()
    }

    fun getShareableIdentityText(): String {
        return cryptoEngine.getShareableIdentityText()
    }

    fun updateDeviceDisplayName(name: String) {
        cryptoEngine.setDisplayName(name)
        viewModelScope.launch {
            transportManager.broadcastPresenceAnnounce()
        }
    }
}
