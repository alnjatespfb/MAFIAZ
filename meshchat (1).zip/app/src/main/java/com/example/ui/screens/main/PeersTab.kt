package com.example.ui.screens.main

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Lan
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DeviceIdentity
import com.example.data.model.MeshPeer
import com.example.ui.components.NodeAvatar
import com.example.ui.components.TransportBadge
import com.example.ui.theme.CyanMesh
import com.example.ui.theme.EmeraldConnected

@Composable
fun PeersTab(
    peers: List<MeshPeer>,
    deviceIdentity: DeviceIdentity,
    localIpAddress: String,
    shareableIdentityText: String,
    isScanning: Boolean,
    onScanRequested: () -> Unit,
    onPeerConnect: (MeshPeer) -> Unit,
    onPeerMessage: (MeshPeer) -> Unit,
    onAddManualPeer: () -> Unit,
    onConnectDirectIp: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var showHowItWorksDialog by remember { mutableStateOf(false) }

    if (showHowItWorksDialog) {
        AlertDialog(
            onDismissRequest = { showHowItWorksDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Sensors,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("كيف يعمل بدون إنترنت أو راوتر؟", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "التطبيق يعمل بتقنية الشبكة المباشرة (Mesh P2P) من هاتف إلى هاتف مباشرة بدون خوادم، ولا يتطلب وجود إنترنت أو راوتر منزلي نهائياً!",
                        style = MaterialTheme.typography.bodySmall,
                        lineHeight = 19.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.Top) {
                                Icon(Icons.Default.Bluetooth, contentDescription = null, tint = CyanMesh, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("1. البلوتوث المباشر (Bluetooth BLE)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                    Text("يعمل حتى لو كان الواي فاي مغلقاً تماماً ولا توجد أي شبكة، عبر راديو البلوتوث المباشر.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Row(verticalAlignment = Alignment.Top) {
                                Icon(Icons.Default.Wifi, contentDescription = null, tint = EmeraldConnected, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("2. واي فاي مباشر (Wi-Fi Direct P2P)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                    Text("يربط الهاتفين ببعضهما بسرعة عالية دون راوتر ودون إنترنت (فقط يحتاج تشغيل زر الواي فاي في الهاتف لتفعيل الراديو).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Row(verticalAlignment = Alignment.Top) {
                                Icon(Icons.Default.Lan, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("3. نقطة اتصال اختيارية (Hotspot)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                    Text("يمكن فتح نقطة اتصال من أحد الهاتفين دون الحاجة لباقة إنترنت لتغطية مسافات أكبر وسرعة قصوى.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }

                    Text(
                        text = "ملاحظة: طلب أندرويد لإذن 'أجهزة الواي فاي المجاورة' هو إذن نظامي خاص بـ Wi-Fi Direct لربط الهاتفين ببعضهما، ولا يعني أبداً الحاجة لشبكة واي فاي منزلية.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 16.sp
                    )
                }
            },
            confirmButton = {
                Button(onClick = { showHowItWorksDialog = false }) {
                    Text("فهمت ذلك")
                }
            }
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Nearby Mesh Peers",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "100% Offline • Bluetooth BLE & Wi-Fi Direct P2P",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = { showHowItWorksDialog = true },
                        modifier = Modifier.testTag("offline_help_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.HelpOutline,
                            contentDescription = "Offline Info",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    IconButton(
                        onClick = onConnectDirectIp,
                        modifier = Modifier.testTag("direct_ip_button")
                    ) {
                        Icon(Icons.Default.Lan, contentDescription = "Connect by IP", tint = MaterialTheme.colorScheme.primary)
                    }

                    IconButton(
                        onClick = onScanRequested,
                        enabled = !isScanning,
                        modifier = Modifier.testTag("scan_peers_button")
                    ) {
                        if (isScanning) {
                            CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.Refresh, contentDescription = "Scan Radios", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // User's own Mesh Identity Banner with Copy & Share
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            NodeAvatar(name = deviceIdentity.displayName, size = 38.dp, isOnline = true)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "My Handle: @${deviceIdentity.displayName}",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                val statusText = if (localIpAddress == "127.0.0.1" || localIpAddress.isBlank()) {
                                    "ID: ${deviceIdentity.nodeId} • Bluetooth Direct Ready"
                                } else {
                                    "ID: ${deviceIdentity.nodeId} • Subnet: $localIpAddress"
                                }
                                Text(
                                    text = statusText,
                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(shareableIdentityText))
                                    Toast.makeText(context, "Copied your Mesh ID to clipboard!", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier
                                    .size(32.dp)
                                    .testTag("copy_my_id_icon_button")
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy ID", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                            }

                            IconButton(
                                onClick = {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_SUBJECT, "Add me on MeshTalk")
                                        putExtra(Intent.EXTRA_TEXT, shareableIdentityText)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Share MeshTalk ID"))
                                },
                                modifier = Modifier
                                    .size(32.dp)
                                    .testTag("share_my_id_icon_button")
                            ) {
                                Icon(Icons.Default.Share, contentDescription = "Share ID", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (peers.isEmpty()) {
                EmptyPeersState(
                    onScan = onScanRequested,
                    isScanning = isScanning,
                    onAddFriend = onAddManualPeer,
                    onHowItWorks = { showHowItWorksDialog = true }
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 88.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(peers, key = { it.nodeId + it.transport.name }) { peer ->
                        PeerCard(
                            peer = peer,
                            onConnect = { onPeerConnect(peer) },
                            onMessage = { onPeerMessage(peer) }
                        )
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = onAddManualPeer,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 80.dp, end = 16.dp)
                .testTag("add_peer_fab"),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "Add Peer by ID")
        }
    }
}

@Composable
private fun PeerCard(
    peer: MeshPeer,
    onConnect: () -> Unit,
    onMessage: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onMessage() }
            .testTag("peer_card_${peer.nodeId}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                NodeAvatar(name = peer.displayName, size = 48.dp, isOnline = peer.isConnected)

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = peer.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "ID: ${peer.nodeId}${if (peer.address.isNotBlank() && !peer.address.startsWith("127.")) " • " + peer.address else ""}",
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                ) {
                    Text(
                        text = if (peer.hopDistance <= 1) "Direct Link" else "${peer.hopDistance} Hops",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TransportBadge(protocol = peer.transport)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!peer.isConnected) {
                        OutlinedButton(
                            onClick = onConnect,
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("connect_peer_button_${peer.nodeId}")
                        ) {
                            Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Connect", style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    Button(
                        onClick = onMessage,
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("chat_peer_button_${peer.nodeId}")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Chat", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyPeersState(
    onScan: () -> Unit,
    isScanning: Boolean,
    onAddFriend: () -> Unit,
    onHowItWorks: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Sensors,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "شبكة Mesh المباشرة بدون إنترنت",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "يعمل بالكامل بدون نت وبدون راوتر عبر راديو الهاتف المباشر",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Quick Tutorial Box
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldConnected, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "طرق الاتصال المباشر المتاحة:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Text(
                    text = "• عبر البلوتوث المباشر (Bluetooth BLE): فعّل البلوتوث على كلا الجهازين واضغط على 'Scan Mesh'.\n• أو عبر Wi-Fi Direct: اتصال مباشر P2P بين الهاتفين بدون راوتر وبدون نت.\n• أو عبر نقطة اتصال (Hotspot) من أحد الهاتفين لمسافات أكبر وسرعة قصوى.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )

                TextButton(
                    onClick = onHowItWorks,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("تفاصيل أكثر عن طريقة العمل", fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = onScan,
                enabled = !isScanning,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("empty_scan_button")
            ) {
                if (isScanning) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("جارِ الفحص...")
                } else {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Scan Mesh")
                }
            }

            OutlinedButton(
                onClick = onAddFriend,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("empty_add_friend_by_id_button")
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Friend's Handle")
            }
        }
    }
}
