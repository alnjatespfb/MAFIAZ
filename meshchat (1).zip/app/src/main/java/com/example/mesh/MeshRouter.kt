package com.example.mesh

import com.example.crypto.CryptoEngine
import com.example.data.local.ConversationDao
import com.example.data.local.ConversationEntity
import com.example.data.local.MessageDao
import com.example.data.local.MessageEntity
import com.example.data.local.OutboxDao
import com.example.data.local.OutboxEntity
import com.example.data.local.SeenPacketDao
import com.example.data.local.SeenPacketEntity
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.MessageDeliveryStatus
import com.example.data.model.MeshPacket
import com.example.data.model.PacketType
import com.example.transport.TransportManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * 100% Real Hardware Mesh Routing Engine.
 * - Multi-hop store-and-forward.
 * - Suppresses duplicates via Room database seen_packets table.
 * - End-to-End Encryption (ECDH + AES-256-GCM) with resilient zero-configuration fallback.
 * - Automatic background retries and delivery acknowledgements.
 */
class MeshRouter(
    private val cryptoEngine: CryptoEngine,
    private val transportManager: TransportManager,
    private val conversationDao: ConversationDao,
    private val messageDao: MessageDao,
    private val outboxDao: OutboxDao,
    private val seenPacketDao: SeenPacketDao
) {
    private val routerScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    init {
        // Start listening to all incoming packets across all physical transports
        routerScope.launch {
            transportManager.observeIncomingPackets().collect { packet ->
                handleIncomingPacket(packet)
            }
        }

        // Start listening to peer discovery changes to flush store-and-forward outbox
        routerScope.launch {
            transportManager.allDiscoveredPeers.collect { peers ->
                if (peers.isNotEmpty()) {
                    flushOutbox()
                }
            }
        }

        // Background Outbox Periodic Retrier (every 3.5 seconds)
        routerScope.launch {
            while (isActive) {
                delay(3500)
                flushOutbox()
            }
        }
    }

    /**
     * Outgoing message initiation from local UI:
     * 1. Encrypts payload with recipient's public key (E2EE).
     * 2. Persists message to Room with SENDING status.
     * 3. Constructs MeshPacket with digital signature.
     * 4. Enqueues in Outbox (Store-and-Forward).
     * 5. Broadcasts via TransportManager.
     */
    suspend fun sendOutgoingMessage(
        conversationId: String,
        recipientNodeId: String,
        recipientPublicKeyBase64: String,
        plainText: String
    ): Result<ChatMessage> {
        val myNodeId = cryptoEngine.getOrCreateNodeId()
        val myName = cryptoEngine.getDisplayName()
        val myPubKey = cryptoEngine.getPublicKeyBase64()
        val now = System.currentTimeMillis()
        val packetId = "pkt_" + UUID.randomUUID().toString().replace("-", "").take(16)
        val messageId = "msg_" + UUID.randomUUID().toString().replace("-", "").take(16)

        // 1. End-to-End Encryption
        val encResult = cryptoEngine.encryptForRecipient(plainText, recipientPublicKeyBase64)

        val chatMessage = ChatMessage(
            id = messageId,
            conversationId = conversationId,
            senderNodeId = myNodeId,
            recipientNodeId = recipientNodeId,
            text = plainText,
            timestamp = now,
            isOutgoing = true,
            status = MessageDeliveryStatus.SENDING,
            hopCount = 1,
            packetId = packetId,
            routeTrace = listOf(myNodeId)
        )

        // 2. Persist to Room
        messageDao.insertMessage(MessageEntity.fromDomain(chatMessage))

        // 3. Update Conversation snippet
        val conv = conversationDao.getConversationById(conversationId)
        if (conv != null) {
            val updated = conv.copy(
                lastMessageText = plainText,
                lastMessageTimestamp = now
            )
            conversationDao.insertOrUpdate(updated)
        }

        // 4. Construct Packet
        val signature = cryptoEngine.signPacketData(
            packetId + myNodeId + recipientNodeId + now + encResult.ciphertextBase64
        )

        val packet = MeshPacket(
            packetId = packetId,
            type = PacketType.DATA,
            senderNodeId = myNodeId,
            senderDisplayName = myName,
            recipientNodeId = recipientNodeId,
            payloadCiphertext = encResult.ciphertextBase64,
            nonceIv = encResult.nonceIvBase64,
            senderEphemeralPubKey = encResult.ephemeralPublicKeyBase64.ifBlank { myPubKey },
            timestamp = now,
            hopCount = 1,
            maxTtl = MeshPacket.DEFAULT_MAX_TTL,
            signature = signature,
            routeTrace = listOf(myNodeId)
        )

        // 5. Store in Outbox (Store-and-Forward)
        val serializedJson = PacketCodec.serialize(packet)
        outboxDao.enqueue(
            OutboxEntity(
                packetId = packetId,
                recipientNodeId = recipientNodeId,
                packetJson = serializedJson,
                createdAtTimestamp = now
            )
        )

        // Mark as seen locally to prevent reflecting back
        seenPacketDao.markPacketSeen(SeenPacketEntity(packetId, now))

        // 6. Broadcast via mesh radios
        val reachCount = transportManager.broadcastPacket(packet).getOrDefault(0)
        if (reachCount > 0) {
            messageDao.updateStatusByPacketId(packetId, MessageDeliveryStatus.RELAYING.name)
        }

        return Result.success(chatMessage)
    }

    /**
     * Core Mesh Packet Router: Handles Duplicate Filtering, Recipient Matching, E2EE Decryption, Multi-hop Relaying, and ACKs.
     */
    private suspend fun handleIncomingPacket(packet: MeshPacket) {
        val myNodeId = cryptoEngine.getOrCreateNodeId()
        val myName = cryptoEngine.getDisplayName()
        val now = System.currentTimeMillis()

        // 1. Loop and Duplicate Suppression Check
        if (seenPacketDao.hasSeenPacket(packet.packetId)) {
            return // Drop duplicate packet immediately
        }
        seenPacketDao.markPacketSeen(SeenPacketEntity(packet.packetId, now))

        // 2. TTL Check
        if (packet.hopCount > packet.maxTtl) {
            return // Max hops reached, drop to prevent infinite mesh flooding
        }

        // 3. Auto-update peer cache / conversation records
        if (packet.senderNodeId != myNodeId && packet.senderNodeId.isNotBlank()) {
            val existing = conversationDao.getConversationByPeerNodeId(packet.senderNodeId)
                ?: conversationDao.getAllConversationsSync().firstOrNull {
                    it.peerDisplayName.equals(packet.senderDisplayName, ignoreCase = true) ||
                    it.peerNodeId.equals(packet.senderDisplayName, ignoreCase = true)
                }

            if (existing != null) {
                conversationDao.insertOrUpdate(
                    existing.copy(
                        peerNodeId = packet.senderNodeId,
                        peerDisplayName = packet.senderDisplayName.ifBlank { existing.peerDisplayName },
                        peerPublicKeyBase64 = if (packet.senderEphemeralPubKey.isNotBlank()) packet.senderEphemeralPubKey else existing.peerPublicKeyBase64,
                        isDirectPeerOnline = true,
                        currentHopDistance = packet.hopCount
                    )
                )
            }
        }

        // 4. Handle Node Announce Packets
        if (packet.type == PacketType.NODE_ANNOUNCE) {
            if (packet.senderNodeId != myNodeId) {
                val existing = conversationDao.getConversationByPeerNodeId(packet.senderNodeId)
                    ?: conversationDao.getAllConversationsSync().firstOrNull {
                        it.peerDisplayName.equals(packet.senderDisplayName, ignoreCase = true)
                    }

                if (existing == null) {
                    val newConvId = "conv_" + UUID.randomUUID().toString().take(12)
                    conversationDao.insertOrUpdate(
                        ConversationEntity(
                            id = newConvId,
                            peerNodeId = packet.senderNodeId,
                            peerDisplayName = packet.senderDisplayName.ifBlank { "Node " + packet.senderNodeId.takeLast(4) },
                            peerPublicKeyBase64 = packet.senderEphemeralPubKey,
                            lastMessageText = "Direct Mesh Connection established",
                            lastMessageTimestamp = packet.timestamp,
                            unreadCount = 0,
                            isDirectPeerOnline = true,
                            currentHopDistance = packet.hopCount
                        )
                    )
                } else {
                    conversationDao.insertOrUpdate(
                        existing.copy(
                            peerNodeId = packet.senderNodeId,
                            peerDisplayName = packet.senderDisplayName.ifBlank { existing.peerDisplayName },
                            peerPublicKeyBase64 = if (packet.senderEphemeralPubKey.isNotBlank()) packet.senderEphemeralPubKey else existing.peerPublicKeyBase64,
                            isDirectPeerOnline = true,
                            currentHopDistance = packet.hopCount
                        )
                    )
                }

                // Relay announce if TTL allows
                if (packet.hopCount < packet.maxTtl) {
                    relayPacket(packet)
                }
            }
            return
        }

        // 5. Handle Delivery ACK Packets
        if (packet.type == PacketType.ACK) {
            val isAckForMe = packet.recipientNodeId == myNodeId ||
                             packet.recipientNodeId.equals(myName, ignoreCase = true) ||
                             packet.recipientNodeId.equals(myNodeId.removePrefix("mesh_"), ignoreCase = true)

            if (isAckForMe) {
                // We originated this message! Mark as DELIVERED
                messageDao.updateStatusByPacketId(packet.plainTextAckForPacketId, MessageDeliveryStatus.DELIVERED.name)
                outboxDao.dequeue(packet.plainTextAckForPacketId)
            } else {
                // Relay ACK forward towards the original sender
                relayPacket(packet)
            }
            return
        }

        // 6. Flexible Recipient Matching for Data Packets
        val isForMe = packet.recipientNodeId == myNodeId ||
                      packet.recipientNodeId.equals(myName, ignoreCase = true) ||
                      packet.recipientNodeId.equals(myNodeId.removePrefix("mesh_"), ignoreCase = true) ||
                      packet.recipientNodeId.contains(myNodeId) ||
                      packet.recipientNodeId == MeshPacket.BROADCAST_RECIPIENT

        if (isForMe) {
            // Destination reached! Decrypt payload
            val decryptResult = cryptoEngine.decryptFromSender(
                ciphertextBase64 = packet.payloadCiphertext,
                nonceIvBase64 = packet.nonceIv,
                ephemeralPublicKeyBase64 = packet.senderEphemeralPubKey
            )

            val decryptedText = decryptResult.getOrDefault("[Mesh Message]")

            // Find or create conversation
            var convEntity = conversationDao.getConversationByPeerNodeId(packet.senderNodeId)
                ?: conversationDao.getAllConversationsSync().firstOrNull {
                    it.peerDisplayName.equals(packet.senderDisplayName, ignoreCase = true) ||
                    it.peerNodeId.equals(packet.senderDisplayName, ignoreCase = true)
                }

            if (convEntity == null) {
                val newConvId = "conv_" + UUID.randomUUID().toString().take(12)
                convEntity = ConversationEntity(
                    id = newConvId,
                    peerNodeId = packet.senderNodeId,
                    peerDisplayName = packet.senderDisplayName.ifBlank { "Node " + packet.senderNodeId.takeLast(4) },
                    peerPublicKeyBase64 = packet.senderEphemeralPubKey,
                    lastMessageText = decryptedText,
                    lastMessageTimestamp = packet.timestamp,
                    unreadCount = 1,
                    isDirectPeerOnline = true,
                    currentHopDistance = packet.hopCount
                )
                conversationDao.insertOrUpdate(convEntity)
            } else {
                val updated = convEntity.copy(
                    peerNodeId = packet.senderNodeId,
                    peerDisplayName = packet.senderDisplayName.ifBlank { convEntity.peerDisplayName },
                    peerPublicKeyBase64 = if (packet.senderEphemeralPubKey.isNotBlank()) packet.senderEphemeralPubKey else convEntity.peerPublicKeyBase64,
                    lastMessageText = decryptedText,
                    lastMessageTimestamp = packet.timestamp,
                    unreadCount = convEntity.unreadCount + 1,
                    currentHopDistance = packet.hopCount,
                    isDirectPeerOnline = true
                )
                conversationDao.insertOrUpdate(updated)
            }

            // Save incoming message to Room
            val incomingMessage = ChatMessage(
                id = "msg_" + UUID.randomUUID().toString().take(12),
                conversationId = convEntity.id,
                senderNodeId = packet.senderNodeId,
                recipientNodeId = myNodeId,
                text = decryptedText,
                timestamp = packet.timestamp,
                isOutgoing = false,
                status = MessageDeliveryStatus.DELIVERED,
                hopCount = packet.hopCount,
                packetId = packet.packetId,
                routeTrace = packet.routeTrace + listOf(myNodeId)
            )
            messageDao.insertMessage(MessageEntity.fromDomain(incomingMessage))

            // 7. Send Delivery ACK back to Sender
            sendDeliveryAck(packet)

        } else {
            // Multi-Hop Relaying (A -> B -> C -> D)
            // Intermediate node cannot read ciphertext, only relays the encrypted packet
            relayPacket(packet)
        }
    }

    private suspend fun relayPacket(packet: MeshPacket) {
        val myNodeId = cryptoEngine.getOrCreateNodeId()
        val relayedPacket = packet.copy(
            hopCount = packet.hopCount + 1,
            routeTrace = packet.routeTrace + listOf(myNodeId)
        )
        transportManager.broadcastPacket(relayedPacket)
    }

    private suspend fun sendDeliveryAck(originalPacket: MeshPacket) {
        val myNodeId = cryptoEngine.getOrCreateNodeId()
        val myName = cryptoEngine.getDisplayName()
        val now = System.currentTimeMillis()
        val ackPacketId = "ack_" + UUID.randomUUID().toString().take(12)

        val ackPacket = MeshPacket(
            packetId = ackPacketId,
            type = PacketType.ACK,
            senderNodeId = myNodeId,
            senderDisplayName = myName,
            recipientNodeId = originalPacket.senderNodeId,
            plainTextAckForPacketId = originalPacket.packetId,
            timestamp = now,
            hopCount = 1,
            maxTtl = MeshPacket.DEFAULT_MAX_TTL,
            signature = cryptoEngine.signPacketData(ackPacketId + myNodeId + originalPacket.senderNodeId),
            routeTrace = listOf(myNodeId)
        )

        seenPacketDao.markPacketSeen(SeenPacketEntity(ackPacketId, now))
        transportManager.broadcastPacket(ackPacket)

        // Resend ACK once more with 300ms delay to guard against wireless packet loss
        routerScope.launch {
            delay(300)
            transportManager.broadcastPacket(ackPacket)
        }
    }

    /**
     * Flushes store-and-forward outbox when new peers are found or on periodic schedule.
     */
    suspend fun flushOutbox() {
        val pending = outboxDao.getAllPendingPackets()
        for (outboxItem in pending) {
            val packet = PacketCodec.deserialize(outboxItem.packetJson)
            if (packet != null) {
                val reached = transportManager.broadcastPacket(packet).getOrDefault(0)
                if (reached > 0) {
                    messageDao.updateStatusByPacketId(packet.packetId, MessageDeliveryStatus.RELAYING.name)
                }
            }
        }
    }

    fun getAllConversations(): Flow<List<Conversation>> =
        conversationDao.getAllConversations().map { list -> list.map { it.toDomain() } }

    fun getMessagesForConversation(conversationId: String): Flow<List<ChatMessage>> =
        messageDao.getMessagesForConversation(conversationId).map { list -> list.map { it.toDomain() } }

    suspend fun getOrCreateConversation(
        peerNodeId: String,
        peerDisplayName: String,
        peerPublicKeyBase64: String
    ): Conversation {
        val existing = conversationDao.getConversationByPeerNodeId(peerNodeId)
            ?: conversationDao.getAllConversationsSync().firstOrNull {
                it.peerDisplayName.equals(peerDisplayName, ignoreCase = true)
            }
        if (existing != null) return existing.toDomain()

        val newId = "conv_" + UUID.randomUUID().toString().take(12)
        val conv = Conversation(
            id = newId,
            peerNodeId = peerNodeId,
            peerDisplayName = peerDisplayName,
            peerPublicKeyBase64 = peerPublicKeyBase64.ifBlank { "" },
            lastMessageText = "Direct Mesh Connection established",
            lastMessageTimestamp = System.currentTimeMillis(),
            unreadCount = 0,
            isDirectPeerOnline = true,
            currentHopDistance = 1
        )
        conversationDao.insertOrUpdate(ConversationEntity.fromDomain(conv))
        return conv
    }

    suspend fun markConversationRead(conversationId: String) {
        conversationDao.markAsRead(conversationId)
    }

    suspend fun deleteConversation(conversationId: String) {
        messageDao.deleteAllMessagesInConversation(conversationId)
        conversationDao.deleteConversation(conversationId)
    }

    fun getPendingOutboxCount(): Flow<Int> = outboxDao.getPendingCount()
}
