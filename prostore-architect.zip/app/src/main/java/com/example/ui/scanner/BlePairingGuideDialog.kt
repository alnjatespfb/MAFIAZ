package com.example.ui.scanner

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bluetooth.BleConnectionState

@Composable
fun BlePairingGuideDialog(
    deviceName: String,
    connectionState: BleConnectionState,
    isAdvertising: Boolean,
    onStartBle: () -> Unit,
    onStopBle: () -> Unit,
    onDismiss: () -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    val webBluetoothSnippet = """
// CorePOS Web Bluetooth Client Snippet
const NUS_SERVICE = '6e400001-b5a3-f393-e0a9-e50e24dcca9e';
const NUS_TX_CHAR = '6e400003-b5a3-f393-e0a9-e50e24dcca9e';

async function connectCorePosScanner() {
  const device = await navigator.bluetooth.requestDevice({
    filters: [{ services: [NUS_SERVICE] }, { namePrefix: 'CorePOS' }],
    optionalServices: ['0000ffe0-0000-1000-8000-00805f9b34fb']
  });
  const server = await device.gatt.connect();
  const service = await server.getPrimaryService(NUS_SERVICE);
  const txChar = await service.getCharacteristic(NUS_TX_CHAR);
  await txChar.startNotifications();
  txChar.addEventListener('characteristicvaluechanged', (e) => {
    const text = new TextDecoder().decode(e.target.value);
    console.log('Scanned Barcode:', text.trim());
    window.onCorePosBarcodeScanned?.(text.trim());
  });
}
""".trimIndent()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    Icons.Default.Bluetooth,
                    contentDescription = null,
                    tint = Color(0xFF2979FF)
                )
                Text(
                    text = "CorePOS Web Bluetooth Bridge",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Status banner
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = when (connectionState) {
                        is BleConnectionState.Connected -> Color(0xFF00E676).copy(alpha = 0.15f)
                        is BleConnectionState.Advertising -> Color(0xFFFFD54F).copy(alpha = 0.15f)
                        is BleConnectionState.Error -> Color(0xFFFF5252).copy(alpha = 0.15f)
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = when (connectionState) {
                                is BleConnectionState.Connected -> Icons.Default.BluetoothConnected
                                is BleConnectionState.Advertising -> Icons.Default.BluetoothSearching
                                is BleConnectionState.Error -> Icons.Default.Error
                                else -> Icons.Default.BluetoothDisabled
                            },
                            contentDescription = null,
                            tint = when (connectionState) {
                                is BleConnectionState.Connected -> Color(0xFF00E676)
                                is BleConnectionState.Advertising -> Color(0xFFFFB300)
                                is BleConnectionState.Error -> Color(0xFFFF5252)
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = when (connectionState) {
                                    is BleConnectionState.Connected -> "Connected (${connectionState.deviceCount} POS Terminal)"
                                    is BleConnectionState.Advertising -> "Advertising • Ready to Pair"
                                    is BleConnectionState.Error -> connectionState.message
                                    else -> "Bluetooth Standby"
                                },
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = "Advertised Name: $deviceName",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Control Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Bluetooth GATT Server",
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Switch(
                        checked = isAdvertising || connectionState is BleConnectionState.Connected,
                        onCheckedChange = { active ->
                            if (active) onStartBle() else onStopBle()
                        },
                        modifier = Modifier.testTag("toggle_ble_advertising_switch")
                    )
                }

                Divider()

                // Instructions Step-by-Step
                Text(
                    text = "How to connect with CorePOS Web Terminal:",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelMedium
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "1. Open CorePOS Web POS in Google Chrome / Edge / Opera.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "2. Click 'Connect Wireless Scanner' or press Web Bluetooth icon in the cashier header.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "3. Select '$deviceName' from the browser Bluetooth device picker.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "4. Every scanned barcode will immediately beam into the active cart with zero latency!",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF00C853)
                    )
                }

                Divider()

                // Technical UUIDs for Integration
                Text(
                    text = "GATT Service UUIDs (Nordic UART & Serial FFE0):",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelSmall
                )

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "NUS Service: 6e400001-b5a3-f393-e0a9-e50e24dcca9e",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "TX (Notify): 6e400003-b5a3-f393-e0a9-e50e24dcca9e",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "Serial Barcode: 0000ffe0-0000-1000-8000-00805f9b34fb",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    }
                }

                Button(
                    onClick = {
                        clipboardManager.setText(AnnotatedString(webBluetoothSnippet))
                    },
                    modifier = Modifier.fillMaxWidth().testTag("copy_web_bluetooth_snippet_button")
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Copy Web Bluetooth JavaScript Snippet")
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
