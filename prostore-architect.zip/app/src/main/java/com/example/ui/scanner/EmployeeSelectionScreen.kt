package com.example.ui.scanner

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.Employee
import com.example.data.model.Role
import com.example.data.model.Store
import com.example.ui.AppViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmployeeSelectionScreen(
    store: Store,
    appViewModel: AppViewModel,
    onEmployeeUnlocked: () -> Unit,
    onSwitchStore: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val employees by appViewModel.storeEmployees.collectAsState()

    var selectedEmployeeForPin by remember { mutableStateOf<Employee?>(null) }
    var pinInput by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf<String?>(null) }
    var showAddEmployeeDialog by remember { mutableStateOf(false) }

    var newEmpName by remember { mutableStateOf("") }
    var newEmpPin by remember { mutableStateOf("") }
    var newEmpRole by remember { mutableStateOf(Role.CASHIER.name) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(store.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("Device: ${appViewModel.deviceName}", style = MaterialTheme.typography.labelSmall)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                actions = {
                    TextButton(onClick = onSwitchStore) {
                        Icon(Icons.Default.SwapHoriz, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Switch Store", color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.secondaryContainer,
                modifier = Modifier.size(68.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Badge,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Who is using this scanner?",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Select your employee profile to unlock the wireless scanner.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            if (employees.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "No Employees Registered Yet",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Create the first cashier or manager profile for ${store.name} to start scanning.",
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { showAddEmployeeDialog = true },
                            modifier = Modifier.testTag("add_first_employee_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Add Employee Profile")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(employees, key = { it.id }) { employee ->
                        Card(
                            onClick = {
                                if (employee.pin.isBlank()) {
                                    // Unlock immediately if no PIN
                                    appViewModel.verifyAndSelectEmployee(
                                        employee = employee,
                                        inputPin = "",
                                        onSuccess = onEmployeeUnlocked,
                                        onError = { /* no error */ }
                                    )
                                } else {
                                    selectedEmployeeForPin = employee
                                    pinInput = ""
                                    pinError = null
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("employee_item_${employee.id}"),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(44.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = employee.name.take(1).uppercase(),
                                                color = MaterialTheme.colorScheme.onPrimary,
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.titleMedium
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column {
                                        Text(
                                            text = employee.name,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = employee.role,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            if (employee.pin.isNotBlank()) {
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Icon(
                                                    imageVector = Icons.Default.Lock,
                                                    contentDescription = "PIN Protected",
                                                    modifier = Modifier.size(12.dp),
                                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                Text(
                                                    text = "PIN Protected",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }
                                }

                                FilledTonalButton(
                                    onClick = {
                                        if (employee.pin.isBlank()) {
                                            appViewModel.verifyAndSelectEmployee(
                                                employee = employee,
                                                inputPin = "",
                                                onSuccess = onEmployeeUnlocked,
                                                onError = {}
                                            )
                                        } else {
                                            selectedEmployeeForPin = employee
                                            pinInput = ""
                                            pinError = null
                                        }
                                    }
                                ) {
                                    Text("Select")
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = { showAddEmployeeDialog = true },
                    modifier = Modifier.fillMaxWidth().testTag("add_employee_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Add Another Employee")
                }
            }
        }
    }

    // PIN Verification Dialog
    selectedEmployeeForPin?.let { employee ->
        AlertDialog(
            onDismissRequest = { selectedEmployeeForPin = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Enter PIN for ${employee.name}", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "Please enter the 4-digit security PIN for this employee account:",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = {
                            if (it.length <= 6) {
                                pinInput = it
                                pinError = null
                            }
                        },
                        label = { Text("PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.NumberPassword,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                appViewModel.verifyAndSelectEmployee(
                                    employee = employee,
                                    inputPin = pinInput,
                                    onSuccess = {
                                        selectedEmployeeForPin = null
                                        onEmployeeUnlocked()
                                    },
                                    onError = { pinError = it }
                                )
                            }
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("employee_pin_input"),
                        singleLine = true
                    )
                    if (pinError != null) {
                        Text(
                            text = pinError ?: "",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        appViewModel.verifyAndSelectEmployee(
                            employee = employee,
                            inputPin = pinInput,
                            onSuccess = {
                                selectedEmployeeForPin = null
                                onEmployeeUnlocked()
                            },
                            onError = { pinError = it }
                        )
                    },
                    modifier = Modifier.testTag("verify_pin_button")
                ) {
                    Text("Unlock Scanner")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedEmployeeForPin = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Add Employee Profile Dialog
    if (showAddEmployeeDialog) {
        AlertDialog(
            onDismissRequest = { showAddEmployeeDialog = false },
            title = { Text("New Employee Profile", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = newEmpName,
                        onValueChange = { newEmpName = it },
                        label = { Text("Full Name *") },
                        modifier = Modifier.fillMaxWidth().testTag("new_employee_name_input"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = newEmpPin,
                        onValueChange = { if (it.length <= 6) newEmpPin = it },
                        label = { Text("Security PIN (Optional)") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        modifier = Modifier.fillMaxWidth().testTag("new_employee_pin_input"),
                        singleLine = true
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = newEmpRole == Role.CASHIER.name,
                            onClick = { newEmpRole = Role.CASHIER.name },
                            label = { Text("Cashier") }
                        )
                        FilterChip(
                            selected = newEmpRole == Role.MANAGER.name,
                            onClick = { newEmpRole = Role.MANAGER.name },
                            label = { Text("Manager") }
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newEmpName.isNotBlank()) {
                            coroutineScope.launch {
                                val emp = Employee(
                                    name = newEmpName.trim(),
                                    pin = newEmpPin.trim(),
                                    role = newEmpRole,
                                    storeId = store.id
                                )
                                val res = appViewModel.employeeRepo.saveEmployee(store.id, emp)
                                if (res.isSuccess) {
                                    val created = res.getOrNull()
                                    if (created != null) {
                                        appViewModel.verifyAndSelectEmployee(
                                            employee = created,
                                            inputPin = created.pin,
                                            onSuccess = {
                                                showAddEmployeeDialog = false
                                                onEmployeeUnlocked()
                                            },
                                            onError = {}
                                        )
                                    } else {
                                        showAddEmployeeDialog = false
                                    }
                                }
                            }
                        }
                    },
                    enabled = newEmpName.isNotBlank(),
                    modifier = Modifier.testTag("save_employee_button")
                ) {
                    Text("Save & Select")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddEmployeeDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
