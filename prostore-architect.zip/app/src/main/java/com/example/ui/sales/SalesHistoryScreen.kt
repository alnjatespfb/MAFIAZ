package com.example.ui.sales

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.SaleItemJsonConverter
import com.example.data.model.Sale
import com.example.data.model.Store
import com.example.data.sync.SyncState
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalesHistoryScreen(
    store: Store,
    salesHistoryViewModel: SalesHistoryViewModel
) {
    val sales by salesHistoryViewModel.sales.collectAsState()
    val pendingSales by salesHistoryViewModel.pendingSales.collectAsState()
    val isLoading by salesHistoryViewModel.isLoading.collectAsState()
    val syncState by salesHistoryViewModel.syncState.collectAsState()

    var selectedSale by remember { mutableStateOf<Sale?>(null) }
    val dateFormatter = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) }

    Scaffold { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Offline Pending Queue Card if any transactions exist in local Room DB
            if (pendingSales.isNotEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.CloudQueue,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Offline Pending Queue (${pendingSales.size})",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Button(
                                onClick = { salesHistoryViewModel.triggerSyncNow() },
                                enabled = syncState !is SyncState.Syncing,
                                modifier = Modifier.testTag("sync_now_button")
                            ) {
                                if (syncState is SyncState.Syncing) {
                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = MaterialTheme.colorScheme.onPrimary)
                                } else {
                                    Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Sync Now")
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "These transactions were completed offline and are stored in local Room database. They will sync idempotently with Firestore as soon as internet is available.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }
            }

            if (isLoading && sales.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else if (sales.isEmpty() && pendingSales.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ReceiptLong,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No sales yet.",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Completed checkout transactions and audits will appear here.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text(
                            text = "Sales Audit Trail (${sales.size} transactions)",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    items(sales, key = { it.transactionId }) { sale ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedSale = sale }
                                .testTag("sale_card_${sale.transactionId.take(8)}"),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = "${store.currency} ${String.format("%.2f", sale.totalAmount)}",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        SuggestionChip(
                                            onClick = {},
                                            label = { Text(sale.paymentMethod, style = MaterialTheme.typography.labelSmall) }
                                        )
                                    }

                                    Text(
                                        text = "TxID: ${sale.transactionId.take(12)}... • ${dateFormatter.format(Date(sale.timestamp))}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    Text(
                                        text = "Cashier: ${sale.cashierName} • Device: ${sale.deviceId.take(8)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "${sale.items.sumOf { it.quantity }} items",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Icon(Icons.Default.ChevronRight, contentDescription = "View Details")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Receipt Detail Modal
    if (selectedSale != null) {
        val sale = selectedSale!!
        AlertDialog(
            onDismissRequest = { selectedSale = null },
            title = {
                Column {
                    Text("Transaction Audit Receipt", fontWeight = FontWeight.Bold)
                    Text(
                        text = "TxID: ${sale.transactionId}",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Timestamp: ${dateFormatter.format(Date(sale.timestamp))}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "Cashier: ${sale.cashierName} (${sale.cashierId})",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "Terminal Device: ${sale.deviceId}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "Payment Method: ${sale.paymentMethod}",
                        style = MaterialTheme.typography.bodySmall
                    )

                    Divider(modifier = Modifier.padding(vertical = 4.dp))

                    Text("Purchased Items:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)

                    sale.items.forEach { item ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${item.quantity}x ${item.productName}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = "${store.currency} ${String.format("%.2f", item.subtotal)}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Subtotal:", style = MaterialTheme.typography.bodyMedium)
                        Text("${store.currency} ${String.format("%.2f", sale.subtotal)}", style = MaterialTheme.typography.bodyMedium)
                    }
                    if (sale.tax > 0) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Tax:", style = MaterialTheme.typography.bodyMedium)
                            Text("${store.currency} ${String.format("%.2f", sale.tax)}", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Total Amount:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = "${store.currency} ${String.format("%.2f", sale.totalAmount)}",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = { selectedSale = null }) {
                    Text("Close")
                }
            }
        )
    }
}
