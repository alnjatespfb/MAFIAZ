package com.example.ui

import androidx.compose.runtime.*
import com.example.ui.auth.AuthScreen
import com.example.ui.store.StoreDashboardScreen
import com.example.ui.store.StoreSelectorScreen

@Composable
fun MainAppScreen(appViewModel: AppViewModel) {
    val currentUser by appViewModel.currentUser.collectAsState()
    val activeStore by appViewModel.activeStore.collectAsState()

    // 1. Unauthenticated User: Login / Create Account
    if (currentUser == null) {
        AuthScreen(
            authRepo = appViewModel.authRepo,
            onAuthSuccess = {
                // currentUser state flow will automatically emit the signed-in user
            }
        )
        return
    }

    // 2. Authenticated User with an Active Store: Real Store Dashboard
    val store = activeStore
    if (store != null) {
        StoreDashboardScreen(
            store = store,
            appViewModel = appViewModel,
            onSwitchStore = {
                appViewModel.setActiveStore(null)
            }
        )
        return
    }

    // 3. Authenticated User without an Active Store: Create or Select Store
    StoreSelectorScreen(
        appViewModel = appViewModel,
        onStoreSelected = { selectedStore ->
            appViewModel.setActiveStore(selectedStore)
        }
    )
}
