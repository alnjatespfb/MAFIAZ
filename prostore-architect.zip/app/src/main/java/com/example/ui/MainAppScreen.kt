package com.example.ui

import androidx.compose.runtime.*
import com.example.ui.auth.AuthScreen
import com.example.ui.counter.SelectCounterScreen
import com.example.ui.scanner.ScannerScreen
import com.example.ui.scanner.ScannerSettingsScreen
import com.example.ui.store.StoreSelectorScreen

@Composable
fun MainAppScreen(appViewModel: AppViewModel) {
    val currentUser by appViewModel.currentUser.collectAsState()
    val activeStore by appViewModel.activeStore.collectAsState()
    val isCounterConfirmed by appViewModel.isCounterConfirmed.collectAsState()
    var showSettings by remember { mutableStateOf(false) }

    // 1. Unauthenticated User: Login / Create Account
    if (currentUser == null) {
        AuthScreen(
            authRepo = appViewModel.authRepo,
            onAuthSuccess = {
                // currentUser state flow will automatically emit the signed-in user
            }
        )
        return
    }

    // 2. Authenticated User without an Active Store: Select or Create Store
    val store = activeStore
    if (store == null) {
        StoreSelectorScreen(
            appViewModel = appViewModel,
            onStoreSelected = { selectedStore ->
                appViewModel.setActiveStore(selectedStore)
            }
        )
        return
    }

    // 3. Settings Screen (Optional drawer / settings accessed from scanner)
    if (showSettings) {
        ScannerSettingsScreen(
            store = store,
            appViewModel = appViewModel,
            onBack = { showSettings = false },
            onSwitchEmployee = {},
            onSwitchStore = {
                showSettings = false
                appViewModel.setActiveStore(null)
            }
        )
        return
    }

    // 4. Counter Selection: Admin chooses the counter before scanning
    if (!isCounterConfirmed) {
        SelectCounterScreen(
            store = store,
            appViewModel = appViewModel,
            onCounterSelected = {
                // Counter confirmed in AppViewModel, transitions directly to Scanner
            },
            onBackToStores = {
                appViewModel.setActiveStore(null)
            }
        )
        return
    }

    // 5. Dedicated Scanner Screen: Operates solely as a wireless scanner
    ScannerScreen(
        store = store,
        appViewModel = appViewModel,
        onOpenSettings = { showSettings = true },
        onSwitchCounter = { appViewModel.resetCounterSelection() },
        onSwitchStore = { appViewModel.setActiveStore(null) }
    )
}
