package com.example.ui.scanner

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ScanEvent
import com.example.data.repository.ScanEventRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ScannerViewModel(
    private val storeId: String,
    private val scannerDeviceId: String,
    private val scanEventRepo: ScanEventRepository
) : ViewModel() {

    private val _recentScans = MutableStateFlow<List<ScanEvent>>(emptyList())
    val recentScans: StateFlow<List<ScanEvent>> = _recentScans.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    fun emitBarcode(barcode: String) {
        val trimmed = barcode.trim()
        if (trimmed.isBlank()) return

        viewModelScope.launch {
            val result = scanEventRepo.emitScanEvent(storeId, trimmed, scannerDeviceId)
            if (result.isSuccess) {
                val event = result.getOrNull()!!
                _recentScans.value = listOf(event) + _recentScans.value.take(15)
                _statusMessage.value = "Barcode '$trimmed' sent to POS terminal"
            } else {
                _statusMessage.value = result.exceptionOrNull()?.localizedMessage ?: "Failed to emit scan event"
            }
        }
    }

    fun clearStatus() {
        _statusMessage.value = null
    }
}
