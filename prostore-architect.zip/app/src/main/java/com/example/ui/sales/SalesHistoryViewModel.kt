package com.example.ui.sales

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.PendingSaleEntity
import com.example.data.model.Sale
import com.example.data.repository.SalesRepository
import com.example.data.sync.SyncManager
import com.example.data.sync.SyncState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SalesHistoryViewModel(
    private val storeId: String,
    private val salesRepo: SalesRepository,
    private val syncManager: SyncManager
) : ViewModel() {

    private val _sales = MutableStateFlow<List<Sale>>(emptyList())
    val sales: StateFlow<List<Sale>> = _sales.asStateFlow()

    private val _pendingSales = MutableStateFlow<List<PendingSaleEntity>>(emptyList())
    val pendingSales: StateFlow<List<PendingSaleEntity>> = _pendingSales.asStateFlow()

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    val syncState: StateFlow<SyncState> = syncManager.syncState

    init {
        loadSales()
        loadPendingSales()
    }

    private fun loadSales() {
        viewModelScope.launch {
            _isLoading.value = true
            salesRepo.getSalesHistory(storeId).collect { list ->
                _sales.value = list
                _isLoading.value = false
            }
        }
    }

    private fun loadPendingSales() {
        viewModelScope.launch {
            salesRepo.getPendingSales(storeId).collect { list ->
                _pendingSales.value = list
            }
        }
    }

    fun triggerSyncNow() {
        syncManager.triggerSync()
    }
}
