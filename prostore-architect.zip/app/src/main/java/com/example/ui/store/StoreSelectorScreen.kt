package com.example.ui.store

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.Store
import com.example.ui.AppViewModel
import com.example.ui.scanner.TargetPosSelectorDialog

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoreSelectorScreen(
    appViewModel: AppViewModel,
    onStoreSelected: (Store) -> Unit
) {
    val stores by appViewModel.userStores.collectAsState()
    val approvedPosDevices by appViewModel.approvedPosDevices.collectAsState()
    var pendingStore by remember { mutableStateOf<Store?>(null) }


    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Select Store", fontWeight = FontWeight.Bold)
                        Text(
                            "Scanner setup",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { appViewModel.authRepo.signOut() },
                        modifier = Modifier.testTag("sign_out_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Sign out")
                    }
                }
            )
        }
    ) { padding ->
        if (stores.isEmpty()) {
            Column(
                Modifier.fillMaxSize().padding(padding).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.Storefront, null, modifier = Modifier.size(64.dp))
                Spacer(Modifier.height(16.dp))
                Text("No stores available", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Ask the store administrator to add your account to a store. Store management is not available in the scanner app.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(
                        "Choose the store you are working in",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                items(stores, key = { it.id }) { store ->
                    Card(
                        onClick = {
                            appViewModel.setActiveStore(store)
                            pendingStore = store
                        },
                        modifier = Modifier.fillMaxWidth().testTag("store_item_${store.id}")
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Storefront, null)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(store.name, fontWeight = FontWeight.Bold)
                                Text(store.currency, style = MaterialTheme.typography.labelSmall)
                            }
                            Icon(Icons.Default.PointOfSale, null)
                        }
                    }
                }
            }
        }
    }

    pendingStore?.let { store ->
        TargetPosSelectorDialog(
            currentPosId = appViewModel.targetPosId.value,
            availablePosDevices = approvedPosDevices,
            onSelectPos = {
                appViewModel.setTargetPos(it)
                pendingStore = null
                onStoreSelected(store)
            },
            onDismiss = { pendingStore = null }
        )
    }
}
