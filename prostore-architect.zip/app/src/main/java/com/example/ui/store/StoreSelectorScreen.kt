package com.example.ui.store

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.Store
import com.example.ui.AppViewModel
import com.example.ui.scanner.TargetPosSelectorDialog
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoreSelectorScreen(
    appViewModel: AppViewModel,
    onStoreSelected: (Store) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val stores by appViewModel.userStores.collectAsState()
    val activeStore by appViewModel.activeStore.collectAsState()
    val currentUser by appViewModel.currentUser.collectAsState()

    var showCreateDialog by remember { mutableStateOf(false) }
    var storeWaitingForCounter by remember { mutableStateOf<Store?>(null) }
    val approvedPosDevices by appViewModel.approvedPosDevices.collectAsState()

    // Form fields for store creation
    var storeName by remember { mutableStateOf("") }
    var storeCountry by remember { mutableStateOf("") }
    var storeCurrency by remember { mutableStateOf("USD") }
    var storeAddress by remember { mutableStateOf("") }
    var storePhone by remember { mutableStateOf("") }
    var storeLogoUrl by remember { mutableStateOf("") }

    var isCreating by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    fun resetForm() {
        storeName = ""
        storeCountry = ""
        storeCurrency = "USD"
        storeAddress = ""
        storePhone = ""
        storeLogoUrl = ""
        errorMessage = null
    }

    fun openStore(store: Store) {
        appViewModel.setActiveStore(store)
        if (appViewModel.targetPosId.value.isBlank()) {
            storeWaitingForCounter = store
        } else {
            onStoreSelected(store)
        }
    }

    fun handleCreateStore() {
        val uid = currentUser?.uid
        if (storeName.isBlank()) {
            errorMessage = "Please enter a store name."
            return
        }
        if (storeCountry.isBlank()) {
            errorMessage = "Please enter your store's country."
            return
        }
        if (storeCurrency.isBlank()) {
            errorMessage = "Please enter a currency code."
            return
        }
        if (uid == null) {
            errorMessage = "Authentication expired. Please sign in again."
            return
        }

        isCreating = true
        coroutineScope.launch {
            val result = appViewModel.storeRepo.createStore(
                name = storeName,
                country = storeCountry,
                currency = storeCurrency.uppercase(),
                address = storeAddress,
                phone = storePhone,
                logoUrl = storeLogoUrl,
                ownerId = uid
            )
            isCreating = false
            if (result.isSuccess) {
                val createdStore = result.getOrNull()!!
                showCreateDialog = false
                resetForm()
                openStore(createdStore)
            } else {
                errorMessage = result.exceptionOrNull()?.localizedMessage ?: "Failed to create store."
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (stores.isEmpty()) "StorePOS" else "Store Selection",
                            fontWeight = FontWeight.Bold
                        )
                        currentUser?.email?.let { email ->
                            Text(
                                text = "Admin: $email",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                actions = {
                    IconButton(
                        onClick = { appViewModel.authRepo.signOut() },
                        modifier = Modifier.testTag("sign_out_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Logout,
                            contentDescription = "Sign Out",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            if (stores.isNotEmpty()) {
                FloatingActionButton(
                    onClick = {
                        resetForm()
                        showCreateDialog = true
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("add_store_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Create New Store")
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            if (stores.isEmpty()) {
                // First-time onboarding: "Create your first store"
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(72.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Storefront,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }

                    Text(
                        text = "Create your first store",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "Enter your store details below to set up your POS terminal, inventory catalog, and sales register.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            OutlinedTextField(
                                value = storeName,
                                onValueChange = { storeName = it; errorMessage = null },
                                label = { Text("Store Name *") },
                                placeholder = { Text("e.g. Downtown Boutique") },
                                leadingIcon = { Icon(Icons.Default.Store, contentDescription = null) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("first_store_name_input"),
                                singleLine = true
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                OutlinedTextField(
                                    value = storeCountry,
                                    onValueChange = { storeCountry = it; errorMessage = null },
                                    label = { Text("Country *") },
                                    placeholder = { Text("e.g. United States") },
                                    leadingIcon = { Icon(Icons.Default.Public, contentDescription = null) },
                                    modifier = Modifier
                                        .weight(1.2f)
                                        .testTag("first_store_country_input"),
                                    singleLine = true
                                )

                                OutlinedTextField(
                                    value = storeCurrency,
                                    onValueChange = { storeCurrency = it.uppercase() },
                                    label = { Text("Currency *") },
                                    placeholder = { Text("USD") },
                                    leadingIcon = { Icon(Icons.Default.AttachMoney, contentDescription = null) },
                                    modifier = Modifier
                                        .weight(0.8f)
                                        .testTag("first_store_currency_input"),
                                    singleLine = true
                                )
                            }

                            OutlinedTextField(
                                value = storeAddress,
                                onValueChange = { storeAddress = it },
                                label = { Text("Address (Optional)") },
                                placeholder = { Text("123 Market Street, Suite 100") },
                                leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("first_store_address_input"),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = storePhone,
                                onValueChange = { storePhone = it },
                                label = { Text("Phone Number (Optional)") },
                                placeholder = { Text("+1 (555) 012-3456") },
                                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("first_store_phone_input"),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = storeLogoUrl,
                                onValueChange = { storeLogoUrl = it },
                                label = { Text("Logo URL / Tag (Optional)") },
                                placeholder = { Text("https://... or store logo keyword") },
                                leadingIcon = { Icon(Icons.Default.Image, contentDescription = null) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("first_store_logo_input"),
                                singleLine = true
                            )

                            if (errorMessage != null) {
                                Text(
                                    text = errorMessage ?: "",
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Button(
                                onClick = { handleCreateStore() },
                                enabled = !isCreating,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("create_first_store_submit_button")
                            ) {
                                if (isCreating) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Creating Store...")
                                } else {
                                    Icon(Icons.Default.Check, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Create Store & Launch Dashboard", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            } else {
                // Stores exist: Show list of stores
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = "Your Stores",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${stores.size} store(s) available. Tap a store to launch its POS dashboard.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Button(
                                    onClick = {
                                        resetForm()
                                        showCreateDialog = true
                                    },
                                    modifier = Modifier.testTag("add_store_header_button")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("New Store")
                                }
                            }
                        }
                    }

                    items(stores, key = { it.id }) { store ->
                        val isSelected = activeStore?.id == store.id
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    openStore(store)
                                }
                                .testTag("store_item_${store.id}"),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected)
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                                else
                                    MaterialTheme.colorScheme.surface
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Storefront,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(16.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = store.name,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (isSelected) {
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Surface(
                                                color = MaterialTheme.colorScheme.primary,
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    text = "ACTIVE",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onPrimary,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        if (store.country.isNotBlank()) {
                                            Text(
                                                text = store.country,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Text(
                                                text = "•",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.outline
                                            )
                                        }
                                        Text(
                                            text = "Currency: ${store.currency}",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }

                                    if (store.address.isNotBlank()) {
                                        Text(
                                            text = store.address,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    if (store.phone.isNotBlank()) {
                                        Text(
                                            text = "Tel: ${store.phone}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.outline
                                        )
                                    }
                                }

                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = "Open Store",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal dialog to create an additional store
    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { if (!isCreating) showCreateDialog = false },
            title = {
                Text(
                    text = "Create New Store",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = storeName,
                        onValueChange = { storeName = it; errorMessage = null },
                        label = { Text("Store Name *") },
                        placeholder = { Text("e.g. Midtown Branch") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dialog_store_name_input"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = storeCountry,
                        onValueChange = { storeCountry = it; errorMessage = null },
                        label = { Text("Country *") },
                        placeholder = { Text("e.g. United States") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dialog_store_country_input"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = storeCurrency,
                        onValueChange = { storeCurrency = it.uppercase() },
                        label = { Text("Currency *") },
                        placeholder = { Text("USD, EUR, GBP, EGP, SAR") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dialog_store_currency_input"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = storeAddress,
                        onValueChange = { storeAddress = it },
                        label = { Text("Address (Optional)") },
                        placeholder = { Text("456 Central Ave") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dialog_store_address_input"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = storePhone,
                        onValueChange = { storePhone = it },
                        label = { Text("Phone Number (Optional)") },
                        placeholder = { Text("+1 (555) 012-3456") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dialog_store_phone_input"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = storeLogoUrl,
                        onValueChange = { storeLogoUrl = it },
                        label = { Text("Logo URL / Tag (Optional)") },
                        placeholder = { Text("https://... or logo tag") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dialog_store_logo_input"),
                        singleLine = true
                    )

                    if (errorMessage != null) {
                        Text(
                            text = errorMessage ?: "",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { handleCreateStore() },
                    enabled = !isCreating,
                    modifier = Modifier.testTag("submit_create_store_button")
                ) {
                    if (isCreating) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    } else {
                        Text("Create Store")
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showCreateDialog = false },
                    enabled = !isCreating
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    if (storeWaitingForCounter != null) {
        TargetPosSelectorDialog(
            currentPosId = appViewModel.targetPosId.value,
            availablePosDevices = approvedPosDevices,
            onSelectPos = { appViewModel.setTargetPos(it) },
            onDismiss = {
                val selectedStore = storeWaitingForCounter
                storeWaitingForCounter = null
                if (selectedStore != null) onStoreSelected(selectedStore)
            }
        )
    }
}
