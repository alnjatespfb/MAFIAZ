package com.example.ui.inventory

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Product
import com.example.data.repository.ProductRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class InventoryViewModel(
    private val storeId: String,
    private val productRepo: ProductRepository
) : ViewModel() {

    private val _products = MutableStateFlow<List<Product>>(emptyList())
    val products: StateFlow<List<Product>> = _products.asStateFlow()

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    init {
        loadProducts()
    }

    private fun loadProducts() {
        viewModelScope.launch {
            _isLoading.value = true
            productRepo.getProducts(storeId).collect { list ->
                _products.value = list
                _isLoading.value = false
            }
        }
    }

    fun saveProduct(product: Product, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch {
            val result = productRepo.saveProduct(storeId, product)
            if (result.isSuccess) {
                _statusMessage.value = "Product saved successfully"
                onComplete(true)
            } else {
                _statusMessage.value = result.exceptionOrNull()?.localizedMessage ?: "Failed to save product"
                onComplete(false)
            }
        }
    }

    fun deleteProduct(productId: String) {
        viewModelScope.launch {
            val result = productRepo.deleteProduct(storeId, productId)
            if (result.isSuccess) {
                _statusMessage.value = "Product deleted"
            } else {
                _statusMessage.value = result.exceptionOrNull()?.localizedMessage ?: "Failed to delete product"
            }
        }
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }
}
