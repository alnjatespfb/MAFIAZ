package com.example.ui.scanner

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.Store
import com.example.ui.AppViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConnectScannerScreen(
    appViewModel: AppViewModel,
    onAdminLoginClick: () -> Unit,
    onStoreSelected: (Store) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var showManualPairDialog by remember { mutableStateOf(false) }
    var storeIdInput by remember { mutableStateOf("") }
    var storeNameInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isVerifying by remember { mutableStateOf(false) }

    val userStores by appViewModel.userStores.collectAsState()
    val currentUser by appViewModel.currentUser.collectAsState()

    var deviceNameInput by remember { mutableStateOf(appViewModel.deviceName) }
    var isEditingDeviceName by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Wireless Barcode Scanner", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(88.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.QrCodeScanner,
                        contentDescription = "Scanner",
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(52.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Connect Scanner",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Turn this phone into a high-speed wireless barcode scanner for your cloud POS register.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Device Identity Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Devices, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Device Identity", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        }
                        TextButton(onClick = { isEditingDeviceName = !isEditingDeviceName }) {
                            Text(if (isEditingDeviceName) "Done" else "Edit Name")
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (isEditingDeviceName) {
                        OutlinedTextField(
                            value = deviceNameInput,
                            onValueChange = {
                                deviceNameInput = it
                                appViewModel.updateScannerName(it)
                            },
                            label = { Text("Scanner Label") },
                            modifier = Modifier.fillMaxWidth().testTag("edit_device_name_input"),
                            singleLine = true
                        )
                    } else {
                        Text(
                            text = deviceNameInput,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "ID: ${appViewModel.deviceId}",
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // If user is logged in and has stores, show store quick selection
            if (currentUser != null && userStores.isNotEmpty()) {
                Text(
                    text = "Select Store to Connect",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Start)
                )
                Spacer(modifier = Modifier.height(8.dp))

                userStores.forEach { store ->
                    Card(
                        onClick = { onStoreSelected(store) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .testTag("select_store_${store.id}"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Store, contentDescription = null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = store.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                    Text(
                                        text = "Currency: ${store.currency}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f)
                                    )
                                }
                            }
                            FilledTonalButton(onClick = { onStoreSelected(store) }) {
                                Text("Connect")
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Main Action 1: Login as Admin
            Button(
                onClick = onAdminLoginClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("login_as_admin_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.AdminPanelSettings, contentDescription = null)
                Spacer(modifier = Modifier.width(12.dp))
                Text("Login as Admin", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Action 2: Pair this device with a store
            OutlinedButton(
                onClick = { showManualPairDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("pair_device_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Link, contentDescription = null)
                Spacer(modifier = Modifier.width(12.dp))
                Text("Pair This Device with a Store", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        }
    }

    // Dialog for Manual Store Pairing
    if (showManualPairDialog) {
        AlertDialog(
            onDismissRequest = { showManualPairDialog = false },
            title = { Text("Pair with Store", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "Enter the Store ID or Store Name provided by your store administrator:",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = storeIdInput,
                        onValueChange = { storeIdInput = it },
                        label = { Text("Store ID *") },
                        modifier = Modifier.fillMaxWidth().testTag("pair_store_id_input"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = storeNameInput,
                        onValueChange = { storeNameInput = it },
                        label = { Text("Store Name (Optional)") },
                        modifier = Modifier.fillMaxWidth().testTag("pair_store_name_input"),
                        singleLine = true
                    )
                    if (errorMessage != null) {
                        Text(
                            text = errorMessage ?: "",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val cleanId = storeIdInput.trim()
                        if (cleanId.isBlank()) {
                            errorMessage = "Store ID is required."
                            return@Button
                        }
                        isVerifying = true
                        errorMessage = null
                        coroutineScope.launch {
                            val foundStore = appViewModel.storeRepo.getStoreOnce(cleanId)
                            isVerifying = false
                            if (foundStore != null) {
                                onStoreSelected(foundStore)
                                showManualPairDialog = false
                            } else {
                                // Connect by ID
                                val sName = storeNameInput.trim().ifBlank { "Store $cleanId" }
                                val newStore = Store(id = cleanId, name = sName)
                                onStoreSelected(newStore)
                                showManualPairDialog = false
                            }
                        }
                    },
                    modifier = Modifier.testTag("confirm_pair_store_button"),
                    enabled = !isVerifying
                ) {
                    if (isVerifying) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = MaterialTheme.colorScheme.onPrimary)
                    } else {
                        Text("Connect Scanner")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showManualPairDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
