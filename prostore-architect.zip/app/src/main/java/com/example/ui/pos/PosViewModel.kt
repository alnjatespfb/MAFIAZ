package com.example.ui.pos

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.PaymentMethod
import com.example.data.model.Product
import com.example.data.model.Sale
import com.example.data.model.SaleItem
import com.example.data.repository.ProductRepository
import com.example.data.repository.SalesRepository
import com.example.data.repository.SaleResult
import com.example.data.repository.ScanEventRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

sealed class CheckoutState {
    object Idle : CheckoutState()
    object Processing : CheckoutState()
    data class Success(val sale: Sale, val isOffline: Boolean, val message: String) : CheckoutState()
    data class Error(val message: String) : CheckoutState()
}

class PosViewModel(
    val storeId: String,
    val posDeviceId: String = "",
    private val productRepo: ProductRepository,
    private val salesRepo: SalesRepository,
    private val scanEventRepo: ScanEventRepository
) : ViewModel() {

    private val _cart = MutableStateFlow<List<SaleItem>>(emptyList())
    val cart: StateFlow<List<SaleItem>> = _cart.asStateFlow()

    private val _allProducts = MutableStateFlow<List<Product>>(emptyList())
    val allProducts: StateFlow<List<Product>> = _allProducts.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _checkoutState = MutableStateFlow<CheckoutState>(CheckoutState.Idle)
    val checkoutState: StateFlow<CheckoutState> = _checkoutState.asStateFlow()

    private val _lastScannedBarcode = MutableStateFlow<String?>(null)
    val lastScannedBarcode: StateFlow<String?> = _lastScannedBarcode.asStateFlow()

    private var scanListenerJob: Job? = null

    init {
        loadProducts()
        startListeningToRemoteScans()
    }

    private fun loadProducts() {
        if (storeId.isBlank()) return
        viewModelScope.launch {
            try {
                productRepo.getProducts(storeId).collect { products ->
                    _allProducts.value = products
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun startListeningToRemoteScans() {
        if (storeId.isBlank()) return
        scanListenerJob?.cancel()
        scanListenerJob = viewModelScope.launch {
            try {
                scanEventRepo.listenToPendingScans(storeId, posDeviceId).collect { pendingEvents ->
                    for (event in pendingEvents) {
                        val barcode = event.barcode.trim()
                        if (barcode.isBlank()) continue

                        // 1. Try finding in loaded products catalog
                        var product = _allProducts.value.find { p ->
                            p.barcode.trim().equals(barcode, ignoreCase = true) ||
                            (p.sku.isNotBlank() && p.sku.trim().equals(barcode, ignoreCase = true))
                        }

                        // 2. If not found in cache, lookup directly via repository
                        if (product == null) {
                            try {
                                product = productRepo.findProductByBarcode(storeId, barcode)
                            } catch (_: Exception) {}
                        }

                        // 3. Add to cart (or increment quantity if already present)
                        if (product != null) {
                            addToCart(product)
                            _lastScannedBarcode.value = "Remote Scan: ${product.name} added"
                        } else {
                            // If not in catalog, still add item so sale can proceed
                            val genericProduct = Product(
                                id = "scan_${UUID.randomUUID()}",
                                productId = "scan_${UUID.randomUUID()}",
                                storeId = storeId,
                                name = "Scanned Item ($barcode)",
                                barcode = barcode,
                                price = 0.0,
                                sellingPrice = 0.0,
                                stockQuantity = 999L
                            )
                            addToCart(genericProduct)
                            _lastScannedBarcode.value = "Scanned: $barcode (not in catalog)"
                        }

                        // 4. Mark scan processed in Firestore
                        try {
                            val eventIdToMark = event.id.ifBlank { event.scanId }
                            if (eventIdToMark.isNotBlank()) {
                                scanEventRepo.markScanProcessed(storeId, eventIdToMark)
                            }
                        } catch (_: Exception) {}
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun addToCart(product: Product, quantity: Long = 1) {
        val currentList = _cart.value.toMutableList()
        val prodId = product.id.ifBlank { product.productId }
        val prodBarcode = product.barcode.trim()
        val effectivePrice = if (product.price > 0.0) product.price else product.sellingPrice

        // Match existing item by productId OR by barcode so repeated scans increment quantity!
        val index = currentList.indexOfFirst {
            (prodId.isNotBlank() && it.productId == prodId) ||
            (prodBarcode.isNotBlank() && it.barcode.trim().equals(prodBarcode, ignoreCase = true))
        }

        if (index >= 0) {
            val existing = currentList[index]
            val newQty = existing.quantity + quantity
            currentList[index] = existing.copy(
                quantity = newQty,
                subtotal = newQty * existing.unitPrice
            )
        } else {
            currentList.add(
                SaleItem(
                    productId = prodId.ifBlank { UUID.randomUUID().toString() },
                    productName = product.name.ifBlank { "Item ($prodBarcode)" },
                    barcode = prodBarcode,
                    sku = product.sku,
                    unitPrice = effectivePrice,
                    quantity = quantity,
                    subtotal = quantity * effectivePrice
                )
            )
        }
        _cart.value = currentList
    }

    fun updateCartItemQuantity(productId: String, delta: Long) {
        val currentList = _cart.value.toMutableList()
        val index = currentList.indexOfFirst { it.productId == productId }
        if (index >= 0) {
            val item = currentList[index]
            val newQty = item.quantity + delta
            if (newQty <= 0) {
                currentList.removeAt(index)
            } else {
                currentList[index] = item.copy(
                    quantity = newQty,
                    subtotal = newQty * item.unitPrice
                )
            }
            _cart.value = currentList
        }
    }

    fun removeFromCart(productId: String) {
        _cart.value = _cart.value.filter { it.productId != productId }
    }

    fun clearCart() {
        _cart.value = emptyList()
    }

    fun resetCheckoutState() {
        _checkoutState.value = CheckoutState.Idle
    }

    fun processCheckout(
        paymentMethod: PaymentMethod,
        cashierId: String,
        cashierName: String,
        deviceId: String,
        taxRate: Double = 0.0
    ) {
        val items = _cart.value
        if (items.isEmpty()) return

        val subtotal = items.sumOf { it.subtotal }
        val tax = subtotal * taxRate
        val total = subtotal + tax

        val transactionId = UUID.randomUUID().toString()
        val sale = Sale(
            id = transactionId,
            transactionId = transactionId,
            storeId = storeId,
            cashierId = cashierId,
            cashierName = cashierName,
            deviceId = deviceId,
            items = items,
            subtotal = subtotal,
            tax = tax,
            totalAmount = total,
            paymentMethod = paymentMethod.name,
            timestamp = System.currentTimeMillis()
        )

        viewModelScope.launch {
            _checkoutState.value = CheckoutState.Processing
            val result = salesRepo.processSale(sale)
            when {
                result.isSuccess -> {
                    when (val saleRes = result.getOrNull()) {
                        is SaleResult.CompletedOnline -> {
                            clearCart()
                            _checkoutState.value = CheckoutState.Success(
                                sale = saleRes.sale,
                                isOffline = false,
                                message = "Sale completed successfully and inventory updated."
                            )
                        }
                        is SaleResult.QueuedOffline -> {
                            clearCart()
                            _checkoutState.value = CheckoutState.Success(
                                sale = saleRes.sale,
                                isOffline = true,
                                message = "Device is offline. Transaction safely queued and will sync automatically."
                            )
                        }
                        null -> {
                            _checkoutState.value = CheckoutState.Error("Unknown transaction result")
                        }
                    }
                }
                else -> {
                    val errorMsg = result.exceptionOrNull()?.localizedMessage ?: "Transaction failed."
                    _checkoutState.value = CheckoutState.Error(errorMsg)
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        scanListenerJob?.cancel()
    }
}
