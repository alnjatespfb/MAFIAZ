package com.example.ui.devices

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Device
import com.example.data.model.DeviceStatus
import com.example.data.model.Employee
import com.example.data.repository.DeviceRepository
import com.example.data.repository.EmployeeRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class DeviceViewModel(
    private val storeId: String,
    private val deviceRepo: DeviceRepository,
    private val employeeRepo: EmployeeRepository
) : ViewModel() {

    private val _devices = MutableStateFlow<List<Device>>(emptyList())
    val devices: StateFlow<List<Device>> = _devices.asStateFlow()

    private val _employees = MutableStateFlow<List<Employee>>(emptyList())
    val employees: StateFlow<List<Employee>> = _employees.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            deviceRepo.getDevicesForStore(storeId).collect { list ->
                _devices.value = list
            }
        }
        viewModelScope.launch {
            employeeRepo.getEmployees(storeId).collect { list ->
                _employees.value = list
            }
        }
    }

    fun updateDeviceStatus(deviceId: String, status: DeviceStatus) {
        viewModelScope.launch {
            val result = deviceRepo.updateDeviceStatus(storeId, deviceId, status)
            if (result.isSuccess) {
                _statusMessage.value = "Device status updated to ${status.name}"
            } else {
                _statusMessage.value = result.exceptionOrNull()?.localizedMessage ?: "Failed to update device status"
            }
        }
    }

    fun saveEmployee(employee: Employee, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch {
            val result = employeeRepo.saveEmployee(storeId, employee)
            if (result.isSuccess) {
                _statusMessage.value = "Employee saved"
                onComplete(true)
            } else {
                _statusMessage.value = result.exceptionOrNull()?.localizedMessage ?: "Failed to save employee"
                onComplete(false)
            }
        }
    }

    fun deleteEmployee(employeeId: String) {
        viewModelScope.launch {
            val result = employeeRepo.deleteEmployee(storeId, employeeId)
            if (result.isSuccess) {
                _statusMessage.value = "Employee removed"
            } else {
                _statusMessage.value = result.exceptionOrNull()?.localizedMessage ?: "Failed to remove employee"
            }
        }
    }

    fun clearStatus() {
        _statusMessage.value = null
    }
}
