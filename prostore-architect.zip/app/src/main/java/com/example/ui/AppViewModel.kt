package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.FirebaseManager
import com.example.data.model.AccessRequest
import com.example.data.model.Device
import com.example.data.model.DeviceStatus
import com.example.data.model.DeviceType
import com.example.data.model.Employee
import com.example.data.model.Product
import com.example.data.model.Role
import com.example.data.model.ScanEvent
import com.example.data.model.Store
import com.example.data.model.StorePermission
import com.example.data.repository.AuthRepository
import com.example.data.repository.DeviceRepository
import com.example.data.repository.EmployeeRepository
import com.example.data.repository.ProductRepository
import com.example.data.repository.SalesRepository
import com.example.data.repository.ScanEventRepository
import com.example.data.repository.StoreRepository
import com.example.data.sync.ScanSyncManager
import com.example.data.sync.ScanSyncStatus
import com.example.data.sync.SyncManager
import com.example.util.DeviceIdManager
import com.example.util.FeedbackHelper
import com.example.util.NetworkMonitor
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class AppViewModel(application: Application) : AndroidViewModel(application) {
    val authRepo = AuthRepository()
    val storeRepo = StoreRepository()
    val deviceRepo = DeviceRepository()
    val employeeRepo = EmployeeRepository()
    val productRepo = ProductRepository()
    val scanEventRepo = ScanEventRepository()
    val networkMonitor = NetworkMonitor(application)
    val salesRepo = SalesRepository(application, networkMonitor)
    val syncManager = SyncManager(application, networkMonitor, salesRepo)
    val scanSyncManager = ScanSyncManager(application, networkMonitor, scanEventRepo)

    val isOnline: StateFlow<Boolean> = networkMonitor.isOnline
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), networkMonitor.isCurrentlyConnected())

    val scanSyncStatus: StateFlow<ScanSyncStatus> = scanSyncManager.syncStatus
    val pendingScansCount: StateFlow<Int> = scanSyncManager.pendingCountFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _isFirebaseConfigured = MutableStateFlow(true)
    val isFirebaseConfigured: StateFlow<Boolean> = _isFirebaseConfigured.asStateFlow()

    val currentUser: StateFlow<FirebaseUser?> = authRepo.currentUserFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _userStores = MutableStateFlow<List<Store>>(emptyList())
    val userStores: StateFlow<List<Store>> = _userStores.asStateFlow()

    private val _activeStore = MutableStateFlow<Store?>(null)
    val activeStore: StateFlow<Store?> = _activeStore.asStateFlow()

    private val _currentDevice = MutableStateFlow<Device?>(null)
    val currentDevice: StateFlow<Device?> = _currentDevice.asStateFlow()

    private val _activeEmployee = MutableStateFlow<Employee?>(null)
    val activeEmployee: StateFlow<Employee?> = _activeEmployee.asStateFlow()

    private val _storeEmployees = MutableStateFlow<List<Employee>>(emptyList())
    val storeEmployees: StateFlow<List<Employee>> = _storeEmployees.asStateFlow()

    private val _approvedPosDevices = MutableStateFlow<List<Device>>(emptyList())
    val approvedPosDevices: StateFlow<List<Device>> = _approvedPosDevices.asStateFlow()

    private val _targetPosId = MutableStateFlow<String>(DeviceIdManager.getTargetPosId(application) ?: "")
    val targetPosId: StateFlow<String> = _targetPosId.asStateFlow()

    private val _targetPosName = MutableStateFlow<String>(DeviceIdManager.getTargetPosName(application))
    val targetPosName: StateFlow<String> = _targetPosName.asStateFlow()

    private val _recentScans = MutableStateFlow<List<ScanEvent>>(emptyList())
    val recentScans: StateFlow<List<ScanEvent>> = _recentScans.asStateFlow()

    private val _lastScannedEvent = MutableStateFlow<ScanEvent?>(null)
    val lastScannedEvent: StateFlow<ScanEvent?> = _lastScannedEvent.asStateFlow()

    private val _lastScannedProduct = MutableStateFlow<Product?>(null)
    val lastScannedProduct: StateFlow<Product?> = _lastScannedProduct.asStateFlow()

    private val _adminAccessRequest = MutableStateFlow<AccessRequest?>(null)
    val adminAccessRequest: StateFlow<AccessRequest?> = _adminAccessRequest.asStateFlow()

    private val _adminRequestMessage = MutableStateFlow<String?>(null)
    val adminRequestMessage: StateFlow<String?> = _adminRequestMessage.asStateFlow()

    // Scanner preferences
    val scanSoundEnabled = MutableStateFlow(DeviceIdManager.isSoundEnabled(application))
    val vibrationEnabled = MutableStateFlow(DeviceIdManager.isVibrationEnabled(application))
    val cooldownMs = MutableStateFlow(DeviceIdManager.getCooldownMs(application))
    val autoScanEnabled = MutableStateFlow(DeviceIdManager.isAutoScanEnabled(application))

    val deviceId = DeviceIdManager.getDeviceId(application)
    val deviceName = DeviceIdManager.getDeviceName(application)

    private var heartbeatJob: Job? = null
    private var deviceObserveJob: Job? = null
    private var employeesJob: Job? = null
    private var posDevicesJob: Job? = null

    init {
        FirebaseManager.initialize(application)

        // Observe logged in user stores
        viewModelScope.launch {
            currentUser.collect { user ->
                if (user != null) {
                    storeRepo.getStoresForUser(user.uid).collect { stores ->
                        _userStores.value = stores
                    }
                } else {
                    _userStores.value = emptyList()
                }
            }
        }

        // Restore active store from local preference if present
        val savedStoreId = DeviceIdManager.getActiveStoreId(application)
        if (!savedStoreId.isNullOrBlank()) {
            loadStoreById(savedStoreId)
        }

        startHeartbeat()
    }

    fun configureFirebase(projectId: String, appId: String, apiKey: String): Boolean {
        val success = FirebaseManager.saveConfiguration(getApplication(), projectId, appId, apiKey)
        _isFirebaseConfigured.value = success
        return success
    }

    fun loadStoreById(storeId: String) {
        viewModelScope.launch {
            val store = storeRepo.getStoreOnce(storeId)
            if (store != null) {
                setActiveStore(store)
            } else {
                // Fallback: create temporary Store representation with saved name
                val savedName = DeviceIdManager.getActiveStoreName(getApplication())
                val fallbackStore = Store(id = storeId, name = if (savedName.isNotBlank()) savedName else "Store ($storeId)")
                setActiveStore(fallbackStore)
            }
        }
    }

    fun switchDeviceRole(newRole: DeviceType) {
        DeviceIdManager.setDeviceRole(getApplication(), newRole.name)
        activeStore.value?.let { registerAndObserveDevice(it.id) }
    }

    fun setActiveStore(store: Store?) {
        val savedTargetStoreId = DeviceIdManager.getTargetPosStoreId(getApplication())
        if (store != null && !savedTargetStoreId.isNullOrBlank() &&
            savedTargetStoreId != store.id
        ) {
            clearTargetPosLocally()
        }
        _activeStore.value = store
        DeviceIdManager.setActiveStoreId(getApplication(), store?.id)
        DeviceIdManager.setActiveStoreName(getApplication(), store?.name ?: "")

        deviceObserveJob?.cancel()
        employeesJob?.cancel()
        posDevicesJob?.cancel()

        if (store != null) {
            _approvedPosDevices.value = emptyList()
            registerAndObserveDevice(store.id)
            observeStoreEmployees(store.id)
            observeStorePosDevices(store.id)

            // Restore saved employee if valid
            val savedEmpId = DeviceIdManager.getCurrentEmployeeId(getApplication())
            val savedEmpName = DeviceIdManager.getCurrentEmployeeName(getApplication())
            if (!savedEmpId.isNullOrBlank() && savedEmpName.isNotBlank()) {
                _activeEmployee.value = Employee(id = savedEmpId, name = savedEmpName, storeId = store.id)
            }
        } else {
            _currentDevice.value = null
            _activeEmployee.value = null
            _storeEmployees.value = emptyList()
            _approvedPosDevices.value = emptyList()
        }
    }

    fun registerAndObserveDevice(storeId: String) {
        deviceObserveJob?.cancel()
        deviceObserveJob = viewModelScope.launch {
            val currentName = DeviceIdManager.getDeviceName(getApplication())
            val savedRole = runCatching {
                DeviceType.valueOf(DeviceIdManager.getDeviceRole(getApplication()))
            }.getOrDefault(DeviceType.SCANNER)
            deviceRepo.registerDevice(storeId, deviceId, currentName, savedRole)

            deviceRepo.observeDevice(storeId, deviceId).collect { dev ->
                _currentDevice.value = dev
                val serverPairedPosId = dev?.effectivePairedPosId.orEmpty()
                if (_targetPosId.value.isBlank() && serverPairedPosId.isNotBlank()) {
                    _targetPosId.value = serverPairedPosId
                    _targetPosName.value = dev?.connectedPosName.orEmpty()
                    DeviceIdManager.setTargetPosId(getApplication(), serverPairedPosId)
                    DeviceIdManager.setTargetPosName(getApplication(), _targetPosName.value)
                    DeviceIdManager.setTargetPosStoreId(getApplication(), storeId)
                }
            }
        }
    }

    private fun observeStoreEmployees(storeId: String) {
        employeesJob?.cancel()
        employeesJob = viewModelScope.launch {
            employeeRepo.getEmployees(storeId).collect { employees ->
                _storeEmployees.value = employees
                // Refresh active employee reference if still valid
                val current = _activeEmployee.value
                if (current != null) {
                    val refreshed = employees.find { it.id == current.id }
                    if (refreshed != null) {
                        _activeEmployee.value = refreshed
                    }
                }
            }
        }
    }

    private fun observeStorePosDevices(storeId: String) {
        posDevicesJob?.cancel()
        posDevicesJob = viewModelScope.launch {
            deviceRepo.observeApprovedPosDevices(storeId).collect { posList ->
                _approvedPosDevices.value = posList
            }
        }
    }

    fun verifyAndSelectEmployee(
        employee: Employee,
        inputPin: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val store = _activeStore.value ?: return@launch
            if (employee.status == "DISABLED") {
                onError("This employee account is disabled.")
                return@launch
            }
            if (employee.pin.isNotBlank() && employee.pin.trim() != inputPin.trim()) {
                FeedbackHelper.playErrorBeep(getApplication())
                onError("Incorrect PIN. Please try again.")
                return@launch
            }

            // PIN verified or not configured
            _activeEmployee.value = employee
            DeviceIdManager.setCurrentEmployee(getApplication(), employee.id, employee.name)
            onSuccess()
        }
    }

    fun logoutEmployee() {
        _activeEmployee.value = null
        DeviceIdManager.setCurrentEmployee(getApplication(), null, null)
    }

    fun setTargetPos(posDevice: Device) {
        _targetPosId.value = posDevice.deviceId
        _targetPosName.value = posDevice.deviceName
        DeviceIdManager.setTargetPosId(getApplication(), posDevice.deviceId)
        DeviceIdManager.setTargetPosName(getApplication(), posDevice.deviceName)
        DeviceIdManager.setTargetPosStoreId(getApplication(), _activeStore.value?.id)
        val store = _activeStore.value
        if (store != null) {
            viewModelScope.launch {
                deviceRepo.updateHeartbeat(
                    storeId = store.id,
                    deviceId = deviceId,
                    connectedPosId = posDevice.deviceId,
                    connectedPosName = posDevice.deviceName,
                    isOnline = networkMonitor.isCurrentlyConnected()
                )
            }
        }
    }

    private fun clearTargetPosLocally() {
        _targetPosId.value = ""
        _targetPosName.value = ""
        DeviceIdManager.clearTargetPos(getApplication())
    }

    fun disconnectTargetPos() {
        val store = _activeStore.value
        viewModelScope.launch {
            if (store != null) {
                deviceRepo.disconnectPosBinding(store.id, deviceId)
            }
            clearTargetPosLocally()
        }
    }

    fun updateScannerName(newName: String) {
        DeviceIdManager.setDeviceName(getApplication(), newName)
        val store = _activeStore.value ?: return
        viewModelScope.launch {
            val role = runCatching {
                DeviceType.valueOf(DeviceIdManager.getDeviceRole(getApplication()))
            }.getOrDefault(DeviceType.SCANNER)
            deviceRepo.registerDevice(store.id, deviceId, newName, role)
        }
    }

    fun toggleSound(enabled: Boolean) {
        scanSoundEnabled.value = enabled
        DeviceIdManager.setSoundEnabled(getApplication(), enabled)
    }

    fun toggleVibration(enabled: Boolean) {
        vibrationEnabled.value = enabled
        DeviceIdManager.setVibrationEnabled(getApplication(), enabled)
    }

    fun setCooldown(ms: Long) {
        cooldownMs.value = ms
        DeviceIdManager.setCooldownMs(getApplication(), ms)
    }

    fun toggleAutoScan(enabled: Boolean) {
        autoScanEnabled.value = enabled
        DeviceIdManager.setAutoScanEnabled(getApplication(), enabled)
    }

    fun disconnectDevice() {
        disconnectTargetPos()
        DeviceIdManager.disconnectDevice(getApplication())
        setActiveStore(null)
    }

    // The scanner intentionally stages ONE barcode locally. Nothing is sent
    // to Firestore until the operator explicitly presses SEND.
    private val _pendingBarcode = MutableStateFlow<String?>(null)
    val pendingBarcode: StateFlow<String?> = _pendingBarcode.asStateFlow()

    private val _pendingBarcodeFormat = MutableStateFlow("EAN_13")
    val pendingBarcodeFormat: StateFlow<String> = _pendingBarcodeFormat.asStateFlow()

    private val _scanMode = MutableStateFlow("SALE")
    val scanMode: StateFlow<String> = _scanMode.asStateFlow()

    private val _sendStatus = MutableStateFlow<String?>(null)
    val sendStatus: StateFlow<String?> = _sendStatus.asStateFlow()

    fun setScanMode(mode: String) {
        if (mode == "ADD_PRODUCT" || mode == "SALE") {
            _scanMode.value = mode
            _sendStatus.value = null
        }
    }

    fun processBarcodeScanned(barcode: String, format: String = "EAN_13") {
        val trimmed = barcode.trim()
        if (trimmed.isBlank() || _pendingBarcode.value != null) return

        FeedbackHelper.playBeep(getApplication())
        FeedbackHelper.vibrate(getApplication(), 60L)

        // Reserve the staging slot immediately so repeated camera callbacks
        // cannot accumulate multiple unsent scans.
        _pendingBarcode.value = trimmed
        _pendingBarcodeFormat.value = format
        _sendStatus.value = "Ready to send"

        viewModelScope.launch {
            val store = _activeStore.value ?: return@launch
            try {
                _lastScannedProduct.value = productRepo.findProductByBarcode(store.id, trimmed)
            } catch (_: Exception) {
                _lastScannedProduct.value = null
            }
        }
    }

    fun cancelPendingScan() {
        _pendingBarcode.value = null
        _pendingBarcodeFormat.value = "EAN_13"
        _lastScannedProduct.value = null
        _sendStatus.value = null
    }

    fun sendPendingScan() {
        val barcode = _pendingBarcode.value?.trim().orEmpty()
        if (barcode.isBlank()) return

        val store = _activeStore.value ?: return
        val employee = _activeEmployee.value
        val empId = employee?.id ?: ""
        val empName = employee?.name ?: currentUser.value?.displayName ?: "Scanner User"
        val posId = _targetPosId.value
        val posName = _targetPosName.value
        val mode = _scanMode.value

        // Inventory/product-creation mode is privileged.
        if (mode == "ADD_PRODUCT") {
            val allowed = employee?.role == Role.ADMIN.name ||
                employee?.role == Role.MANAGER.name ||
                employee?.permissions?.contains(StorePermission.MANAGE_INVENTORY) == true
            if (!allowed) {
                _sendStatus.value = "You do not have permission to add products"
                return
            }
        } else {
            val allowed = employee == null ||
                employee.role == Role.ADMIN.name ||
                employee.role == Role.MANAGER.name ||
                employee.permissions.isEmpty() ||
                employee.permissions.contains(StorePermission.PROCESS_SALES)
            if (!allowed) {
                _sendStatus.value = "You do not have permission to process sales"
                return
            }
        }

        if (posId.isBlank()) {
            _sendStatus.value = "Select a POS counter first"
            return
        }

        viewModelScope.launch {
            _sendStatus.value = "Sending..."
            val format = _pendingBarcodeFormat.value
            val queued = scanSyncManager.queueScan(
                storeId = store.id,
                deviceId = deviceId,
                employeeId = empId,
                employeeName = empName,
                barcode = barcode,
                format = format,
                targetPosId = posId,
                targetPosName = posName,
                scanMode = mode,
                autoSync = false
            )
            val sent = scanSyncManager.syncPendingScansAndWait()

            // Explicit SEND accepted this barcode. Clear the staging slot so
            // the same scan cannot accidentally be sent twice.
            _pendingBarcode.value = null
            _pendingBarcodeFormat.value = "EAN_13"

            _sendStatus.value = if (sent) {
                "Sent to $posName"
            } else if (!isOnline.value) {
                "Saved offline — will send when online"
            } else {
                "Queued — delivery will retry automatically"
            }

            val scanEvent = ScanEvent(
                id = queued.id,
                scanId = queued.id,
                storeId = store.id,
                deviceId = deviceId,
                scannerDeviceId = deviceId,
                employeeId = empId,
                employeeName = empName,
                barcode = barcode,
                format = format,
                targetPosId = posId,
                targetPosName = posName,
                scanMode = mode,
                status = "PENDING",
                processed = false,
                timestamp = System.currentTimeMillis()
            )
            _lastScannedEvent.value = scanEvent
            _recentScans.value = listOf(scanEvent) + _recentScans.value.take(19)
        }
    }


    fun triggerSyncNow() {
        scanSyncManager.syncPendingScans()
        syncManager.triggerSync()
    }

    fun requestAdminAccess(email: String) {
        val store = _activeStore.value ?: return
        viewModelScope.launch {
            _adminRequestMessage.value = "Sending access request..."
            val result = deviceRepo.requestAdminAccess(
                storeId = store.id,
                deviceId = deviceId,
                deviceName = DeviceIdManager.getDeviceName(getApplication()),
                userEmail = email
            )
            if (result.isSuccess) {
                val req = result.getOrNull()
                _adminAccessRequest.value = req
                _adminRequestMessage.value = "Admin access requested. Waiting for store approval."
                if (req != null) {
                    deviceRepo.observeAccessRequest(store.id, req.id).collect { updatedReq ->
                        _adminAccessRequest.value = updatedReq
                        if (updatedReq?.status == "APPROVED") {
                            _adminRequestMessage.value = "Admin access APPROVED! You now have store management rights."
                        } else if (updatedReq?.status == "REJECTED") {
                            _adminRequestMessage.value = "Admin access request was REJECTED by the store owner."
                        }
                    }
                }
            } else {
                _adminRequestMessage.value = "Error requesting admin access: ${result.exceptionOrNull()?.localizedMessage}"
            }
        }
    }

    fun isStoreAdmin(): Boolean {
        val user = currentUser.value ?: return false
        val store = activeStore.value ?: return false
        if (store.ownerId == user.uid) return true
        val myEmp = _storeEmployees.value.find { it.uid == user.uid || it.email.equals(user.email, ignoreCase = true) }
        return myEmp?.role == Role.ADMIN.name
    }

    fun isDeviceApproved(): Boolean {
        return _currentDevice.value?.status == DeviceStatus.APPROVED.name
    }

    private fun startHeartbeat() {
        heartbeatJob?.cancel()
        heartbeatJob = viewModelScope.launch {
            while (isActive) {
                val store = _activeStore.value
                if (store != null) {
                    deviceRepo.updateHeartbeat(
                        storeId = store.id,
                        deviceId = deviceId,
                        employeeName = _activeEmployee.value?.name ?: "",
                        connectedPosId = _targetPosId.value,
                        connectedPosName = _targetPosName.value,
                        isOnline = networkMonitor.isCurrentlyConnected()
                    )
                }
                delay(30_000L) // 30-second heartbeat interval
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        heartbeatJob?.cancel()
        FeedbackHelper.release()
    }
}
