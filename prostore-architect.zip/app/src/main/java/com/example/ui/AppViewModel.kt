package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.bluetooth.BleConnectionState
import com.example.bluetooth.BleGattServerManager
import com.example.data.firebase.FirebaseManager
import com.example.data.model.AccessRequest
import com.example.data.model.Device
import com.example.data.model.DeviceStatus
import com.example.data.model.DeviceType
import com.example.data.model.Employee
import com.example.data.model.Product
import com.example.data.model.Role
import com.example.data.model.ScanEvent
import com.example.data.model.Store
import com.example.data.repository.AuthRepository
import com.example.data.repository.DeviceRepository
import com.example.data.repository.EmployeeRepository
import com.example.data.repository.ProductRepository
import com.example.data.repository.SalesRepository
import com.example.data.repository.ScanEventRepository
import com.example.data.repository.StoreRepository
import com.example.data.sync.ScanSyncManager
import com.example.data.sync.ScanSyncStatus
import com.example.data.sync.SyncManager
import com.example.network.LocalBridgeManager
import com.example.util.DeviceIdManager
import com.example.util.FeedbackHelper
import com.example.util.NetworkMonitor
import com.example.util.ParsedScaleBarcode
import com.example.util.ScaleBarcodeParser
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

enum class ScannerOperationMode {
    INSTANT_BEAM,   // Zero-lag continuous scanning, beams immediately over BLE + LAN + Cloud
    STAGED_CONFIRM, // Staged confirmation preview card before sending
    BATCH_COUNT     // Accumulate scans with quantities before bulk beaming
}

data class BatchScanItem(
    val id: String = UUID.randomUUID().toString(),
    val barcode: String,
    val format: String = "EAN_13",
    var quantity: Int = 1,
    val product: Product? = null,
    val scaleInfo: ParsedScaleBarcode? = null,
    val timestamp: Long = System.currentTimeMillis()
)

class AppViewModel(application: Application) : AndroidViewModel(application) {
    val authRepo = AuthRepository()
    val storeRepo = StoreRepository()
    val deviceRepo = DeviceRepository()
    val employeeRepo = EmployeeRepository()
    val productRepo = ProductRepository()
    val scanEventRepo = ScanEventRepository()
    val networkMonitor = NetworkMonitor(application)
    val salesRepo = SalesRepository(application, networkMonitor)
    val syncManager = SyncManager(application, networkMonitor, salesRepo)
    val scanSyncManager = ScanSyncManager(application, networkMonitor, scanEventRepo)

    // Bluetooth Low Energy GATT Server & Local Network Bridge & SPP Manager
    val bleServerManager = BleGattServerManager(application)
    val localBridgeManager = LocalBridgeManager(application)
    val sppScannerManager = com.example.bluetooth.BluetoothSppScannerManager(application)

    val bleConnectionState: StateFlow<BleConnectionState> = bleServerManager.connectionState
    val sppConnectionState = sppScannerManager.connectionState
    val isBleAdvertising: StateFlow<Boolean> = bleServerManager.isAdvertising
    val bleConnectedCount: StateFlow<Int> = bleServerManager.connectedCount
    val lastBeamedCode: StateFlow<String?> = bleServerManager.lastBeamedCode

    val isOnline: StateFlow<Boolean> = networkMonitor.isOnline
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), networkMonitor.isCurrentlyConnected())

    val scanSyncStatus: StateFlow<ScanSyncStatus> = scanSyncManager.syncStatus
    val pendingScansCount: StateFlow<Int> = scanSyncManager.pendingCountFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _isFirebaseConfigured = MutableStateFlow(true)
    val isFirebaseConfigured: StateFlow<Boolean> = _isFirebaseConfigured.asStateFlow()

    val currentUser: StateFlow<FirebaseUser?> = authRepo.currentUserFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _userStores = MutableStateFlow<List<Store>>(emptyList())
    val userStores: StateFlow<List<Store>> = _userStores.asStateFlow()

    private val _activeStore = MutableStateFlow<Store?>(null)
    val activeStore: StateFlow<Store?> = _activeStore.asStateFlow()

    private val _currentDevice = MutableStateFlow<Device?>(null)
    val currentDevice: StateFlow<Device?> = _currentDevice.asStateFlow()

    private val _activeEmployee = MutableStateFlow<Employee?>(null)
    val activeEmployee: StateFlow<Employee?> = _activeEmployee.asStateFlow()

    private val _storeEmployees = MutableStateFlow<List<Employee>>(emptyList())
    val storeEmployees: StateFlow<List<Employee>> = _storeEmployees.asStateFlow()

    private val _approvedPosDevices = MutableStateFlow<List<Device>>(emptyList())
    val approvedPosDevices: StateFlow<List<Device>> = _approvedPosDevices.asStateFlow()

    private val _targetPosId = MutableStateFlow<String>(DeviceIdManager.getTargetPosId(application) ?: "")
    val targetPosId: StateFlow<String> = _targetPosId.asStateFlow()

    private val _targetPosName = MutableStateFlow<String>(DeviceIdManager.getTargetPosName(application))
    val targetPosName: StateFlow<String> = _targetPosName.asStateFlow()

    private val _recentScans = MutableStateFlow<List<ScanEvent>>(emptyList())
    val recentScans: StateFlow<List<ScanEvent>> = _recentScans.asStateFlow()

    private val _lastScannedEvent = MutableStateFlow<ScanEvent?>(null)
    val lastScannedEvent: StateFlow<ScanEvent?> = _lastScannedEvent.asStateFlow()

    private val _lastScannedProduct = MutableStateFlow<Product?>(null)
    val lastScannedProduct: StateFlow<Product?> = _lastScannedProduct.asStateFlow()

    // Scanning Operation Mode (Instant Beam vs Staged Confirm vs Batch Count)
    private val _scannerMode = MutableStateFlow(ScannerOperationMode.INSTANT_BEAM)
    val scannerMode: StateFlow<ScannerOperationMode> = _scannerMode.asStateFlow()

    // Batch Scans Collection
    private val _batchItems = MutableStateFlow<List<BatchScanItem>>(emptyList())
    val batchItems: StateFlow<List<BatchScanItem>> = _batchItems.asStateFlow()

    // Barcode staging for confirmation before sending
    private val _stagedBarcode = MutableStateFlow<String?>(null)
    val stagedBarcode: StateFlow<String?> = _stagedBarcode.asStateFlow()

    private val _stagedFormat = MutableStateFlow<String>("EAN_13")
    val stagedFormat: StateFlow<String> = _stagedFormat.asStateFlow()

    private val _stagedProduct = MutableStateFlow<Product?>(null)
    val stagedProduct: StateFlow<Product?> = _stagedProduct.asStateFlow()

    private val _stagedScaleInfo = MutableStateFlow<ParsedScaleBarcode?>(null)
    val stagedScaleInfo: StateFlow<ParsedScaleBarcode?> = _stagedScaleInfo.asStateFlow()

    private val _isCounterConfirmed = MutableStateFlow<Boolean>(false)
    val isCounterConfirmed: StateFlow<Boolean> = _isCounterConfirmed.asStateFlow()

    private val _adminAccessRequest = MutableStateFlow<AccessRequest?>(null)
    val adminAccessRequest: StateFlow<AccessRequest?> = _adminAccessRequest.asStateFlow()

    private val _adminRequestMessage = MutableStateFlow<String?>(null)
    val adminRequestMessage: StateFlow<String?> = _adminRequestMessage.asStateFlow()

    // Scanner preferences
    val scanSoundEnabled = MutableStateFlow(DeviceIdManager.isSoundEnabled(application))
    val vibrationEnabled = MutableStateFlow(DeviceIdManager.isVibrationEnabled(application))
    val cooldownMs = MutableStateFlow(150L)
    val autoScanEnabled = MutableStateFlow(DeviceIdManager.isAutoScanEnabled(application))

    val deviceId = DeviceIdManager.getDeviceId(application)
    val deviceName = DeviceIdManager.getDeviceName(application)

    private var heartbeatJob: Job? = null
    private var deviceObserveJob: Job? = null
    private var employeesJob: Job? = null
    private var posDevicesJob: Job? = null

    init {
        FirebaseManager.initialize(application)

        // Observe logged in user stores and auto-select to bypass selector overhead
        viewModelScope.launch {
            currentUser.collect { user ->
                if (user != null) {
                    storeRepo.getStoresForUser(user.uid).collect { stores ->
                        _userStores.value = stores
                        if (stores.isNotEmpty() && _activeStore.value == null) {
                            val firstStore = stores.first()
                            setActiveStore(firstStore)
                            // Auto-confirm target counter to go straight to scanner
                            _isCounterConfirmed.value = true
                        } else if (stores.isEmpty() && _activeStore.value == null) {
                            // If no stores exist, auto-create a default scanner store to bypass selector!
                            viewModelScope.launch {
                                val result = storeRepo.createStore(
                                    name = "Main Scanner Store",
                                    ownerId = user.uid
                                )
                                if (result.isSuccess) {
                                    val defaultStore = result.getOrNull()!!
                                    setActiveStore(defaultStore)
                                    _isCounterConfirmed.value = true
                                }
                            }
                        }
                    }
                } else {
                    _userStores.value = emptyList()
                }
            }
        }

        // Restore active store from local preference if present
        val savedStoreId = DeviceIdManager.getActiveStoreId(application)
        if (!savedStoreId.isNullOrBlank()) {
            loadStoreById(savedStoreId)
            // Auto-confirm target counter to go straight to scanner on restore
            _isCounterConfirmed.value = true
        }

        startHeartbeat()

        // Automatically start BLE GATT Server on startup if permissions available
        if (bleServerManager.hasRequiredPermissions() && bleServerManager.isBluetoothEnabled()) {
            bleServerManager.startGattServer(deviceName)
        }
    }

    fun setScannerMode(mode: ScannerOperationMode) {
        _scannerMode.value = mode
    }

    fun startBleAdvertising(): Boolean {
        return bleServerManager.startGattServer(deviceName)
    }

    fun stopBleAdvertising() {
        bleServerManager.stopGattServer()
    }

    fun configureFirebase(projectId: String, appId: String, apiKey: String): Boolean {
        val success = FirebaseManager.saveConfiguration(getApplication(), projectId, appId, apiKey)
        _isFirebaseConfigured.value = success
        return success
    }

    fun loadStoreById(storeId: String) {
        viewModelScope.launch {
            val store = storeRepo.getStoreOnce(storeId)
            if (store != null) {
                setActiveStore(store)
            } else {
                val savedName = DeviceIdManager.getActiveStoreName(getApplication())
                val fallbackStore = Store(id = storeId, name = if (savedName.isNotBlank()) savedName else "Store ($storeId)")
                setActiveStore(fallbackStore)
            }
        }
    }

    fun switchDeviceRole(newRole: DeviceType) {
        DeviceIdManager.setDeviceRole(getApplication(), newRole.name)
        activeStore.value?.let { registerAndObserveDevice(it.id) }
    }

    fun setActiveStore(store: Store?) {
        _activeStore.value = store
        DeviceIdManager.setActiveStoreId(getApplication(), store?.id)
        DeviceIdManager.setActiveStoreName(getApplication(), store?.name ?: "")

        deviceObserveJob?.cancel()
        employeesJob?.cancel()
        posDevicesJob?.cancel()

        if (store != null) {
            registerAndObserveDevice(store.id)
            observeStoreEmployees(store.id)
            observeStorePosDevices(store.id)

            val savedEmpId = DeviceIdManager.getCurrentEmployeeId(getApplication())
            val savedEmpName = DeviceIdManager.getCurrentEmployeeName(getApplication())
            if (!savedEmpId.isNullOrBlank() && savedEmpName.isNotBlank()) {
                _activeEmployee.value = Employee(id = savedEmpId, name = savedEmpName, storeId = store.id)
            }
        } else {
            _currentDevice.value = null
            _activeEmployee.value = null
            _storeEmployees.value = emptyList()
            _approvedPosDevices.value = emptyList()
        }
    }

    fun registerAndObserveDevice(storeId: String) {
        deviceObserveJob?.cancel()
        deviceObserveJob = viewModelScope.launch {
            val currentName = DeviceIdManager.getDeviceName(getApplication())
            deviceRepo.registerDevice(storeId, deviceId, currentName, DeviceType.SCANNER)

            deviceRepo.observeDevice(storeId, deviceId).collect { dev ->
                _currentDevice.value = dev
            }
        }
    }

    private fun observeStoreEmployees(storeId: String) {
        employeesJob?.cancel()
        employeesJob = viewModelScope.launch {
            employeeRepo.getEmployees(storeId).collect { employees ->
                _storeEmployees.value = employees
                val user = currentUser.value
                val current = _activeEmployee.value

                // If user logged in and we don't have activeEmployee set matching them, auto-select matching profile!
                if (user != null && (current == null || current.uid != user.uid)) {
                    val matchingEmp = employees.find { it.uid == user.uid || it.email.equals(user.email, ignoreCase = true) }
                    if (matchingEmp != null) {
                        _activeEmployee.value = matchingEmp
                        DeviceIdManager.setCurrentEmployee(getApplication(), matchingEmp.id, matchingEmp.name)
                    } else if (current == null && employees.isNotEmpty()) {
                        // Fallback to first employee if none match exactly
                        val firstEmp = employees.first()
                        _activeEmployee.value = firstEmp
                        DeviceIdManager.setCurrentEmployee(getApplication(), firstEmp.id, firstEmp.name)
                    }
                } else if (current != null) {
                    val refreshed = employees.find { it.id == current.id }
                    if (refreshed != null) {
                        _activeEmployee.value = refreshed
                    }
                }
            }
        }
    }

    private fun observeStorePosDevices(storeId: String) {
        posDevicesJob?.cancel()
        posDevicesJob = viewModelScope.launch {
            deviceRepo.observeApprovedPosDevices(storeId).collect { posList ->
                _approvedPosDevices.value = posList
                if (_targetPosId.value.isBlank() && posList.isNotEmpty()) {
                    setTargetPos(posList.first())
                }
            }
        }
    }

    fun loginWithStoreIdAndPin(
        storeId: String,
        pinCode: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val trimmedStore = storeId.trim()
            val trimmedPin = pinCode.trim()
            if (trimmedStore.isBlank() || trimmedPin.isBlank()) {
                onError("Please enter Store ID and Employee PIN Code.")
                return@launch
            }
            val emp = employeeRepo.getEmployeeByPin(trimmedStore, trimmedPin)
            if (emp != null) {
                val store = storeRepo.getStoreOnce(trimmedStore) ?: Store(id = trimmedStore, name = "Store $trimmedStore")
                setActiveStore(store)
                _activeEmployee.value = emp
                DeviceIdManager.setCurrentEmployee(getApplication(), emp.id, emp.name)
                FeedbackHelper.playBarcodeMatchFeedback(getApplication())
                onSuccess()
            } else {
                FeedbackHelper.playErrorBeep(getApplication())
                onError("Invalid Store ID or Employee PIN Code. Please verify credentials.")
            }
        }
    }

    fun verifyAndSelectEmployee(
        employee: Employee,
        inputPin: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            if (employee.status == "DISABLED") {
                onError("This employee account is disabled.")
                return@launch
            }
            if (employee.pin.isNotBlank() && employee.pin.trim() != inputPin.trim()) {
                FeedbackHelper.playErrorBeep(getApplication())
                onError("Incorrect PIN. Please try again.")
                return@launch
            }

            _activeEmployee.value = employee
            DeviceIdManager.setCurrentEmployee(getApplication(), employee.id, employee.name)
            onSuccess()
        }
    }

    /**
     * Entry point for external Bluetooth HID keypress streams & Bluetooth SPP laser readers
     */
    fun onExternalBarcodeScanned(barcode: String, format: String = "EAN_13") {
        onBarcodeDetected(barcode, format)
    }

    fun logoutEmployee() {
        _activeEmployee.value = null
        DeviceIdManager.setCurrentEmployee(getApplication(), null, null)
    }

    fun setTargetPos(posDevice: Device) {
        _targetPosId.value = posDevice.deviceId
        _targetPosName.value = posDevice.deviceName
        DeviceIdManager.setTargetPosId(getApplication(), posDevice.deviceId)
        DeviceIdManager.setTargetPosName(getApplication(), posDevice.deviceName)
        _isCounterConfirmed.value = true
    }

    fun selectTargetCounter(id: String, name: String) {
        _targetPosId.value = id
        _targetPosName.value = name
        DeviceIdManager.setTargetPosId(getApplication(), id)
        DeviceIdManager.setTargetPosName(getApplication(), name)
        _isCounterConfirmed.value = true
    }

    fun resetCounterSelection() {
        _isCounterConfirmed.value = false
    }

    /**
     * Handles Camera barcode scan event depending on current operation mode
     */
    fun onBarcodeDetected(barcode: String, format: String) {
        when (_scannerMode.value) {
            ScannerOperationMode.INSTANT_BEAM -> {
                // Instant zero-lag beaming directly to POS
                processBarcodeScanned(barcode, format)
            }
            ScannerOperationMode.STAGED_CONFIRM -> {
                // Stage for visual confirmation before transmitting
                stageBarcodeForConfirmation(barcode, format)
            }
            ScannerOperationMode.BATCH_COUNT -> {
                // Accumulate to batch
                addToBatch(barcode, format)
            }
        }
    }

    fun stageBarcodeForConfirmation(barcode: String, format: String = "EAN_13") {
        val trimmed = barcode.trim()
        if (trimmed.isBlank()) return

        FeedbackHelper.playBeep(getApplication())
        FeedbackHelper.vibrate(getApplication(), 40L)

        _stagedBarcode.value = trimmed
        _stagedFormat.value = format
        _stagedScaleInfo.value = ScaleBarcodeParser.parse(trimmed)
        _stagedProduct.value = null

        val store = _activeStore.value
        if (store != null) {
            val effectiveStoreId = store.id.ifBlank { store.storeId }
            viewModelScope.launch {
                try {
                    val product = productRepo.findProductByBarcode(effectiveStoreId, trimmed)
                    if (_stagedBarcode.value == trimmed) {
                        _stagedProduct.value = product
                    }
                } catch (_: Exception) {}
            }
        }
    }

    fun cancelStagedBarcode() {
        _stagedBarcode.value = null
        _stagedProduct.value = null
        _stagedScaleInfo.value = null
    }

    fun sendStagedBarcode() {
        val barcode = _stagedBarcode.value ?: return
        val format = _stagedFormat.value
        _stagedBarcode.value = null
        _stagedProduct.value = null
        _stagedScaleInfo.value = null
        processBarcodeScanned(barcode, format)
    }

    /**
     * Batch Scanning Operations
     */
    fun addToBatch(barcode: String, format: String = "EAN_13") {
        val trimmed = barcode.trim()
        if (trimmed.isBlank()) return

        FeedbackHelper.playConfirmBeep(getApplication())
        FeedbackHelper.vibrate(getApplication(), 45L)

        val currentList = _batchItems.value.toMutableList()
        val existingIndex = currentList.indexOfFirst { it.barcode == trimmed }

        if (existingIndex >= 0) {
            val existing = currentList[existingIndex]
            currentList[existingIndex] = existing.copy(quantity = existing.quantity + 1)
        } else {
            val scaleInfo = ScaleBarcodeParser.parse(trimmed)
            currentList.add(0, BatchScanItem(
                barcode = trimmed,
                format = format,
                quantity = 1,
                scaleInfo = scaleInfo
            ))
        }
        _batchItems.value = currentList
    }

    fun updateBatchItemQuantity(id: String, delta: Int) {
        val currentList = _batchItems.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == id }
        if (index >= 0) {
            val item = currentList[index]
            val newQty = item.quantity + delta
            if (newQty <= 0) {
                currentList.removeAt(index)
            } else {
                currentList[index] = item.copy(quantity = newQty)
            }
            _batchItems.value = currentList
        }
    }

    fun clearBatch() {
        _batchItems.value = emptyList()
    }

    fun transmitBatchAll() {
        val items = _batchItems.value
        if (items.isEmpty()) return

        viewModelScope.launch {
            for (item in items) {
                repeat(item.quantity) {
                    processBarcodeScanned(item.barcode, item.format)
                    delay(50L) // Micro-delay between rapid burst transmissions
                }
            }
            FeedbackHelper.playConfirmBeep(getApplication())
            clearBatch()
        }
    }

    fun updateScannerName(newName: String) {
        DeviceIdManager.setDeviceName(getApplication(), newName)
        val store = _activeStore.value ?: return
        viewModelScope.launch {
            deviceRepo.registerDevice(store.id, deviceId, newName, DeviceType.SCANNER)
        }
    }

    fun toggleSound(enabled: Boolean) {
        scanSoundEnabled.value = enabled
        DeviceIdManager.setSoundEnabled(getApplication(), enabled)
    }

    fun toggleVibration(enabled: Boolean) {
        vibrationEnabled.value = enabled
        DeviceIdManager.setVibrationEnabled(getApplication(), enabled)
    }

    fun setCooldown(ms: Long) {
        cooldownMs.value = ms
        DeviceIdManager.setCooldownMs(getApplication(), ms)
    }

    fun toggleAutoScan(enabled: Boolean) {
        autoScanEnabled.value = enabled
        DeviceIdManager.setAutoScanEnabled(getApplication(), enabled)
    }

    fun disconnectDevice() {
        DeviceIdManager.disconnectDevice(getApplication())
        setActiveStore(null)
    }

    /**
     * Multi-Channel Zero-Lag Barcode Dispatch Engine:
     * 1. Bluetooth Low Energy (BLE) GATT Server notification to CorePOS Web Terminal via Web Bluetooth.
     * 2. Local Wi-Fi / LAN UDP broadcast packet for zero-config offline network terminals.
     * 3. Cloud Firestore real-time scan event sync (and Room DB local queue if temporarily offline).
     */
    fun processBarcodeScanned(barcode: String, format: String = "EAN_13") {
        val trimmed = barcode.trim()
        if (trimmed.isBlank()) return

        // 1. Audio beep feedback (800Hz) and haptic vibration (80ms) on barcode match
        FeedbackHelper.playBarcodeMatchFeedback(getApplication())

        val store = _activeStore.value
        val effectiveStoreId = store?.id?.ifBlank { store.storeId } ?: "offline_store"
        val employee = _activeEmployee.value
        val empId = employee?.id ?: ""
        val empUid = currentUser.value?.uid ?: employee?.effectiveUid ?: empId
        val empName = employee?.name ?: "Mobile Cashier"
        val empRole = employee?.role ?: "CASHIER"
        val posId = _targetPosId.value
        val posName = _targetPosName.value

        // Role Permission Routing Configuration
        val canSell = employee?.effectiveCanSell ?: true
        val canManageInventory = employee?.effectiveCanManageInventory ?: false
        val canProcessReturns = employee?.effectiveCanProcessReturns ?: false

        // Determine destination POS based on employee role permissions
        val targetPosDevId = when {
            canSell -> if (posId.isBlank()) "ALL" else posId
            canManageInventory -> "INVENTORY"
            canProcessReturns -> "RETURNS"
            else -> "ALL"
        }

        // CHANNEL 1: BLE GATT Notification (Nordic UART + Serial FFE1) ending with \r\n
        bleServerManager.beamBarcode(trimmed)

        // CHANNEL 2: Local LAN / Wi-Fi UDP Broadcast Packet (Offline fallback bridge)
        localBridgeManager.broadcastScanPacket(
            barcode = trimmed,
            deviceName = deviceName,
            storeId = effectiveStoreId,
            targetPosId = targetPosDevId,
            format = format
        )

        // Local instant scan event representation
        val localScanEvent = ScanEvent(
            id = UUID.randomUUID().toString(),
            storeId = effectiveStoreId,
            barcode = trimmed,
            deviceId = deviceId,
            employeeId = empId,
            employeeUid = empUid,
            employeeName = empName,
            scannerRole = empRole,
            targetPosId = targetPosDevId,
            targetPosDeviceId = targetPosDevId,
            targetPosName = posName,
            format = format,
            timestamp = System.currentTimeMillis()
        )
        _lastScannedEvent.value = localScanEvent
        _recentScans.value = (listOf(localScanEvent) + _recentScans.value).take(25)

        // CHANNEL 3: Firestore Cloud Event / Local Room DB queue
        viewModelScope.launch {
            if (store != null) {
                try {
                    val foundProduct = productRepo.findProductByBarcode(effectiveStoreId, trimmed)
                    _lastScannedProduct.value = foundProduct
                } catch (_: Exception) {}

                val emitResult = scanEventRepo.emitScanEvent(
                    storeId = effectiveStoreId,
                    barcode = trimmed,
                    deviceId = deviceId,
                    employeeId = empId,
                    employeeUid = empUid,
                    employeeName = empName,
                    scannerRole = empRole,
                    targetPosId = targetPosDevId,
                    targetPosName = posName,
                    format = format
                )

                if (emitResult.isFailure) {
                    scanSyncManager.queueScan(
                        storeId = effectiveStoreId,
                        deviceId = deviceId,
                        employeeId = empId,
                        employeeName = empName,
                        barcode = trimmed,
                        format = format,
                        targetPosId = targetPosDevId,
                        targetPosName = posName
                    )
                }
            }
        }
    }

    fun triggerSyncNow() {
        scanSyncManager.syncPendingScans()
        syncManager.triggerSync()
    }

    fun requestAdminAccess(email: String) {
        val store = _activeStore.value ?: return
        viewModelScope.launch {
            _adminRequestMessage.value = "Sending access request..."
            val result = deviceRepo.requestAdminAccess(
                storeId = store.id,
                deviceId = deviceId,
                deviceName = DeviceIdManager.getDeviceName(getApplication()),
                userEmail = email
            )
            if (result.isSuccess) {
                val req = result.getOrNull()
                _adminAccessRequest.value = req
                _adminRequestMessage.value = "Admin access requested. Waiting for store approval."
                if (req != null) {
                    deviceRepo.observeAccessRequest(store.id, req.id).collect { updatedReq ->
                        _adminAccessRequest.value = updatedReq
                        if (updatedReq?.status == "APPROVED") {
                            _adminRequestMessage.value = "Admin access APPROVED! You now have store management rights."
                        } else if (updatedReq?.status == "REJECTED") {
                            _adminRequestMessage.value = "Admin access request was REJECTED by the store owner."
                        }
                    }
                }
            } else {
                _adminRequestMessage.value = "Error requesting admin access: ${result.exceptionOrNull()?.localizedMessage}"
            }
        }
    }

    fun isStoreAdmin(): Boolean {
        val user = currentUser.value ?: return false
        val store = activeStore.value ?: return false
        if (store.ownerId == user.uid) return true
        val myEmp = _storeEmployees.value.find { it.uid == user.uid || it.email.equals(user.email, ignoreCase = true) }
        return myEmp?.role == Role.ADMIN.name
    }

    fun isDeviceApproved(): Boolean {
        return _currentDevice.value?.status == DeviceStatus.APPROVED.name
    }

    private fun startHeartbeat() {
        heartbeatJob?.cancel()
        heartbeatJob = viewModelScope.launch {
            while (isActive) {
                val store = _activeStore.value
                if (store != null) {
                    deviceRepo.updateHeartbeat(
                        storeId = store.id,
                        deviceId = deviceId,
                        employeeName = _activeEmployee.value?.name ?: "",
                        connectedPosId = _targetPosId.value,
                        connectedPosName = _targetPosName.value,
                        isOnline = networkMonitor.isCurrentlyConnected()
                    )
                }
                delay(30_000L)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        heartbeatJob?.cancel()
        bleServerManager.stopGattServer()
        localBridgeManager.release()
        FeedbackHelper.release()
    }
}
