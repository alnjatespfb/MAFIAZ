package com.example.ui.scanner

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.Product
import com.example.data.model.ScanEvent
import com.example.data.model.Store
import com.example.data.sync.ScanSyncStatus
import com.example.ui.AppViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScannerScreen(
    store: Store,
    appViewModel: AppViewModel,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    val isOnline by appViewModel.isOnline.collectAsState()
    val syncStatus by appViewModel.scanSyncStatus.collectAsState()
    val pendingScansCount by appViewModel.pendingScansCount.collectAsState()
    val activeEmployee by appViewModel.activeEmployee.collectAsState()
    val targetPosName by appViewModel.targetPosName.collectAsState()
    val targetPosId by appViewModel.targetPosId.collectAsState()
    val approvedPosList by appViewModel.approvedPosDevices.collectAsState()
    val autoScanEnabled by appViewModel.autoScanEnabled.collectAsState()
    val cooldownMs by appViewModel.cooldownMs.collectAsState()
    val recentScans by appViewModel.recentScans.collectAsState()
    val lastScannedEvent by appViewModel.lastScannedEvent.collectAsState()
    val lastScannedProduct by appViewModel.lastScannedProduct.collectAsState()
    val pendingBarcode by appViewModel.pendingBarcode.collectAsState()
    val scanMode by appViewModel.scanMode.collectAsState()
    val sendStatus by appViewModel.sendStatus.collectAsState()

    var isTorchEnabled by remember { mutableStateOf(false) }
    var showPosDialog by remember { mutableStateOf(false) }
    var showManualInputDialog by remember { mutableStateOf(false) }
    var manualBarcodeInput by remember { mutableStateOf("") }
    var showRecentScansSheet by remember { mutableStateOf(false) }

    // Camera permission check
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = appViewModel.deviceName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = store.name,
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "Operator: ${activeEmployee?.name ?: "Ahmed"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                actions = {
                    // Real-time Connectivity Badge
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = when {
                            !isOnline -> Color(0xFFFF8F00)
                            syncStatus is ScanSyncStatus.Syncing -> MaterialTheme.colorScheme.tertiary
                            else -> Color(0xFF00C853)
                        },
                        modifier = Modifier.padding(end = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = when {
                                    !isOnline -> Icons.Default.WifiOff
                                    syncStatus is ScanSyncStatus.Syncing -> Icons.Default.Sync
                                    else -> Icons.Default.Wifi
                                },
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = when {
                                    !isOnline -> if (pendingScansCount > 0) "Offline ($pendingScansCount)" else "Offline"
                                    syncStatus is ScanSyncStatus.Syncing -> "Syncing"
                                    else -> "Online"
                                },
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier.testTag("open_settings_button")
                    ) {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color.Black)
        ) {
            // 1. Camera Viewfinder or Permission Rationale
            if (hasCameraPermission) {
                CameraPreviewView(
                    modifier = Modifier.fillMaxSize(),
                    isTorchEnabled = isTorchEnabled,
                    isScanningActive = autoScanEnabled && pendingBarcode == null,
                    cooldownMs = cooldownMs,
                    onBarcodeScanned = { barcode, format ->
                        appViewModel.processBarcodeScanned(barcode, format)
                    }
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.surface),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(32.dp)
                    ) {
                        Icon(
                            Icons.Default.PhotoCamera,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Camera Permission Required",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "The wireless scanner requires camera access to scan retail product barcodes.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                            modifier = Modifier.testTag("grant_camera_permission_button")
                        ) {
                            Text("Grant Camera Access")
                        }
                    }
                }
            }

            // 2. Top POS Route & Status Pill
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // POS Target Chip
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (targetPosId.isNotBlank()) Color(0xCC000000) else Color(0xDDB71C1C),
                    modifier = Modifier
                        .clickable { showPosDialog = true }
                        .align(Alignment.CenterHorizontally)
                        .testTag("target_pos_badge")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (targetPosId.isNotBlank()) Icons.Default.PointOfSale else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (targetPosId.isNotBlank()) Color(0xFF00E676) else Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (targetPosId.isNotBlank()) "Target POS: $targetPosName" else "POS connection unavailable",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.labelMedium
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            Icons.Default.ArrowDropDown,
                            contentDescription = "Switch",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Recent Scan Confirmation Banner
                AnimatedVisibility(
                    visible = lastScannedEvent != null,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    lastScannedEvent?.let { event ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xEE1E1E1E)),
                            modifier = Modifier.fillMaxWidth().testTag("scan_confirmation_card")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        shape = CircleShape,
                                        color = Color(0xFF00C853),
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                Icons.Default.Check,
                                                contentDescription = null,
                                                tint = Color.Black,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = if (lastScannedProduct != null) {
                                                "${lastScannedProduct?.name} (${String.format(Locale.US, "$%.2f", lastScannedProduct?.price)})"
                                            } else {
                                                "Barcode: ${event.barcode}"
                                            },
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            text = "Sent to ${if (targetPosName.isNotBlank()) targetPosName else "Store POS"}",
                                            color = Color(0xFF00E676),
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                }

                                Text(
                                    text = event.barcode,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFFAAAAAA),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
            }

            // Scan mode: normal sale scan or privileged product-add scan.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .align(Alignment.TopCenter),
                horizontalArrangement = Arrangement.Center
            ) {
                SingleChoiceSegmentedButtonRow {
                    SegmentedButton(
                        selected = scanMode == "SALE",
                        onClick = { appViewModel.setScanMode("SALE") },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                    ) {
                        Text("Calculate / Sale")
                    }
                    SegmentedButton(
                        selected = scanMode == "ADD_PRODUCT",
                        onClick = { appViewModel.setScanMode("ADD_PRODUCT") },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                        enabled = run {
                            val e = activeEmployee
                            e != null && (e.role == "ADMIN" || e.role == "MANAGER" ||
                                e.permissions.contains("MANAGE_INVENTORY"))
                        }
                    ) {
                        Text("Add Product")
                    }
                }
            }

            // 3. Side Quick Controls (Torch, Manual Input, Auto-Scan Toggle, Recent List)
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Torch Toggle
                FilledIconButton(
                    onClick = { isTorchEnabled = !isTorchEnabled },
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = if (isTorchEnabled) Color(0xFFFFD54F) else Color(0x99222222),
                        contentColor = if (isTorchEnabled) Color.Black else Color.White
                    ),
                    modifier = Modifier.size(52.dp).testTag("torch_toggle_button")
                ) {
                    Icon(
                        imageVector = if (isTorchEnabled) Icons.Default.FlashOn else Icons.Default.FlashOff,
                        contentDescription = "Flashlight"
                    )
                }

                // Manual Barcode Entry (for damaged labels / tests)
                FilledIconButton(
                    onClick = {
                        manualBarcodeInput = ""
                        showManualInputDialog = true
                    },
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = Color(0x99222222),
                        contentColor = Color.White
                    ),
                    modifier = Modifier.size(52.dp).testTag("manual_barcode_button")
                ) {
                    Icon(Icons.Default.Edit, contentDescription = "Manual Barcode Entry")
                }

                // Recent Scans History Sheet
                FilledIconButton(
                    onClick = { showRecentScansSheet = true },
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = Color(0x99222222),
                        contentColor = Color.White
                    ),
                    modifier = Modifier.size(52.dp).testTag("history_button")
                ) {
                    BadgedBox(badge = {
                        if (recentScans.isNotEmpty()) {
                            Badge(containerColor = MaterialTheme.colorScheme.primary) {
                                Text(recentScans.size.toString())
                            }
                        }
                    }) {
                        Icon(Icons.Default.History, contentDescription = "Recent Scans")
                    }
                }
            }

            // 4. Large Visual Trigger Button at Bottom
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Button(
                    onClick = {
                        if (pendingBarcode != null) {
                            appViewModel.sendPendingScan()
                        } else {
                            showManualInputDialog = true
                        }
                    },
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00E676),
                        contentColor = Color.Black
                    ),
                    modifier = Modifier
                        .fillMaxWidth(0.72f)
                        .height(64.dp)
                        .testTag("scanner_trigger_button")
                ) {
                    Icon(
                        imageVector = if (pendingBarcode != null) Icons.Default.Send else Icons.Default.QrCodeScanner,
                        contentDescription = null,
                        modifier = Modifier.size(28.dp),
                        tint = Color.Black
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = if (pendingBarcode != null) "SEND" else "SCAN",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.2.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = when {
                        sendStatus != null -> sendStatus!!
                        pendingBarcode != null -> "Ready: $pendingBarcode — press SEND"
                        autoScanEnabled -> "Live Auto-Scan Active"
                        else -> "Trigger Mode Active"
                    },
                    color = if (pendingBarcode != null) Color(0xFFFFD54F) else Color.White.copy(alpha = 0.7f),
                    style = MaterialTheme.typography.labelSmall
                )
                if (pendingBarcode != null) {
                    TextButton(
                        onClick = { appViewModel.cancelPendingScan() },
                        colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
                    ) {
                        Text("Cancel scan")
                    }
                }
            }
        }
    }

    // Target POS Selection Dialog
    if (showPosDialog) {
        TargetPosSelectorDialog(
            currentPosId = targetPosId,
            availablePosDevices = approvedPosList,
            onSelectPos = { appViewModel.setTargetPos(it) },
            onDismiss = { showPosDialog = false }
        )
    }

    // Manual Barcode Input Dialog
    if (showManualInputDialog) {
        AlertDialog(
            onDismissRequest = { showManualInputDialog = false },
            title = { Text("Manual Barcode Entry", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Enter the barcode digits directly if the printed label is damaged or for testing:",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = manualBarcodeInput,
                        onValueChange = { manualBarcodeInput = it },
                        label = { Text("Barcode Number") },
                        placeholder = { Text("e.g. 6291234567890") },
                        modifier = Modifier.fillMaxWidth().testTag("manual_barcode_input"),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val code = manualBarcodeInput.trim()
                        if (code.isNotBlank()) {
                            appViewModel.processBarcodeScanned(code, "MANUAL")
                            showManualInputDialog = false
                        }
                    },
                    modifier = Modifier.testTag("submit_manual_barcode_button")
                ) {
                    Text("Scan / Prepare")
                }
            },
            dismissButton = {
                TextButton(onClick = { showManualInputDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Recent Scans Bottom Sheet
    if (showRecentScansSheet) {
        ModalBottomSheet(
            onDismissRequest = { showRecentScansSheet = false }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent Scans",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    if (pendingScansCount > 0) {
                        FilledTonalButton(
                            onClick = { appViewModel.triggerSyncNow() },
                            modifier = Modifier.testTag("sync_recent_scans_button")
                        ) {
                            Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Sync All ($pendingScansCount)")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (recentScans.isEmpty()) {
                    Text(
                        text = "No barcodes scanned yet in this session.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(vertical = 24.dp)
                    )
                } else {
                    val timeFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().heightIn(max = 320.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(recentScans, key = { it.id }) { scan ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = scan.barcode,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            text = "Time: ${timeFormat.format(Date(scan.timestamp))} • Format: ${scan.format}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (scan.syncedFromOffline) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.primaryContainer
                                    ) {
                                        Text(
                                            text = if (scan.syncedFromOffline) "Synced" else "Sent ✓",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (scan.syncedFromOffline) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onPrimaryContainer,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
