package com.example.ui.scanner

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.bluetooth.BleConnectionState
import com.example.data.model.Store
import com.example.data.sync.ScanSyncStatus
import com.example.ui.AppViewModel
import com.example.ui.ScannerOperationMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScannerScreen(
    store: Store,
    appViewModel: AppViewModel,
    onOpenSettings: () -> Unit = {},
    onSwitchCounter: () -> Unit = {},
    onSwitchStore: () -> Unit = {}
) {
    val context = LocalContext.current
    val isOnline by appViewModel.isOnline.collectAsState()
    val syncStatus by appViewModel.scanSyncStatus.collectAsState()
    val pendingScansCount by appViewModel.pendingScansCount.collectAsState()
    val activeEmployee by appViewModel.activeEmployee.collectAsState()
    val targetPosName by appViewModel.targetPosName.collectAsState()
    val targetPosId by appViewModel.targetPosId.collectAsState()
    val approvedPosList by appViewModel.approvedPosDevices.collectAsState()
    val autoScanEnabled by appViewModel.autoScanEnabled.collectAsState()
    val cooldownMs by appViewModel.cooldownMs.collectAsState()
    val recentScans by appViewModel.recentScans.collectAsState()
    val lastScannedEvent by appViewModel.lastScannedEvent.collectAsState()
    val lastScannedProduct by appViewModel.lastScannedProduct.collectAsState()

    val bleConnectionState by appViewModel.bleConnectionState.collectAsState()
    val sppConnectionState by appViewModel.sppConnectionState.collectAsState()
    val isBleAdvertising by appViewModel.isBleAdvertising.collectAsState()
    val scannerMode by appViewModel.scannerMode.collectAsState()
    val batchItems by appViewModel.batchItems.collectAsState()

    val stagedBarcode by appViewModel.stagedBarcode.collectAsState()
    val stagedFormat by appViewModel.stagedFormat.collectAsState()
    val stagedProduct by appViewModel.stagedProduct.collectAsState()
    val stagedScaleInfo by appViewModel.stagedScaleInfo.collectAsState()

    var isTorchEnabled by remember { mutableStateOf(false) }
    var showPosDialog by remember { mutableStateOf(false) }
    var showManualInputDialog by remember { mutableStateOf(false) }
    var manualBarcodeInput by remember { mutableStateOf("") }
    var showRecentScansSheet by remember { mutableStateOf(false) }
    var showBlePairingGuide by remember { mutableStateOf(false) }
    var showBatchSheet by remember { mutableStateOf(false) }
    var showSppDevicesDialog by remember { mutableStateOf(false) }

    // Camera & Bluetooth permissions check
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
    }

    val blePermissionsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        appViewModel.startBleAdvertising()
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            val hasBleAdv = ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED
            val hasBleConn = ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
            if (!hasBleAdv || !hasBleConn) {
                blePermissionsLauncher.launch(
                    arrayOf(
                        Manifest.permission.BLUETOOTH_ADVERTISE,
                        Manifest.permission.BLUETOOTH_CONNECT,
                        Manifest.permission.BLUETOOTH_SCAN
                    )
                )
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "CorePOS Scanner",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = store.name,
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        val emp = activeEmployee
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Staff: ${emp?.name ?: "Operator"} (${emp?.role ?: "CASHIER"})",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            if (emp != null) {
                                if (emp.effectiveCanSell) {
                                    Surface(color = Color(0xFF00C853), shape = RoundedCornerShape(3.dp), modifier = Modifier.padding(horizontal = 2.dp)) {
                                        Text("Sell", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp))
                                    }
                                }
                                if (emp.effectiveCanManageInventory) {
                                    Surface(color = Color(0xFFFFB300), shape = RoundedCornerShape(3.dp), modifier = Modifier.padding(horizontal = 2.dp)) {
                                        Text("Stock", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp))
                                    }
                                }
                                if (emp.effectiveCanProcessReturns) {
                                    Surface(color = Color(0xFF29B6F6), shape = RoundedCornerShape(3.dp), modifier = Modifier.padding(horizontal = 2.dp)) {
                                        Text("Return", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp))
                                    }
                                }
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                actions = {
                    // Quick Action: Switch Counter
                    TextButton(
                        onClick = onSwitchCounter,
                        modifier = Modifier.testTag("switch_counter_top_action")
                    ) {
                        Icon(
                            Icons.Default.PointOfSale,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Counter",
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Live Bluetooth SPP Status Badge (🟢 Connected / 🟡 Connecting / 🔴 Disconnected)
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = when (sppConnectionState) {
                            is com.example.bluetooth.SppConnectionState.Connected -> Color(0xFF00C853)
                            is com.example.bluetooth.SppConnectionState.Connecting -> Color(0xFFFFB300)
                            is com.example.bluetooth.SppConnectionState.Error -> Color(0xFFE53935)
                            else -> Color(0xFF555555)
                        },
                        modifier = Modifier
                            .padding(end = 4.dp)
                            .clickable { showSppDevicesDialog = true }
                            .testTag("spp_status_badge")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.SettingsInputHdmi,
                                contentDescription = "SPP Laser Scanner",
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = when (sppConnectionState) {
                                    is com.example.bluetooth.SppConnectionState.Connected -> "SPP Connected"
                                    is com.example.bluetooth.SppConnectionState.Connecting -> "SPP Connecting"
                                    is com.example.bluetooth.SppConnectionState.Error -> "SPP Error"
                                    else -> "SPP Scanner"
                                },
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Live Bluetooth Status Badge (🟢 Connected / 🟡 Advertising / 🔴 Standby)
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = when (bleConnectionState) {
                            is BleConnectionState.Connected -> Color(0xFF00C853)
                            is BleConnectionState.Advertising -> Color(0xFFFFB300)
                            is BleConnectionState.Error -> Color(0xFFE53935)
                            else -> Color(0xFF555555)
                        },
                        modifier = Modifier
                            .padding(end = 4.dp)
                            .clickable { showBlePairingGuide = true }
                            .testTag("ble_status_badge")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = when (bleConnectionState) {
                                    is BleConnectionState.Connected -> Icons.Default.BluetoothConnected
                                    is BleConnectionState.Advertising -> Icons.Default.BluetoothSearching
                                    is BleConnectionState.Error -> Icons.Default.BluetoothDisabled
                                    else -> Icons.Default.Bluetooth
                                },
                                contentDescription = "Bluetooth Status",
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = when (bleConnectionState) {
                                    is BleConnectionState.Connected -> "BLE Connected"
                                    is BleConnectionState.Advertising -> "BLE Ready"
                                    is BleConnectionState.Error -> "BLE Error"
                                    else -> "BLE Standby"
                                },
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier.testTag("open_settings_button")
                    ) {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color.Black)
        ) {
            // 1. Camera Viewfinder or Permission Rationale
            if (hasCameraPermission) {
                CameraPreviewView(
                    modifier = Modifier.fillMaxSize(),
                    isTorchEnabled = isTorchEnabled,
                    isScanningActive = autoScanEnabled && (scannerMode != ScannerOperationMode.STAGED_CONFIRM || stagedBarcode == null),
                    cooldownMs = cooldownMs,
                    onBarcodeScanned = { barcode, format ->
                        appViewModel.onBarcodeDetected(barcode, format)
                    }
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.surface),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(32.dp)
                    ) {
                        Icon(
                            Icons.Default.PhotoCamera,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Camera Permission Required",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "CorePOS Scanner requires camera access to scan retail product barcodes.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) },
                            modifier = Modifier.testTag("grant_camera_permission_button")
                        ) {
                            Text("Grant Camera Access")
                        }
                    }
                }
            }

            // 2. Top Header Overlay: Mode Switcher & Target Counter Pill
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Operation Mode Switcher Tabs
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = Color(0xDD121212),
                    modifier = Modifier.testTag("scanner_mode_selector")
                ) {
                    Row(
                        modifier = Modifier.padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Instant Mode
                        FilterChip(
                            selected = scannerMode == ScannerOperationMode.INSTANT_BEAM,
                            onClick = { appViewModel.setScannerMode(ScannerOperationMode.INSTANT_BEAM) },
                            label = { Text("⚡ Instant Beam", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF00E676),
                                selectedLabelColor = Color.Black
                            )
                        )
                        // Staged Mode
                        FilterChip(
                            selected = scannerMode == ScannerOperationMode.STAGED_CONFIRM,
                            onClick = { appViewModel.setScannerMode(ScannerOperationMode.STAGED_CONFIRM) },
                            label = { Text("✋ Confirm", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF00E676),
                                selectedLabelColor = Color.Black
                            )
                        )
                        // Batch Mode
                        FilterChip(
                            selected = scannerMode == ScannerOperationMode.BATCH_COUNT,
                            onClick = {
                                appViewModel.setScannerMode(ScannerOperationMode.BATCH_COUNT)
                                if (batchItems.isNotEmpty()) showBatchSheet = true
                            },
                            label = {
                                Text(
                                    if (batchItems.isNotEmpty()) "📦 Batch (${batchItems.sumOf { it.quantity }})" else "📦 Batch",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF00E676),
                                selectedLabelColor = Color.Black
                            )
                        )
                    }
                }

                // POS Target Chip
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (targetPosId.isNotBlank()) Color(0xCC000000) else Color(0xDDB71C1C),
                    modifier = Modifier
                        .clickable { onSwitchCounter() }
                        .testTag("target_pos_badge")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (targetPosId.isNotBlank()) Icons.Default.PointOfSale else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (targetPosId.isNotBlank()) Color(0xFF00E676) else Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (targetPosName.isNotBlank()) "Counter: $targetPosName" else "Tap to Select Counter",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.labelMedium
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            Icons.Default.ArrowDropDown,
                            contentDescription = "Switch",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Recent Scan Live Confirmation Banner
                AnimatedVisibility(
                    visible = lastScannedEvent != null,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    lastScannedEvent?.let { event ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xEE1E1E1E)),
                            modifier = Modifier.fillMaxWidth().testTag("scan_confirmation_card")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        shape = CircleShape,
                                        color = Color(0xFF00C853),
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                Icons.Default.Check,
                                                contentDescription = null,
                                                tint = Color.Black,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = if (lastScannedProduct != null) {
                                                "${lastScannedProduct?.name} (${String.format(Locale.US, "$%.2f", lastScannedProduct?.price)})"
                                            } else {
                                                "Barcode: ${event.barcode}"
                                            },
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            text = "Beamed to ${if (targetPosName.isNotBlank()) targetPosName else "Web POS"}",
                                            color = Color(0xFF00E676),
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                }

                                Text(
                                    text = event.barcode,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFFAAAAAA),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
            }

            // 3. Side Quick Controls (Torch, Manual Input, Batch Sheet, History Sheet, BLE Info)
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Torch Toggle
                FilledIconButton(
                    onClick = { isTorchEnabled = !isTorchEnabled },
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = if (isTorchEnabled) Color(0xFFFFD54F) else Color(0x99222222),
                        contentColor = if (isTorchEnabled) Color.Black else Color.White
                    ),
                    modifier = Modifier.size(52.dp).testTag("torch_toggle_button")
                ) {
                    Icon(
                        imageVector = if (isTorchEnabled) Icons.Default.FlashOn else Icons.Default.FlashOff,
                        contentDescription = "Flashlight"
                    )
                }

                // Batch Mode Sheet Launcher
                FilledIconButton(
                    onClick = { showBatchSheet = true },
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = if (batchItems.isNotEmpty()) Color(0xFF00E676) else Color(0x99222222),
                        contentColor = if (batchItems.isNotEmpty()) Color.Black else Color.White
                    ),
                    modifier = Modifier.size(52.dp).testTag("batch_sheet_button")
                ) {
                    BadgedBox(badge = {
                        if (batchItems.isNotEmpty()) {
                            Badge(containerColor = MaterialTheme.colorScheme.error) {
                                Text(batchItems.sumOf { it.quantity }.toString())
                            }
                        }
                    }) {
                        Icon(Icons.Default.Inventory2, contentDescription = "Batch Scans")
                    }
                }

                // Manual Barcode Entry
                FilledIconButton(
                    onClick = {
                        manualBarcodeInput = ""
                        showManualInputDialog = true
                    },
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = Color(0x99222222),
                        contentColor = Color.White
                    ),
                    modifier = Modifier.size(52.dp).testTag("manual_barcode_button")
                ) {
                    Icon(Icons.Default.Edit, contentDescription = "Manual Barcode Entry")
                }

                // Recent Scans History Sheet
                FilledIconButton(
                    onClick = { showRecentScansSheet = true },
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = Color(0x99222222),
                        contentColor = Color.White
                    ),
                    modifier = Modifier.size(52.dp).testTag("history_button")
                ) {
                    BadgedBox(badge = {
                        if (recentScans.isNotEmpty()) {
                            Badge(containerColor = MaterialTheme.colorScheme.primary) {
                                Text(recentScans.size.toString())
                            }
                        }
                    }) {
                        Icon(Icons.Default.History, contentDescription = "Recent Scans")
                    }
                }
            }

            // 4. Staged Barcode Confirmation Card (When in Confirm Mode)
            AnimatedVisibility(
                visible = stagedBarcode != null && scannerMode == ScannerOperationMode.STAGED_CONFIRM,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
            ) {
                Card(
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("staged_barcode_confirmation_sheet")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .width(40.dp)
                                .height(4.dp)
                                .background(Color(0xFF555555), RoundedCornerShape(2.dp))
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF00E676).copy(alpha = 0.15f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.QrCodeScanner,
                                        contentDescription = null,
                                        tint = Color(0xFF00E676),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = stagedFormat,
                                        color = Color(0xFF00E676),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF333333),
                                modifier = Modifier.clickable { onSwitchCounter() }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.PointOfSale,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (targetPosName.isNotBlank()) targetPosName else "Counter",
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Icon(
                                        Icons.Default.ArrowDropDown,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = stagedBarcode ?: "",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                            color = Color.White,
                            letterSpacing = 2.sp
                        )

                        if (stagedScaleInfo?.isScaleBarcode == true) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = stagedScaleInfo?.description ?: "",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF00E676),
                                style = MaterialTheme.typography.bodyMedium
                            )
                        } else if (stagedProduct != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = stagedProduct?.name ?: "",
                                fontWeight = FontWeight.SemiBold,
                                style = MaterialTheme.typography.titleMedium,
                                color = Color(0xFF81D4FA)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${store.currency} ${String.format(Locale.US, "%.2f", stagedProduct?.price ?: 0.0)}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFFCCCCCC)
                            )
                        } else {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Ready to beam to POS terminal",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFAAAAAA)
                            )
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedButton(
                                onClick = { appViewModel.cancelStagedBarcode() },
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(54.dp)
                                    .testTag("cancel_staged_barcode_button")
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Cancel", fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { appViewModel.sendStagedBarcode() },
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF00E676),
                                    contentColor = Color.Black
                                ),
                                modifier = Modifier
                                    .weight(2f)
                                    .height(54.dp)
                                    .testTag("send_barcode_to_counter_button")
                            ) {
                                Icon(Icons.Default.Send, contentDescription = null, tint = Color.Black)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Send",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 17.sp
                                )
                            }
                        }
                    }
                }
            }

            // 5. Normal Bottom Action Strip (When in Instant or Batch mode)
            AnimatedVisibility(
                visible = stagedBarcode == null || scannerMode != ScannerOperationMode.STAGED_CONFIRM,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (scannerMode == ScannerOperationMode.BATCH_COUNT && batchItems.isNotEmpty()) {
                        Button(
                            onClick = { appViewModel.transmitBatchAll() },
                            shape = RoundedCornerShape(20.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF00E676),
                                contentColor = Color.Black
                            ),
                            modifier = Modifier
                                .fillMaxWidth(0.85f)
                                .height(56.dp)
                                .testTag("transmit_batch_button")
                        ) {
                            Icon(Icons.Default.Send, contentDescription = null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "BEAM BATCH (${batchItems.sumOf { it.quantity }} ITEMS)",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp
                            )
                        }
                    } else {
                        Button(
                            onClick = { showManualInputDialog = true },
                            shape = RoundedCornerShape(24.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF00E676),
                                contentColor = Color.Black
                            ),
                            modifier = Modifier
                                .fillMaxWidth(0.75f)
                                .height(58.dp)
                                .testTag("scanner_trigger_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCodeScanner,
                                contentDescription = null,
                                modifier = Modifier.size(26.dp),
                                tint = Color.Black
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "TRIGGER SCAN",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = when (scannerMode) {
                            ScannerOperationMode.INSTANT_BEAM -> "Continuous Zero-Lag Scanning Active (150ms debounce)"
                            ScannerOperationMode.BATCH_COUNT -> "Continuous Batch Accumulation Active"
                            ScannerOperationMode.STAGED_CONFIRM -> "Confirm Mode Active"
                        },
                        color = Color.White.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
    }

    // BLE Pairing Guide Dialog
    if (showBlePairingGuide) {
        BlePairingGuideDialog(
            deviceName = appViewModel.deviceName,
            connectionState = bleConnectionState,
            isAdvertising = isBleAdvertising,
            onStartBle = { appViewModel.startBleAdvertising() },
            onStopBle = { appViewModel.stopBleAdvertising() },
            onDismiss = { showBlePairingGuide = false }
        )
    }

    // Batch Scans Sheet
    if (showBatchSheet) {
        BatchScansBottomSheet(
            batchItems = batchItems,
            onUpdateQuantity = { id, delta -> appViewModel.updateBatchItemQuantity(id, delta) },
            onTransmitAll = { appViewModel.transmitBatchAll() },
            onClearBatch = { appViewModel.clearBatch() },
            onDismiss = { showBatchSheet = false }
        )
    }

    // Manual Barcode Input Dialog
    if (showManualInputDialog) {
        AlertDialog(
            onDismissRequest = { showManualInputDialog = false },
            title = { Text("Manual Barcode Entry", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Enter the barcode digits directly if the printed label is damaged or for testing:",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = manualBarcodeInput,
                        onValueChange = { manualBarcodeInput = it },
                        label = { Text("Barcode Number") },
                        placeholder = { Text("e.g. 6291234567890") },
                        modifier = Modifier.fillMaxWidth().testTag("manual_barcode_input"),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val code = manualBarcodeInput.trim()
                        if (code.isNotBlank()) {
                            appViewModel.onBarcodeDetected(code, "MANUAL")
                            showManualInputDialog = false
                        }
                    },
                    modifier = Modifier.testTag("submit_manual_barcode_button")
                ) {
                    Text("Confirm Barcode")
                }
            },
            dismissButton = {
                TextButton(onClick = { showManualInputDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Recent Scans Bottom Sheet
    if (showRecentScansSheet) {
        ModalBottomSheet(
            onDismissRequest = { showRecentScansSheet = false }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent Scans History",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    if (pendingScansCount > 0) {
                        FilledTonalButton(
                            onClick = { appViewModel.triggerSyncNow() },
                            modifier = Modifier.testTag("sync_recent_scans_button")
                        ) {
                            Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Sync All ($pendingScansCount)")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (recentScans.isEmpty()) {
                    Text(
                        text = "No barcodes scanned yet in this session.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(vertical = 24.dp)
                    )
                } else {
                    val timeFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().heightIn(max = 320.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(recentScans, key = { it.id }) { scan ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = scan.barcode,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            text = "Time: ${timeFormat.format(Date(scan.timestamp))} • Format: ${scan.format}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(
                                            onClick = { appViewModel.processBarcodeScanned(scan.barcode, scan.format) },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.Replay, contentDescription = "Resend", modifier = Modifier.size(16.dp))
                                        }
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (scan.syncedFromOffline) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.primaryContainer
                                        ) {
                                            Text(
                                                text = if (scan.syncedFromOffline) "Synced" else "Beamed ✓",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = if (scan.syncedFromOffline) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onPrimaryContainer,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSppDevicesDialog) {
        val pairedDevices = remember { appViewModel.sppScannerManager.getPairedSppDevices() }
        AlertDialog(
            onDismissRequest = { showSppDevicesDialog = false },
            title = { Text("Connect SPP Laser Scanner", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Select a paired physical Bluetooth laser barcode scanner to stream codes over SPP profile.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    if (pairedDevices.isEmpty()) {
                        Text(
                            text = "No paired Bluetooth devices detected. Pair your laser barcode reader in Android Bluetooth settings first.",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.heightIn(max = 240.dp)
                        ) {
                            items(pairedDevices) { device ->
                                val devName = try { device.name ?: device.address } catch (_: Exception) { device.address }
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            appViewModel.sppScannerManager.connectToDevice(device) { barcode ->
                                                appViewModel.onExternalBarcodeScanned(barcode)
                                            }
                                            showSppDevicesDialog = false
                                        },
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.SettingsInputHdmi, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(devName, fontWeight = FontWeight.Bold)
                                            Text(device.address, style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                if (sppConnectionState is com.example.bluetooth.SppConnectionState.Connected) {
                    TextButton(onClick = {
                        appViewModel.sppScannerManager.disconnect()
                        showSppDevicesDialog = false
                    }) {
                        Text("Disconnect", color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showSppDevicesDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}
