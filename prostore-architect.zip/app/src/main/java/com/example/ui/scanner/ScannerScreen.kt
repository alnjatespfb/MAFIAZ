package com.example.ui.scanner

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.Product
import com.example.data.model.ScanEvent
import com.example.data.model.Store
import com.example.data.sync.ScanSyncStatus
import com.example.ui.AppViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScannerScreen(
    store: Store,
    appViewModel: AppViewModel,
    onOpenSettings: () -> Unit = {},
    onSwitchCounter: () -> Unit = {},
    onSwitchStore: () -> Unit = {}
) {
    val context = LocalContext.current
    val isOnline by appViewModel.isOnline.collectAsState()
    val syncStatus by appViewModel.scanSyncStatus.collectAsState()
    val pendingScansCount by appViewModel.pendingScansCount.collectAsState()
    val activeEmployee by appViewModel.activeEmployee.collectAsState()
    val targetPosName by appViewModel.targetPosName.collectAsState()
    val targetPosId by appViewModel.targetPosId.collectAsState()
    val approvedPosList by appViewModel.approvedPosDevices.collectAsState()
    val autoScanEnabled by appViewModel.autoScanEnabled.collectAsState()
    val cooldownMs by appViewModel.cooldownMs.collectAsState()
    val recentScans by appViewModel.recentScans.collectAsState()
    val lastScannedEvent by appViewModel.lastScannedEvent.collectAsState()
    val lastScannedProduct by appViewModel.lastScannedProduct.collectAsState()

    val stagedBarcode by appViewModel.stagedBarcode.collectAsState()
    val stagedFormat by appViewModel.stagedFormat.collectAsState()
    val stagedProduct by appViewModel.stagedProduct.collectAsState()

    var isTorchEnabled by remember { mutableStateOf(false) }
    var showPosDialog by remember { mutableStateOf(false) }
    var showManualInputDialog by remember { mutableStateOf(false) }
    var manualBarcodeInput by remember { mutableStateOf("") }
    var showRecentScansSheet by remember { mutableStateOf(false) }

    // Camera permission check
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = appViewModel.deviceName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = store.name,
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "Operator: ${activeEmployee?.name ?: "Ahmed"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                actions = {
                    // Quick Action: Switch Counter
                    TextButton(
                        onClick = onSwitchCounter,
                        modifier = Modifier.testTag("switch_counter_top_action")
                    ) {
                        Icon(
                            Icons.Default.PointOfSale,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Counter",
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Quick Action: Switch Store
                    TextButton(
                        onClick = onSwitchStore,
                        modifier = Modifier.testTag("switch_store_top_action")
                    ) {
                        Icon(
                            Icons.Default.Store,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Stores",
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }

                    // Real-time Connectivity Badge
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = when {
                            !isOnline -> Color(0xFFFF8F00)
                            syncStatus is ScanSyncStatus.Syncing -> MaterialTheme.colorScheme.tertiary
                            else -> Color(0xFF00C853)
                        },
                        modifier = Modifier.padding(end = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = when {
                                    !isOnline -> Icons.Default.WifiOff
                                    syncStatus is ScanSyncStatus.Syncing -> Icons.Default.Sync
                                    else -> Icons.Default.Wifi
                                },
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = when {
                                    !isOnline -> if (pendingScansCount > 0) "Offline ($pendingScansCount)" else "Offline"
                                    syncStatus is ScanSyncStatus.Syncing -> "Syncing"
                                    else -> "Online"
                                },
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier.testTag("open_settings_button")
                    ) {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color.Black)
        ) {
            // 1. Camera Viewfinder or Permission Rationale
            if (hasCameraPermission) {
                CameraPreviewView(
                    modifier = Modifier.fillMaxSize(),
                    isTorchEnabled = isTorchEnabled,
                    isScanningActive = autoScanEnabled && stagedBarcode == null,
                    cooldownMs = cooldownMs,
                    onBarcodeScanned = { barcode, format ->
                        appViewModel.stageBarcodeForConfirmation(barcode, format)
                    }
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.surface),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(32.dp)
                    ) {
                        Icon(
                            Icons.Default.PhotoCamera,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Camera Permission Required",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "The wireless scanner requires camera access to scan retail product barcodes.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                            modifier = Modifier.testTag("grant_camera_permission_button")
                        ) {
                            Text("Grant Camera Access")
                        }
                    }
                }
            }

            // 2. Top POS Route & Status Pill
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // POS Target Chip
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (targetPosId.isNotBlank()) Color(0xCC000000) else Color(0xDDB71C1C),
                    modifier = Modifier
                        .clickable { onSwitchCounter() }
                        .align(Alignment.CenterHorizontally)
                        .testTag("target_pos_badge")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (targetPosId.isNotBlank()) Icons.Default.PointOfSale else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (targetPosId.isNotBlank()) Color(0xFF00E676) else Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (targetPosName.isNotBlank()) "Counter: $targetPosName" else "Tap to Select Counter",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.labelMedium
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            Icons.Default.ArrowDropDown,
                            contentDescription = "Switch",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Recent Scan Confirmation Banner
                AnimatedVisibility(
                    visible = lastScannedEvent != null,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    lastScannedEvent?.let { event ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xEE1E1E1E)),
                            modifier = Modifier.fillMaxWidth().testTag("scan_confirmation_card")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        shape = CircleShape,
                                        color = Color(0xFF00C853),
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                Icons.Default.Check,
                                                contentDescription = null,
                                                tint = Color.Black,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = if (lastScannedProduct != null) {
                                                "${lastScannedProduct?.name} (${String.format(Locale.US, "$%.2f", lastScannedProduct?.price)})"
                                            } else {
                                                "Barcode: ${event.barcode}"
                                            },
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            text = "Sent to ${if (targetPosName.isNotBlank()) targetPosName else "Counter"}",
                                            color = Color(0xFF00E676),
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                }

                                Text(
                                    text = event.barcode,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFFAAAAAA),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
            }

            // 3. Side Quick Controls (Torch, Manual Input, Auto-Scan Toggle, Recent List)
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Torch Toggle
                FilledIconButton(
                    onClick = { isTorchEnabled = !isTorchEnabled },
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = if (isTorchEnabled) Color(0xFFFFD54F) else Color(0x99222222),
                        contentColor = if (isTorchEnabled) Color.Black else Color.White
                    ),
                    modifier = Modifier.size(52.dp).testTag("torch_toggle_button")
                ) {
                    Icon(
                        imageVector = if (isTorchEnabled) Icons.Default.FlashOn else Icons.Default.FlashOff,
                        contentDescription = "Flashlight"
                    )
                }

                // Manual Barcode Entry (for damaged labels / tests)
                FilledIconButton(
                    onClick = {
                        manualBarcodeInput = ""
                        showManualInputDialog = true
                    },
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = Color(0x99222222),
                        contentColor = Color.White
                    ),
                    modifier = Modifier.size(52.dp).testTag("manual_barcode_button")
                ) {
                    Icon(Icons.Default.Edit, contentDescription = "Manual Barcode Entry")
                }

                // Recent Scans History Sheet
                FilledIconButton(
                    onClick = { showRecentScansSheet = true },
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = Color(0x99222222),
                        contentColor = Color.White
                    ),
                    modifier = Modifier.size(52.dp).testTag("history_button")
                ) {
                    BadgedBox(badge = {
                        if (recentScans.isNotEmpty()) {
                            Badge(containerColor = MaterialTheme.colorScheme.primary) {
                                Text(recentScans.size.toString())
                            }
                        }
                    }) {
                        Icon(Icons.Default.History, contentDescription = "Recent Scans")
                    }
                }
            }

            // 4. Staged Barcode Confirmation Card with Send Button (Prevents Accidental Duplicate Sending)
            AnimatedVisibility(
                visible = stagedBarcode != null,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
            ) {
                Card(
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("staged_barcode_confirmation_sheet")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Drag handle / accent pill
                        Box(
                            modifier = Modifier
                                .width(40.dp)
                                .height(4.dp)
                                .background(Color(0xFF555555), RoundedCornerShape(2.dp))
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        // Status header and Target Counter badge
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF00E676).copy(alpha = 0.15f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.QrCodeScanner,
                                        contentDescription = null,
                                        tint = Color(0xFF00E676),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Barcode Scanned",
                                        color = Color(0xFF00E676),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF333333),
                                modifier = Modifier.clickable { onSwitchCounter() }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.PointOfSale,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (targetPosName.isNotBlank()) targetPosName else "Main Register",
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Icon(
                                        Icons.Default.ArrowDropDown,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Large Barcode Number Display
                        Text(
                            text = stagedBarcode ?: "",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                            color = Color.White,
                            letterSpacing = 2.sp
                        )

                        // Product Name & Price preview if found
                        if (stagedProduct != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = stagedProduct?.name ?: "",
                                fontWeight = FontWeight.SemiBold,
                                style = MaterialTheme.typography.titleMedium,
                                color = Color(0xFF81D4FA)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${store.currency} ${String.format(Locale.US, "%.2f", stagedProduct?.price ?: 0.0)}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFFCCCCCC)
                            )
                        } else {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Ready to send to selected counter",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFAAAAAA)
                            )
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // Action Buttons: Cancel and Send
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedButton(
                                onClick = { appViewModel.cancelStagedBarcode() },
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(54.dp)
                                    .testTag("cancel_staged_barcode_button")
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Cancel", fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { appViewModel.sendStagedBarcode() },
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF00E676),
                                    contentColor = Color.Black
                                ),
                                modifier = Modifier
                                    .weight(2f)
                                    .height(54.dp)
                                    .testTag("send_barcode_to_counter_button")
                            ) {
                                Icon(Icons.Default.Send, contentDescription = null, tint = Color.Black)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Send",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 17.sp
                                )
                            }
                        }
                    }
                }
            }

            // Normal Trigger Button when no barcode is awaiting confirmation
            AnimatedVisibility(
                visible = stagedBarcode == null,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Button(
                        onClick = {
                            showManualInputDialog = true
                        },
                        shape = RoundedCornerShape(24.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF00E676),
                            contentColor = Color.Black
                        ),
                        modifier = Modifier
                            .fillMaxWidth(0.72f)
                            .height(64.dp)
                            .testTag("scanner_trigger_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = null,
                            modifier = Modifier.size(28.dp),
                            tint = Color.Black
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "SCAN",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.2.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (autoScanEnabled) "Live Auto-Scan Active" else "Trigger Mode Active",
                        color = Color.White.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
    }

    // Target POS Selection Dialog
    if (showPosDialog) {
        TargetPosSelectorDialog(
            currentPosId = targetPosId,
            availablePosDevices = approvedPosList,
            onSelectPos = { appViewModel.setTargetPos(it) },
            onDismiss = { showPosDialog = false }
        )
    }

    // Manual Barcode Input Dialog
    if (showManualInputDialog) {
        AlertDialog(
            onDismissRequest = { showManualInputDialog = false },
            title = { Text("Manual Barcode Entry", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Enter the barcode digits directly if the printed label is damaged or for testing:",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = manualBarcodeInput,
                        onValueChange = { manualBarcodeInput = it },
                        label = { Text("Barcode Number") },
                        placeholder = { Text("e.g. 6291234567890") },
                        modifier = Modifier.fillMaxWidth().testTag("manual_barcode_input"),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val code = manualBarcodeInput.trim()
                        if (code.isNotBlank()) {
                            appViewModel.stageBarcodeForConfirmation(code, "MANUAL")
                            showManualInputDialog = false
                        }
                    },
                    modifier = Modifier.testTag("submit_manual_barcode_button")
                ) {
                    Text("Confirm Barcode")
                }
            },
            dismissButton = {
                TextButton(onClick = { showManualInputDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Recent Scans Bottom Sheet
    if (showRecentScansSheet) {
        ModalBottomSheet(
            onDismissRequest = { showRecentScansSheet = false }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent Scans",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    if (pendingScansCount > 0) {
                        FilledTonalButton(
                            onClick = { appViewModel.triggerSyncNow() },
                            modifier = Modifier.testTag("sync_recent_scans_button")
                        ) {
                            Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Sync All ($pendingScansCount)")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (recentScans.isEmpty()) {
                    Text(
                        text = "No barcodes scanned yet in this session.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(vertical = 24.dp)
                    )
                } else {
                    val timeFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().heightIn(max = 320.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(recentScans, key = { it.id }) { scan ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = scan.barcode,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            text = "Time: ${timeFormat.format(Date(scan.timestamp))} • Format: ${scan.format}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (scan.syncedFromOffline) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.primaryContainer
                                    ) {
                                        Text(
                                            text = if (scan.syncedFromOffline) "Synced" else "Sent ✓",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (scan.syncedFromOffline) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onPrimaryContainer,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
