package com.example.ui.scanner

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bluetooth.BleConnectionState
import com.example.data.model.Store
import com.example.ui.AppViewModel
import com.example.ui.ScannerOperationMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScannerSettingsScreen(
    store: Store,
    appViewModel: AppViewModel,
    onBack: () -> Unit,
    onSwitchEmployee: () -> Unit,
    onSwitchStore: () -> Unit
) {
    val soundEnabled by appViewModel.scanSoundEnabled.collectAsState()
    val vibrationEnabled by appViewModel.vibrationEnabled.collectAsState()
    val cooldownMs by appViewModel.cooldownMs.collectAsState()
    val autoScanEnabled by appViewModel.autoScanEnabled.collectAsState()
    val scannerMode by appViewModel.scannerMode.collectAsState()
    val activeEmployee by appViewModel.activeEmployee.collectAsState()
    val targetPosName by appViewModel.targetPosName.collectAsState()
    val targetPosId by appViewModel.targetPosId.collectAsState()
    val approvedPosList by appViewModel.approvedPosDevices.collectAsState()
    val pendingScansCount by appViewModel.pendingScansCount.collectAsState()
    val adminAccessRequest by appViewModel.adminAccessRequest.collectAsState()
    val adminMessage by appViewModel.adminRequestMessage.collectAsState()

    val bleConnectionState by appViewModel.bleConnectionState.collectAsState()
    val isBleAdvertising by appViewModel.isBleAdvertising.collectAsState()

    var scannerNameInput by remember { mutableStateOf(appViewModel.deviceName) }
    var isEditingName by remember { mutableStateOf(false) }
    var showPosDialog by remember { mutableStateOf(false) }
    var showAdminRequestDialog by remember { mutableStateOf(false) }
    var adminEmailInput by remember { mutableStateOf(appViewModel.currentUser.value?.email ?: "") }
    var showDisconnectConfirmDialog by remember { mutableStateOf(false) }
    var showBleGuideDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("CorePOS Scanner Settings", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("settings_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Bluetooth Low Energy (BLE GATT Server) Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Bluetooth, contentDescription = null, tint = Color(0xFF2979FF))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Bluetooth GATT Server", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }

                        Switch(
                            checked = isBleAdvertising || bleConnectionState is BleConnectionState.Connected,
                            onCheckedChange = { active ->
                                if (active) appViewModel.startBleAdvertising() else appViewModel.stopBleAdvertising()
                            }
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = when (bleConnectionState) {
                            is BleConnectionState.Connected -> Color(0xFF00E676).copy(alpha = 0.15f)
                            is BleConnectionState.Advertising -> Color(0xFFFFD54F).copy(alpha = 0.15f)
                            is BleConnectionState.Error -> Color(0xFFFF5252).copy(alpha = 0.15f)
                            else -> MaterialTheme.colorScheme.surface
                        }
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = when (bleConnectionState) {
                                    is BleConnectionState.Connected -> Icons.Default.BluetoothConnected
                                    is BleConnectionState.Advertising -> Icons.Default.BluetoothSearching
                                    is BleConnectionState.Error -> Icons.Default.Error
                                    else -> Icons.Default.BluetoothDisabled
                                },
                                contentDescription = null,
                                tint = when (bleConnectionState) {
                                    is BleConnectionState.Connected -> Color(0xFF00C853)
                                    is BleConnectionState.Advertising -> Color(0xFFFFB300)
                                    is BleConnectionState.Error -> Color(0xFFFF5252)
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                },
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = when (bleConnectionState) {
                                    is BleConnectionState.Connected -> "Connected to ${(bleConnectionState as BleConnectionState.Connected).deviceCount} POS Terminal(s)"
                                    is BleConnectionState.Advertising -> "Advertising • Ready for Web POS pairing"
                                    is BleConnectionState.Error -> (bleConnectionState as BleConnectionState.Error).message
                                    else -> "GATT Server Standby"
                                },
                                fontWeight = FontWeight.SemiBold,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }

                    FilledTonalButton(
                        onClick = { showBleGuideDialog = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Web Bluetooth Integration Guide")
                    }
                }
            }

            // 2. Device Identification
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Scanner Device Name", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        TextButton(onClick = {
                            if (isEditingName) {
                                appViewModel.updateScannerName(scannerNameInput)
                            }
                            isEditingName = !isEditingName
                        }) {
                            Text(if (isEditingName) "Save" else "Edit")
                        }
                    }

                    if (isEditingName) {
                        OutlinedTextField(
                            value = scannerNameInput,
                            onValueChange = { scannerNameInput = it },
                            modifier = Modifier.fillMaxWidth().testTag("settings_scanner_name_input"),
                            singleLine = true
                        )
                    } else {
                        Text(scannerNameInput, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                    }

                    Text("Device ID: ${appViewModel.deviceId}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            // 3. Scanning Operation Mode
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Scanning Operation Mode", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = scannerMode == ScannerOperationMode.INSTANT_BEAM,
                            onClick = { appViewModel.setScannerMode(ScannerOperationMode.INSTANT_BEAM) },
                            label = { Text("⚡ Instant", fontSize = 12.sp) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = scannerMode == ScannerOperationMode.STAGED_CONFIRM,
                            onClick = { appViewModel.setScannerMode(ScannerOperationMode.STAGED_CONFIRM) },
                            label = { Text("✋ Confirm", fontSize = 12.sp) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = scannerMode == ScannerOperationMode.BATCH_COUNT,
                            onClick = { appViewModel.setScannerMode(ScannerOperationMode.BATCH_COUNT) },
                            label = { Text("📦 Batch", fontSize = 12.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Text(
                        text = when (scannerMode) {
                            ScannerOperationMode.INSTANT_BEAM -> "Zero-lag instant beaming directly to POS upon camera detection."
                            ScannerOperationMode.STAGED_CONFIRM -> "Shows a confirmation bottom sheet with product info before beaming."
                            ScannerOperationMode.BATCH_COUNT -> "Accumulates barcodes into a batch list with item quantity counters."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // 4. Scanner Controls & Cooldown
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Scanner Feedback & Debounce", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Scan Audio Tone", fontWeight = FontWeight.SemiBold)
                            Text("800Hz / 1200Hz cash register tone", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = soundEnabled,
                            onCheckedChange = { appViewModel.toggleSound(it) },
                            modifier = Modifier.testTag("sound_toggle")
                        )
                    }

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Haptic Vibration", fontWeight = FontWeight.SemiBold)
                            Text("Tactile trigger pulse", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = vibrationEnabled,
                            onCheckedChange = { appViewModel.toggleVibration(it) },
                            modifier = Modifier.testTag("vibration_toggle")
                        )
                    }

                    HorizontalDivider()

                    Column {
                        Text("Duplicate Debounce Window", fontWeight = FontWeight.SemiBold)
                        Text(
                            "Prevents re-scanning the same barcode while held in frame (${cooldownMs}ms)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(150L, 300L, 500L, 800L).forEach { ms ->
                                FilterChip(
                                    selected = cooldownMs == ms,
                                    onClick = { appViewModel.setCooldown(ms) },
                                    label = { Text("${ms}ms") },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            // 5. Connected Store & POS
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Store & Cashier Routing", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Store", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(store.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        }
                        OutlinedButton(onClick = onSwitchStore) {
                            Text("Change Store")
                        }
                    }

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Target Counter", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                if (targetPosName.isNotBlank()) targetPosName else "All / Broadcast",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        FilledTonalButton(onClick = { showPosDialog = true }) {
                            Text("Select Counter")
                        }
                    }

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Current Cashier", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                activeEmployee?.name ?: "No cashier selected",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        OutlinedButton(onClick = onSwitchEmployee, modifier = Modifier.testTag("switch_employee_button")) {
                            Text("Switch")
                        }
                    }
                }
            }

            // 6. Offline Queue & Sync
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Offline Data & Synchronization", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "Scans are captured locally in Room when offline and automatically pushed to Firestore once reconnected.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Pending Scans in Queue: $pendingScansCount", fontWeight = FontWeight.SemiBold)
                        Button(
                            onClick = { appViewModel.triggerSyncNow() },
                            enabled = pendingScansCount > 0,
                            modifier = Modifier.testTag("sync_now_button")
                        ) {
                            Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Sync Now")
                        }
                    }
                }
            }

            // Disconnect Device Button
            Button(
                onClick = { showDisconnectConfirmDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().testTag("disconnect_device_button")
            ) {
                Icon(Icons.Default.LinkOff, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Disconnect Device")
            }
        }
    }

    // BLE Guide Dialog
    if (showBleGuideDialog) {
        BlePairingGuideDialog(
            deviceName = appViewModel.deviceName,
            connectionState = bleConnectionState,
            isAdvertising = isBleAdvertising,
            onStartBle = { appViewModel.startBleAdvertising() },
            onStopBle = { appViewModel.stopBleAdvertising() },
            onDismiss = { showBleGuideDialog = false }
        )
    }

    // POS Selector Dialog
    if (showPosDialog) {
        TargetPosSelectorDialog(
            currentPosId = targetPosId,
            availablePosDevices = approvedPosList,
            onSelectPos = { appViewModel.setTargetPos(it) },
            onDismiss = { showPosDialog = false }
        )
    }

    // Disconnect Confirm Dialog
    if (showDisconnectConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDisconnectConfirmDialog = false },
            title = { Text("Disconnect This Scanner?", fontWeight = FontWeight.Bold) },
            text = {
                Text("This will remove the store association and require re-pairing before this phone can scan again.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDisconnectConfirmDialog = false
                        appViewModel.disconnectDevice()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Disconnect")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDisconnectConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
