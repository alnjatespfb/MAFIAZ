package com.example.ui.scanner

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.Store
import com.example.ui.AppViewModel

/**
 * Scanner-only settings.
 * No inventory, employee-management, device-admin or store-admin actions are
 * exposed from the phone application.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScannerSettingsScreen(
    store: Store,
    appViewModel: AppViewModel,
    onBack: () -> Unit,
    onSwitchEmployee: () -> Unit,
    onSwitchStore: () -> Unit
) {
    val soundEnabled by appViewModel.scanSoundEnabled.collectAsState()
    val vibrationEnabled by appViewModel.vibrationEnabled.collectAsState()
    val cooldownMs by appViewModel.cooldownMs.collectAsState()
    val activeEmployee by appViewModel.activeEmployee.collectAsState()
    val targetPosName by appViewModel.targetPosName.collectAsState()
    val targetPosId by appViewModel.targetPosId.collectAsState()
    val approvedPosList by appViewModel.approvedPosDevices.collectAsState()
    var showPosDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Scanner Settings", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("settings_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Connection", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Store: ${store.name}", fontWeight = FontWeight.SemiBold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text("Counter", style = MaterialTheme.typography.labelMedium)
                            Text(if (targetPosName.isBlank()) "Not selected" else targetPosName)
                        }
                        Button(onClick = { showPosDialog = true }) { Text("Change") }
                    }
                    OutlinedButton(onClick = onSwitchStore, Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Storefront, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Change Store")
                    }
                }
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Operator", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(activeEmployee?.name ?: "Signed-in user", fontWeight = FontWeight.SemiBold)
                    if (activeEmployee != null) {
                        Text("Role: ${activeEmployee!!.role}", style = MaterialTheme.typography.bodySmall)
                    }
                    OutlinedButton(onClick = onSwitchEmployee, Modifier.fillMaxWidth()) {
                        Text("Switch Operator")
                    }
                }
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Scanner", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Beep")
                        Switch(checked = soundEnabled, onCheckedChange = appViewModel::toggleSound)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Vibration")
                        Switch(checked = vibrationEnabled, onCheckedChange = appViewModel::toggleVibration)
                    }
                    Text("Cooldown: ${cooldownMs} ms", style = MaterialTheme.typography.bodySmall)
                    Slider(
                        value = cooldownMs.toFloat(),
                        onValueChange = { appViewModel.setCooldown(it.toLong()) },
                        valueRange = 300f..3000f
                    )
                }
            }

            Text(
                "This phone is a barcode scanner only. POS, inventory, sales history and store administration are handled outside this app.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }

    if (showPosDialog) {
        TargetPosSelectorDialog(
            currentPosId = targetPosId,
            availablePosDevices = approvedPosList,
            onSelectPos = { appViewModel.setTargetPos(it) },
            onDismiss = { showPosDialog = false }
        )
    }
}
