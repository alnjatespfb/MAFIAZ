package com.example.ui.scanner

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.Role
import com.example.data.model.Store
import com.example.ui.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScannerSettingsScreen(
    store: Store,
    appViewModel: AppViewModel,
    onBack: () -> Unit,
    onSwitchEmployee: () -> Unit,
    onSwitchStore: () -> Unit
) {
    val soundEnabled by appViewModel.scanSoundEnabled.collectAsState()
    val vibrationEnabled by appViewModel.vibrationEnabled.collectAsState()
    val cooldownMs by appViewModel.cooldownMs.collectAsState()
    val autoScanEnabled by appViewModel.autoScanEnabled.collectAsState()
    val activeEmployee by appViewModel.activeEmployee.collectAsState()
    val targetPosName by appViewModel.targetPosName.collectAsState()
    val targetPosId by appViewModel.targetPosId.collectAsState()
    val approvedPosList by appViewModel.approvedPosDevices.collectAsState()
    val pendingScansCount by appViewModel.pendingScansCount.collectAsState()
    val adminAccessRequest by appViewModel.adminAccessRequest.collectAsState()
    val adminMessage by appViewModel.adminRequestMessage.collectAsState()

    var scannerNameInput by remember { mutableStateOf(appViewModel.deviceName) }
    var isEditingName by remember { mutableStateOf(false) }
    var showPosDialog by remember { mutableStateOf(false) }
    var showAdminRequestDialog by remember { mutableStateOf(false) }
    var adminEmailInput by remember { mutableStateOf(appViewModel.currentUser.value?.email ?: "") }
    var showDisconnectConfirmDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Scanner Settings", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("settings_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Device Identification
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Scanner Name", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        TextButton(onClick = {
                            if (isEditingName) {
                                appViewModel.updateScannerName(scannerNameInput)
                            }
                            isEditingName = !isEditingName
                        }) {
                            Text(if (isEditingName) "Save" else "Edit")
                        }
                    }

                    if (isEditingName) {
                        OutlinedTextField(
                            value = scannerNameInput,
                            onValueChange = { scannerNameInput = it },
                            modifier = Modifier.fillMaxWidth().testTag("settings_scanner_name_input"),
                            singleLine = true
                        )
                    } else {
                        Text(scannerNameInput, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                    }

                    Text("Device ID: ${appViewModel.deviceId}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            // 2. Connected Store & POS
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Connection Routing", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Connected Store", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(store.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        }
                        OutlinedButton(onClick = onSwitchStore) {
                            Text("Change Store")
                        }
                    }

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Connected POS", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                if (targetPosName.isNotBlank()) targetPosName else "None (Broadcasting)",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        FilledTonalButton(onClick = { showPosDialog = true }) {
                            Text("Select POS")
                        }
                    }

                    if (targetPosId.isNotBlank()) {
                        OutlinedButton(
                            onClick = { appViewModel.disconnectTargetPos() },
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = MaterialTheme.colorScheme.error
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("disconnect_pos_binding_button")
                        ) {
                            Icon(Icons.Default.LinkOff, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Disconnect Counter Binding")
                        }
                    }
                }
            }

            // 3. Current Employee
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Current Operator", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                activeEmployee?.name ?: "No operator selected",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            if (activeEmployee != null) {
                                Text("Role: ${activeEmployee?.role}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        OutlinedButton(onClick = onSwitchEmployee, modifier = Modifier.testTag("switch_employee_button")) {
                            Text("Switch")
                        }
                    }
                }
            }

            // 4. Scanner Controls & Cooldown
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Scanning Behavior", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Scan Sound Beep", fontWeight = FontWeight.SemiBold)
                            Text("Audio feedback upon successful scan", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = soundEnabled,
                            onCheckedChange = { appViewModel.toggleSound(it) },
                            modifier = Modifier.testTag("sound_toggle")
                        )
                    }

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Vibration Feedback", fontWeight = FontWeight.SemiBold)
                            Text("Haptic pulse on scan confirmation", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = vibrationEnabled,
                            onCheckedChange = { appViewModel.toggleVibration(it) },
                            modifier = Modifier.testTag("vibration_toggle")
                        )
                    }

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Auto-Scan Reticle", fontWeight = FontWeight.SemiBold)
                            Text("Scan immediately when barcode is in view", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = autoScanEnabled,
                            onCheckedChange = { appViewModel.toggleAutoScan(it) },
                            modifier = Modifier.testTag("autoscan_toggle")
                        )
                    }

                    HorizontalDivider()

                    Column {
                        Text("Duplicate Scan Cooldown", fontWeight = FontWeight.SemiBold)
                        Text(
                            "Prevents re-scanning the same barcode while held in front of camera (${cooldownMs}ms)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(500L, 800L, 1000L, 1500L).forEach { ms ->
                                FilterChip(
                                    selected = cooldownMs == ms,
                                    onClick = { appViewModel.setCooldown(ms) },
                                    label = { Text("${ms}ms") },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            // 5. Offline Queue & Sync
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Offline Data & Synchronization", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "Scans are captured locally in Room when offline and automatically pushed to Firestore once reconnected.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Pending Scans in Queue: $pendingScansCount", fontWeight = FontWeight.SemiBold)
                        Button(
                            onClick = { appViewModel.triggerSyncNow() },
                            enabled = pendingScansCount > 0,
                            modifier = Modifier.testTag("sync_now_button")
                        ) {
                            Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Sync Now")
                        }
                    }
                }
            }

            // 6. Section 15: Admin Access from Scanner
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Admin Access Mode", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }

                    if (appViewModel.isStoreAdmin()) {
                        Text(
                            "You are currently authorized as an administrator for this store.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    } else {
                        Text(
                            "Request administrative permissions from the web store dashboard for this device.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )

                        if (adminAccessRequest != null) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text("Request Status: ${adminAccessRequest?.status}", fontWeight = FontWeight.Bold)
                                    Text(adminMessage ?: "", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }

                        Button(
                            onClick = { showAdminRequestDialog = true },
                            modifier = Modifier.testTag("request_admin_access_button")
                        ) {
                            Text("Request Admin Access")
                        }
                    }
                }
            }

            Button(
                onClick = { showDisconnectConfirmDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().testTag("disconnect_device_button")
            ) {
                Icon(Icons.Default.LinkOff, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Disconnect Device")
            }
        }
    }

    // POS Selector Dialog
    if (showPosDialog) {
        TargetPosSelectorDialog(
            currentPosId = targetPosId,
            availablePosDevices = approvedPosList,
            onSelectPos = { appViewModel.setTargetPos(it) },
            onDismiss = { showPosDialog = false }
        )
    }

    // Admin Request Dialog
    if (showAdminRequestDialog) {
        AlertDialog(
            onDismissRequest = { showAdminRequestDialog = false },
            title = { Text("Request Admin Privileges", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "An access request will be sent to the store web dashboard for approval:",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = adminEmailInput,
                        onValueChange = { adminEmailInput = it },
                        label = { Text("Admin / User Email") },
                        modifier = Modifier.fillMaxWidth().testTag("admin_email_input"),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        appViewModel.requestAdminAccess(adminEmailInput.trim())
                        showAdminRequestDialog = false
                    },
                    modifier = Modifier.testTag("confirm_admin_request_button")
                ) {
                    Text("Send Request")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAdminRequestDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Disconnect Confirm Dialog
    if (showDisconnectConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDisconnectConfirmDialog = false },
            title = { Text("Disconnect This Scanner?", fontWeight = FontWeight.Bold) },
            text = {
                Text("This will remove the store association and require re-pairing before this phone can scan again.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDisconnectConfirmDialog = false
                        appViewModel.disconnectDevice()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Disconnect")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDisconnectConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
