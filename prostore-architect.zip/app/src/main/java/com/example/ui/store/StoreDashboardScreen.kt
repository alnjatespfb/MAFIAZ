package com.example.ui.store

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.data.model.Store
import com.example.ui.AppViewModel
import com.example.ui.scanner.ScannerScreen
import com.example.ui.scanner.ScannerSettingsScreen

/**
 * Phone app is intentionally SCANNER-ONLY.
 * POS, Inventory, Sales and Admin are not exposed from the phone.
 * Those privileged operations belong to the web/admin application.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoreDashboardScreen(
    store: Store,
    appViewModel: AppViewModel,
    onSwitchStore: () -> Unit
) {
    var showScannerSettings by remember { mutableStateOf(false) }

    if (showScannerSettings) {
        ScannerSettingsScreen(
            store = store,
            appViewModel = appViewModel,
            onBack = { showScannerSettings = false },
            onSwitchEmployee = { appViewModel.logoutEmployee() },
            onSwitchStore = onSwitchStore
        )
    } else {
        ScannerScreen(
            store = store,
            appViewModel = appViewModel,
            onOpenSettings = { showScannerSettings = true }
        )
    }
}
