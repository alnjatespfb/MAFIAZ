package com.example.ui.store

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.Store
import com.example.ui.AppViewModel
import com.example.ui.admin.StoreAdminScreen
import com.example.ui.devices.DeviceViewModel
import com.example.ui.inventory.InventoryScreen
import com.example.ui.inventory.InventoryViewModel
import com.example.ui.pos.PosRegisterScreen
import com.example.ui.pos.PosViewModel
import com.example.ui.sales.SalesHistoryScreen
import com.example.ui.sales.SalesHistoryViewModel
import com.example.ui.scanner.ScannerScreen
import com.example.ui.scanner.ScannerSettingsScreen

enum class DashboardTab(val title: String) {
    POS("POS Register"),
    INVENTORY("Inventory"),
    SALES("Sales History"),
    SCANNER("Barcode Scanner"),
    ADMIN("Store Admin")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoreDashboardScreen(
    store: Store,
    appViewModel: AppViewModel,
    onSwitchStore: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(DashboardTab.POS) }
    var showScannerSettings by remember { mutableStateOf(false) }

    val isOnline by appViewModel.isOnline.collectAsState()

    val effectiveStoreId = store.id.ifBlank { store.storeId }

    // Scoped ViewModels for the active store
    val posViewModel = remember(effectiveStoreId) {
        PosViewModel(
            storeId = effectiveStoreId,
            posDeviceId = appViewModel.deviceId,
            productRepo = appViewModel.productRepo,
            salesRepo = appViewModel.salesRepo,
            scanEventRepo = appViewModel.scanEventRepo
        )
    }

    val inventoryViewModel = remember(effectiveStoreId) {
        InventoryViewModel(
            storeId = effectiveStoreId,
            productRepo = appViewModel.productRepo
        )
    }

    val salesHistoryViewModel = remember(effectiveStoreId) {
        SalesHistoryViewModel(
            storeId = effectiveStoreId,
            salesRepo = appViewModel.salesRepo,
            syncManager = appViewModel.syncManager
        )
    }

    val deviceViewModel = remember(store.id) {
        DeviceViewModel(
            storeId = store.id,
            deviceRepo = appViewModel.deviceRepo,
            employeeRepo = appViewModel.employeeRepo
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = store.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            // Online/Offline badge
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isOnline) Color(0xFF2E7D32).copy(alpha = 0.2f) else MaterialTheme.colorScheme.error.copy(alpha = 0.2f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .background(
                                                color = if (isOnline) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error,
                                                shape = CircleShape
                                            )
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isOnline) "ONLINE" else "OFFLINE",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isOnline) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                        val subtitleText = buildString {
                            if (store.country.isNotBlank()) append(store.country).append(" • ")
                            append(store.currency)
                            if (store.phone.isNotBlank()) append(" • ").append(store.phone)
                        }
                        Text(
                            text = subtitleText,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    TextButton(
                        onClick = onSwitchStore,
                        modifier = Modifier.testTag("switch_store_action_button")
                    ) {
                        Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Stores")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                tonalElevation = 6.dp,
                modifier = Modifier.testTag("dashboard_navigation_bar")
            ) {
                NavigationBarItem(
                    selected = selectedTab == DashboardTab.POS,
                    onClick = {
                        selectedTab = DashboardTab.POS
                        showScannerSettings = false
                    },
                    icon = { Icon(Icons.Default.PointOfSale, contentDescription = "POS Register") },
                    label = { Text("POS") },
                    modifier = Modifier.testTag("tab_pos")
                )
                NavigationBarItem(
                    selected = selectedTab == DashboardTab.INVENTORY,
                    onClick = {
                        selectedTab = DashboardTab.INVENTORY
                        showScannerSettings = false
                    },
                    icon = { Icon(Icons.Default.Inventory2, contentDescription = "Inventory") },
                    label = { Text("Inventory") },
                    modifier = Modifier.testTag("tab_inventory")
                )
                NavigationBarItem(
                    selected = selectedTab == DashboardTab.SALES,
                    onClick = {
                        selectedTab = DashboardTab.SALES
                        showScannerSettings = false
                    },
                    icon = { Icon(Icons.Default.ReceiptLong, contentDescription = "Sales") },
                    label = { Text("Sales") },
                    modifier = Modifier.testTag("tab_sales")
                )
                NavigationBarItem(
                    selected = selectedTab == DashboardTab.SCANNER,
                    onClick = {
                        selectedTab = DashboardTab.SCANNER
                    },
                    icon = { Icon(Icons.Default.QrCodeScanner, contentDescription = "Scanner") },
                    label = { Text("Scanner") },
                    modifier = Modifier.testTag("tab_scanner")
                )
                NavigationBarItem(
                    selected = selectedTab == DashboardTab.ADMIN,
                    onClick = {
                        selectedTab = DashboardTab.ADMIN
                        showScannerSettings = false
                    },
                    icon = { Icon(Icons.Default.AdminPanelSettings, contentDescription = "Admin") },
                    label = { Text("Admin") },
                    modifier = Modifier.testTag("tab_admin")
                )
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (selectedTab) {
                DashboardTab.POS -> {
                    PosRegisterScreen(
                        store = store,
                        appViewModel = appViewModel,
                        posViewModel = posViewModel
                    )
                }
                DashboardTab.INVENTORY -> {
                    InventoryScreen(
                        store = store,
                        inventoryViewModel = inventoryViewModel
                    )
                }
                DashboardTab.SALES -> {
                    SalesHistoryScreen(
                        store = store,
                        salesHistoryViewModel = salesHistoryViewModel
                    )
                }
                DashboardTab.SCANNER -> {
                    if (showScannerSettings) {
                        ScannerSettingsScreen(
                            store = store,
                            appViewModel = appViewModel,
                            onBack = { showScannerSettings = false },
                            onSwitchEmployee = { appViewModel.logoutEmployee() },
                            onSwitchStore = onSwitchStore
                        )
                    } else {
                        ScannerScreen(
                            store = store,
                            appViewModel = appViewModel,
                            onOpenSettings = { showScannerSettings = true }
                        )
                    }
                }
                DashboardTab.ADMIN -> {
                    StoreAdminScreen(
                        store = store,
                        appViewModel = appViewModel,
                        deviceViewModel = deviceViewModel,
                        onSwitchStore = onSwitchStore
                    )
                }
            }
        }
    }
}
