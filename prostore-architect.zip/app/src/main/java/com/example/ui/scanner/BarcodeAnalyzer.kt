package com.example.ui.scanner

import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage

class BarcodeAnalyzer(
    var cooldownMs: Long = 150L,
    var isEnabled: Boolean = true,
    private val onBarcodeDetected: (barcode: String, format: String) -> Unit
) : ImageAnalysis.Analyzer {

    private val options = BarcodeScannerOptions.Builder()
        .setBarcodeFormats(
            Barcode.FORMAT_EAN_13,
            Barcode.FORMAT_EAN_8,
            Barcode.FORMAT_UPC_A,
            Barcode.FORMAT_UPC_E,
            Barcode.FORMAT_CODE_128,
            Barcode.FORMAT_CODE_39,
            Barcode.FORMAT_CODE_93,
            Barcode.FORMAT_CODABAR,
            Barcode.FORMAT_ITF,
            Barcode.FORMAT_DATA_MATRIX,
            Barcode.FORMAT_PDF417,
            Barcode.FORMAT_AZTEC,
            Barcode.FORMAT_QR_CODE
        )
        .build()

    private val scanner = BarcodeScanning.getClient(options)

    @Volatile
    private var lastScannedBarcode: String? = null
    @Volatile
    private var lastScannedTime: Long = 0L

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage != null && isEnabled) {
            val inputImage = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
            scanner.process(inputImage)
                .addOnSuccessListener { barcodes ->
                    val now = System.currentTimeMillis()
                    for (barcode in barcodes) {
                        val rawValue = barcode.rawValue ?: barcode.displayValue
                        if (!rawValue.isNullOrBlank()) {
                            // Check debounce: prevent accidental duplicate scans within cooldown window
                            if (rawValue == lastScannedBarcode && (now - lastScannedTime) < cooldownMs) {
                                continue
                            }
                            lastScannedBarcode = rawValue
                            lastScannedTime = now

                            val formatStr = when (barcode.format) {
                                Barcode.FORMAT_EAN_13 -> if (rawValue.startsWith("20") || rawValue.startsWith("02")) "EAN-13 (Scale)" else "EAN-13"
                                Barcode.FORMAT_EAN_8 -> "EAN-8"
                                Barcode.FORMAT_UPC_A -> "UPC-A"
                                Barcode.FORMAT_UPC_E -> "UPC-E"
                                Barcode.FORMAT_CODE_128 -> "Code 128"
                                Barcode.FORMAT_CODE_39 -> "Code 39"
                                Barcode.FORMAT_CODE_93 -> "Code 93"
                                Barcode.FORMAT_CODABAR -> "Codabar"
                                Barcode.FORMAT_ITF -> "ITF / Interleaved 2 of 5"
                                Barcode.FORMAT_DATA_MATRIX -> "DataMatrix"
                                Barcode.FORMAT_PDF417 -> "PDF-417"
                                Barcode.FORMAT_AZTEC -> "Aztec"
                                Barcode.FORMAT_QR_CODE -> "QR Code"
                                else -> "Barcode"
                            }

                            onBarcodeDetected(rawValue, formatStr)
                            break
                        }
                    }
                }
                .addOnFailureListener {
                    // Ignore transient frames
                }
                .addOnCompleteListener {
                    imageProxy.close()
                }
        } else {
            imageProxy.close()
        }
    }

    fun resetCooldown() {
        lastScannedBarcode = null
        lastScannedTime = 0L
    }
}
