package com.example.util

data class ParsedScaleBarcode(
    val rawBarcode: String,
    val isScaleBarcode: Boolean,
    val itemPlu: String,
    val weightKg: Double? = null,
    val priceValue: Double? = null,
    val description: String
)

object ScaleBarcodeParser {
    /**
     * Parses standard supermarket embedded barcodes:
     * - EAN-13 starting with 20: 20PPPPPWWWWWC (e.g. 20 + 5-digit item code + 5-digit weight/price + check digit)
     * - EAN-13 starting with 02: 02PPPPPWWWWWC
     */
    fun parse(barcode: String): ParsedScaleBarcode {
        val clean = barcode.trim()
        if (clean.length == 13 && (clean.startsWith("20") || clean.startsWith("02") || clean.startsWith("21") || clean.startsWith("22"))) {
            try {
                val prefix = clean.substring(0, 2)
                val itemPlu = clean.substring(2, 7) // 5-digit item code
                val valuePart = clean.substring(7, 12).toIntOrNull() ?: 0

                // Typically in retail, last 5 digits before check digit represent weight in grams (e.g. 01250 = 1.250kg) or price in cents
                val weightKg = valuePart / 1000.0

                return ParsedScaleBarcode(
                    rawBarcode = clean,
                    isScaleBarcode = true,
                    itemPlu = itemPlu,
                    weightKg = weightKg,
                    priceValue = valuePart / 100.0,
                    description = "Scale Item PLU #$itemPlu (${String.format("%.3f", weightKg)} kg)"
                )
            } catch (_: Exception) {}
        }

        return ParsedScaleBarcode(
            rawBarcode = clean,
            isScaleBarcode = false,
            itemPlu = clean,
            description = "Standard Barcode"
        )
    }
}
