package com.example.util

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/**
 * Audio (800Hz / 1200Hz tone generator) & Haptic Vibration helper
 * for high-speed cashier barcode scanning feedback.
 */
object FeedbackHelper {
    private var toneGenerator: ToneGenerator? = null

    init {
        initToneGenerator()
    }

    private fun initToneGenerator() {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 100)
        } catch (_: Exception) {
            try {
                toneGenerator = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90)
            } catch (_: Exception) {}
        }
    }

    /**
     * 800Hz confirmation chime (for Bluetooth HID/SPP & Camera barcode matches)
     */
    fun play800HzBeep(context: Context) {
        if (!DeviceIdManager.isSoundEnabled(context)) return
        try {
            if (toneGenerator == null) {
                initToneGenerator()
            }
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 90)
        } catch (_: Exception) {}
    }

    /**
     * 80ms haptic vibration for barcode match feedback
     */
    fun vibrate80ms(context: Context) {
        vibrate(context, 80L)
    }

    /**
     * Combined 800Hz audio beep and 80ms haptic vibration on barcode match
     */
    fun playBarcodeMatchFeedback(context: Context) {
        play800HzBeep(context)
        vibrate80ms(context)
    }

    /**
     * Crisp high-pitched success beep for rapid barcode registration
     */
    fun playBeep(context: Context) {
        play800HzBeep(context)
    }

    /**
     * 800Hz confirmation chime (e.g. for Bluetooth packet beamed / batch added)
     */
    fun playConfirmBeep(context: Context) {
        play800HzBeep(context)
    }

    /**
     * Low warning/error tone
     */
    fun playErrorBeep(context: Context) {
        if (!DeviceIdManager.isSoundEnabled(context)) return
        try {
            if (toneGenerator == null) {
                initToneGenerator()
            }
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 200)
        } catch (_: Exception) {}
    }

    @Suppress("DEPRECATION")
    fun vibrate(context: Context, durationMs: Long = 50L) {
        if (!DeviceIdManager.isVibrationEnabled(context)) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                val vibrator = vibratorManager?.defaultVibrator
                vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    vibrator?.vibrate(durationMs)
                }
            }
        } catch (_: Exception) {}
    }

    fun release() {
        try {
            toneGenerator?.release()
            toneGenerator = null
        } catch (_: Exception) {}
    }
}
