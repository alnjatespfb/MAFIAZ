package com.example.util

import android.content.Context
import android.os.Build
import java.util.UUID

object DeviceIdManager {
    private const val PREFS_NAME = "device_identity_prefs"
    private const val KEY_DEVICE_ID = "local_device_id"
    private const val KEY_DEVICE_NAME = "local_device_name"
    private const val KEY_ACTIVE_STORE_ID = "active_store_id"
    private const val KEY_ACTIVE_STORE_NAME = "active_store_name"
    private const val KEY_DEVICE_ROLE = "local_device_role" // SCANNER
    private const val KEY_TARGET_POS_ID = "target_pos_id"
    private const val KEY_TARGET_POS_NAME = "target_pos_name"
    private const val KEY_EMPLOYEE_ID = "current_employee_id"
    private const val KEY_EMPLOYEE_NAME = "current_employee_name"
    private const val KEY_SOUND_ENABLED = "scan_sound_enabled"
    private const val KEY_VIBRATION_ENABLED = "scan_vibration_enabled"
    private const val KEY_COOLDOWN_MS = "scan_cooldown_ms"
    private const val KEY_AUTO_SCAN_ENABLED = "auto_scan_enabled"

    fun getDeviceId(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        var deviceId = prefs.getString(KEY_DEVICE_ID, null)
        if (deviceId == null) {
            deviceId = "dev_scan_" + UUID.randomUUID().toString().replace("-", "").take(10)
            prefs.edit().putString(KEY_DEVICE_ID, deviceId).apply()
        }
        return deviceId
    }

    fun getDeviceName(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(KEY_DEVICE_NAME, null)
        if (!saved.isNullOrBlank()) return saved

        val defaultName = "Scanner 01 (${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL})"
        return defaultName
    }

    fun setDeviceName(context: Context, name: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_DEVICE_NAME, name.trim()).apply()
    }

    fun getActiveStoreId(context: Context): String? {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_ACTIVE_STORE_ID, null)
    }

    fun setActiveStoreId(context: Context, storeId: String?) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_ACTIVE_STORE_ID, storeId).apply()
    }

    fun getActiveStoreName(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_ACTIVE_STORE_NAME, "") ?: ""
    }

    fun setActiveStoreName(context: Context, name: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_ACTIVE_STORE_NAME, name).apply()
    }

    fun getDeviceRole(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_DEVICE_ROLE, "SCANNER") ?: "SCANNER"
    }

    fun setDeviceRole(context: Context, role: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_DEVICE_ROLE, role).apply()
    }

    fun getTargetPosId(context: Context): String? {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_TARGET_POS_ID, null)
    }

    fun setTargetPosId(context: Context, posId: String?) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_TARGET_POS_ID, posId).apply()
    }

    fun getTargetPosName(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_TARGET_POS_NAME, "POS-01") ?: "POS-01"
    }

    fun setTargetPosName(context: Context, name: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_TARGET_POS_NAME, name).apply()
    }

    fun getCurrentEmployeeId(context: Context): String? {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_EMPLOYEE_ID, null)
    }

    fun setCurrentEmployee(context: Context, id: String?, name: String?) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_EMPLOYEE_ID, id)
            .putString(KEY_EMPLOYEE_NAME, name)
            .apply()
    }

    fun getCurrentEmployeeName(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_EMPLOYEE_NAME, "") ?: ""
    }

    fun isSoundEnabled(context: Context): Boolean {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_SOUND_ENABLED, true)
    }

    fun setSoundEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_SOUND_ENABLED, enabled).apply()
    }

    fun isVibrationEnabled(context: Context): Boolean {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_VIBRATION_ENABLED, true)
    }

    fun setVibrationEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_VIBRATION_ENABLED, enabled).apply()
    }

    fun getCooldownMs(context: Context): Long {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getLong(KEY_COOLDOWN_MS, 800L)
    }

    fun setCooldownMs(context: Context, cooldown: Long) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putLong(KEY_COOLDOWN_MS, cooldown).apply()
    }

    fun isAutoScanEnabled(context: Context): Boolean {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_AUTO_SCAN_ENABLED, true)
    }

    fun setAutoScanEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_AUTO_SCAN_ENABLED, enabled).apply()
    }

    fun disconnectDevice(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_ACTIVE_STORE_ID)
            .remove(KEY_ACTIVE_STORE_NAME)
            .remove(KEY_TARGET_POS_ID)
            .remove(KEY_TARGET_POS_NAME)
            .remove(KEY_EMPLOYEE_ID)
            .remove(KEY_EMPLOYEE_NAME)
            .apply()
    }
}
