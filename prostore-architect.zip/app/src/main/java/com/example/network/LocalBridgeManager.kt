package com.example.network

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InterfaceAddress
import java.net.NetworkInterface

/**
 * High-Speed Offline Local Network Bridge.
 * Broadcasts barcode scan events across Local Wi-Fi / LAN via UDP multicast / broadcast,
 * allowing instant zero-configuration delivery to any CorePOS Web or Desktop terminal on the same Wi-Fi.
 */
class LocalBridgeManager(private val context: Context) {

    companion object {
        private const val TAG = "LocalBridgeManager"
        const val DEFAULT_UDP_PORT = 9191
    }

    private val scope = CoroutineScope(Dispatchers.IO)
    private var multicastLock: WifiManager.MulticastLock? = null

    private val _lastBroadcastPayload = MutableStateFlow<String?>(null)
    val lastBroadcastPayload: StateFlow<String?> = _lastBroadcastPayload.asStateFlow()

    private val _isLanActive = MutableStateFlow(true)
    val isLanActive: StateFlow<Boolean> = _isLanActive.asStateFlow()

    init {
        acquireMulticastLock()
    }

    private fun acquireMulticastLock() {
        try {
            val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            multicastLock = wifi?.createMulticastLock("CorePOSMulticastLock")?.apply {
                setReferenceCounted(true)
                acquire()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not acquire multicast lock: ${e.message}")
        }
    }

    /**
     * Broadcasts barcode scan packet to all LAN / Wi-Fi subnet terminals.
     * Matches exact CorePOS offline event format:
     * {"type": "OFFLINE_BARCODE_SCAN", "barcode": "...", "deviceName": "...", "timestamp": ...}
     */
    fun broadcastScanPacket(
        barcode: String,
        deviceName: String,
        storeId: String = "",
        targetPosId: String = "",
        format: String = "EAN_13",
        port: Int = DEFAULT_UDP_PORT
    ) {
        scope.launch {
            try {
                val json = JSONObject().apply {
                    put("type", "OFFLINE_BARCODE_SCAN")
                    put("barcode", barcode)
                    put("deviceName", deviceName)
                    put("storeId", storeId)
                    put("targetPosId", targetPosId)
                    put("format", format)
                    put("timestamp", System.currentTimeMillis())
                }

                val payload = json.toString()
                _lastBroadcastPayload.value = payload

                val bytes = payload.toByteArray(Charsets.UTF_8)
                val broadcastAddresses = getBroadcastAddresses()

                DatagramSocket().use { socket ->
                    socket.broadcast = true
                    for (addr in broadcastAddresses) {
                        try {
                            val packet = DatagramPacket(bytes, bytes.size, addr, port)
                            socket.send(packet)
                        } catch (e: Exception) {
                            Log.w(TAG, "Failed sending to $addr: ${e.message}")
                        }
                    }
                    // Also send to standard local broadcast 255.255.255.255
                    try {
                        val universalPacket = DatagramPacket(
                            bytes,
                            bytes.size,
                            InetAddress.getByName("255.255.255.255"),
                            port
                        )
                        socket.send(universalPacket)
                    } catch (_: Exception) {}
                }
                Log.d(TAG, "Broadcast scan packet sent via UDP to ${broadcastAddresses.size + 1} endpoints")
            } catch (e: Exception) {
                Log.e(TAG, "Error in broadcastScanPacket: ${e.message}", e)
            }
        }
    }

    private fun getBroadcastAddresses(): List<InetAddress> {
        val list = mutableListOf<InetAddress>()
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                if (networkInterface.isLoopback || !networkInterface.isUp) continue

                for (interfaceAddress in networkInterface.interfaceAddresses) {
                    val broadcast = interfaceAddress.broadcast
                    if (broadcast != null) {
                        list.add(broadcast)
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error resolving broadcast addresses: ${e.message}")
        }
        return list
    }

    fun release() {
        try {
            if (multicastLock?.isHeld == true) {
                multicastLock?.release()
            }
        } catch (_: Exception) {}
    }
}
