package com.example

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.AppViewModel
import com.example.ui.MainAppScreen
import com.example.ui.theme.StorePOSTheme

class MainActivity : ComponentActivity() {
    private val appViewModel: AppViewModel by viewModels()

    private val barcodeBuffer = StringBuilder()
    private val handler = Handler(Looper.getMainLooper())
    private var flushRunnable: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            StorePOSTheme {
                MainAppScreen(appViewModel = appViewModel)
            }
        }
    }

    /**
     * Intercepts Bluetooth HID Keypress Events from external physical laser barcode scanners.
     * Buffers character streams until '\n', Enter keycode, or 30ms delimiter timeout.
     */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            val unicodeChar = event.unicodeChar

            if (event.keyCode == KeyEvent.KEYCODE_ENTER || unicodeChar == '\n'.code || unicodeChar == '\r'.code) {
                if (barcodeBuffer.isNotEmpty()) {
                    flushBarcodeBuffer()
                    return true
                }
            } else if (unicodeChar > 0 && !Character.isISOControl(unicodeChar)) {
                barcodeBuffer.append(unicodeChar.toChar())
                resetFlushTimer()
                // Consume rapid barcode character keystrokes to prevent triggering random UI shortcuts
                if (barcodeBuffer.length > 3) {
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun resetFlushTimer() {
        flushRunnable?.let { handler.removeCallbacks(it) }
        val runnable = Runnable { flushBarcodeBuffer() }
        flushRunnable = runnable
        handler.postDelayed(runnable, 30L) // 30ms delimiter timeout
    }

    private fun flushBarcodeBuffer() {
        flushRunnable?.let { handler.removeCallbacks(it) }
        flushRunnable = null
        val scanned = barcodeBuffer.toString().trim()
        barcodeBuffer.setLength(0)
        if (scanned.length >= 3) {
            appViewModel.onExternalBarcodeScanned(scanned)
        }
    }
}

