package com.example.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothGattServer
import android.bluetooth.BluetoothGattServerCallback
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.BluetoothLeAdvertiser
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.ParcelUuid
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.nio.charset.StandardCharsets
import java.util.UUID

sealed class BleConnectionState {
    object Standby : BleConnectionState()
    object Advertising : BleConnectionState()
    data class Connected(val deviceCount: Int, val deviceNames: List<String>) : BleConnectionState()
    data class Error(val message: String) : BleConnectionState()
}

/**
 * High-Speed Offline Bluetooth Low Energy (BLE) GATT Server & Serial Peripheral
 * Emulates:
 * 1. Nordic Semiconductor UART Service (NUS) - Standard for Web Bluetooth & POS Terminals
 * 2. Serial Barcode Service (FFE0/FFE1) - Universal Barcode Gun standard
 */
class BleGattServerManager(private val context: Context) {

    companion object {
        private const val TAG = "BleGattServer"

        // Nordic UART Service (NUS)
        val NORDIC_UART_SERVICE_UUID: UUID = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e")
        val NORDIC_RX_CHAR_UUID: UUID = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e") // POS writes to Scanner
        val NORDIC_TX_CHAR_UUID: UUID = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e") // Scanner notifies POS

        // Standard Serial Barcode Service (0xFFE0 / 0xFFE1)
        val SERIAL_BARCODE_SERVICE_UUID: UUID = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb")
        val SERIAL_BARCODE_CHAR_UUID: UUID = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb")

        // Standard Client Characteristic Configuration Descriptor (CCCD)
        val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }

    private val scope = CoroutineScope(Dispatchers.IO)
    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    private var gattServer: BluetoothGattServer? = null
    private var advertiser: BluetoothLeAdvertiser? = null

    private val connectedDevices = mutableSetOf<BluetoothDevice>()
    private val subscribedDevices = mutableSetOf<BluetoothDevice>()

    private val _connectionState = MutableStateFlow<BleConnectionState>(BleConnectionState.Standby)
    val connectionState: StateFlow<BleConnectionState> = _connectionState.asStateFlow()

    private val _isAdvertising = MutableStateFlow(false)
    val isAdvertising: StateFlow<Boolean> = _isAdvertising.asStateFlow()

    private val _connectedCount = MutableStateFlow(0)
    val connectedCount: StateFlow<Int> = _connectedCount.asStateFlow()

    private val _lastBeamedCode = MutableStateFlow<String?>(null)
    val lastBeamedCode: StateFlow<String?> = _lastBeamedCode.asStateFlow()

    private val _incomingMessages = MutableStateFlow<List<String>>(emptyList())
    val incomingMessages: StateFlow<List<String>> = _incomingMessages.asStateFlow()

    private var nordicTxCharacteristic: BluetoothGattCharacteristic? = null
    private var serialBarcodeCharacteristic: BluetoothGattCharacteristic? = null

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
            Log.d(TAG, "BLE Peripheral Advertising started successfully")
            _isAdvertising.value = true
            updateConnectionState()
        }

        override fun onStartFailure(errorCode: Int) {
            val errorMsg = when (errorCode) {
                ADVERTISE_FAILED_ALREADY_STARTED -> "Advertising already started"
                ADVERTISE_FAILED_DATA_TOO_LARGE -> "Advertise data too large"
                ADVERTISE_FAILED_FEATURE_UNSUPPORTED -> "BLE Advertising unsupported on this device"
                ADVERTISE_FAILED_INTERNAL_ERROR -> "BLE Internal error"
                ADVERTISE_FAILED_TOO_MANY_ADVERTISERS -> "Too many BLE advertisers active"
                else -> "Advertise failed ($errorCode)"
            }
            Log.e(TAG, "BLE Advertising failed: $errorMsg")
            _isAdvertising.value = false
            _connectionState.value = BleConnectionState.Error(errorMsg)
        }
    }

    private val gattServerCallback = object : BluetoothGattServerCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) {
            super.onConnectionStateChange(device, status, newState)
            Log.d(TAG, "Device ${device.address} connection state changed: $newState (status: $status)")
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                connectedDevices.add(device)
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                connectedDevices.remove(device)
                subscribedDevices.remove(device)
            }
            updateConnectionState()
        }

        @SuppressLint("MissingPermission")
        override fun onDescriptorReadRequest(
            device: BluetoothDevice,
            requestId: Int,
            offset: Int,
            descriptor: BluetoothGattDescriptor
        ) {
            super.onDescriptorReadRequest(device, requestId, offset, descriptor)
            if (descriptor.uuid == CCCD_UUID) {
                val value = if (subscribedDevices.contains(device)) {
                    BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                } else {
                    BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE
                }
                gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, value)
            } else {
                gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, descriptor.value)
            }
        }

        @SuppressLint("MissingPermission")
        override fun onDescriptorWriteRequest(
            device: BluetoothDevice,
            requestId: Int,
            descriptor: BluetoothGattDescriptor,
            preparedWrite: Boolean,
            responseNeeded: Boolean,
            offset: Int,
            value: ByteArray
        ) {
            super.onDescriptorWriteRequest(device, requestId, descriptor, preparedWrite, responseNeeded, offset, value)
            if (descriptor.uuid == CCCD_UUID) {
                if (value.contentEquals(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE) ||
                    value.contentEquals(BluetoothGattDescriptor.ENABLE_INDICATION_VALUE)
                ) {
                    subscribedDevices.add(device)
                    Log.d(TAG, "Device ${device.address} SUBSCRIBED to barcode notifications")
                } else {
                    subscribedDevices.remove(device)
                    Log.d(TAG, "Device ${device.address} UNSUBSCRIBED from notifications")
                }
                if (responseNeeded) {
                    gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, value)
                }
                updateConnectionState()
            } else if (responseNeeded) {
                gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, value)
            }
        }

        @SuppressLint("MissingPermission")
        override fun onCharacteristicWriteRequest(
            device: BluetoothDevice,
            requestId: Int,
            characteristic: BluetoothGattCharacteristic,
            preparedWrite: Boolean,
            responseNeeded: Boolean,
            offset: Int,
            value: ByteArray
        ) {
            super.onCharacteristicWriteRequest(device, requestId, characteristic, preparedWrite, responseNeeded, offset, value)
            val msg = String(value, StandardCharsets.UTF_8).trim()
            Log.d(TAG, "Received message from POS: $msg")
            _incomingMessages.value = (listOf(msg) + _incomingMessages.value).take(10)

            if (responseNeeded) {
                gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, value)
            }
        }

        @SuppressLint("MissingPermission")
        override fun onCharacteristicReadRequest(
            device: BluetoothDevice,
            requestId: Int,
            offset: Int,
            characteristic: BluetoothGattCharacteristic
        ) {
            super.onCharacteristicReadRequest(device, requestId, offset, characteristic)
            gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, characteristic.value ?: ByteArray(0))
        }

        override fun onNotificationSent(device: BluetoothDevice?, status: Int) {
            super.onNotificationSent(device, status)
            Log.d(TAG, "Notification sent to ${device?.address}, status: $status")
        }
    }

    private fun updateConnectionState() {
        val count = connectedDevices.size
        _connectedCount.value = count
        if (count > 0) {
            val names = connectedDevices.map { dev ->
                try {
                    dev.name ?: dev.address
                } catch (_: SecurityException) {
                    dev.address
                }
            }
            _connectionState.value = BleConnectionState.Connected(count, names)
        } else if (_isAdvertising.value) {
            _connectionState.value = BleConnectionState.Advertising
        } else {
            _connectionState.value = BleConnectionState.Standby
        }
    }

    fun hasRequiredPermissions(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val adv = ContextCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED
            val conn = ContextCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
            return adv && conn
        }
        return ContextCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED
    }

    fun isBluetoothSupported(): Boolean = bluetoothAdapter != null

    fun isBluetoothEnabled(): Boolean = bluetoothAdapter?.isEnabled == true

    @SuppressLint("MissingPermission")
    fun startGattServer(deviceName: String = "CorePOS-Scanner"): Boolean {
        if (!isBluetoothSupported() || !isBluetoothEnabled() || !hasRequiredPermissions()) {
            _connectionState.value = BleConnectionState.Error("Bluetooth disabled or permissions missing")
            return false
        }

        try {
            stopGattServer()

            // 1. Initialize GATT Server
            gattServer = bluetoothManager?.openGattServer(context, gattServerCallback)
            if (gattServer == null) {
                _connectionState.value = BleConnectionState.Error("Failed to open BLE GATT Server")
                return false
            }

            // 2. Build Nordic UART Service (NUS)
            val nusService = BluetoothGattService(
                NORDIC_UART_SERVICE_UUID,
                BluetoothGattService.SERVICE_TYPE_PRIMARY
            )

            // NUS RX Characteristic (Write from POS Web Terminal to Scanner)
            val rxChar = BluetoothGattCharacteristic(
                NORDIC_RX_CHAR_UUID,
                BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE,
                BluetoothGattCharacteristic.PERMISSION_WRITE
            )

            // NUS TX Characteristic (Notify from Scanner to POS Web Terminal)
            val txChar = BluetoothGattCharacteristic(
                NORDIC_TX_CHAR_UUID,
                BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_READ,
                BluetoothGattCharacteristic.PERMISSION_READ
            )
            val txCccd = BluetoothGattDescriptor(
                CCCD_UUID,
                BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE
            )
            txCccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            txChar.addDescriptor(txCccd)

            nordicTxCharacteristic = txChar
            nusService.addCharacteristic(rxChar)
            nusService.addCharacteristic(txChar)
            gattServer?.addService(nusService)

            // 3. Build Universal Serial Barcode Service (FFE0/FFE1)
            val serialService = BluetoothGattService(
                SERIAL_BARCODE_SERVICE_UUID,
                BluetoothGattService.SERVICE_TYPE_PRIMARY
            )
            val serialChar = BluetoothGattCharacteristic(
                SERIAL_BARCODE_CHAR_UUID,
                BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_READ or BluetoothGattCharacteristic.PROPERTY_WRITE,
                BluetoothGattCharacteristic.PERMISSION_READ or BluetoothGattCharacteristic.PERMISSION_WRITE
            )
            val serialCccd = BluetoothGattDescriptor(
                CCCD_UUID,
                BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE
            )
            serialCccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            serialChar.addDescriptor(serialCccd)

            serialBarcodeCharacteristic = serialChar
            serialService.addCharacteristic(serialChar)
            gattServer?.addService(serialService)

            // 4. Start Advertising as BLE Wireless Scanner Gun
            startAdvertising(deviceName)
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Error starting GATT Server: ${e.message}", e)
            _connectionState.value = BleConnectionState.Error(e.localizedMessage ?: "GATT Server Error")
            return false
        }
    }

    @SuppressLint("MissingPermission")
    private fun startAdvertising(deviceName: String) {
        advertiser = bluetoothAdapter?.bluetoothLeAdvertiser
        if (advertiser == null) {
            _connectionState.value = BleConnectionState.Error("BLE Advertiser not available")
            return
        }

        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setConnectable(true)
            .setTimeout(0) // Advertise indefinitely
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
            .build()

        val data = AdvertiseData.Builder()
            .setIncludeDeviceName(true)
            .setIncludeTxPowerLevel(true)
            .addServiceUuid(ParcelUuid(NORDIC_UART_SERVICE_UUID))
            .build()

        val scanResponse = AdvertiseData.Builder()
            .addServiceUuid(ParcelUuid(SERIAL_BARCODE_SERVICE_UUID))
            .build()

        advertiser?.startAdvertising(settings, data, scanResponse, advertiseCallback)
    }

    @SuppressLint("MissingPermission")
    fun stopGattServer() {
        try {
            advertiser?.stopAdvertising(advertiseCallback)
        } catch (_: Exception) {}
        _isAdvertising.value = false

        try {
            gattServer?.clearServices()
            gattServer?.close()
        } catch (_: Exception) {}
        gattServer = null

        connectedDevices.clear()
        subscribedDevices.clear()
        _connectedCount.value = 0
        _connectionState.value = BleConnectionState.Standby
    }

    /**
     * Beams scanned barcode directly to all connected BLE POS Web Terminals.
     * Transmits raw UTF-8 string followed by \r\n (Carriage Return + Line Feed).
     */
    @SuppressLint("MissingPermission")
    fun beamBarcode(barcode: String): Boolean {
        val server = gattServer ?: return false
        val targetPayload = "$barcode\r\n".toByteArray(StandardCharsets.UTF_8)
        var anySent = false

        _lastBeamedCode.value = barcode

        // Send through Nordic UART TX characteristic
        nordicTxCharacteristic?.let { char ->
            char.value = targetPayload
            for (device in connectedDevices) {
                val sent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    val status = server.notifyCharacteristicChanged(device, char, false, targetPayload)
                    status == 0 || status == BluetoothGatt.GATT_SUCCESS
                } else {
                    @Suppress("DEPRECATION")
                    server.notifyCharacteristicChanged(device, char, false)
                }
                if (sent) anySent = true
            }
        }

        // Send through Serial Barcode (FFE1) characteristic
        serialBarcodeCharacteristic?.let { char ->
            char.value = targetPayload
            for (device in connectedDevices) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    server.notifyCharacteristicChanged(device, char, false, targetPayload)
                } else {
                    @Suppress("DEPRECATION")
                    server.notifyCharacteristicChanged(device, char, false)
                }
            }
        }

        return anySent
    }
}
