package com.example.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.InputStream
import java.util.UUID

sealed class SppConnectionState {
    object Disconnected : SppConnectionState()
    data class Connecting(val deviceName: String) : SppConnectionState()
    data class Connected(val deviceName: String) : SppConnectionState()
    data class Error(val message: String) : SppConnectionState()
}

/**
 * Serial Port Profile (SPP) Bluetooth Laser Scanner Manager
 * Connects directly to external Bluetooth physical laser scanners communicating over RFCOMM/SPP stream.
 */
class BluetoothSppScannerManager(private val context: Context) {

    companion object {
        private const val TAG = "BluetoothSppScanner"
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter
    private val scope = CoroutineScope(Dispatchers.IO)

    private var socket: BluetoothSocket? = null
    private var readJob: Job? = null

    private val _connectionState = MutableStateFlow<SppConnectionState>(SppConnectionState.Disconnected)
    val connectionState: StateFlow<SppConnectionState> = _connectionState.asStateFlow()

    @SuppressLint("MissingPermission")
    fun getPairedSppDevices(): List<BluetoothDevice> {
        return try {
            bluetoothAdapter?.bondedDevices?.toList() ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    @SuppressLint("MissingPermission")
    fun connectToDevice(device: BluetoothDevice, onBarcodeScanned: (String) -> Unit) {
        disconnect()

        val devName = try { device.name ?: device.address } catch (_: Exception) { device.address }
        _connectionState.value = SppConnectionState.Connecting(devName)

        readJob = scope.launch {
            try {
                val sppSocket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                bluetoothAdapter?.cancelDiscovery()
                sppSocket.connect()
                socket = sppSocket

                _connectionState.value = SppConnectionState.Connected(devName)
                Log.d(TAG, "Connected to SPP Scanner: $devName")

                val inputStream: InputStream = sppSocket.inputStream
                val buffer = ByteArray(1024)
                val lineBuffer = StringBuilder()

                while (isActive) {
                    val bytesRead = inputStream.read(buffer)
                    if (bytesRead > 0) {
                        val text = String(buffer, 0, bytesRead, Charsets.UTF_8)
                        for (ch in text) {
                            if (ch == '\n' || ch == '\r') {
                                val barcode = lineBuffer.toString().trim()
                                lineBuffer.setLength(0)
                                if (barcode.length >= 3) {
                                    scope.launch(Dispatchers.Main) {
                                        onBarcodeScanned(barcode)
                                    }
                                }
                            } else {
                                lineBuffer.append(ch)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "SPP socket error: ${e.message}")
                _connectionState.value = SppConnectionState.Error(e.message ?: "Connection lost")
                disconnect()
            }
        }
    }

    fun disconnect() {
        readJob?.cancel()
        readJob = null
        try {
            socket?.close()
        } catch (_: Exception) {}
        socket = null
        _connectionState.value = SppConnectionState.Disconnected
    }
}
