package com.example.data.repository

import com.example.data.firebase.FirebaseManager
import com.example.data.model.AccessRequest
import com.example.data.model.Device
import com.example.data.model.DeviceStatus
import com.example.data.model.DeviceType
import com.example.data.model.currentIsoTimestamp
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class DeviceRepository {
    private val firestore: FirebaseFirestore
        get() = FirebaseManager.getFirestore()

    private fun parseDeviceFromDoc(doc: com.google.firebase.firestore.DocumentSnapshot, storeId: String): Device? {
        try {
            val d = doc.toObject(Device::class.java)
            if (d != null) {
                val finalId = if (d.id.isNotBlank()) d.id else if (d.deviceId.isNotBlank()) d.deviceId else doc.id
                val finalName = if (d.name.isNotBlank()) d.name else if (d.deviceName.isNotBlank()) d.deviceName else "Device"
                val finalType = if (d.type.isNotBlank()) d.type else d.deviceType
                return d.copy(
                    id = finalId,
                    deviceId = finalId,
                    storeId = storeId,
                    name = finalName,
                    deviceName = finalName,
                    type = finalType,
                    deviceType = finalType
                )
            }
        } catch (_: Exception) {}

        return try {
            val data = doc.data ?: return null
            val finalId = (data["deviceId"] as? String) ?: (data["id"] as? String) ?: doc.id
            val finalName = (data["name"] as? String) ?: (data["deviceName"] as? String) ?: "Device"
            val finalType = (data["type"] as? String) ?: (data["deviceType"] as? String) ?: DeviceType.SCANNER.name
            val status = (data["status"] as? String) ?: DeviceStatus.PENDING.name
            val online = (data["onlineStatus"] as? String) ?: "ONLINE"
            val paired = (data["pairedPosDeviceId"] as? String) ?: (data["connectedPosId"] as? String) ?: ""
            Device(
                id = finalId,
                deviceId = finalId,
                storeId = storeId,
                name = finalName,
                deviceName = finalName,
                type = finalType,
                deviceType = finalType,
                status = status,
                onlineStatus = online,
                pairedPosDeviceId = paired,
                connectedPosId = paired,
                createdAt = data["createdAt"],
                lastSeen = data["lastSeen"],
                lastActiveAt = data["lastActiveAt"]
            )
        } catch (_: Exception) {
            null
        }
    }

    fun getDevicesForStore(storeId: String): Flow<List<Device>> = observeDevices(storeId)

    fun observeDevices(storeId: String): Flow<List<Device>> = callbackFlow {
        if (storeId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val registration = firestore.collection("stores").document(storeId)
            .collection("devices")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { doc ->
                    parseDeviceFromDoc(doc, storeId)
                } ?: emptyList()
                trySend(list)
            }

        awaitClose { registration.remove() }
    }

    fun observeApprovedPosDevices(storeId: String): Flow<List<Device>> = callbackFlow {
        if (storeId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val registration = firestore.collection("stores").document(storeId)
            .collection("devices")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { doc ->
                    val d = parseDeviceFromDoc(doc, storeId) ?: return@mapNotNull null
                    val t = d.deviceType.uppercase()
                    val isPos = t == "POS" || t == "POS_TERMINAL" || t == "POS_REGISTER"
                    val isApproved = d.status.uppercase() == DeviceStatus.APPROVED.name || d.status.uppercase() == "ACTIVE"
                    if (isPos && isApproved) d else null
                } ?: emptyList()
                trySend(list)
            }

        awaitClose { registration.remove() }
    }

    fun observeDevice(storeId: String, deviceId: String): Flow<Device?> = callbackFlow {
        if (storeId.isBlank() || deviceId.isBlank()) {
            trySend(null)
            close()
            return@callbackFlow
        }

        val registration = firestore.collection("stores").document(storeId)
            .collection("devices").document(deviceId)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null || !snapshot.exists()) {
                    trySend(null)
                    return@addSnapshotListener
                }
                val d = parseDeviceFromDoc(snapshot, storeId)
                trySend(d)
            }

        awaitClose { registration.remove() }
    }

    suspend fun registerDevice(
        storeId: String,
        deviceId: String,
        deviceName: String,
        deviceType: DeviceType = DeviceType.SCANNER
    ): Result<Device> {
        return try {
            val docRef = firestore.collection("stores").document(storeId)
                .collection("devices").document(deviceId)

            val existingSnapshot = docRef.get().await()
            val isoNow = currentIsoTimestamp()
            if (existingSnapshot.exists()) {
                val existing = parseDeviceFromDoc(existingSnapshot, storeId)
                docRef.update(
                    mapOf(
                        "name" to deviceName,
                        "deviceName" to deviceName,
                        "type" to deviceType.name,
                        "deviceType" to deviceType.name,
                        "onlineStatus" to "ONLINE",
                        "lastSeen" to isoNow,
                        "lastActiveAt" to isoNow
                    )
                ).await()
                Result.success(existing?.copy(
                    name = deviceName,
                    deviceName = deviceName,
                    type = deviceType.name,
                    deviceType = deviceType.name,
                    onlineStatus = "ONLINE"
                )
                    ?: Device(id = deviceId, deviceId = deviceId, storeId = storeId, name = deviceName, deviceName = deviceName))
            } else {
                val newDevice = Device(
                    id = deviceId,
                    deviceId = deviceId,
                    storeId = storeId,
                    name = deviceName,
                    deviceName = deviceName,
                    type = deviceType.name,
                    deviceType = deviceType.name,
                    status = DeviceStatus.PENDING.name,
                    onlineStatus = "ONLINE",
                    createdAt = isoNow,
                    lastSeen = isoNow,
                    registeredAt = isoNow,
                    lastActiveAt = isoNow
                )
                docRef.set(newDevice).await()

                val requestId = "req_" + deviceId.replace("dev_", "").take(16)
                val accessRequest = AccessRequest(
                    id = requestId,
                    requestId = requestId,
                    storeId = storeId,
                    deviceId = deviceId,
                    deviceName = deviceName,
                    requesterName = deviceName,
                    requestType = "SCANNER",
                    requestedRole = "SCANNER",
                    requestedPermission = "SCANNER",
                    status = DeviceStatus.PENDING.name,
                    message = "$deviceName wants to connect as a Scanner.",
                    createdAt = isoNow
                )
                firestore.collection("stores").document(storeId)
                    .collection("accessRequests").document(requestId)
                    .set(accessRequest).await()

                Result.success(newDevice)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateDeviceStatus(
        storeId: String,
        deviceId: String,
        newStatus: DeviceStatus
    ): Result<Unit> {
        return try {
            firestore.collection("stores").document(storeId)
                .collection("devices").document(deviceId)
                .update("status", newStatus.name).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateHeartbeat(
        storeId: String,
        deviceId: String,
        employeeName: String = "",
        connectedPosId: String = "",
        connectedPosName: String = "",
        isOnline: Boolean = true
    ) {
        try {
            val isoNow = currentIsoTimestamp()
            val updates = mutableMapOf<String, Any>(
                "lastSeen" to isoNow,
                "lastActiveAt" to isoNow,
                "onlineStatus" to (if (isOnline) "ONLINE" else "OFFLINE")
            )
            if (employeeName.isNotBlank()) updates["currentEmployeeName"] = employeeName
            if (connectedPosId.isNotBlank()) {
                updates["connectedPosId"] = connectedPosId
                updates["pairedPosDeviceId"] = connectedPosId
            }
            if (connectedPosName.isNotBlank()) updates["connectedPosName"] = connectedPosName

            firestore.collection("stores").document(storeId)
                .collection("devices").document(deviceId)
                .update(updates).await()
        } catch (_: Exception) {}
    }

    suspend fun disconnectPosBinding(storeId: String, deviceId: String): Result<Unit> {
        return try {
            firestore.collection("stores").document(storeId)
                .collection("devices").document(deviceId)
                .update(
                    mapOf(
                        "connectedPosId" to "",
                        "connectedPosName" to "",
                        "pairedPosDeviceId" to ""
                    )
                ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun requestAdminAccess(
        storeId: String,
        deviceId: String,
        deviceName: String,
        userEmail: String
    ): Result<AccessRequest> {
        return try {
            val requestId = UUID.randomUUID().toString()
            val isoNow = currentIsoTimestamp()
            val request = AccessRequest(
                id = requestId,
                requestId = requestId,
                storeId = storeId,
                deviceId = deviceId,
                deviceName = deviceName,
                requesterName = deviceName,
                requestType = "ADMIN_ACCESS",
                requestedRole = "ADMIN",
                requestedPermission = "ADMIN",
                userEmail = userEmail,
                status = DeviceStatus.PENDING.name,
                message = "$deviceName ($userEmail) requested Admin access.",
                createdAt = isoNow
            )
            firestore.collection("stores").document(storeId)
                .collection("accessRequests").document(requestId)
                .set(request).await()

            Result.success(request)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun observeAccessRequest(storeId: String, requestId: String): Flow<AccessRequest?> = callbackFlow {
        if (storeId.isBlank() || requestId.isBlank()) {
            trySend(null)
            close()
            return@callbackFlow
        }

        val registration = firestore.collection("stores").document(storeId)
            .collection("accessRequests").document(requestId)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null || !snapshot.exists()) {
                    trySend(null)
                    return@addSnapshotListener
                }
                try {
                    val req = snapshot.toObject(AccessRequest::class.java)?.copy(id = snapshot.id, requestId = snapshot.id)
                    trySend(req)
                } catch (_: Exception) {
                    val data = snapshot.data
                    if (data != null) {
                        val reqId = (data["requestId"] as? String) ?: snapshot.id
                        val dId = (data["deviceId"] as? String) ?: ""
                        val dName = (data["deviceName"] as? String) ?: (data["requesterName"] as? String) ?: ""
                        val status = (data["status"] as? String) ?: DeviceStatus.PENDING.name
                        trySend(AccessRequest(id = reqId, requestId = reqId, storeId = storeId, deviceId = dId, deviceName = dName, requesterName = dName, status = status))
                    } else {
                        trySend(null)
                    }
                }
            }

        awaitClose { registration.remove() }
    }
}
