package com.example.data.repository

import com.example.data.firebase.FirebaseManager
import com.example.data.model.AccessRequest
import com.example.data.model.Device
import com.example.data.model.DeviceStatus
import com.example.data.model.DeviceType
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class DeviceRepository {
    private val firestore: FirebaseFirestore
        get() = FirebaseManager.getFirestore()

    fun getDevicesForStore(storeId: String): Flow<List<Device>> = callbackFlow {
        if (storeId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val registration = firestore.collection("stores").document(storeId)
            .collection("devices")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { doc ->
                    doc.toObject(Device::class.java)?.copy(id = doc.id, deviceId = doc.id, storeId = storeId)
                } ?: emptyList()
                trySend(list)
            }

        awaitClose { registration.remove() }
    }

    fun observeApprovedPosDevices(storeId: String): Flow<List<Device>> = callbackFlow {
        if (storeId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val registration = firestore.collection("stores").document(storeId)
            .collection("devices")
            .whereIn("deviceType", listOf("POS", "POS_TERMINAL", "pos", "POS_REGISTER"))
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { doc ->
                    val d = doc.toObject(Device::class.java)?.copy(id = doc.id, deviceId = doc.id, storeId = storeId)
                    if (d != null && d.status == DeviceStatus.APPROVED.name) d else null
                } ?: emptyList()
                trySend(list)
            }

        awaitClose { registration.remove() }
    }

    fun observeDevice(storeId: String, deviceId: String): Flow<Device?> = callbackFlow {
        if (storeId.isBlank() || deviceId.isBlank()) {
            trySend(null)
            close()
            return@callbackFlow
        }

        val registration = firestore.collection("stores").document(storeId)
            .collection("devices").document(deviceId)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null || !snapshot.exists()) {
                    trySend(null)
                    return@addSnapshotListener
                }
                val device = snapshot.toObject(Device::class.java)?.copy(
                    id = snapshot.id,
                    deviceId = snapshot.id,
                    storeId = storeId
                )
                trySend(device)
            }

        awaitClose { registration.remove() }
    }

    suspend fun registerDevice(
        storeId: String,
        deviceId: String,
        deviceName: String,
        deviceType: DeviceType = DeviceType.SCANNER
    ): Result<Device> {
        return try {
            val docRef = firestore.collection("stores").document(storeId)
                .collection("devices").document(deviceId)

            val existingSnapshot = docRef.get().await()
            if (existingSnapshot.exists()) {
                val existing = existingSnapshot.toObject(Device::class.java)!!
                // Update heartbeat
                docRef.update(
                    mapOf(
                        "deviceName" to deviceName,
                        "onlineStatus" to "ONLINE",
                        "lastSeen" to System.currentTimeMillis(),
                        "lastActiveAt" to System.currentTimeMillis()
                    )
                ).await()
                Result.success(existing.copy(deviceName = deviceName, onlineStatus = "ONLINE"))
            } else {
                val newDevice = Device(
                    id = deviceId,
                    deviceId = deviceId,
                    storeId = storeId,
                    deviceName = deviceName,
                    deviceType = deviceType.name,
                    status = DeviceStatus.PENDING.name,
                    onlineStatus = "ONLINE",
                    createdAt = System.currentTimeMillis(),
                    lastSeen = System.currentTimeMillis(),
                    registeredAt = System.currentTimeMillis(),
                    lastActiveAt = System.currentTimeMillis()
                )
                docRef.set(newDevice).await()

                // Also create an AccessRequest in stores/{storeId}/accessRequests/{requestId}
                val requestId = "req_" + deviceId.replace("dev_", "").take(16)
                val accessRequest = AccessRequest(
                    id = requestId,
                    requestId = requestId,
                    storeId = storeId,
                    deviceId = deviceId,
                    deviceName = deviceName,
                    requestType = "SCANNER",
                    requestedRole = "SCANNER",
                    status = DeviceStatus.PENDING.name,
                    message = "$deviceName wants to connect as a Scanner.",
                    createdAt = System.currentTimeMillis()
                )
                firestore.collection("stores").document(storeId)
                    .collection("accessRequests").document(requestId)
                    .set(accessRequest).await()

                Result.success(newDevice)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateDeviceStatus(
        storeId: String,
        deviceId: String,
        newStatus: DeviceStatus
    ): Result<Unit> {
        return try {
            firestore.collection("stores").document(storeId)
                .collection("devices").document(deviceId)
                .update("status", newStatus.name).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateHeartbeat(
        storeId: String,
        deviceId: String,
        employeeName: String = "",
        connectedPosId: String = "",
        connectedPosName: String = "",
        isOnline: Boolean = true
    ) {
        try {
            val updates = mutableMapOf<String, Any>(
                "lastSeen" to System.currentTimeMillis(),
                "lastActiveAt" to System.currentTimeMillis(),
                "onlineStatus" to (if (isOnline) "ONLINE" else "OFFLINE")
            )
            if (employeeName.isNotBlank()) updates["currentEmployeeName"] = employeeName
            if (connectedPosId.isNotBlank()) updates["connectedPosId"] = connectedPosId
            if (connectedPosName.isNotBlank()) updates["connectedPosName"] = connectedPosName

            firestore.collection("stores").document(storeId)
                .collection("devices").document(deviceId)
                .update(updates).await()
        } catch (_: Exception) {}
    }

    suspend fun requestAdminAccess(
        storeId: String,
        deviceId: String,
        deviceName: String,
        userEmail: String
    ): Result<AccessRequest> {
        return try {
            val requestId = UUID.randomUUID().toString()
            val request = AccessRequest(
                id = requestId,
                requestId = requestId,
                storeId = storeId,
                deviceId = deviceId,
                deviceName = deviceName,
                requestType = "ADMIN_ACCESS",
                requestedRole = "ADMIN",
                userEmail = userEmail,
                status = DeviceStatus.PENDING.name,
                message = "$deviceName ($userEmail) requested Admin access.",
                createdAt = System.currentTimeMillis()
            )
            firestore.collection("stores").document(storeId)
                .collection("accessRequests").document(requestId)
                .set(request).await()

            Result.success(request)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun observeAccessRequest(storeId: String, requestId: String): Flow<AccessRequest?> = callbackFlow {
        if (storeId.isBlank() || requestId.isBlank()) {
            trySend(null)
            close()
            return@callbackFlow
        }

        val registration = firestore.collection("stores").document(storeId)
            .collection("accessRequests").document(requestId)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null || !snapshot.exists()) {
                    trySend(null)
                    return@addSnapshotListener
                }
                val req = snapshot.toObject(AccessRequest::class.java)?.copy(id = snapshot.id)
                trySend(req)
            }

        awaitClose { registration.remove() }
    }
}
