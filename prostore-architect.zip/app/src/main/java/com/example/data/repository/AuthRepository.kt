package com.example.data.repository

import android.content.Context
import com.example.data.firebase.FirebaseManager
import com.example.data.model.UserProfile
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class AuthRepository {
    private val auth: FirebaseAuth
        get() = FirebaseManager.getAuth()

    private val firestore
        get() = FirebaseManager.getFirestore()

    val currentUserFlow: Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            trySend(auth.currentUser)
        }
        try {
            auth.addAuthStateListener(listener)
            trySend(auth.currentUser)
        } catch (_: Exception) {
            trySend(null)
        }
        awaitClose {
            try {
                auth.removeAuthStateListener(listener)
            } catch (_: Exception) {}
        }
    }

    val currentUserId: String?
        get() = try { auth.currentUser?.uid } catch (_: Exception) { null }

    val currentUserEmail: String?
        get() = try { auth.currentUser?.email } catch (_: Exception) { null }

    suspend fun signIn(email: String, password: String): Result<FirebaseUser> {
        return try {
            val result = auth.signInWithEmailAndPassword(email.trim(), password).await()
            val user = result.user ?: throw IllegalStateException("Authentication failed - user is null")
            syncUserProfile(user)
            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun signUp(email: String, password: String, displayName: String): Result<FirebaseUser> {
        return try {
            val result = auth.createUserWithEmailAndPassword(email.trim(), password).await()
            val user = result.user ?: throw IllegalStateException("Sign up failed - user is null")
            syncUserProfile(user, displayName)
            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Opens the system Google account chooser, then exchanges the returned
     * Google ID token for a Firebase session. No Google token is persisted by
     * the app; Firebase Auth owns the session lifecycle.
     */
    suspend fun signInWithGoogle(context: Context): Result<FirebaseUser> {
        return try {
            val credentialManager = CredentialManager.create(context)
            val googleOption = GetGoogleIdOption.Builder()
                .setServerClientId(com.example.BuildConfig.GOOGLE_WEB_CLIENT_ID)
                .setFilterByAuthorizedAccounts(false)
                .setAutoSelectEnabled(false)
                .build()
            val request = GetCredentialRequest.Builder()
                .addCredentialOption(googleOption)
                .build()
            val credentialResult = credentialManager.getCredential(context, request)
            val googleCredential = GoogleIdTokenCredential.createFrom(credentialResult.credential.data)
            val firebaseCredential = GoogleAuthProvider.getCredential(googleCredential.idToken, null)
            val result = auth.signInWithCredential(firebaseCredential).await()
            val user = result.user ?: throw IllegalStateException("Google authentication returned no user")
            syncUserProfile(user, googleCredential.displayName)
            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun syncUserProfile(user: FirebaseUser, displayName: String? = null) {
        try {
            val name = displayName?.takeIf { it.isNotBlank() } ?: user.displayName ?: user.email?.substringBefore("@") ?: "User"
            val isoNow = com.example.data.model.currentIsoTimestamp()
            val userMap = hashMapOf(
                "userId" to user.uid,
                "uid" to user.uid,
                "email" to (user.email ?: ""),
                "displayName" to name,
                "createdAt" to isoNow
            )
            firestore.collection("users").document(user.uid)
                .set(userMap, com.google.firebase.firestore.SetOptions.merge()).await()
        } catch (e: Exception) {
            // Profile sync failure should not block auth
            e.printStackTrace()
        }
    }

    fun signOut() {
        try {
            auth.signOut()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
