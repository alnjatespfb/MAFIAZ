package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "pending_scans")
data class PendingScanEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val storeId: String,
    val deviceId: String,
    val employeeId: String,
    val employeeName: String,
    val barcode: String,
    val format: String = "EAN_13",
    val targetPosId: String = "",
    val targetPosName: String = "",
    val scanMode: String = "SALE",
    val timestamp: Long = System.currentTimeMillis(),
    val isSynced: Boolean = false,
    val retryCount: Int = 0
)
