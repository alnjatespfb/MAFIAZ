package com.example.data.repository

import com.example.data.firebase.FirebaseManager
import com.example.data.model.Employee
import com.example.data.model.Role
import com.example.data.model.Store
import com.example.data.model.StorePermission
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class StoreRepository {
    private val firestore: FirebaseFirestore
        get() = FirebaseManager.getFirestore()

    fun getStoresForUser(userId: String): Flow<List<Store>> = callbackFlow {
        if (userId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        // Real-time listener on stores owned by this user
        val registration = firestore.collection("stores")
            .whereEqualTo("ownerId", userId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val stores = snapshot?.documents?.mapNotNull { doc ->
                    doc.toObject(Store::class.java)?.copy(id = doc.id)
                } ?: emptyList()
                trySend(stores)
            }

        awaitClose { registration.remove() }
    }

    suspend fun createStore(
        name: String,
        country: String = "",
        currency: String = "USD",
        address: String = "",
        phone: String = "",
        logoUrl: String = "",
        ownerId: String
    ): Result<Store> {
        return try {
            val storeId = UUID.randomUUID().toString()
            val newStore = Store(
                id = storeId,
                name = name.trim(),
                ownerId = ownerId,
                country = country.trim(),
                currency = currency.trim(),
                address = address.trim(),
                phone = phone.trim(),
                logoUrl = logoUrl.trim(),
                createdAt = System.currentTimeMillis()
            )
            firestore.collection("stores").document(storeId).set(newStore).await()

            // Also automatically add the creator as Admin employee of this store
            val adminEmployee = Employee(
                id = ownerId,
                storeId = storeId,
                uid = ownerId,
                name = "Owner Admin",
                email = FirebaseManager.getAuth().currentUser?.email ?: "",
                role = Role.ADMIN.name,
                permissions = StorePermission.defaultForRole(Role.ADMIN),
                createdAt = System.currentTimeMillis()
            )
            firestore.collection("stores").document(storeId)
                .collection("employees").document(ownerId)
                .set(adminEmployee).await()

            Result.success(newStore)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getStoreOnce(storeId: String): Store? {
        return try {
            val doc = firestore.collection("stores").document(storeId).get().await()
            if (doc.exists()) {
                doc.toObject(Store::class.java)?.copy(id = doc.id)
            } else null
        } catch (_: Exception) {
            null
        }
    }

    fun getStore(storeId: String): Flow<Store?> = callbackFlow {
        if (storeId.isBlank()) {
            trySend(null)
            close()
            return@callbackFlow
        }

        val registration = firestore.collection("stores").document(storeId)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null || !snapshot.exists()) {
                    trySend(null)
                    return@addSnapshotListener
                }
                val store = snapshot.toObject(Store::class.java)?.copy(id = snapshot.id)
                trySend(store)
            }

        awaitClose { registration.remove() }
    }
}
