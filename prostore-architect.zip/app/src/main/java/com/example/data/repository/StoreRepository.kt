package com.example.data.repository

import com.example.data.firebase.FirebaseManager
import com.example.data.model.Employee
import com.example.data.model.Role
import com.example.data.model.Store
import com.example.data.model.StorePermission
import com.example.data.model.currentIsoTimestamp
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class StoreRepository {
    private val firestore: FirebaseFirestore
        get() = FirebaseManager.getFirestore()

    fun getStoresForUser(userId: String): Flow<List<Store>> = callbackFlow {
        if (userId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        // Real-time listener on stores owned by this user
        val registration = firestore.collection("stores")
            .whereEqualTo("ownerId", userId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val stores = snapshot?.documents?.mapNotNull { doc ->
                    try {
                        val s = doc.toObject(Store::class.java)
                        if (s != null) {
                            val finalId = if (s.id.isNotBlank()) s.id else if (s.storeId.isNotBlank()) s.storeId else doc.id
                            val finalName = if (s.name.isNotBlank()) s.name else "Store (${doc.id.take(8)})"
                            s.copy(id = finalId, storeId = finalId, name = finalName)
                        } else null
                    } catch (e: Exception) {
                        try {
                            val data = doc.data ?: return@mapNotNull null
                            val id = (data["storeId"] as? String) ?: (data["id"] as? String) ?: doc.id
                            val name = (data["name"] as? String) ?: "Store (${doc.id.take(8)})"
                            val ownerId = (data["ownerId"] as? String) ?: userId
                            val country = (data["country"] as? String) ?: ""
                            val currency = (data["currency"] as? String) ?: "USD"
                            val address = (data["address"] as? String) ?: ""
                            val phone = (data["phone"] as? String) ?: ""
                            val logoUrl = (data["logo"] as? String) ?: (data["logoUrl"] as? String) ?: ""
                            val taxRate = (data["taxRate"] as? Number)?.toDouble() ?: 0.0
                            Store(
                                id = id,
                                storeId = id,
                                name = name,
                                ownerId = ownerId,
                                country = country,
                                currency = currency,
                                address = address,
                                phone = phone,
                                logoUrl = logoUrl,
                                logo = logoUrl,
                                taxRate = taxRate,
                                createdAt = data["createdAt"],
                                updatedAt = data["updatedAt"]
                            )
                        } catch (_: Exception) {
                            null
                        }
                    }
                } ?: emptyList()
                trySend(stores)
            }

        awaitClose { registration.remove() }
    }

    suspend fun createStore(
        name: String,
        country: String = "",
        currency: String = "USD",
        address: String = "",
        phone: String = "",
        logoUrl: String = "",
        ownerId: String
    ): Result<Store> {
        return try {
            val storeId = UUID.randomUUID().toString()
            val isoNow = currentIsoTimestamp()
            val newStore = Store(
                id = storeId,
                storeId = storeId,
                name = name.trim(),
                ownerId = ownerId,
                country = country.trim(),
                currency = currency.trim(),
                address = address.trim(),
                phone = phone.trim(),
                logoUrl = logoUrl.trim(),
                logo = logoUrl.trim(),
                createdAt = isoNow,
                updatedAt = isoNow
            )
            firestore.collection("stores").document(storeId).set(newStore).await()

            // Also automatically add the creator as Admin employee of this store
            val adminEmployee = Employee(
                id = ownerId,
                employeeId = ownerId,
                storeId = storeId,
                uid = ownerId,
                name = "Owner Admin",
                email = FirebaseManager.getAuth().currentUser?.email ?: "",
                pin = "1234",
                pinCode = "1234",
                role = Role.ADMIN.name,
                permissions = StorePermission.defaultForRole(Role.ADMIN),
                createdAt = isoNow
            )
            firestore.collection("stores").document(storeId)
                .collection("employees").document(ownerId)
                .set(adminEmployee).await()

            Result.success(newStore)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getStoreOnce(storeId: String): Store? {
        return try {
            val doc = firestore.collection("stores").document(storeId).get().await()
            if (doc.exists()) {
                try {
                    val s = doc.toObject(Store::class.java)
                    if (s != null) {
                        val finalId = if (s.id.isNotBlank()) s.id else if (s.storeId.isNotBlank()) s.storeId else doc.id
                        s.copy(id = finalId, storeId = finalId)
                    } else null
                } catch (_: Exception) {
                    val data = doc.data ?: return null
                    val id = (data["storeId"] as? String) ?: (data["id"] as? String) ?: doc.id
                    val name = (data["name"] as? String) ?: "Store (${doc.id.take(8)})"
                    Store(id = id, storeId = id, name = name, ownerId = (data["ownerId"] as? String) ?: "")
                }
            } else null
        } catch (_: Exception) {
            null
        }
    }

    fun getStore(storeId: String): Flow<Store?> = callbackFlow {
        if (storeId.isBlank()) {
            trySend(null)
            close()
            return@callbackFlow
        }

        val registration = firestore.collection("stores").document(storeId)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null || !snapshot.exists()) {
                    trySend(null)
                    return@addSnapshotListener
                }
                try {
                    val store = snapshot.toObject(Store::class.java)?.let { s ->
                        val finalId = if (s.id.isNotBlank()) s.id else if (s.storeId.isNotBlank()) s.storeId else snapshot.id
                        s.copy(id = finalId, storeId = finalId)
                    }
                    trySend(store)
                } catch (_: Exception) {
                    val data = snapshot.data
                    if (data != null) {
                        val id = (data["storeId"] as? String) ?: (data["id"] as? String) ?: snapshot.id
                        val name = (data["name"] as? String) ?: "Store (${snapshot.id.take(8)})"
                        trySend(Store(id = id, storeId = id, name = name, ownerId = (data["ownerId"] as? String) ?: ""))
                    } else {
                        trySend(null)
                    }
                }
            }

        awaitClose { registration.remove() }
    }
}
