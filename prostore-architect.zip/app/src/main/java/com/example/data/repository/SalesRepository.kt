package com.example.data.repository

import android.content.Context
import com.example.data.firebase.FirebaseManager
import com.example.data.local.AppDatabase
import com.example.data.local.PendingSaleEntity
import com.example.data.local.SaleItemJsonConverter
import com.example.data.model.Sale
import com.example.data.model.SaleItem
import com.example.data.model.currentIsoTimestamp
import com.example.util.NetworkMonitor
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class SalesRepository(
    private val context: Context,
    private val networkMonitor: NetworkMonitor
) {
    private val firestore: FirebaseFirestore
        get() = FirebaseManager.getFirestore()

    private val pendingSaleDao = AppDatabase.getInstance(context).pendingSaleDao()

    val pendingCountFlow: Flow<Int> = pendingSaleDao.getPendingCountFlow()

    fun getPendingSales(storeId: String): Flow<List<PendingSaleEntity>> {
        return pendingSaleDao.getPendingForStore(storeId)
    }

    fun getSalesHistory(storeId: String): Flow<List<Sale>> = callbackFlow {
        if (storeId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val registration = firestore.collection("stores").document(storeId)
            .collection("sales")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { doc ->
                    try {
                        doc.toObject(Sale::class.java)?.let { s ->
                            val finalId = if (s.id.isNotBlank()) s.id else if (s.saleId.isNotBlank()) s.saleId else doc.id
                            s.copy(id = finalId, saleId = finalId, transactionId = finalId, storeId = storeId)
                        }
                    } catch (_: Exception) {
                        try {
                            val data = doc.data ?: return@mapNotNull null
                            val finalId = (data["saleId"] as? String) ?: (data["transactionId"] as? String) ?: (data["id"] as? String) ?: doc.id
                            val cashier = (data["cashierName"] as? String) ?: (data["employeeName"] as? String) ?: ""
                            val total = (data["total"] as? Number)?.toDouble() ?: (data["totalAmount"] as? Number)?.toDouble() ?: 0.0
                            val subtotal = (data["subtotal"] as? Number)?.toDouble() ?: total
                            val tax = (data["tax"] as? Number)?.toDouble() ?: (data["taxTotal"] as? Number)?.toDouble() ?: 0.0
                            val payMethod = (data["paymentMethod"] as? String) ?: "CASH"
                            Sale(
                                id = finalId,
                                saleId = finalId,
                                transactionId = finalId,
                                storeId = storeId,
                                cashierName = cashier,
                                employeeName = cashier,
                                subtotal = subtotal,
                                tax = tax,
                                taxTotal = tax,
                                total = total,
                                totalAmount = total,
                                paymentMethod = payMethod,
                                createdAt = data["createdAt"],
                                timestamp = (data["timestamp"] as? Number)?.toLong() ?: System.currentTimeMillis()
                            )
                        } catch (_: Exception) {
                            null
                        }
                    }
                }?.sortedByDescending { it.createdAtMillis } ?: emptyList()
                trySend(list)
            }

        awaitClose { registration.remove() }
    }

    suspend fun processSale(sale: Sale): Result<SaleResult> {
        val isConnected = networkMonitor.isCurrentlyConnected()

        if (!isConnected) {
            // Offline queueing
            return queueSaleLocally(sale, "Device is offline. Queued for synchronization.")
        }

        return try {
            executeFirestoreTransaction(sale)
            Result.success(SaleResult.CompletedOnline(sale))
        } catch (e: Exception) {
            // Check if network failure
            if (e is FirebaseNetworkException ||
                (e is FirebaseFirestoreException && e.code == FirebaseFirestoreException.Code.UNAVAILABLE)
            ) {
                queueSaleLocally(sale, "Network unavailable during checkout. Queued for synchronization.")
            } else {
                Result.failure(e)
            }
        }
    }

    private suspend fun executeFirestoreTransaction(sale: Sale) {
        firestore.runTransaction { tx ->
            // 1. Read phase: Read all product records to verify stock
            val productRefsAndNewStock = sale.items.map { item ->
                val ref = firestore.collection("stores").document(sale.storeId)
                    .collection("products").document(item.productId)
                val snapshot = tx.get(ref)
                if (!snapshot.exists()) {
                    throw IllegalStateException("Product '${item.productName}' does not exist in inventory.")
                }
                val currentStock = snapshot.getLong("stockQuantity")
                    ?: snapshot.getLong("quantity")
                    ?: 0L
                if (currentStock < item.quantity) {
                    throw IllegalStateException(
                        "Insufficient stock for '${item.productName}'. In stock: $currentStock, required: ${item.quantity}"
                    )
                }
                val newStock = currentStock - item.quantity
                ref to newStock
            }

            val isoNow = currentIsoTimestamp()

            // 2. Write phase: Decrement stock for each product
            for ((ref, newStock) in productRefsAndNewStock) {
                tx.update(
                    ref,
                    mapOf(
                        "stockQuantity" to newStock,
                        "quantity" to newStock,
                        "updatedAt" to isoNow
                    )
                )
            }

            // 3. Write sale record (Idempotent: document ID is transactionId)
            val txId = if (sale.transactionId.isNotBlank()) sale.transactionId else sale.id
            val totalVal = if (sale.totalAmount > 0.0) sale.totalAmount else sale.total
            val saleRef = firestore.collection("stores").document(sale.storeId)
                .collection("sales").document(txId)

            val fullSale = sale.copy(
                id = txId,
                saleId = txId,
                transactionId = txId,
                total = totalVal,
                totalAmount = totalVal,
                createdAt = isoNow
            )
            tx.set(saleRef, fullSale)
        }.await()
    }

    private suspend fun queueSaleLocally(sale: Sale, reason: String): Result<SaleResult> {
        val entity = PendingSaleEntity(
            transactionId = sale.transactionId,
            storeId = sale.storeId,
            cashierId = sale.cashierId,
            cashierName = sale.cashierName,
            deviceId = sale.deviceId,
            itemsJson = SaleItemJsonConverter.toJson(sale.items),
            subtotal = sale.subtotal,
            tax = sale.tax,
            totalAmount = sale.totalAmount,
            paymentMethod = sale.paymentMethod,
            timestamp = sale.timestamp,
            syncStatus = "PENDING",
            errorMessage = reason
        )
        pendingSaleDao.insert(entity)
        return Result.success(SaleResult.QueuedOffline(sale, reason))
    }

    suspend fun syncSinglePendingSale(pending: PendingSaleEntity): Result<Unit> {
        return try {
            pendingSaleDao.updateStatus(pending.transactionId, "SYNCING", null)
            val items = SaleItemJsonConverter.fromJson(pending.itemsJson)
            val sale = Sale(
                id = pending.transactionId,
                saleId = pending.transactionId,
                transactionId = pending.transactionId,
                storeId = pending.storeId,
                cashierId = pending.cashierId,
                cashierName = pending.cashierName,
                deviceId = pending.deviceId,
                items = items,
                subtotal = pending.subtotal,
                tax = pending.tax,
                totalAmount = pending.totalAmount,
                total = pending.totalAmount,
                paymentMethod = pending.paymentMethod,
                timestamp = pending.timestamp,
                isOfflineQueued = false
            )

            executeFirestoreTransaction(sale)
            // Successfully pushed to Firestore: delete from local Room queue
            pendingSaleDao.delete(pending.transactionId)
            Result.success(Unit)
        } catch (e: Exception) {
            val errorMsg = e.localizedMessage ?: "Sync error"
            pendingSaleDao.updateStatus(pending.transactionId, "FAILED", errorMsg)
            Result.failure(e)
        }
    }
}

sealed class SaleResult {
    data class CompletedOnline(val sale: Sale) : SaleResult()
    data class QueuedOffline(val sale: Sale, val message: String) : SaleResult()
}
