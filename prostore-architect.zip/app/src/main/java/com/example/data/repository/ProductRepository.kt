package com.example.data.repository

import com.example.data.firebase.FirebaseManager
import com.example.data.model.Product
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class ProductRepository {
    private val firestore: FirebaseFirestore
        get() = FirebaseManager.getFirestore()

    fun getProducts(storeId: String): Flow<List<Product>> = callbackFlow {
        if (storeId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val registration = firestore.collection("stores").document(storeId)
            .collection("products")
            .orderBy("name")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { doc ->
                    doc.toObject(Product::class.java)?.copy(id = doc.id, storeId = storeId)
                } ?: emptyList()
                trySend(list)
            }

        awaitClose { registration.remove() }
    }

    suspend fun saveProduct(storeId: String, product: Product): Result<Product> {
        return try {
            val productId = if (product.id.isBlank()) UUID.randomUUID().toString() else product.id
            val finalProduct = product.copy(
                id = productId,
                storeId = storeId,
                updatedAt = System.currentTimeMillis(),
                createdAt = if (product.createdAt == 0L) System.currentTimeMillis() else product.createdAt
            )
            firestore.collection("stores").document(storeId)
                .collection("products").document(productId)
                .set(finalProduct).await()

            Result.success(finalProduct)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteProduct(storeId: String, productId: String): Result<Unit> {
        return try {
            firestore.collection("stores").document(storeId)
                .collection("products").document(productId)
                .delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun findProductByBarcode(storeId: String, barcode: String): Product? {
        return findByBarcode(storeId, barcode)
    }

    suspend fun findByBarcode(storeId: String, barcode: String): Product? {
        return try {
            val query = firestore.collection("stores").document(storeId)
                .collection("products")
                .whereEqualTo("barcode", barcode.trim())
                .limit(1)
                .get().await()

            query.documents.firstOrNull()?.let { doc ->
                doc.toObject(Product::class.java)?.copy(id = doc.id, storeId = storeId)
            }
        } catch (e: Exception) {
            null
        }
    }
}
