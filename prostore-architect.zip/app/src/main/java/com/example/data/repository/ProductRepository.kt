package com.example.data.repository

import com.example.data.firebase.FirebaseManager
import com.example.data.model.Product
import com.example.data.model.currentIsoTimestamp
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class ProductRepository {
    private val firestore: FirebaseFirestore
        get() = FirebaseManager.getFirestore()

    fun getProducts(storeId: String): Flow<List<Product>> = callbackFlow {
        if (storeId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val registration = firestore.collection("stores").document(storeId)
            .collection("products")
            .orderBy("name")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { doc ->
                    try {
                        val p = doc.toObject(Product::class.java)
                        if (p != null) {
                            val finalId = if (p.id.isNotBlank()) p.id else if (p.productId.isNotBlank()) p.productId else doc.id
                            val price = if (p.price > 0.0) p.price else p.sellingPrice
                            val qty = if (p.stockQuantity > 0L) p.stockQuantity else p.quantity
                            p.copy(
                                id = finalId,
                                productId = finalId,
                                storeId = storeId,
                                price = price,
                                sellingPrice = price,
                                stockQuantity = qty,
                                quantity = qty
                            )
                        } else null
                    } catch (_: Exception) {
                        try {
                            val data = doc.data ?: return@mapNotNull null
                            val finalId = (data["productId"] as? String) ?: (data["id"] as? String) ?: doc.id
                            val name = (data["name"] as? String) ?: "Product"
                            val barcode = (data["barcode"] as? String) ?: ""
                            val sku = (data["sku"] as? String) ?: ""
                            val price = (data["sellingPrice"] as? Number)?.toDouble()
                                ?: (data["price"] as? Number)?.toDouble() ?: 0.0
                            val qty = (data["quantity"] as? Number)?.toLong()
                                ?: (data["stockQuantity"] as? Number)?.toLong() ?: 0L
                            val category = (data["category"] as? String) ?: ""
                            val image = (data["image"] as? String) ?: ""
                            val active = (data["active"] as? Boolean) ?: true
                            Product(
                                id = finalId,
                                productId = finalId,
                                storeId = storeId,
                                name = name,
                                barcode = barcode,
                                sku = sku,
                                price = price,
                                sellingPrice = price,
                                stockQuantity = qty,
                                quantity = qty,
                                category = category,
                                image = image,
                                active = active,
                                createdAt = data["createdAt"],
                                updatedAt = data["updatedAt"]
                            )
                        } catch (_: Exception) {
                            null
                        }
                    }
                } ?: emptyList()
                trySend(list)
            }

        awaitClose { registration.remove() }
    }

    suspend fun saveProduct(storeId: String, product: Product): Result<Product> {
        return try {
            val productId = if (product.id.isNotBlank()) product.id else if (product.productId.isNotBlank()) product.productId else UUID.randomUUID().toString()
            val isoNow = currentIsoTimestamp()
            val effectivePrice = if (product.price > 0.0) product.price else product.sellingPrice
            val effectiveQty = if (product.stockQuantity > 0L) product.stockQuantity else product.quantity
            val finalProduct = product.copy(
                id = productId,
                productId = productId,
                storeId = storeId,
                price = effectivePrice,
                sellingPrice = effectivePrice,
                stockQuantity = effectiveQty,
                quantity = effectiveQty,
                updatedAt = isoNow,
                createdAt = product.createdAt ?: isoNow
            )
            firestore.collection("stores").document(storeId)
                .collection("products").document(productId)
                .set(finalProduct).await()

            Result.success(finalProduct)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteProduct(storeId: String, productId: String): Result<Unit> {
        return try {
            firestore.collection("stores").document(storeId)
                .collection("products").document(productId)
                .delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun findProductByBarcode(storeId: String, barcode: String): Product? {
        return findByBarcode(storeId, barcode)
    }

    suspend fun findByBarcode(storeId: String, barcode: String): Product? {
        return try {
            val query = firestore.collection("stores").document(storeId)
                .collection("products")
                .whereEqualTo("barcode", barcode.trim())
                .limit(1)
                .get().await()

            val doc = query.documents.firstOrNull() ?: return null
            try {
                val p = doc.toObject(Product::class.java)
                if (p != null) {
                    val finalId = if (p.id.isNotBlank()) p.id else if (p.productId.isNotBlank()) p.productId else doc.id
                    val price = if (p.price > 0.0) p.price else p.sellingPrice
                    val qty = if (p.stockQuantity > 0L) p.stockQuantity else p.quantity
                    p.copy(
                        id = finalId,
                        productId = finalId,
                        storeId = storeId,
                        price = price,
                        sellingPrice = price,
                        stockQuantity = qty,
                        quantity = qty
                    )
                } else null
            } catch (_: Exception) {
                val data = doc.data ?: return null
                val finalId = (data["productId"] as? String) ?: (data["id"] as? String) ?: doc.id
                val name = (data["name"] as? String) ?: "Product"
                val bc = (data["barcode"] as? String) ?: barcode.trim()
                val price = (data["sellingPrice"] as? Number)?.toDouble() ?: (data["price"] as? Number)?.toDouble() ?: 0.0
                val qty = (data["quantity"] as? Number)?.toLong() ?: (data["stockQuantity"] as? Number)?.toLong() ?: 0L
                Product(
                    id = finalId,
                    productId = finalId,
                    storeId = storeId,
                    name = name,
                    barcode = bc,
                    price = price,
                    sellingPrice = price,
                    stockQuantity = qty,
                    quantity = qty
                )
            }
        } catch (_: Exception) {
            null
        }
    }
}
