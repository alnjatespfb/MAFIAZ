package com.example.data.sync

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.repository.SalesRepository
import com.example.util.NetworkMonitor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class SyncState {
    object Idle : SyncState()
    data class Syncing(val remainingCount: Int) : SyncState()
    data class Completed(val syncedCount: Int) : SyncState()
    data class Failed(val error: String) : SyncState()
}

class SyncManager(
    private val context: Context,
    private val networkMonitor: NetworkMonitor,
    private val salesRepository: SalesRepository
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val pendingSaleDao = AppDatabase.getInstance(context).pendingSaleDao()

    private val _syncState = MutableStateFlow<SyncState>(SyncState.Idle)
    val syncState: StateFlow<SyncState> = _syncState.asStateFlow()

    init {
        // Automatically listen to network connectivity
        scope.launch {
            networkMonitor.isOnline.collect { isOnline ->
                if (isOnline) {
                    triggerSync()
                }
            }
        }
    }

    fun triggerSync() {
        scope.launch {
            if (_syncState.value is SyncState.Syncing) return@launch
            if (!networkMonitor.isCurrentlyConnected()) {
                _syncState.value = SyncState.Failed("Device is currently offline")
                return@launch
            }

            val pendingList = pendingSaleDao.getAllPendingList()
            if (pendingList.isEmpty()) {
                _syncState.value = SyncState.Idle
                return@launch
            }

            _syncState.value = SyncState.Syncing(pendingList.size)
            var successCount = 0
            var lastError: String? = null

            for (pending in pendingList) {
                val result = salesRepository.syncSinglePendingSale(pending)
                if (result.isSuccess) {
                    successCount++
                } else {
                    lastError = result.exceptionOrNull()?.localizedMessage
                }
            }

            if (lastError != null && successCount == 0) {
                _syncState.value = SyncState.Failed(lastError)
            } else {
                _syncState.value = SyncState.Completed(successCount)
            }
        }
    }
}
