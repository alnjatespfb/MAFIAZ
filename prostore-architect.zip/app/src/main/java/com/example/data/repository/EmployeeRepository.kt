package com.example.data.repository

import com.example.data.firebase.FirebaseManager
import com.example.data.model.Employee
import com.example.data.model.Role
import com.example.data.model.StorePermission
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class EmployeeRepository {
    private val firestore: FirebaseFirestore
        get() = FirebaseManager.getFirestore()

    fun getEmployees(storeId: String): Flow<List<Employee>> = callbackFlow {
        if (storeId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val registration = firestore.collection("stores").document(storeId)
            .collection("employees")
            .orderBy("createdAt")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { doc ->
                    doc.toObject(Employee::class.java)?.copy(id = doc.id, storeId = storeId)
                } ?: emptyList()
                trySend(list)
            }

        awaitClose { registration.remove() }
    }

    suspend fun saveEmployee(storeId: String, employee: Employee): Result<Employee> {
        return try {
            val employeeId = if (employee.id.isBlank()) UUID.randomUUID().toString() else employee.id
            val roleEnum = try { Role.valueOf(employee.role) } catch (_: Exception) { Role.CASHIER }
            val permissions = if (employee.permissions.isEmpty()) StorePermission.defaultForRole(roleEnum) else employee.permissions

            val finalEmp = employee.copy(
                id = employeeId,
                storeId = storeId,
                permissions = permissions,
                createdAt = if (employee.createdAt == 0L) System.currentTimeMillis() else employee.createdAt
            )
            firestore.collection("stores").document(storeId)
                .collection("employees").document(employeeId)
                .set(finalEmp).await()

            Result.success(finalEmp)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getEmployeeById(storeId: String, employeeId: String): Employee? {
        return try {
            val doc = firestore.collection("stores").document(storeId)
                .collection("employees").document(employeeId).get().await()
            if (doc.exists()) {
                doc.toObject(Employee::class.java)?.copy(id = doc.id, storeId = storeId)
            } else null
        } catch (e: Exception) {
            null
        }
    }

    suspend fun verifyPin(storeId: String, employeeId: String, inputPin: String): Boolean {
        val emp = getEmployeeById(storeId, employeeId) ?: return false
        if (emp.status == "DISABLED") return false
        if (emp.pin.isBlank()) return true // No PIN configured
        return emp.pin.trim() == inputPin.trim()
    }

    suspend fun deleteEmployee(storeId: String, employeeId: String): Result<Unit> {
        return try {
            firestore.collection("stores").document(storeId)
                .collection("employees").document(employeeId)
                .delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
