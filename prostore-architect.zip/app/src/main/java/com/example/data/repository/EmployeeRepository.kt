package com.example.data.repository

import com.example.data.firebase.FirebaseManager
import com.example.data.model.Employee
import com.example.data.model.Role
import com.example.data.model.StorePermission
import com.example.data.model.currentIsoTimestamp
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class EmployeeRepository {
    private val firestore: FirebaseFirestore
        get() = FirebaseManager.getFirestore()

    fun getEmployees(storeId: String): Flow<List<Employee>> = callbackFlow {
        if (storeId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val registration = firestore.collection("stores").document(storeId)
            .collection("employees")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { doc ->
                    try {
                        val emp = doc.toObject(Employee::class.java)
                        if (emp != null) {
                            val finalId = if (emp.id.isNotBlank()) emp.id else if (emp.employeeId.isNotBlank()) emp.employeeId else doc.id
                            val pin = if (emp.pin.isNotBlank()) emp.pin else emp.pinCode
                            emp.copy(id = finalId, employeeId = finalId, storeId = storeId, pin = pin, pinCode = pin)
                        } else null
                    } catch (_: Exception) {
                        try {
                            val data = doc.data ?: return@mapNotNull null
                            val finalId = (data["employeeId"] as? String) ?: (data["id"] as? String) ?: doc.id
                            val name = (data["name"] as? String) ?: "Employee"
                            val email = (data["email"] as? String) ?: ""
                            val pin = (data["pinCode"] as? String) ?: (data["pin"] as? String) ?: "1234"
                            val role = (data["role"] as? String) ?: Role.CASHIER.name
                            @Suppress("UNCHECKED_CAST")
                            val perms = (data["permissions"] as? List<String>) ?: emptyList()
                            Employee(
                                id = finalId,
                                employeeId = finalId,
                                storeId = storeId,
                                name = name,
                                email = email,
                                pin = pin,
                                pinCode = pin,
                                role = role,
                                permissions = perms,
                                createdAt = data["createdAt"]
                            )
                        } catch (_: Exception) {
                            null
                        }
                    }
                } ?: emptyList()
                trySend(list)
            }

        awaitClose { registration.remove() }
    }

    suspend fun saveEmployee(storeId: String, employee: Employee): Result<Employee> {
        return try {
            val employeeId = if (employee.id.isNotBlank()) employee.id else if (employee.employeeId.isNotBlank()) employee.employeeId else UUID.randomUUID().toString()
            val roleEnum = try { Role.valueOf(employee.role) } catch (_: Exception) { Role.CASHIER }
            val permissions = if (employee.permissions.isEmpty()) StorePermission.defaultForRole(roleEnum) else employee.permissions
            val pin = employee.pin.ifBlank { employee.pinCode }.ifBlank { "1234" }
            val isoNow = currentIsoTimestamp()

            val finalEmp = employee.copy(
                id = employeeId,
                employeeId = employeeId,
                storeId = storeId,
                pin = pin,
                pinCode = pin,
                permissions = permissions,
                createdAt = employee.createdAt ?: isoNow
            )
            firestore.collection("stores").document(storeId)
                .collection("employees").document(employeeId)
                .set(finalEmp).await()

            Result.success(finalEmp)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getEmployeeById(storeId: String, employeeId: String): Employee? {
        return try {
            val doc = firestore.collection("stores").document(storeId)
                .collection("employees").document(employeeId).get().await()
            if (doc.exists()) {
                try {
                    val emp = doc.toObject(Employee::class.java)
                    if (emp != null) {
                        val finalId = if (emp.id.isNotBlank()) emp.id else if (emp.employeeId.isNotBlank()) emp.employeeId else doc.id
                        val pin = if (emp.pin.isNotBlank()) emp.pin else emp.pinCode
                        emp.copy(id = finalId, employeeId = finalId, storeId = storeId, pin = pin, pinCode = pin)
                    } else null
                } catch (_: Exception) {
                    val data = doc.data ?: return null
                    val finalId = (data["employeeId"] as? String) ?: (data["id"] as? String) ?: doc.id
                    val name = (data["name"] as? String) ?: "Employee"
                    val pin = (data["pinCode"] as? String) ?: (data["pin"] as? String) ?: "1234"
                    Employee(id = finalId, employeeId = finalId, storeId = storeId, name = name, pin = pin, pinCode = pin)
                }
            } else null
        } catch (e: Exception) {
            null
        }
    }

    suspend fun verifyPin(storeId: String, employeeId: String, inputPin: String): Boolean {
        val emp = getEmployeeById(storeId, employeeId) ?: return false
        if (emp.status == "DISABLED" || !emp.active) return false
        val effectivePin = emp.pin.ifBlank { emp.pinCode }
        if (effectivePin.isBlank()) return true
        return effectivePin.trim() == inputPin.trim()
    }

    suspend fun deleteEmployee(storeId: String, employeeId: String): Result<Unit> {
        return try {
            firestore.collection("stores").document(storeId)
                .collection("employees").document(employeeId)
                .delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
