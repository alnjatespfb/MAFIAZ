package com.example.data.local

import com.example.data.model.SaleItem
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

object SaleItemJsonConverter {
    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val type = Types.newParameterizedType(List::class.java, SaleItem::class.java)
    private val adapter = moshi.adapter<List<SaleItem>>(type)

    fun toJson(items: List<SaleItem>): String {
        return adapter.toJson(items)
    }

    fun fromJson(json: String): List<SaleItem> {
        return try {
            adapter.fromJson(json) ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }
    }
}
