package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pending_sales")
data class PendingSaleEntity(
    @PrimaryKey val transactionId: String,
    val storeId: String,
    val cashierId: String,
    val cashierName: String,
    val deviceId: String,
    val itemsJson: String,
    val subtotal: Double,
    val tax: Double,
    val totalAmount: Double,
    val paymentMethod: String,
    val timestamp: Long,
    val syncStatus: String = "PENDING", // PENDING, SYNCING, FAILED
    val errorMessage: String? = null
)
