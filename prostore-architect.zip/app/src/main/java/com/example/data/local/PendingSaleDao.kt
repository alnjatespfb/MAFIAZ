package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PendingSaleDao {
    @Query("SELECT * FROM pending_sales WHERE storeId = :storeId ORDER BY timestamp ASC")
    fun getPendingForStore(storeId: String): Flow<List<PendingSaleEntity>>

    @Query("SELECT * FROM pending_sales ORDER BY timestamp ASC")
    suspend fun getAllPendingList(): List<PendingSaleEntity>

    @Query("SELECT COUNT(*) FROM pending_sales")
    fun getPendingCountFlow(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: PendingSaleEntity)

    @Query("DELETE FROM pending_sales WHERE transactionId = :transactionId")
    suspend fun delete(transactionId: String)

    @Query("UPDATE pending_sales SET syncStatus = :status, errorMessage = :error WHERE transactionId = :transactionId")
    suspend fun updateStatus(transactionId: String, status: String, error: String?)
}
