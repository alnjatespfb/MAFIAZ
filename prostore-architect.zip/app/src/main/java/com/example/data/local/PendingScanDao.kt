package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PendingScanDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(scan: PendingScanEntity)

    @Query("SELECT * FROM pending_scans WHERE isSynced = 0 ORDER BY timestamp ASC")
    fun getPendingScansFlow(): Flow<List<PendingScanEntity>>

    @Query("SELECT * FROM pending_scans WHERE isSynced = 0 ORDER BY timestamp ASC")
    suspend fun getPendingScans(): List<PendingScanEntity>

    @Query("SELECT * FROM pending_scans WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): PendingScanEntity?

    @Query("SELECT COUNT(*) FROM pending_scans WHERE isSynced = 0")
    fun getPendingScanCountFlow(): Flow<Int>

    @Query("UPDATE pending_scans SET isSynced = 1 WHERE id = :id")
    suspend fun markSynced(id: String)

    @Query("DELETE FROM pending_scans WHERE isSynced = 1")
    suspend fun deleteSyncedScans()

    @Query("UPDATE pending_scans SET retryCount = retryCount + 1 WHERE id = :id")
    suspend fun incrementRetry(id: String)
}
