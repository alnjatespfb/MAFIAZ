package com.example.data.sync

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.local.PendingScanEntity
import com.example.data.repository.ScanEventRepository
import com.example.util.NetworkMonitor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class ScanSyncStatus {
    object Synced : ScanSyncStatus()
    data class Syncing(val pendingCount: Int) : ScanSyncStatus()
    data class Pending(val pendingCount: Int) : ScanSyncStatus()
    data class Error(val message: String) : ScanSyncStatus()
}

class ScanSyncManager(
    private val context: Context,
    private val networkMonitor: NetworkMonitor,
    private val scanEventRepository: ScanEventRepository
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val pendingScanDao = AppDatabase.getInstance(context).pendingScanDao()

    private val _syncStatus = MutableStateFlow<ScanSyncStatus>(ScanSyncStatus.Synced)
    val syncStatus: StateFlow<ScanSyncStatus> = _syncStatus.asStateFlow()

    val pendingCountFlow: Flow<Int> = pendingScanDao.getPendingScanCountFlow()

    init {
        scope.launch {
            networkMonitor.isOnline.collect { isOnline ->
                if (isOnline) {
                    syncPendingScans()
                }
            }
        }
    }

    suspend fun queueScan(
        storeId: String,
        deviceId: String,
        employeeId: String,
        employeeName: String,
        barcode: String,
        format: String = "EAN_13",
        targetPosId: String = "",
        targetPosName: String = ""
    ): PendingScanEntity {
        val entity = PendingScanEntity(
            storeId = storeId,
            deviceId = deviceId,
            employeeId = employeeId,
            employeeName = employeeName,
            barcode = barcode,
            format = format,
            targetPosId = targetPosId,
            targetPosName = targetPosName,
            timestamp = System.currentTimeMillis()
        )
        pendingScanDao.insert(entity)

        if (networkMonitor.isCurrentlyConnected()) {
            syncPendingScans()
        } else {
            val count = pendingScanDao.getPendingScans().size
            _syncStatus.value = ScanSyncStatus.Pending(count)
        }
        return entity
    }

    fun syncPendingScans() {
        scope.launch {
            if (!networkMonitor.isCurrentlyConnected()) {
                val count = pendingScanDao.getPendingScans().size
                if (count > 0) {
                    _syncStatus.value = ScanSyncStatus.Pending(count)
                }
                return@launch
            }

            val pending = pendingScanDao.getPendingScans()
            if (pending.isEmpty()) {
                _syncStatus.value = ScanSyncStatus.Synced
                return@launch
            }

            _syncStatus.value = ScanSyncStatus.Syncing(pending.size)

            for (scan in pending) {
                val result = scanEventRepository.emitScanEvent(
                    storeId = scan.storeId,
                    barcode = scan.barcode,
                    deviceId = scan.deviceId,
                    employeeId = scan.employeeId,
                    employeeName = scan.employeeName,
                    targetPosId = scan.targetPosId,
                    targetPosName = scan.targetPosName,
                    format = scan.format,
                    syncedFromOffline = true,
                    customEventId = scan.id
                )

                if (result.isSuccess) {
                    pendingScanDao.markSynced(scan.id)
                } else {
                    pendingScanDao.incrementRetry(scan.id)
                }
            }

            pendingScanDao.deleteSyncedScans()
            val remaining = pendingScanDao.getPendingScans().size
            if (remaining > 0) {
                _syncStatus.value = ScanSyncStatus.Pending(remaining)
            } else {
                _syncStatus.value = ScanSyncStatus.Synced
            }
        }
    }
}
