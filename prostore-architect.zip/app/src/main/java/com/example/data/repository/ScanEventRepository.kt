package com.example.data.repository

import com.example.data.firebase.FirebaseManager
import com.example.data.model.ScanEvent
import com.example.data.model.ScanEventStatus
import com.example.data.model.currentIsoTimestamp
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import android.util.Log
import java.util.UUID

class ScanEventRepository {
    private val firestore: FirebaseFirestore
        get() = FirebaseManager.getFirestore()

    suspend fun emitScanEvent(
        storeId: String,
        barcode: String,
        deviceId: String,
        employeeId: String = "",
        employeeName: String = "",
        targetPosId: String = "",
        targetPosName: String = "",
        scanMode: String = "SALE",
        format: String = "EAN_13",
        syncedFromOffline: Boolean = false,
        customEventId: String? = null
    ): Result<ScanEvent> {
        return try {
            val eventId = customEventId ?: UUID.randomUUID().toString()
            val isoNow = currentIsoTimestamp()
            val event = ScanEvent(
                id = eventId,
                scanId = eventId,
                eventId = eventId,
                storeId = storeId,
                deviceId = deviceId,
                scannerDeviceId = deviceId,
                employeeId = employeeId,
                employeeName = employeeName,
                barcode = barcode.trim(),
                format = format,
                targetPosId = targetPosId,
                targetPosDeviceId = targetPosId,
                targetPosName = targetPosName,
                scanMode = scanMode,
                status = ScanEventStatus.PENDING.name,
                processed = false,
                timestamp = System.currentTimeMillis(),
                createdAt = isoNow,
                clientTimestamp = System.currentTimeMillis(),
                syncedFromOffline = syncedFromOffline
            )
            val docData = hashMapOf(
                "id" to event.id,
                "scanId" to event.id,
                "eventId" to event.id,
                "storeId" to event.storeId,
                "deviceId" to event.deviceId,
                "scannerDeviceId" to event.deviceId,
                "employeeId" to event.employeeId,
                "employeeName" to event.employeeName,
                "barcode" to event.barcode,
                "format" to event.format,
                "targetPosId" to event.targetPosId,
                "targetPosDeviceId" to event.targetPosId,
                "targetPosName" to event.targetPosName,
                "scanMode" to event.scanMode,
                "status" to event.status,
                "processed" to false,
                "createdAt" to isoNow,
                "timestamp" to FieldValue.serverTimestamp(),
                "clientTimestamp" to event.clientTimestamp,
                "syncedFromOffline" to event.syncedFromOffline
            )

            // Write to stores/{storeId}/scanEvents/{scanId}
            firestore.collection("stores").document(storeId)
                .collection("scanEvents").document(eventId)
                .set(docData).await()

            Log.d("StorePOS.Scan", "SEND_OK eventId=$eventId storeId=$storeId targetPosId=$targetPosId barcode=${event.barcode} mode=$scanMode")
            Result.success(event)
        } catch (e: Exception) {
            Log.e("StorePOS.Scan", "SEND_FAILED storeId=$storeId targetPosId=$targetPosId barcode=${barcode.trim()}", e)
            Result.failure(e)
        }
    }

    fun listenToPendingScans(storeId: String, targetPosId: String? = null): Flow<List<ScanEvent>> = callbackFlow {
        if (storeId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val query = firestore.collection("stores").document(storeId)
            .collection("scanEvents")
            .whereEqualTo("processed", false)

        val registration = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.e("StorePOS.Scan", "LISTENER_FAILED storeId=$storeId targetPosId=$targetPosId", error)
                trySend(emptyList())
                return@addSnapshotListener
            }
            val list = snapshot?.documents?.mapNotNull { doc ->
                val ev = try {
                    doc.toObject(ScanEvent::class.java)?.let { s ->
                        val finalId = if (s.id.isNotBlank()) s.id else if (s.scanId.isNotBlank()) s.scanId else doc.id
                        val targetPos = if (s.targetPosId.isNotBlank()) s.targetPosId else s.targetPosDeviceId
                        s.copy(id = finalId, scanId = finalId, eventId = finalId, storeId = storeId, targetPosId = targetPos, targetPosDeviceId = targetPos)
                    }
                } catch (_: Exception) {
                    try {
                        val data = doc.data ?: return@mapNotNull null
                        val id = (data["eventId"] as? String) ?: (data["scanId"] as? String) ?: (data["id"] as? String) ?: doc.id
                        val devId = (data["scannerDeviceId"] as? String) ?: (data["deviceId"] as? String) ?: ""
                        val targetPos = (data["targetPosDeviceId"] as? String) ?: (data["targetPosId"] as? String) ?: ""
                        val barcode = (data["barcode"] as? String) ?: ""
                        val scanMode = (data["scanMode"] as? String) ?: "SALE"
                        val processed = (data["processed"] as? Boolean) ?: false
                        ScanEvent(
                            id = id,
                            scanId = id,
                            eventId = id,
                            storeId = storeId,
                            deviceId = devId,
                            scannerDeviceId = devId,
                            targetPosId = targetPos,
                            targetPosDeviceId = targetPos,
                            barcode = barcode,
                            scanMode = scanMode,
                            processed = processed
                        )
                    } catch (_: Exception) {
                        null
                    }
                }

                if (ev != null && (targetPosId.isNullOrBlank() || ev.targetPosId.isBlank() || ev.targetPosId == targetPosId)) {
                    ev
                } else {
                    null
                }
            } ?: emptyList()
            trySend(list)
        }

        awaitClose { registration.remove() }
    }

    suspend fun markScanProcessed(storeId: String, eventId: String): Result<Unit> {
        return try {
            firestore.collection("stores").document(storeId)
                .collection("scanEvents").document(eventId)
                .update("processed", true).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
