package com.example.data.repository

import com.example.data.firebase.FirebaseManager
import com.example.data.model.ScanEvent
import com.example.data.model.ScanEventStatus
import com.example.data.model.currentIsoTimestamp
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class ScanEventRepository {
    private val firestore: FirebaseFirestore
        get() = FirebaseManager.getFirestore()

    suspend fun emitScanEvent(
        storeId: String,
        barcode: String,
        deviceId: String,
        employeeId: String = "",
        employeeUid: String = employeeId,
        employeeName: String = "",
        scannerRole: String = "CASHIER",
        targetPosId: String = "",
        targetPosName: String = "",
        format: String = "EAN_13",
        syncedFromOffline: Boolean = false,
        customEventId: String? = null
    ): Result<ScanEvent> {
        return try {
            val sec = System.currentTimeMillis() / 1000
            val randHex = UUID.randomUUID().toString().take(4)
            val eventId = customEventId ?: "scan_${sec}_${randHex}"
            val isoNow = currentIsoTimestamp()
            val targetPosDevId = if (targetPosId.isBlank()) "ALL" else targetPosId

            val event = ScanEvent(
                id = eventId,
                scanId = eventId,
                eventId = eventId,
                storeId = storeId,
                deviceId = deviceId,
                scannerDeviceId = deviceId,
                employeeId = employeeId,
                employeeUid = employeeUid.ifBlank { employeeId },
                employeeName = employeeName,
                scannerRole = scannerRole,
                barcode = barcode.trim(),
                format = format,
                targetPosId = targetPosId,
                targetPosDeviceId = targetPosDevId,
                targetPosName = targetPosName,
                status = ScanEventStatus.PENDING.name,
                processed = false,
                timestamp = System.currentTimeMillis(),
                createdAt = isoNow,
                clientTimestamp = System.currentTimeMillis(),
                syncedFromOffline = syncedFromOffline
            )
            val docData = hashMapOf(
                "eventId" to event.eventId,
                "storeId" to event.storeId,
                "scannerDeviceId" to event.scannerDeviceId,
                "targetPosDeviceId" to event.targetPosDeviceId,
                "barcode" to event.barcode,
                "processed" to false,
                "employeeUid" to event.employeeUid,
                "employeeName" to event.employeeName,
                "scannerRole" to event.scannerRole,
                "createdAt" to isoNow,

                // Compatibility aliases
                "id" to event.id,
                "scanId" to event.scanId,
                "deviceId" to event.deviceId,
                "employeeId" to event.employeeId,
                "format" to event.format,
                "targetPosId" to event.targetPosId,
                "targetPosName" to event.targetPosName,
                "status" to event.status,
                "timestamp" to FieldValue.serverTimestamp(),
                "clientTimestamp" to event.clientTimestamp,
                "syncedFromOffline" to event.syncedFromOffline
            )

            // Write to stores/{storeId}/scanEvents/{eventId}
            firestore.collection("stores").document(storeId)
                .collection("scanEvents").document(eventId)
                .set(docData).await()

            Result.success(event)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun listenToPendingScans(storeId: String, targetPosId: String? = null): Flow<List<ScanEvent>> = callbackFlow {
        if (storeId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val query = firestore.collection("stores").document(storeId)
            .collection("scanEvents")
            .whereEqualTo("processed", false)

        val registration = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                trySend(emptyList())
                return@addSnapshotListener
            }
            val list = snapshot?.documents?.mapNotNull { doc ->
                val ev = try {
                    doc.toObject(ScanEvent::class.java)?.let { s ->
                        val finalId = if (s.id.isNotBlank()) s.id else if (s.scanId.isNotBlank()) s.scanId else doc.id
                        val targetPos = if (s.targetPosId.isNotBlank()) s.targetPosId else s.targetPosDeviceId
                        s.copy(id = finalId, scanId = finalId, eventId = finalId, storeId = storeId, targetPosId = targetPos, targetPosDeviceId = targetPos)
                    }
                } catch (_: Exception) {
                    try {
                        val data = doc.data ?: return@mapNotNull null
                        val id = (data["eventId"] as? String) ?: (data["scanId"] as? String) ?: (data["id"] as? String) ?: doc.id
                        val devId = (data["scannerDeviceId"] as? String) ?: (data["deviceId"] as? String) ?: ""
                        val targetPos = (data["targetPosDeviceId"] as? String) ?: (data["targetPosId"] as? String) ?: ""
                        val barcode = (data["barcode"] as? String) ?: ""
                        val processed = (data["processed"] as? Boolean) ?: false
                        ScanEvent(
                            id = id,
                            scanId = id,
                            eventId = id,
                            storeId = storeId,
                            deviceId = devId,
                            scannerDeviceId = devId,
                            targetPosId = targetPos,
                            targetPosDeviceId = targetPos,
                            barcode = barcode,
                            processed = processed
                        )
                    } catch (_: Exception) {
                        null
                    }
                }

                if (ev != null) {
                    val evTarget = ev.targetPosId.ifBlank { ev.targetPosDeviceId }
                    if (targetPosId.isNullOrBlank() || evTarget.isBlank() || evTarget == targetPosId) {
                        ev
                    } else {
                        null
                    }
                } else {
                    null
                }
            } ?: emptyList()
            trySend(list)
        }

        awaitClose { registration.remove() }
    }

    suspend fun markScanProcessed(storeId: String, eventId: String): Result<Unit> {
        return try {
            firestore.collection("stores").document(storeId)
                .collection("scanEvents").document(eventId)
                .update(
                    mapOf(
                        "processed" to true,
                        "status" to "PROCESSED"
                    )
                ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
