package com.example.data.repository

import com.example.data.firebase.FirebaseManager
import com.example.data.model.ScanEvent
import com.example.data.model.ScanEventStatus
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class ScanEventRepository {
    private val firestore: FirebaseFirestore
        get() = FirebaseManager.getFirestore()

    suspend fun emitScanEvent(
        storeId: String,
        barcode: String,
        deviceId: String,
        employeeId: String = "",
        employeeName: String = "",
        targetPosId: String = "",
        targetPosName: String = "",
        format: String = "EAN_13",
        syncedFromOffline: Boolean = false,
        customEventId: String? = null
    ): Result<ScanEvent> {
        return try {
            val eventId = customEventId ?: UUID.randomUUID().toString()
            val event = ScanEvent(
                id = eventId,
                scanId = eventId,
                storeId = storeId,
                deviceId = deviceId,
                scannerDeviceId = deviceId,
                employeeId = employeeId,
                employeeName = employeeName,
                barcode = barcode.trim(),
                format = format,
                targetPosId = targetPosId,
                targetPosName = targetPosName,
                status = ScanEventStatus.PENDING.name,
                processed = false,
                timestamp = System.currentTimeMillis(),
                syncedFromOffline = syncedFromOffline
            )
            val docData = hashMapOf(
                "id" to event.id,
                "scanId" to event.id,
                "storeId" to event.storeId,
                "deviceId" to event.deviceId,
                "scannerDeviceId" to event.deviceId,
                "employeeId" to event.employeeId,
                "employeeName" to event.employeeName,
                "barcode" to event.barcode,
                "format" to event.format,
                "targetPosId" to event.targetPosId,
                "targetPosName" to event.targetPosName,
                "status" to event.status,
                "processed" to event.processed,
                "timestamp" to FieldValue.serverTimestamp(),
                "clientTimestamp" to event.timestamp,
                "syncedFromOffline" to event.syncedFromOffline
            )

            // Write to stores/{storeId}/scanEvents/{scanId}
            firestore.collection("stores").document(storeId)
                .collection("scanEvents").document(eventId)
                .set(docData).await()

            Result.success(event)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun listenToPendingScans(storeId: String, targetPosId: String? = null): Flow<List<ScanEvent>> = callbackFlow {
        if (storeId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        var query = firestore.collection("stores").document(storeId)
            .collection("scanEvents")
            .whereEqualTo("processed", false)

        val registration = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                trySend(emptyList())
                return@addSnapshotListener
            }
            val list = snapshot?.documents?.mapNotNull { doc ->
                val ev = doc.toObject(ScanEvent::class.java)?.copy(id = doc.id, storeId = storeId)
                if (ev != null && (targetPosId.isNullOrBlank() || ev.targetPosId.isBlank() || ev.targetPosId == targetPosId)) {
                    ev
                } else {
                    null
                }
            } ?: emptyList()
            trySend(list)
        }

        awaitClose { registration.remove() }
    }

    suspend fun markScanProcessed(storeId: String, eventId: String): Result<Unit> {
        return try {
            firestore.collection("stores").document(storeId)
                .collection("scanEvents").document(eventId)
                .update(
                    mapOf(
                        "processed" to true,
                        "status" to ScanEventStatus.PROCESSED.name,
                        "processedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
