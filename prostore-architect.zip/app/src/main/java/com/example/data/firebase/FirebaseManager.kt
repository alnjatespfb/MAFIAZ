package com.example.data.firebase

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.PersistentCacheSettings

/**
 * Single Firebase entry point for the StorePOS Android client.
 *
 * Firebase configuration is developer/build configuration supplied by
 * google-services.json. Never collect Firebase credentials from end users
 * and never fall back to fake credentials.
 */
object FirebaseManager {

    fun isConfigured(context: Context): Boolean {
        return initialize(context)
    }

    fun initialize(context: Context): Boolean {
        val app = try {
            FirebaseApp.getApps(context).firstOrNull()
                ?: FirebaseApp.initializeApp(context.applicationContext)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }

        if (app == null) {
            // No google-services.json / valid Firebase configuration is available.
            // Deliberately do not invent or persist Firebase credentials.
            return false
        }

        return try {
            configureFirestoreSettings(FirebaseFirestore.getInstance(app))
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun configureFirestoreSettings(firestore: FirebaseFirestore) {
        try {
            val settings = FirebaseFirestoreSettings.Builder()
                .setLocalCacheSettings(PersistentCacheSettings.newBuilder().build())
                .build()
            firestore.firestoreSettings = settings
        } catch (_: Exception) {
            // Firestore settings can only be changed before operations begin.
        }
    }

    fun getFirestore(): FirebaseFirestore = FirebaseFirestore.getInstance()

    fun getAuth(): FirebaseAuth = FirebaseAuth.getInstance()
}
