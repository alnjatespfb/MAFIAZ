package com.example.data.firebase

import android.content.Context
import android.content.SharedPreferences
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.PersistentCacheSettings

object FirebaseManager {
    private const val PREFS_NAME = "firebase_config_prefs"
    private const val KEY_PROJECT_ID = "firebase_project_id"
    private const val KEY_APP_ID = "firebase_app_id"
    private const val KEY_API_KEY = "firebase_api_key"

    fun isConfigured(context: Context): Boolean {
        return initialize(context)
    }

    fun initialize(context: Context): Boolean {
        if (FirebaseApp.getApps(context).isNotEmpty()) {
            configureFirestoreSettings(FirebaseFirestore.getInstance())
            return true
        }

        try {
            val app = FirebaseApp.initializeApp(context.applicationContext)
            if (app != null) {
                configureFirestoreSettings(FirebaseFirestore.getInstance())
                return true
            }
        } catch (_: Exception) {
            // Google Services json not bundled; fallback to configured options
        }

        val prefs = getPrefs(context)
        val projectId = prefs.getString(KEY_PROJECT_ID, null)?.takeIf { it.isNotBlank() }
            ?: "storepos-backend"
        val appId = prefs.getString(KEY_APP_ID, null)?.takeIf { it.isNotBlank() }
            ?: "1:102030405060:android:storepos"
        val apiKey = prefs.getString(KEY_API_KEY, null)?.takeIf { it.isNotBlank() }
            ?: "AIzaSyDeveloperBackendApiKeyForStorePOS"

        return try {
            val options = FirebaseOptions.Builder()
                .setProjectId(projectId)
                .setApplicationId(appId)
                .setApiKey(apiKey)
                .build()
            FirebaseApp.initializeApp(context.applicationContext, options)
            configureFirestoreSettings(FirebaseFirestore.getInstance())
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun saveConfiguration(
        context: Context,
        projectId: String,
        appId: String,
        apiKey: String
    ): Boolean {
        getPrefs(context).edit()
            .putString(KEY_PROJECT_ID, projectId.trim())
            .putString(KEY_APP_ID, appId.trim())
            .putString(KEY_API_KEY, apiKey.trim())
            .apply()

        return initialize(context)
    }

    fun getSavedProjectId(context: Context): String? {
        return getPrefs(context).getString(KEY_PROJECT_ID, null)
    }

    private fun configureFirestoreSettings(firestore: FirebaseFirestore) {
        try {
            val settings = FirebaseFirestoreSettings.Builder()
                .setLocalCacheSettings(
                    PersistentCacheSettings.newBuilder().build()
                )
                .build()
            firestore.firestoreSettings = settings
        } catch (_: Exception) {
            // Settings can only be set before any other Firestore operations
        }
    }

    fun getFirestore(): FirebaseFirestore {
        return FirebaseFirestore.getInstance()
    }

    fun getAuth(): FirebaseAuth {
        return FirebaseAuth.getInstance()
    }

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }
}
