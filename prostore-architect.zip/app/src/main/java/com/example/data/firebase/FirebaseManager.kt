package com.example.data.firebase

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.PersistentCacheSettings

object FirebaseManager {
    private const val PREFS_NAME = "firebase_config_prefs"
    private const val KEY_PROJECT_ID = "firebase_project_id"
    private const val KEY_APP_ID = "firebase_app_id"
    private const val KEY_API_KEY = "firebase_api_key"

    // Real Firebase Web SDK configuration defaults
    val DEFAULT_PROJECT_ID: String = BuildConfig.FIREBASE_PROJECT_ID
    val DEFAULT_APP_ID: String = BuildConfig.FIREBASE_APP_ID
    val DEFAULT_API_KEY: String = BuildConfig.FIREBASE_API_KEY
    val DEFAULT_AUTH_DOMAIN: String = BuildConfig.FIREBASE_AUTH_DOMAIN
    val DEFAULT_STORAGE_BUCKET: String = BuildConfig.FIREBASE_STORAGE_BUCKET
    val DEFAULT_MESSAGING_SENDER_ID: String = BuildConfig.FIREBASE_MESSAGING_SENDER_ID
    val DEFAULT_FIRESTORE_DATABASE_ID: String = BuildConfig.FIRESTORE_DATABASE_ID

    fun isConfigured(context: Context): Boolean {
        return initialize(context)
    }

    fun initialize(context: Context): Boolean {
        // If an app is already initialized, verify if the API key is valid
        if (FirebaseApp.getApps(context).isNotEmpty()) {
            val currentApp = FirebaseApp.getInstance()
            val currentApiKey = currentApp.options.apiKey
            if (currentApiKey.contains("AIzaSyDeveloperBackendApiKeyForStorePOS") || currentApiKey.isBlank()) {
                try {
                    currentApp.delete()
                } catch (_: Exception) {}
            } else {
                configureFirestoreSettings(getFirestore())
                return true
            }
        }

        val prefs = getPrefs(context)
        // Clean out any stale fake API key from preferences if stored previously
        val savedApiKey = prefs.getString(KEY_API_KEY, null)
        if (savedApiKey != null && savedApiKey.contains("AIzaSyDeveloperBackendApiKeyForStorePOS")) {
            prefs.edit().remove(KEY_API_KEY).remove(KEY_PROJECT_ID).remove(KEY_APP_ID).apply()
        }

        val projectId = prefs.getString(KEY_PROJECT_ID, null)?.takeIf { it.isNotBlank() && it != "storepos-backend" }
            ?: DEFAULT_PROJECT_ID
        val appId = prefs.getString(KEY_APP_ID, null)?.takeIf { it.isNotBlank() && !it.contains("storepos") }
            ?: DEFAULT_APP_ID
        val apiKey = prefs.getString(KEY_API_KEY, null)?.takeIf { it.isNotBlank() && !it.contains("AIzaSyDeveloperBackendApiKeyForStorePOS") }
            ?: DEFAULT_API_KEY

        return try {
            val options = FirebaseOptions.Builder()
                .setProjectId(projectId)
                .setApplicationId(appId)
                .setApiKey(apiKey)
                .setStorageBucket(DEFAULT_STORAGE_BUCKET)
                .setGcmSenderId(DEFAULT_MESSAGING_SENDER_ID)
                .build()
            FirebaseApp.initializeApp(context.applicationContext, options)
            configureFirestoreSettings(getFirestore())
            true
        } catch (e: Exception) {
            e.printStackTrace()
            try {
                configureFirestoreSettings(getFirestore())
                true
            } catch (_: Exception) {
                false
            }
        }
    }

    fun saveConfiguration(
        context: Context,
        projectId: String,
        appId: String,
        apiKey: String
    ): Boolean {
        getPrefs(context).edit()
            .putString(KEY_PROJECT_ID, projectId.trim())
            .putString(KEY_APP_ID, appId.trim())
            .putString(KEY_API_KEY, apiKey.trim())
            .apply()

        try {
            if (FirebaseApp.getApps(context).isNotEmpty()) {
                FirebaseApp.getInstance().delete()
            }
        } catch (_: Exception) {}

        return initialize(context)
    }

    fun getSavedProjectId(context: Context): String? {
        return getPrefs(context).getString(KEY_PROJECT_ID, DEFAULT_PROJECT_ID)
    }

    private fun configureFirestoreSettings(firestore: FirebaseFirestore) {
        try {
            val settings = FirebaseFirestoreSettings.Builder()
                .setLocalCacheSettings(
                    PersistentCacheSettings.newBuilder().build()
                )
                .build()
            firestore.firestoreSettings = settings
        } catch (_: Exception) {
            // Settings can only be set before any other Firestore operations
        }
    }

    fun getFirestore(): FirebaseFirestore {
        return try {
            val app = FirebaseApp.getInstance()
            if (DEFAULT_FIRESTORE_DATABASE_ID.isNotBlank() && DEFAULT_FIRESTORE_DATABASE_ID != "(default)") {
                FirebaseFirestore.getInstance(app, DEFAULT_FIRESTORE_DATABASE_ID)
            } else {
                FirebaseFirestore.getInstance(app)
            }
        } catch (_: Exception) {
            try {
                FirebaseFirestore.getInstance(FirebaseApp.getInstance())
            } catch (_: Exception) {
                FirebaseFirestore.getInstance()
            }
        }
    }

    fun getAuth(): FirebaseAuth {
        return try {
            FirebaseAuth.getInstance(FirebaseApp.getInstance())
        } catch (_: Exception) {
            FirebaseAuth.getInstance()
        }
    }

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }
}
