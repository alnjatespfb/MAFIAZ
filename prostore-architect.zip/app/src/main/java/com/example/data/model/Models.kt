package com.example.data.model

import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import java.util.UUID

@IgnoreExtraProperties
data class UserProfile(
    val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@IgnoreExtraProperties
data class Store(
    val id: String = "",
    val name: String = "",
    val ownerId: String = "",
    val country: String = "",
    val currency: String = "USD",
    val address: String = "",
    val phone: String = "",
    val logoUrl: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

enum class Role {
    ADMIN,
    MANAGER,
    CASHIER
}

object StorePermission {
    const val MANAGE_INVENTORY = "MANAGE_INVENTORY"
    const val MANAGE_EMPLOYEES = "MANAGE_EMPLOYEES"
    const val MANAGE_DEVICES = "MANAGE_DEVICES"
    const val PROCESS_SALES = "PROCESS_SALES"
    const val VIEW_SALES = "VIEW_SALES"

    fun defaultForRole(role: Role): List<String> = when (role) {
        Role.ADMIN -> listOf(
            MANAGE_INVENTORY,
            MANAGE_EMPLOYEES,
            MANAGE_DEVICES,
            PROCESS_SALES,
            VIEW_SALES
        )
        Role.MANAGER -> listOf(
            MANAGE_INVENTORY,
            MANAGE_DEVICES,
            PROCESS_SALES,
            VIEW_SALES
        )
        Role.CASHIER -> listOf(
            PROCESS_SALES,
            VIEW_SALES
        )
    }
}

@IgnoreExtraProperties
data class Employee(
    val id: String = "",
    val storeId: String = "",
    val uid: String = "", // Linked Firebase Auth UID or invitation
    val name: String = "",
    val email: String = "",
    val pin: String = "",
    val role: String = Role.CASHIER.name,
    val permissions: List<String> = emptyList(),
    val status: String = "ACTIVE",
    val createdAt: Long = System.currentTimeMillis()
)

@IgnoreExtraProperties
data class Product(
    val id: String = "",
    val storeId: String = "",
    val name: String = "",
    val barcode: String = "",
    val sku: String = "",
    val price: Double = 0.0,
    val costPrice: Double = 0.0,
    val stockQuantity: Long = 0L,
    val category: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

enum class DeviceType {
    SCANNER,
    POS,
    POS_TERMINAL,
    PHONE_SCANNER
}

enum class DeviceStatus {
    PENDING,
    APPROVED,
    DISABLED,
    REJECTED
}

@IgnoreExtraProperties
data class Device(
    val id: String = "",
    val deviceId: String = id,
    val storeId: String = "",
    val deviceName: String = "",
    val deviceType: String = DeviceType.SCANNER.name,
    val status: String = DeviceStatus.PENDING.name,
    val onlineStatus: String = "ONLINE",
    val currentEmployeeId: String = "",
    val currentEmployeeName: String = "",
    val connectedPosId: String = "",
    val connectedPosName: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val lastSeen: Long = System.currentTimeMillis(),
    val registeredAt: Long = createdAt,
    val lastActiveAt: Long = lastSeen
)

@IgnoreExtraProperties
data class AccessRequest(
    val id: String = UUID.randomUUID().toString(),
    val requestId: String = id,
    val storeId: String = "",
    val deviceId: String = "",
    val deviceName: String = "",
    val requestType: String = "SCANNER", // "SCANNER", "ADMIN_ACCESS"
    val requestedRole: String = "SCANNER",
    val userEmail: String = "",
    val status: String = DeviceStatus.PENDING.name,
    val message: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@IgnoreExtraProperties
data class PosSession(
    val id: String = "",
    val storeId: String = "",
    val deviceId: String = "",
    val deviceName: String = "",
    val cashierName: String = "",
    val status: String = "ACTIVE",
    val lastSeen: Long = System.currentTimeMillis()
)

enum class PaymentMethod {
    CASH,
    CARD,
    MOBILE_PAY
}

@IgnoreExtraProperties
data class SaleItem(
    val productId: String = "",
    val productName: String = "",
    val barcode: String = "",
    val unitPrice: Double = 0.0,
    val quantity: Long = 1L,
    val subtotal: Double = 0.0
)

@IgnoreExtraProperties
data class Sale(
    val id: String = UUID.randomUUID().toString(), // transactionId
    val storeId: String = "",
    val cashierId: String = "",
    val cashierName: String = "",
    val deviceId: String = "",
    val items: List<SaleItem> = emptyList(),
    val subtotal: Double = 0.0,
    val tax: Double = 0.0,
    val totalAmount: Double = 0.0,
    val paymentMethod: String = PaymentMethod.CASH.name,
    val timestamp: Long = System.currentTimeMillis(),
    val transactionId: String = id,
    val isOfflineQueued: Boolean = false
)

enum class ScanEventStatus {
    PENDING,
    PROCESSED
}

@IgnoreExtraProperties
data class ScanEvent(
    val id: String = UUID.randomUUID().toString(),
    val scanId: String = id,
    val storeId: String = "",
    val deviceId: String = "",
    val scannerDeviceId: String = deviceId,
    val employeeId: String = "",
    val employeeName: String = "",
    val barcode: String = "",
    val format: String = "EAN_13",
    val targetPosId: String = "",
    val targetPosName: String = "",
    val status: String = ScanEventStatus.PENDING.name,
    val processed: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
    val syncedFromOffline: Boolean = false
)
