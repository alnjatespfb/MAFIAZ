package com.example.data.model

import com.google.firebase.firestore.IgnoreExtraProperties
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

fun parseTimestampToMillis(value: Any?): Long {
    if (value == null) return System.currentTimeMillis()
    if (value is Number) return value.toLong()
    if (value is com.google.firebase.Timestamp) return value.toDate().time
    if (value is Date) return value.time
    if (value is String) {
        val num = value.toLongOrNull()
        if (num != null) return num
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            sdf.parse(value)?.time ?: run {
                val sdf2 = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply {
                    timeZone = TimeZone.getTimeZone("UTC")
                }
                sdf2.parse(value)?.time ?: System.currentTimeMillis()
            }
        } catch (_: Exception) {
            System.currentTimeMillis()
        }
    }
    return System.currentTimeMillis()
}

fun currentIsoTimestamp(): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }
    return sdf.format(Date())
}

@IgnoreExtraProperties
data class UserProfile(
    val userId: String = "",
    val uid: String = userId,
    val email: String = "",
    val displayName: String = "",
    val ownedStoreIds: List<String> = emptyList(),
    val createdAt: Any? = null
) {
    val effectiveUid: String
        get() = uid.ifBlank { userId }

    val createdAtMillis: Long
        get() = parseTimestampToMillis(createdAt)
}

@IgnoreExtraProperties
data class Store(
    val id: String = "",
    val storeId: String = id,
    val name: String = "",
    val ownerId: String = "",
    val country: String = "",
    val currency: String = "USD",
    val address: String = "",
    val phone: String = "",
    val logoUrl: String = "",
    val logo: String = logoUrl,
    val taxRate: Double = 0.0,
    val createdAt: Any? = null,
    val updatedAt: Any? = null,
    val serverCreatedAt: Any? = null
) {
    val effectiveId: String
        get() = id.ifBlank { storeId }

    val effectiveLogo: String
        get() = logoUrl.ifBlank { logo }

    val createdAtMillis: Long
        get() = parseTimestampToMillis(createdAt)
}

enum class Role {
    ADMIN,
    MANAGER,
    CASHIER
}

object StorePermission {
    const val MANAGE_INVENTORY = "MANAGE_INVENTORY"
    const val MANAGE_EMPLOYEES = "MANAGE_EMPLOYEES"
    const val MANAGE_DEVICES = "MANAGE_DEVICES"
    const val PROCESS_SALES = "PROCESS_SALES"
    const val VIEW_SALES = "VIEW_SALES"

    fun defaultForRole(role: Role): List<String> = when (role) {
        Role.ADMIN -> listOf(
            MANAGE_INVENTORY,
            MANAGE_EMPLOYEES,
            MANAGE_DEVICES,
            PROCESS_SALES,
            VIEW_SALES
        )
        Role.MANAGER -> listOf(
            MANAGE_INVENTORY,
            MANAGE_DEVICES,
            PROCESS_SALES,
            VIEW_SALES
        )
        Role.CASHIER -> listOf(
            PROCESS_SALES,
            VIEW_SALES
        )
    }
}

@IgnoreExtraProperties
data class Employee(
    val id: String = "",
    val employeeId: String = id,
    val storeId: String = "",
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val pin: String = "",
    val pinCode: String = pin,
    val role: String = Role.CASHIER.name,
    val permissions: List<String> = emptyList(),
    val canSell: Boolean = true,
    val canManageInventory: Boolean = false,
    val canManageDevices: Boolean = false,
    val canViewReports: Boolean = false,
    val status: String = "ACTIVE",
    val active: Boolean = true,
    val createdAt: Any? = null
) {
    val effectiveId: String
        get() = id.ifBlank { employeeId }

    val effectivePin: String
        get() = pin.ifBlank { pinCode }

    val createdAtMillis: Long
        get() = parseTimestampToMillis(createdAt)
}

@IgnoreExtraProperties
data class Product(
    val id: String = "",
    val productId: String = id,
    val storeId: String = "",
    val name: String = "",
    val barcode: String = "",
    val sku: String = "",
    val price: Double = 0.0,
    val sellingPrice: Double = price,
    val costPrice: Double = 0.0,
    val stockQuantity: Long = 0L,
    val quantity: Long = stockQuantity,
    val minimumStock: Long = 5L,
    val minStockAlert: Long = minimumStock,
    val category: String = "",
    val image: String = "",
    val active: Boolean = true,
    val createdAt: Any? = null,
    val updatedAt: Any? = null
) {
    val effectiveId: String
        get() = id.ifBlank { productId }

    val effectivePrice: Double
        get() = if (price > 0.0) price else sellingPrice

    val effectiveStockQuantity: Long
        get() = if (stockQuantity > 0L) stockQuantity else quantity

    val createdAtMillis: Long
        get() = parseTimestampToMillis(createdAt)

    val updatedAtMillis: Long
        get() = parseTimestampToMillis(updatedAt)
}

enum class DeviceType {
    SCANNER,
    POS,
    POS_TERMINAL,
    PHONE_SCANNER
}

enum class DeviceStatus {
    PENDING,
    APPROVED,
    DISABLED,
    REJECTED
}

@IgnoreExtraProperties
data class Device(
    val id: String = "",
    val deviceId: String = id,
    val storeId: String = "",
    val name: String = "",
    val deviceName: String = name,
    val type: String = DeviceType.SCANNER.name,
    val deviceType: String = type,
    val status: String = DeviceStatus.PENDING.name,
    val onlineStatus: String = "ONLINE",
    val pairedPosDeviceId: String = "",
    val assignedEmployee: String = "",
    val registeredBy: String = "",
    val currentEmployeeId: String = "",
    val currentEmployeeName: String = "",
    val connectedPosId: String = "",
    val connectedPosName: String = "",
    val createdAt: Any? = null,
    val lastSeen: Any? = null,
    val registeredAt: Any? = null,
    val lastActiveAt: Any? = null,
    val pairedAt: Any? = null
) {
    val effectiveId: String
        get() = id.ifBlank { deviceId }

    val effectiveName: String
        get() = deviceName.ifBlank { name }

    val effectiveType: String
        get() = deviceType.ifBlank { type }

    val effectivePairedPosId: String
        get() = pairedPosDeviceId.ifBlank { connectedPosId }

    val createdAtMillis: Long
        get() = parseTimestampToMillis(createdAt)

    val lastSeenMillis: Long
        get() = parseTimestampToMillis(lastSeen)

    val lastActiveAtMillis: Long
        get() = parseTimestampToMillis(lastActiveAt)
}

@IgnoreExtraProperties
data class AccessRequest(
    val id: String = UUID.randomUUID().toString(),
    val requestId: String = id,
    val storeId: String = "",
    val deviceId: String = "",
    val deviceName: String = "",
    val requesterName: String = deviceName,
    val requestType: String = "SCANNER",
    val requestedRole: String = "SCANNER",
    val requestedPermission: String = "SCANNER",
    val userEmail: String = "",
    val status: String = DeviceStatus.PENDING.name,
    val message: String = "",
    val createdAt: Any? = null
) {
    val createdAtMillis: Long
        get() = parseTimestampToMillis(createdAt)
}

@IgnoreExtraProperties
data class PosSession(
    val id: String = "",
    val sessionId: String = id,
    val storeId: String = "",
    val deviceId: String = "",
    val deviceName: String = "",
    val employeeId: String = "",
    val cashierName: String = "",
    val employeeName: String = cashierName,
    val status: String = "ACTIVE",
    val loginTime: Any? = null,
    val logoutTime: Any? = null,
    val lastSeen: Any? = null
)

enum class PaymentMethod {
    CASH,
    CARD,
    MOBILE_PAY
}

@IgnoreExtraProperties
data class SaleItem(
    val productId: String = "",
    val productName: String = "",
    val name: String = productName,
    val barcode: String = "",
    val sku: String = "",
    val unitPrice: Double = 0.0,
    val price: Double = unitPrice,
    val quantity: Long = 1L,
    val subtotal: Double = 0.0,
    val total: Double = subtotal
) {
    val effectiveName: String
        get() = productName.ifBlank { name }
    val effectivePrice: Double
        get() = if (unitPrice > 0.0) unitPrice else price
}

@IgnoreExtraProperties
data class Sale(
    val id: String = UUID.randomUUID().toString(),
    val saleId: String = id,
    val transactionId: String = id,
    val storeId: String = "",
    val cashierId: String = "",
    val employeeId: String = cashierId,
    val cashierName: String = "",
    val employeeName: String = cashierName,
    val deviceId: String = "",
    val items: List<SaleItem> = emptyList(),
    val subtotal: Double = 0.0,
    val tax: Double = 0.0,
    val taxTotal: Double = tax,
    val totalAmount: Double = 0.0,
    val total: Double = totalAmount,
    val paymentMethod: String = PaymentMethod.CASH.name,
    val timestamp: Long = System.currentTimeMillis(),
    val createdAt: Any? = null,
    val isOfflineQueued: Boolean = false,
    val offlineQueued: Boolean = isOfflineQueued,
    val syncStatus: String = "SYNCED"
) {
    val effectiveId: String
        get() = id.ifBlank { saleId.ifBlank { transactionId } }

    val effectiveTotal: Double
        get() = if (totalAmount > 0.0) totalAmount else total

    val createdAtMillis: Long
        get() = parseTimestampToMillis(createdAt ?: timestamp)
}

enum class ScanEventStatus {
    PENDING,
    PROCESSED
}

@IgnoreExtraProperties
data class ScanEvent(
    val id: String = UUID.randomUUID().toString(),
    val scanId: String = id,
    val eventId: String = id,
    val storeId: String = "",
    val deviceId: String = "",
    val scannerDeviceId: String = deviceId,
    val employeeId: String = "",
    val employeeName: String = "",
    val barcode: String = "",
    val format: String = "EAN_13",
    val targetPosId: String = "",
    val targetPosDeviceId: String = targetPosId,
    val targetPosName: String = "",
    val scanMode: String = "SALE",
    val status: String = ScanEventStatus.PENDING.name,
    val processed: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
    val createdAt: Any? = null,
    val clientTimestamp: Long = timestamp,
    val syncedFromOffline: Boolean = false
) {
    val effectiveId: String
        get() = id.ifBlank { scanId.ifBlank { eventId } }

    val effectiveScannerDeviceId: String
        get() = scannerDeviceId.ifBlank { deviceId }

    val effectiveTargetPosDeviceId: String
        get() = targetPosDeviceId.ifBlank { targetPosId }

    val createdAtMillis: Long
        get() = parseTimestampToMillis(createdAt ?: timestamp)
}
