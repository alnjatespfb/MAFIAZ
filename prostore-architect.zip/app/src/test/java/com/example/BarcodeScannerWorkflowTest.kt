package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.PendingScanEntity
import com.example.data.model.DeviceType
import com.example.data.model.Employee
import com.example.data.model.Role
import com.example.data.model.ScanEvent
import com.example.util.DeviceIdManager
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class BarcodeScannerWorkflowTest {

    private lateinit var context: Context
    private lateinit var database: AppDatabase

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        database = AppDatabase.getInstance(context)
    }

    @Test
    fun testDeviceIdGenerationAndPersistence() {
        val deviceId1 = DeviceIdManager.getDeviceId(context)
        val deviceId2 = DeviceIdManager.getDeviceId(context)

        assertNotNull(deviceId1)
        assertTrue(deviceId1.startsWith("dev_"))
        assertEquals(deviceId1, deviceId2) // Must be idempotent
    }

    @Test
    fun testScannerPreferences() {
        DeviceIdManager.setSoundEnabled(context, false)
        assertFalse(DeviceIdManager.isSoundEnabled(context))

        DeviceIdManager.setSoundEnabled(context, true)
        assertTrue(DeviceIdManager.isSoundEnabled(context))

        DeviceIdManager.setVibrationEnabled(context, false)
        assertFalse(DeviceIdManager.isVibrationEnabled(context))

        DeviceIdManager.setCooldownMs(context, 1200L)
        assertEquals(1200L, DeviceIdManager.getCooldownMs(context))

        DeviceIdManager.setAutoScanEnabled(context, true)
        assertTrue(DeviceIdManager.isAutoScanEnabled(context))
    }

    @Test
    fun testStoreAndEmployeePersistence() {
        val testStoreId = "store_test_123"
        val testStoreName = "Zeyad Market"
        val testEmpId = "emp_ahmed_456"
        val testEmpName = "Ahmed"

        DeviceIdManager.setActiveStoreId(context, testStoreId)
        DeviceIdManager.setActiveStoreName(context, testStoreName)
        DeviceIdManager.setCurrentEmployee(context, testEmpId, testEmpName)

        assertEquals(testStoreId, DeviceIdManager.getActiveStoreId(context))
        assertEquals(testStoreName, DeviceIdManager.getActiveStoreName(context))
        assertEquals(testEmpId, DeviceIdManager.getCurrentEmployeeId(context))
        assertEquals(testEmpName, DeviceIdManager.getCurrentEmployeeName(context))

        DeviceIdManager.setCurrentEmployee(context, null, null)
        assertNull(DeviceIdManager.getCurrentEmployeeId(context))
    }

    @Test
    fun testTargetPosConfiguration() {
        val posId = "pos_terminal_01"
        val posName = "Register 1"

        DeviceIdManager.setTargetPosId(context, posId)
        DeviceIdManager.setTargetPosName(context, posName)

        assertEquals(posId, DeviceIdManager.getTargetPosId(context))
        assertEquals(posName, DeviceIdManager.getTargetPosName(context))
    }

    @Test
    fun testRoomPendingScansQueue() = runBlocking {
        val scanDao = database.pendingScanDao()
        val scanId = UUID.randomUUID().toString()

        val entity = PendingScanEntity(
            id = scanId,
            storeId = "store_abc",
            deviceId = "dev_scanner_1",
            employeeId = "emp_1",
            employeeName = "Ahmed",
            barcode = "6291234567890",
            format = "EAN_13",
            targetPosId = "pos_01",
            targetPosName = "Register 1",
            timestamp = System.currentTimeMillis()
        )

        scanDao.insert(entity)

        val pending = scanDao.getPendingScans()
        assertTrue(pending.any { it.id == scanId })

        val retrieved = scanDao.getById(scanId)
        assertNotNull(retrieved)
        assertEquals("6291234567890", retrieved?.barcode)
        assertEquals("EAN_13", retrieved?.format)

        // Mark as synced
        scanDao.markSynced(scanId)
        val remaining = scanDao.getPendingScans()
        assertFalse(remaining.any { it.id == scanId })
    }

    @Test
    fun testScanEventModelContract() {
        val event = ScanEvent(
            id = "scan_001",
            scanId = "scan_001",
            storeId = "store_test",
            deviceId = "scanner_s23",
            scannerDeviceId = "scanner_s23",
            employeeId = "emp_01",
            employeeName = "Ahmed",
            barcode = "012345678905",
            format = "UPC_A",
            targetPosId = "pos_register_01",
            targetPosName = "Register 1",
            status = "PENDING",
            processed = false,
            timestamp = 1710000000000L
        )

        assertEquals("scan_001", event.scanId)
        assertEquals("store_test", event.storeId)
        assertEquals("scanner_s23", event.deviceId)
        assertEquals("emp_01", event.employeeId)
        assertEquals("Ahmed", event.employeeName)
        assertEquals("012345678905", event.barcode)
        assertEquals("UPC_A", event.format)
        assertEquals("pos_register_01", event.targetPosId)
        assertFalse(event.processed)
    }

    @Test
    fun testEmployeePinVerificationLogic() {
        val employeeWithPin = Employee(
            id = "emp_1",
            name = "Mohamed",
            pin = "1234",
            role = Role.CASHIER.name,
            storeId = "store_1"
        )

        assertTrue(employeeWithPin.pin.isNotBlank())
        assertEquals("1234", employeeWithPin.pin)
        assertNotEquals("0000", employeeWithPin.pin)

        val employeeWithoutPin = Employee(
            id = "emp_2",
            name = "Ali",
            pin = "",
            role = Role.CASHIER.name,
            storeId = "store_1"
        )
        assertTrue(employeeWithoutPin.pin.isBlank())
    }

    @Test
    fun testPosCartIncrementOnRepeatedBarcode() {
        val firestore = com.example.data.firebase.FirebaseManager.getFirestore()
        val productRepo = com.example.data.repository.ProductRepository(firestore)
        val salesRepo = com.example.data.repository.SalesRepository(firestore)
        val scanRepo = com.example.data.repository.ScanEventRepository(firestore)

        val posViewModel = com.example.ui.pos.PosViewModel(
            storeId = "store_test_pos",
            posDeviceId = "pos_device_1",
            productRepo = productRepo,
            salesRepo = salesRepo,
            scanEventRepo = scanRepo
        )

        val productA = com.example.data.model.Product(
            id = "p1",
            productId = "p1",
            storeId = "store_test_pos",
            name = "Organic Milk",
            barcode = "629100000001",
            price = 4.50,
            stockQuantity = 50L
        )

        // First scan adds item to cart
        posViewModel.addToCart(productA)
        assertEquals(1, posViewModel.cart.value.size)
        assertEquals(1L, posViewModel.cart.value[0].quantity)
        assertEquals(4.50, posViewModel.cart.value[0].subtotal, 0.001)

        // Second scan with same barcode increases quantity
        posViewModel.addToCart(productA)
        assertEquals(1, posViewModel.cart.value.size)
        assertEquals(2L, posViewModel.cart.value[0].quantity)
        assertEquals(9.00, posViewModel.cart.value[0].subtotal, 0.001)

        // Third scan with another product creates a new cart line
        val productB = com.example.data.model.Product(
            id = "p2",
            productId = "p2",
            storeId = "store_test_pos",
            name = "Dark Roast Coffee",
            barcode = "629100000002",
            price = 12.00,
            stockQuantity = 20L
        )
        posViewModel.addToCart(productB)
        assertEquals(2, posViewModel.cart.value.size)
        assertEquals(2L, posViewModel.cart.value[0].quantity)
        assertEquals(1L, posViewModel.cart.value[1].quantity)
    }

    @Test
    fun testTargetPosMatchingLogic() {
        val targetPos = "pos_terminal_01"

        // Targeted to this POS
        val eventForThisPos = ScanEvent(
            id = "e1",
            targetPosId = "pos_terminal_01",
            barcode = "111"
        )
        val target = eventForThisPos.targetPosId.ifBlank { eventForThisPos.targetPosDeviceId }
        val matches = targetPos.isBlank() || target.isBlank() || target == targetPos
        assertTrue("Event targeted to this POS must match", matches)

        // Broadcast to all POS
        val broadcastEvent = ScanEvent(
            id = "e2",
            targetPosId = "",
            targetPosDeviceId = "",
            barcode = "222"
        )
        val broadcastTarget = broadcastEvent.targetPosId.ifBlank { broadcastEvent.targetPosDeviceId }
        val broadcastMatches = targetPos.isBlank() || broadcastTarget.isBlank() || broadcastTarget == targetPos
        assertTrue("Broadcast event must match any POS", broadcastMatches)

        // Targeted to a different POS
        val otherEvent = ScanEvent(
            id = "e3",
            targetPosId = "pos_terminal_02",
            barcode = "333"
        )
        val otherTarget = otherEvent.targetPosId.ifBlank { otherEvent.targetPosDeviceId }
        val otherMatches = targetPos.isBlank() || otherTarget.isBlank() || otherTarget == targetPos
        assertFalse("Event targeted to other POS must not match", otherMatches)
    }
}
