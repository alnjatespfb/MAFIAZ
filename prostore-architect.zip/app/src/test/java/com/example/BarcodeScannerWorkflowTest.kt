package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.PendingScanEntity
import com.example.data.model.DeviceType
import com.example.data.model.Employee
import com.example.data.model.Role
import com.example.data.model.ScanEvent
import com.example.util.DeviceIdManager
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class BarcodeScannerWorkflowTest {

    private lateinit var context: Context
    private lateinit var database: AppDatabase

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        database = AppDatabase.getInstance(context)
    }

    @Test
    fun testDeviceIdGenerationAndPersistence() {
        val deviceId1 = DeviceIdManager.getDeviceId(context)
        val deviceId2 = DeviceIdManager.getDeviceId(context)

        assertNotNull(deviceId1)
        assertTrue(deviceId1.startsWith("dev_"))
        assertEquals(deviceId1, deviceId2) // Must be idempotent
    }

    @Test
    fun testScannerPreferences() {
        DeviceIdManager.setSoundEnabled(context, false)
        assertFalse(DeviceIdManager.isSoundEnabled(context))

        DeviceIdManager.setSoundEnabled(context, true)
        assertTrue(DeviceIdManager.isSoundEnabled(context))

        DeviceIdManager.setVibrationEnabled(context, false)
        assertFalse(DeviceIdManager.isVibrationEnabled(context))

        DeviceIdManager.setCooldownMs(context, 1200L)
        assertEquals(1200L, DeviceIdManager.getCooldownMs(context))

        DeviceIdManager.setAutoScanEnabled(context, true)
        assertTrue(DeviceIdManager.isAutoScanEnabled(context))
    }

    @Test
    fun testStoreAndEmployeePersistence() {
        val testStoreId = "store_test_123"
        val testStoreName = "Zeyad Market"
        val testEmpId = "emp_ahmed_456"
        val testEmpName = "Ahmed"

        DeviceIdManager.setActiveStoreId(context, testStoreId)
        DeviceIdManager.setActiveStoreName(context, testStoreName)
        DeviceIdManager.setCurrentEmployee(context, testEmpId, testEmpName)

        assertEquals(testStoreId, DeviceIdManager.getActiveStoreId(context))
        assertEquals(testStoreName, DeviceIdManager.getActiveStoreName(context))
        assertEquals(testEmpId, DeviceIdManager.getCurrentEmployeeId(context))
        assertEquals(testEmpName, DeviceIdManager.getCurrentEmployeeName(context))

        DeviceIdManager.setCurrentEmployee(context, null, null)
        assertNull(DeviceIdManager.getCurrentEmployeeId(context))
    }

    @Test
    fun testTargetPosConfiguration() {
        val posId = "pos_terminal_01"
        val posName = "Register 1"

        DeviceIdManager.setTargetPosId(context, posId)
        DeviceIdManager.setTargetPosName(context, posName)

        assertEquals(posId, DeviceIdManager.getTargetPosId(context))
        assertEquals(posName, DeviceIdManager.getTargetPosName(context))
    }

    @Test
    fun testRoomPendingScansQueue() = runBlocking {
        val scanDao = database.pendingScanDao()
        val scanId = UUID.randomUUID().toString()

        val entity = PendingScanEntity(
            id = scanId,
            storeId = "store_abc",
            deviceId = "dev_scanner_1",
            employeeId = "emp_1",
            employeeName = "Ahmed",
            barcode = "6291234567890",
            format = "EAN_13",
            targetPosId = "pos_01",
            targetPosName = "Register 1",
            timestamp = System.currentTimeMillis()
        )

        scanDao.insert(entity)

        val pending = scanDao.getPendingScans()
        assertTrue(pending.any { it.id == scanId })

        val retrieved = scanDao.getById(scanId)
        assertNotNull(retrieved)
        assertEquals("6291234567890", retrieved?.barcode)
        assertEquals("EAN_13", retrieved?.format)

        // Mark as synced
        scanDao.markSynced(scanId)
        val remaining = scanDao.getPendingScans()
        assertFalse(remaining.any { it.id == scanId })
    }

    @Test
    fun testScanEventModelContract() {
        val event = ScanEvent(
            id = "scan_001",
            scanId = "scan_001",
            storeId = "store_test",
            deviceId = "scanner_s23",
            scannerDeviceId = "scanner_s23",
            employeeId = "emp_01",
            employeeName = "Ahmed",
            barcode = "012345678905",
            format = "UPC_A",
            targetPosId = "pos_register_01",
            targetPosName = "Register 1",
            status = "PENDING",
            processed = false,
            timestamp = 1710000000000L
        )

        assertEquals("scan_001", event.scanId)
        assertEquals("store_test", event.storeId)
        assertEquals("scanner_s23", event.deviceId)
        assertEquals("emp_01", event.employeeId)
        assertEquals("Ahmed", event.employeeName)
        assertEquals("012345678905", event.barcode)
        assertEquals("UPC_A", event.format)
        assertEquals("pos_register_01", event.targetPosId)
        assertFalse(event.processed)
    }

    @Test
    fun testEmployeePinVerificationLogic() {
        val employeeWithPin = Employee(
            id = "emp_1",
            name = "Mohamed",
            pin = "1234",
            role = Role.CASHIER.name,
            storeId = "store_1"
        )

        assertTrue(employeeWithPin.pin.isNotBlank())
        assertEquals("1234", employeeWithPin.pin)
        assertNotEquals("0000", employeeWithPin.pin)

        val employeeWithoutPin = Employee(
            id = "emp_2",
            name = "Ali",
            pin = "",
            role = Role.CASHIER.name,
            storeId = "store_1"
        )
        assertTrue(employeeWithoutPin.pin.isBlank())
    }
}
