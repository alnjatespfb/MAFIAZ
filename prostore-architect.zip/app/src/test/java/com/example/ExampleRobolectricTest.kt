package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("StorePOS", appName)
  }

  @Test
  fun `verify firebase configuration matches production backend`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    assertTrue(com.example.data.firebase.FirebaseManager.initialize(context))
    
    assertEquals("gen-lang-client-0920175908", com.example.data.firebase.FirebaseManager.DEFAULT_PROJECT_ID)
    assertEquals("1:589311457403:web:3b4b3c580211893a168ade", com.example.data.firebase.FirebaseManager.DEFAULT_APP_ID)
    assertEquals("AIzaSyCd6mWWIIKBBAtv2Gf-q9upIPCzQyZvmvY", com.example.data.firebase.FirebaseManager.DEFAULT_API_KEY)
    assertEquals("gen-lang-client-0920175908.firebaseapp.com", com.example.data.firebase.FirebaseManager.DEFAULT_AUTH_DOMAIN)
    assertEquals("gen-lang-client-0920175908.firebasestorage.app", com.example.data.firebase.FirebaseManager.DEFAULT_STORAGE_BUCKET)
    assertEquals("589311457403", com.example.data.firebase.FirebaseManager.DEFAULT_MESSAGING_SENDER_ID)
    assertEquals("ai-studio-coreposarchitect-efbb6e02-3b3c-45b6-9a01-129865a06f14", com.example.data.firebase.FirebaseManager.DEFAULT_FIRESTORE_DATABASE_ID)

    val app = com.google.firebase.FirebaseApp.getInstance()
    assertEquals("AIzaSyCd6mWWIIKBBAtv2Gf-q9upIPCzQyZvmvY", app.options.apiKey)
    assertEquals("gen-lang-client-0920175908", app.options.projectId)
  }

  @Test
  fun `verify timestamp parsing and model resilience with ISO strings`() {
    val isoDate = "2026-09-10T14:14:00.000Z"
    val millis = com.example.data.model.parseTimestampToMillis(isoDate)
    assertTrue("Parsed timestamp must be positive", millis > 0L)

    // Verify Store model accepts ISO string createdAt without crashing
    val store = com.example.data.model.Store(
      id = "store_test",
      storeId = "store_test",
      name = "Downtown Flagship",
      createdAt = isoDate
    )
    assertEquals("Downtown Flagship", store.name)
    assertEquals(millis, store.createdAtMillis)

    // Verify Product model accepts ISO string createdAt and updatedAt
    val product = com.example.data.model.Product(
      id = "prod_test",
      productId = "prod_test",
      name = "Coffee Beans",
      price = 14.99,
      createdAt = isoDate,
      updatedAt = isoDate
    )
    assertEquals(14.99, product.effectivePrice, 0.001)
    assertEquals(millis, product.createdAtMillis)

    // Verify Employee model accepts ISO string createdAt and pinCode
    val employee = com.example.data.model.Employee(
      id = "emp_test",
      employeeId = "emp_test",
      name = "Sarah Cashier",
      pinCode = "4321",
      createdAt = isoDate
    )
    assertEquals("4321", employee.effectivePin)
    assertEquals(millis, employee.createdAtMillis)

    // Verify Device model accepts ISO string timestamps
    val device = com.example.data.model.Device(
      id = "dev_test",
      deviceId = "dev_test",
      name = "Scanner A",
      createdAt = isoDate,
      lastSeen = isoDate
    )
    assertEquals("Scanner A", device.effectiveName)
    assertEquals(millis, device.lastSeenMillis)
  }
}
