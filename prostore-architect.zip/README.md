<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/60bba9fd-2733-4809-9423-978eb4e2701a

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.


## Firebase setup

This Android client intentionally does **not** contain a Firebase configuration screen or fake fallback credentials.

To connect it to the real StorePOS backend:

1. In Firebase Console, open the **same Firebase project used by the StorePOS Web app**.
2. Add/register this Android application using the exact Android package/application ID from `app/build.gradle.kts`.
3. Download the real `google-services.json`.
4. Place it at `app/google-services.json`.
5. Enable Firebase Authentication (Email/Password if used by the current flow) and Firestore in that same project.
6. Deploy the Firestore rules from `firestore.rules` after reviewing them against the Web app's final schema.

Never commit service-account credentials or private keys to the Android project.

The Android app and Web app must use the same Firebase project and Firestore database.
