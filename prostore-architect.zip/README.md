<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/60bba9fd-2733-4809-9423-978eb4e2701a

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.

## StorePOS update notes

- Scan events now use `stores/{storeId}/scanEvents/{eventId}` consistently in the
  Android app and Firestore rules. Deploy `firestore.rules` after updating the
  Firebase project.
- A POS terminal listens only to scan events addressed to its own device id,
  while unaddressed legacy events remain compatible as broadcasts.
- After an admin selects a store, the app asks for a POS counter. The selected
  counter is persisted locally and mirrored on the scanner device record. Use
  **Disconnect Counter Binding** in Scanner Settings to clear it.
- Google sign-in uses Firebase Authentication and the Android Credential
  Manager. The Google provider must be enabled in Firebase Authentication.

## Scanner send delivery fix (v3)
- Scanner SEND writes to `stores/{storeId}/scanEvents/{scanId}` and logs success/failure in Logcat under `StorePOS.Scan`.
- Firestore rules allow an approved scanner device to create pending scan events, while keeping Admin/member checks for other operations.
- A successful SEND is only reported after the Firestore write/sync succeeds; offline scans remain queued.
