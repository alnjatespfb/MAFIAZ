package com.example.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

object SoundFxManager {

    private val executor = Executors.newSingleThreadExecutor()
    private var mediaPlayer: MediaPlayer? = null
    @Volatile
    private var isDucked: Boolean = false

    /**
     * Lower SFX / Audio volume during voice narration (Audio Ducking)
     */
    fun setDucking(duck: Boolean) {
        isDucked = duck
        try {
            val vol = if (duck) 0.25f else 1.0f
            mediaPlayer?.setVolume(vol, vol)
        } catch (t: Throwable) {
            // Ignore volume adjustments on released player
        }
    }

    fun triggerVibration(context: Context?, milliseconds: Long = 100) {
        if (context == null) return
        try {
            val vibrator = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? android.os.VibratorManager
                vibratorManager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
            }
            if (vibrator?.hasVibrator() == true) {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    vibrator.vibrate(android.os.VibrationEffect.createOneShot(milliseconds, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(milliseconds)
                }
            }
        } catch (t: Throwable) {
            // Silently ignore vibration failure in headless environments
        }
    }

    /**
     * Stop and release active MediaPlayer instance safely
     */
    fun stopMediaPlayer() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (t: Throwable) {
            // Ignore
        } finally {
            mediaPlayer = null
        }
    }

    /**
     * Stop all audio playback
     */
    fun stopAll() {
        stopMediaPlayer()
    }

    /**
     * Plays a dramatic game start sound using MediaPlayer with synthesized WAV sound or fallback.
     */
    fun playGameStartCinematic(context: Context? = null) {
        triggerVibration(context, 150)
        executor.execute {
            playSynthesizedToneWithMediaPlayer(
                context = context,
                durationMs = 800,
                baseFreq = 70.0,
                sweep = true,
                volume = if (isDucked) 0.3f else 0.8f
            )
        }
    }

    /**
     * Plays a sudden event / tragedy / assassination sound using MediaPlayer.
     */
    fun playSuddenEventSound(context: Context? = null) {
        triggerVibration(context, 200)
        executor.execute {
            playSynthesizedToneWithMediaPlayer(
                context = context,
                durationMs = 900,
                baseFreq = 120.0,
                sweep = false,
                volume = if (isDucked) 0.3f else 0.9f
            )
        }
    }

    /**
     * Plays a dramatic double-thump heartbeat sound effect safely on a background thread.
     */
    fun playHeartbeat(context: Context? = null) {
        executor.execute {
            try {
                triggerVibration(context, 80)
            } catch (t: Throwable) { }
            try {
                val sampleRate = 22050
                val durationMs = 300
                val numSamples = sampleRate * durationMs / 1000
                val buffer = ShortArray(numSamples)
                val volFactor = if (isDucked) 0.3 else 1.0

                for (i in 0 until numSamples) {
                    val t = i.toDouble() / sampleRate
                    var sample = 0.0

                    // First Thump (Lub) - 0ms to 100ms at 55Hz
                    if (t in 0.0..0.10) {
                        val env = Math.exp(-t * 26.0)
                        sample = Math.sin(2.0 * Math.PI * 55.0 * t) * env
                    }
                    // Second Thump (Dub) - 140ms to 250ms at 48Hz
                    else if (t in 0.14..0.25) {
                        val t2 = t - 0.14
                        val env = Math.exp(-t2 * 22.0)
                        sample = Math.sin(2.0 * Math.PI * 48.0 * t2) * env * 0.85
                    }

                    buffer[i] = (sample * 20000 * volFactor).toInt().coerceIn(-32768, 32767).toShort()
                }

                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                if (audioTrack.state == AudioTrack.STATE_INITIALIZED) {
                    audioTrack.write(buffer, 0, buffer.size)
                    audioTrack.play()
                    Thread.sleep(durationMs.toLong())
                    audioTrack.stop()
                    audioTrack.release()
                } else {
                    audioTrack.release()
                }
            } catch (t: Throwable) {
                // Ignore audio synthesis errors on headless environments
            }
        }
    }

    /**
     * Plays an ambient eerie synth whisper / mysterious crescendo tone safely on a background thread.
     */
    fun playMysteriousWhisper(context: Context? = null) {
        executor.execute {
            try {
                triggerVibration(context, 60)
            } catch (t: Throwable) { }
            try {
                val sampleRate = 22050
                val durationMs = 300
                val numSamples = sampleRate * durationMs / 1000
                val buffer = ShortArray(numSamples)
                val volFactor = if (isDucked) 0.3 else 1.0

                for (i in 0 until numSamples) {
                    val t = i.toDouble() / sampleRate
                    val attackReleaseEnv = Math.sin(Math.PI * (t / (durationMs / 1000.0)))
                    val wave1 = Math.sin(2.0 * Math.PI * 110.0 * t)
                    val sample = wave1 * attackReleaseEnv * 0.3 * volFactor

                    buffer[i] = (sample * 18000).toInt().coerceIn(-32768, 32767).toShort()
                }

                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                if (audioTrack.state == AudioTrack.STATE_INITIALIZED) {
                    audioTrack.write(buffer, 0, buffer.size)
                    audioTrack.play()
                    Thread.sleep(durationMs.toLong())
                    audioTrack.stop()
                    audioTrack.release()
                } else {
                    audioTrack.release()
                }
            } catch (t: Throwable) {
                // Ignore audio synthesis errors on headless environments
            }
        }
    }

    /**
     * Plays a crisp, subtle haptic glass click sound safely on a background thread.
     */
    fun playGlassClick(context: Context? = null) {
        executor.execute {
            try {
                triggerVibration(context, 30)
            } catch (t: Throwable) { }
            try {
                val sampleRate = 22050
                val durationMs = 60
                val numSamples = sampleRate * durationMs / 1000
                val buffer = ShortArray(numSamples)
                val volFactor = if (isDucked) 0.3 else 1.0

                for (i in 0 until numSamples) {
                    val t = i.toDouble() / sampleRate
                    val env = Math.exp(-t * 80.0)
                    val sample = Math.sin(2.0 * Math.PI * 880.0 * t) * env * 0.2 * volFactor
                    buffer[i] = (sample * 15000).toInt().coerceIn(-32768, 32767).toShort()
                }

                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                if (audioTrack.state == AudioTrack.STATE_INITIALIZED) {
                    audioTrack.write(buffer, 0, buffer.size)
                    audioTrack.play()
                    Thread.sleep(durationMs.toLong())
                    audioTrack.stop()
                    audioTrack.release()
                } else {
                    audioTrack.release()
                }
            } catch (t: Throwable) {
                // Ignore audio synthesis errors on headless environments
            }
        }
    }

    /**
     * Helper to play sound using Android MediaPlayer by generating a temporary WAV file if context is provided.
     */
    private fun playSynthesizedToneWithMediaPlayer(
        context: Context?,
        durationMs: Int,
        baseFreq: Double,
        sweep: Boolean,
        volume: Float
    ) {
        if (context == null) return
        try {
            val sampleRate = 22050
            val numSamples = sampleRate * durationMs / 1000
            val pcmData = ShortArray(numSamples)
            val effectiveVol = if (isDucked) volume * 0.35f else volume

            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                val freq = if (sweep) baseFreq + (t * 120.0) else baseFreq
                val env = Math.sin(Math.PI * (t / (durationMs / 1000.0)))
                val sample = Math.sin(2.0 * Math.PI * freq * t) * env * effectiveVol
                pcmData[i] = (sample * 25000).toInt().coerceIn(-32768, 32767).toShort()
            }

            // Create temporary WAV file for MediaPlayer
            val tempFile = File(context.cacheDir, "sfx_${System.currentTimeMillis()}.wav")
            FileOutputStream(tempFile).use { fos ->
                writeWavHeader(fos, sampleRate, 1, pcmData.size * 2)
                val byteBuf = java.nio.ByteBuffer.allocate(pcmData.size * 2).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                for (s in pcmData) {
                    byteBuf.putShort(s)
                }
                fos.write(byteBuf.array())
            }

            stopMediaPlayer()
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(tempFile.absolutePath)
                prepare()
                setOnCompletionListener { mp ->
                    mp.release()
                    if (mediaPlayer == mp) mediaPlayer = null
                    try { tempFile.delete() } catch (t: Throwable) { }
                }
                start()
            }
        } catch (t: Throwable) {
            // Fallback gracefully
        }
    }

    private fun writeWavHeader(out: FileOutputStream, sampleRate: Int, channels: Int, pcmDataSize: Int) {
        val totalDataLen = pcmDataSize + 36
        val byteRate = sampleRate * channels * 2
        val header = ByteArray(44)

        header[0] = 'R'.code.toByte()
        header[1] = 'I'.code.toByte()
        header[2] = 'F'.code.toByte()
        header[3] = 'F'.code.toByte()
        header[4] = (totalDataLen and 0xff).toByte()
        header[5] = ((totalDataLen shr 8) and 0xff).toByte()
        header[6] = ((totalDataLen shr 16) and 0xff).toByte()
        header[7] = ((totalDataLen shr 24) and 0xff).toByte()
        header[8] = 'W'.code.toByte()
        header[9] = 'A'.code.toByte()
        header[10] = 'V'.code.toByte()
        header[11] = 'E'.code.toByte()
        header[12] = 'f'.code.toByte()
        header[13] = 'm'.code.toByte()
        header[14] = 't'.code.toByte()
        header[15] = ' '.code.toByte()
        header[16] = 16
        header[17] = 0
        header[18] = 0
        header[19] = 0
        header[20] = 1 // PCM
        header[21] = 0
        header[22] = channels.toByte()
        header[23] = 0
        header[24] = (sampleRate and 0xff).toByte()
        header[25] = ((sampleRate shr 8) and 0xff).toByte()
        header[26] = ((sampleRate shr 16) and 0xff).toByte()
        header[27] = ((sampleRate shr 24) and 0xff).toByte()
        header[28] = (byteRate and 0xff).toByte()
        header[29] = ((byteRate shr 8) and 0xff).toByte()
        header[30] = ((byteRate shr 16) and 0xff).toByte()
        header[31] = ((byteRate shr 24) and 0xff).toByte()
        header[32] = (channels * 2).toByte()
        header[33] = 0
        header[34] = 16 // 16 bits
        header[35] = 0
        header[36] = 'd'.code.toByte()
        header[37] = 'a'.code.toByte()
        header[38] = 't'.code.toByte()
        header[39] = 'A'.code.toByte()
        header[40] = (pcmDataSize and 0xff).toByte()
        header[41] = ((pcmDataSize shr 8) and 0xff).toByte()
        header[42] = ((pcmDataSize shr 16) and 0xff).toByte()
        header[43] = ((pcmDataSize shr 24) and 0xff).toByte()

        out.write(header, 0, 44)
    }
}
