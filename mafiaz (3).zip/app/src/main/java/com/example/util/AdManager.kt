package com.example.util

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

object AdManager {
    private const val TAG = "AdManager"

    const val APP_ID = "ca-app-pub-1023841508152731~3806097187"
    const val BANNER_UNIT_ID = "ca-app-pub-1023841508152731/1179933841"
    const val INTERSTITIAL_UNIT_ID = "ca-app-pub-1023841508152731/6280483218"

    private var interstitialAd: InterstitialAd? = null
    private var isAdLoading = false
    private var isInitialized = false

    fun initialize(context: Context) {
        if (isInitialized) return
        try {
            MobileAds.initialize(context.applicationContext) { initializationStatus ->
                Log.d(TAG, "AdMob Initialized: $initializationStatus")
                isInitialized = true
                preloadInterstitialAd(context.applicationContext)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to initialize MobileAds", t)
        }
    }

    fun preloadInterstitialAd(context: Context) {
        if (interstitialAd != null || isAdLoading) return
        isAdLoading = true

        try {
            val adRequest = AdRequest.Builder().build()
            InterstitialAd.load(
                context.applicationContext,
                INTERSTITIAL_UNIT_ID,
                adRequest,
                object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(ad: InterstitialAd) {
                        interstitialAd = ad
                        isAdLoading = false
                        Log.d(TAG, "Interstitial Ad Loaded Successfully")
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        interstitialAd = null
                        isAdLoading = false
                        Log.e(TAG, "Interstitial Ad Failed to Load: ${error.message}")
                    }
                }
            )
        } catch (t: Throwable) {
            isAdLoading = false
            Log.e(TAG, "Exception loading interstitial ad", t)
        }
    }

    fun showInterstitialAdWithDelay(
        activity: Activity?,
        delayMs: Long = 1500L,
        onAdClosedOrSkipped: () -> Unit = {}
    ) {
        if (activity == null || interstitialAd == null) {
            onAdClosedOrSkipped()
            if (activity != null) preloadInterstitialAd(activity.applicationContext)
            return
        }

        Handler(Looper.getMainLooper()).postDelayed({
            try {
                val currentAd = interstitialAd
                if (currentAd != null && !activity.isFinishing && !activity.isDestroyed) {
                    currentAd.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            interstitialAd = null
                            preloadInterstitialAd(activity.applicationContext)
                            onAdClosedOrSkipped()
                        }

                        override fun onAdFailedToShowFullScreenContent(error: com.google.android.gms.ads.AdError) {
                            interstitialAd = null
                            preloadInterstitialAd(activity.applicationContext)
                            onAdClosedOrSkipped()
                        }
                    }
                    currentAd.show(activity)
                } else {
                    onAdClosedOrSkipped()
                }
            } catch (t: Throwable) {
                Log.e(TAG, "Failed to show interstitial ad", t)
                onAdClosedOrSkipped()
            }
        }, delayMs)
    }
}
