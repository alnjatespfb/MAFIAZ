package com.example.util

import android.content.Context
import android.speech.tts.TextToSpeech
import com.example.model.AppLanguage
import java.util.Locale

class TtsHelper(context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var isInitialized = false

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            tts?.setSpeechRate(0.92f)
            tts?.setPitch(1.0f)
            setLanguage(AppLanguage.AR)
        }
    }

    fun setLanguage(lang: AppLanguage) {
        if (!isInitialized) return
        val locale = if (lang == AppLanguage.AR) Locale("ar") else Locale.US
        val result = tts?.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Fallback to default locale if language data missing
            tts?.language = Locale.getDefault()
        }
    }

    fun speak(text: String, lang: AppLanguage = AppLanguage.AR) {
        if (!isInitialized || text.isBlank()) return
        tts?.stop()
        setLanguage(lang)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "Utterance_${System.currentTimeMillis()}")
    }

    fun stop() {
        if (isInitialized) {
            tts?.stop()
        }
    }

    fun shutdown() {
        if (isInitialized) {
            tts?.stop()
            tts?.shutdown()
            isInitialized = false
        }
    }
}
