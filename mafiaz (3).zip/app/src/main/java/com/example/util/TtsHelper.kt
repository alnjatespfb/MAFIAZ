package com.example.util

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.widget.Toast
import com.example.model.AppLanguage
import java.io.File
import java.net.URLEncoder
import java.util.Locale

class TtsHelper(private val context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private var availableEngines = mutableListOf<String>()
    private var currentEngineIndex = -1
    private var isEngineEnumerationStarted = false
    private var onlineMediaPlayer: MediaPlayer? = null
    private var hasShownToast = false
    private var currentLang: AppLanguage = AppLanguage.AR

    init {
        initializeTts()
    }

    private fun initializeTts(enginePackage: String? = null) {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (t: Throwable) {}

        try {
            tts = if (!enginePackage.isNullOrBlank()) {
                TextToSpeech(context.applicationContext, this, enginePackage)
            } else {
                TextToSpeech(context.applicationContext, this)
            }
        } catch (t: Throwable) {
            onInit(TextToSpeech.ERROR)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            try {
                tts?.setSpeechRate(0.92f)
                tts?.setPitch(1.0f)
                setLanguage(currentLang)
            } catch (t: Throwable) {}
        } else {
            tryNextTtsEngine()
        }
    }

    private fun tryNextTtsEngine() {
        try {
            if (!isEngineEnumerationStarted) {
                isEngineEnumerationStarted = true
                val installedEngines = tts?.engines
                if (!installedEngines.isNullOrEmpty()) {
                    val googleEngine = installedEngines.firstOrNull { it.name.contains("google", ignoreCase = true) }
                    if (googleEngine != null) {
                        availableEngines.add(googleEngine.name)
                    }
                    installedEngines.forEach { engine ->
                        if (!availableEngines.contains(engine.name)) {
                            availableEngines.add(engine.name)
                        }
                    }
                }
            }

            currentEngineIndex++
            if (currentEngineIndex < availableEngines.size) {
                initializeTts(availableEngines[currentEngineIndex])
            } else {
                isInitialized = false
                showMissingTtsToast()
            }
        } catch (t: Throwable) {
            isInitialized = false
            showMissingTtsToast()
        }
    }

    private fun showMissingTtsToast() {
        if (hasShownToast) return
        hasShownToast = true
        Handler(Looper.getMainLooper()).post {
            try {
                val msg = if (currentLang == AppLanguage.AR) {
                    "يرجى تثبيت أو تفعيل Google Speech Services لتشغيل المساعد الصوتي"
                } else {
                    "Please install or enable Google Speech Services for voice narration"
                }
                Toast.makeText(context.applicationContext, msg, Toast.LENGTH_LONG).show()
            } catch (t: Throwable) {}
        }
    }

    fun setLanguage(lang: AppLanguage) {
        currentLang = lang
        if (!isInitialized) return
        try {
            val locale = if (lang == AppLanguage.AR) Locale("ar") else Locale.US
            val result = tts?.setLanguage(locale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.getDefault()
            }
        } catch (t: Throwable) {}
    }

    fun speak(text: String, lang: AppLanguage = AppLanguage.AR) {
        if (text.isBlank()) return
        currentLang = lang
        var speakSuccess = false

        val cleanText = sanitizeTextForSpeech(text, lang == AppLanguage.AR)

        if (isInitialized) {
            try {
                tts?.stop()
                setLanguage(lang)
                SoundFxManager.setDucking(true)
                val result = tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, "Utterance_${System.currentTimeMillis()}")
                if (result == TextToSpeech.SUCCESS) {
                    speakSuccess = true
                }
            } catch (t: Throwable) {
                speakSuccess = false
            }
        }

        if (!speakSuccess) {
            playOnlineFallback(cleanText, lang)
        }
    }

    private fun sanitizeTextForSpeech(raw: String, isAr: Boolean): String {
        var result = raw.replace(
            Regex("[\\x{1F600}-\\x{1F64F}\\x{1F300}-\\x{1F5FF}\\x{1F680}-\\x{1F6FF}\\x{1F700}-\\x{1F77F}\\x{1F780}-\\x{1F7FF}\\x{1F800}-\\x{1F8FF}\\x{1F900}-\\x{1F9FF}\\x{1FA00}-\\x{1FA6F}\\x{1FA70}-\\x{1FAFF}\\x{2600}-\\x{26FF}\\x{2700}-\\x{27BF}]"),
            ""
        )
        result = result.replace(Regex("[•#*_~\\|\\[\\]()]"), " ")
        if (isAr) {
            val numberMap = mapOf(
                "0" to "صفر", "1" to "واحد", "2" to "اثنان", "3" to "ثلاثة",
                "4" to "أربعة", "5" to "خمسة", "6" to "ستة", "7" to "سبعة",
                "8" to "ثمانية", "9" to "تسعة", "10" to "عشرة"
            )
            numberMap.forEach { (digit, word) ->
                result = result.replace(Regex("\\b$digit\\b"), word)
            }
            val ArabicPronunciationMap = mapOf(
                "المافيا" to "المَافِيَا",
                "مافيا" to "مَافِيَا",
                "المحقق" to "المُحَقِّق",
                "الطبيب" to "الطَّبِيب",
                "المواطن" to "المُوَاطِن",
                "التصويت" to "التَّصْوِيت"
            )
            ArabicPronunciationMap.forEach { (term, vocalized) ->
                result = result.replace(Regex("\\b$term\\b"), vocalized)
            }
        }
        return result.replace(Regex("\\s+"), " ").trim()
    }

    private fun playOnlineFallback(text: String, lang: AppLanguage) {
        try {
            stopOnlinePlayer()
            val encodedText = URLEncoder.encode(text, "UTF-8")
            val targetLang = if (lang == AppLanguage.AR) "ar" else "en"
            val url = "https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=$targetLang&q=$encodedText"

            SoundFxManager.setDucking(true)

            onlineMediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                setDataSource(url)
                setOnPreparedListener { it.start() }
                setOnCompletionListener { mp ->
                    SoundFxManager.setDucking(false)
                    try { mp.release() } catch (t: Throwable) {}
                    if (onlineMediaPlayer == mp) onlineMediaPlayer = null
                }
                setOnErrorListener { mp, _, _ ->
                    SoundFxManager.setDucking(false)
                    try { mp.release() } catch (t: Throwable) {}
                    if (onlineMediaPlayer == mp) onlineMediaPlayer = null
                    showMissingTtsToast()
                    true
                }
                prepareAsync()
            }
        } catch (t: Throwable) {
            SoundFxManager.setDucking(false)
            showMissingTtsToast()
        }
    }

    private fun stopOnlinePlayer() {
        try {
            onlineMediaPlayer?.stop()
            onlineMediaPlayer?.release()
        } catch (t: Throwable) {}
        finally {
            onlineMediaPlayer = null
            SoundFxManager.setDucking(false)
        }
    }

    fun stop() {
        try {
            if (isInitialized) {
                tts?.stop()
            }
            stopOnlinePlayer()
            SoundFxManager.setDucking(false)
        } catch (t: Throwable) {}
    }

    fun shutdown() {
        try {
            stop()
            if (isInitialized) {
                tts?.shutdown()
                isInitialized = false
            }
        } catch (t: Throwable) {}
    }
}
