package com.example.util

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.net.URLEncoder

object SoundManager {
    private var mediaPlayer: MediaPlayer? = null
    private val client = OkHttpClient()

    fun speakHumanVoice(context: Context, text: String) {
        stopAudio()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val encodedText = URLEncoder.encode(text, "UTF-8")
                val url = "https://api.streamelements.com/kappa/v2/speech?voice=ar-EG-SalmaNeural&text=$encodedText"
                val request = Request.Builder().url(url).build()
                val response = client.newCall(request).execute()

                if (response.isSuccessful) {
                    val tempFile = File(context.cacheDir, "temp_voice.mp3")
                    val fos = FileOutputStream(tempFile)
                    fos.write(response.body?.bytes())
                    fos.close()

                    withContext(Dispatchers.Main) {
                        playMp3File(tempFile.absolutePath)
                    }
                }
            } catch (e: Exception) {
                Log.e("SoundManager", "Error: ${e.message}")
            }
        }
    }

    private fun playMp3File(filePath: String) {
        try {
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(filePath)
                prepare()
                start()
            }
        } catch (e: Exception) {
            Log.e("SoundManager", "Error playing: ${e.message}")
        }
    }

    fun stopAudio() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) it.stop()
                it.reset()
                it.release()
            }
            mediaPlayer = null
        } catch (e: Exception) {
            Log.e("SoundManager", "Error stopping: ${e.message}")
        }
    }
}
