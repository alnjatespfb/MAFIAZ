package com.example.util

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import com.example.data.GeminiVoiceService
import com.example.model.AppLanguage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.URLEncoder
import java.security.MessageDigest

/**
 * Global Configuration for Cloud AI Voice APIs.
 * Easily insert your API Key here to enable human-like voice generation.
 */
object VoiceApiConfig {
    // Edge-TTS Neural Voice Selection (Arabic default: Egyptian Salma Neural / Saudi Zariyah)
    var edgeTtsArabicVoice: String = "ar-EG-SalmaNeural" // "ar-EG-SalmaNeural", "ar-EG-ShakirNeural", "ar-SA-ZariyahNeural"
    var edgeTtsEnglishVoice: String = "en-US-AvaNeural"

    // ElevenLabs API Configuration (https://elevenlabs.io)
    var elevenLabsApiKey: String = "" // e.g., "xi-api-key-here"
    var elevenLabsVoiceId: String = "21m00Tcm4TlvDq8ikWAM" // Smooth multilingual voice ID

    // OpenAI TTS API Configuration (https://platform.openai.com)
    var openAiApiKey: String = "" // e.g., "sk-proj-..."
    var openAiVoice: String = "nova" // alloy, echo, fable, onyx, nova, shimmer
}

/**
 * Unified Human Voice Manager.
 * Uses Pure Neural Stream & External AI Voice APIs with Android MediaPlayer.
 * Completely eliminates old Android TextToSpeech to prevent robotic voices, crashes, and overlaps.
 */
class HybridVoiceManager(private val context: Context) {

    private val TAG = "HybridVoiceManager"
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    val networkObserver = NetworkObserver(context)
    private val geminiService = GeminiVoiceService()

    private var speechRecognizer: SpeechRecognizer? = null
    @Volatile
    private var onlineMediaPlayer: MediaPlayer? = null
    private var currentLang: AppLanguage = AppLanguage.AR
    private var activeSpeakJob: Job? = null

    @Volatile
    private var currentCompletionCallback: (() -> Unit)? = null

    private val cacheDir: File by lazy {
        File(context.cacheDir, "neural_tts_cache").apply { if (!exists()) mkdirs() }
    }

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _lastSpokenText = MutableStateFlow("")
    val lastSpokenText: StateFlow<String> = _lastSpokenText.asStateFlow()

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    val isOnline: StateFlow<Boolean> = networkObserver.isOnline

    private fun setSpeakingState(speaking: Boolean) {
        _isSpeaking.value = speaking
        SoundFxManager.setDucking(speaking)
    }

    private fun triggerCompletionCallback() {
        Handler(Looper.getMainLooper()).post {
            try {
                val callback = currentCompletionCallback
                currentCompletionCallback = null
                callback?.invoke()
            } catch (t: Throwable) {
                Log.e(TAG, "Error triggering completion callback", t)
            }
        }
    }

    fun setLanguage(lang: AppLanguage) {
        currentLang = lang
    }

    /**
     * Cleans, sanitizes, and adds vocalization (diacritics) for natural Arabic speech.
     */
    private fun sanitizeTextForSpeech(raw: String, isAr: Boolean): String {
        var result = raw.replace(
            Regex("[\\x{1F600}-\\x{1F64F}\\x{1F300}-\\x{1F5FF}\\x{1F680}-\\x{1F6FF}\\x{1F700}-\\x{1F77F}\\x{1F780}-\\x{1F7FF}\\x{1F800}-\\x{1F8FF}\\x{1F900}-\\x{1F9FF}\\x{1FA00}-\\x{1FA6F}\\x{1FA70}-\\x{1FAFF}\\x{2600}-\\x{26FF}\\x{2700}-\\x{27BF}]"),
            ""
        )
        result = result.replace(Regex("[•#*_~\\|\\[\\]()]"), " ")

        if (isAr) {
            val numberMap = mapOf(
                "0" to "صفر", "1" to "واحد", "2" to "اثنان", "3" to "ثلاثة",
                "4" to "أربعة", "5" to "خمسة", "6" to "ستة", "7" to "سبعة",
                "8" to "ثمانية", "9" to "تسعة", "10" to "عشرة", "11" to "أحد عشر",
                "12" to "اثنا عشر", "15" to "خمس عشرة دقيقة"
            )
            numberMap.forEach { (digit, word) ->
                result = result.replace(Regex("\\b$digit\\b"), word)
            }
            result = result.replace("٠", "صفر").replace("١", "واحد").replace("٢", "اثنان")
                .replace("٣", "ثلاثة").replace("٤", "أربعة").replace("٥", "خمسة")
                .replace("٦", "ستة").replace("٧", "سبعة").replace("٨", "ثمانية").replace("٩", "تسعة")

            val arabicPronunciationMap = mapOf(
                "المافيا" to "المَافِيَا",
                "مافيا" to "مَافِيَا",
                "المحقق" to "المُحَقِّق",
                "الطبيب" to "الطَّبِيب",
                "المواطن" to "المُوَاطِن",
                "المواطنين" to "المُوَاطِنِين",
                "التصويت" to "التَّصْوِيت",
                "تصويت" to "تَصْوِيت",
                "التحقيق" to "التَّحْقِيق",
                "الليل" to "اللَّيْل",
                "النهار" to "النَّهَار",
                "قتل" to "قَتْل",
                "إقصاء" to "إِقْصَاء",
                "فاز" to "فَازَ",
                "فازت" to "فَازَتْ"
            )
            arabicPronunciationMap.forEach { (term, vocalized) ->
                result = result.replace(Regex("\\b$term\\b"), vocalized)
            }
        }
        return result.replace(Regex("\\s+"), " ").trim()
    }

    private fun getMd5Hash(input: String): String {
        return try {
            val md = MessageDigest.getInstance("MD5")
            val digest = md.digest(input.toByteArray())
            digest.joinToString("") { "%02x".format(it) }
        } catch (t: Throwable) {
            input.hashCode().toString()
        }
    }

    /**
     * Main entry point for human voice speech generation & playback.
     */
    fun speak(
        text: String,
        lang: AppLanguage = AppLanguage.AR,
        enhanceWithAiIfOnline: Boolean = false,
        gameStateContext: String = "",
        onCompletion: (() -> Unit)? = null
    ) {
        // 1. Immediately stop current playing audio and cancel background tasks
        stop()

        if (text.isBlank() || _isMuted.value) {
            onCompletion?.invoke()
            return
        }

        currentLang = lang
        currentCompletionCallback = onCompletion

        activeSpeakJob = scope.launch {
            var textToSpeak = text

            if (enhanceWithAiIfOnline && networkObserver.isOnline.value) {
                try {
                    val aiEnhanced = geminiService.generateVoiceResponse(text, gameStateContext)
                    if (!aiEnhanced.isNullOrBlank()) {
                        textToSpeak = aiEnhanced
                    }
                } catch (t: Throwable) {
                    Log.e(TAG, "Gemini enhancement error", t)
                }
            }

            textToSpeak = sanitizeTextForSpeech(textToSpeak, lang == AppLanguage.AR)
            _lastSpokenText.value = textToSpeak

            if (textToSpeak.isBlank()) {
                triggerCompletionCallback()
                return@launch
            }

            // 2. Check local disk cache (0ms latency for repeated lines)
            val langCode = if (lang == AppLanguage.AR) "ar" else "en"
            val voiceKey = if (lang == AppLanguage.AR) VoiceApiConfig.edgeTtsArabicVoice else VoiceApiConfig.edgeTtsEnglishVoice
            val hash = getMd5Hash("$voiceKey:$textToSpeak")
            val cachedFile = File(cacheDir, "$hash.mp3")

            if (cachedFile.exists() && cachedFile.length() > 0) {
                val success = playAudioFile(cachedFile)
                if (success) return@launch
            }

            // 3. Try configured Human Voice Cloud APIs (ElevenLabs / OpenAI / Edge-TTS Neural)
            var playedWithCloudApi = false
            if (networkObserver.isOnline.value) {
                if (VoiceApiConfig.elevenLabsApiKey.isNotBlank()) {
                    playedWithCloudApi = fetchAndPlayElevenLabs(textToSpeak, cachedFile)
                } else if (VoiceApiConfig.openAiApiKey.isNotBlank()) {
                    playedWithCloudApi = fetchAndPlayOpenAi(textToSpeak, cachedFile)
                }

                if (!playedWithCloudApi) {
                    // Default High Quality Neural Voice Stream (Edge Neural)
                    playedWithCloudApi = fetchAndPlayEdgeNeuralStream(textToSpeak, langCode, cachedFile)
                }
            }

            if (!playedWithCloudApi) {
                setSpeakingState(false)
                triggerCompletionCallback()
            }
        }
    }

    private suspend fun fetchAndPlayElevenLabs(text: String, outputFile: File): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val voiceId = VoiceApiConfig.elevenLabsVoiceId
                val streamUrl = "https://api.elevenlabs.io/v1/text-to-speech/$voiceId/stream"

                val jsonBody = JSONObject().apply {
                    put("text", text)
                    put("model_id", "eleven_multilingual_v2")
                    put("voice_settings", JSONObject().apply {
                        put("stability", 0.5)
                        put("similarity_boost", 0.75)
                    })
                }

                val body = jsonBody.toString().toRequestBody("application/json".toMediaType())
                val request = Request.Builder()
                    .url(streamUrl)
                    .header("xi-api-key", VoiceApiConfig.elevenLabsApiKey)
                    .header("Accept", "audio/mpeg")
                    .post(body)
                    .build()

                val response = okHttpClient.newCall(request).execute()
                if (response.isSuccessful) {
                    val respBody = response.body
                    if (respBody != null) {
                        val tempFile = File(cacheDir, "${outputFile.name}.tmp")
                        tempFile.outputStream().use { output ->
                            respBody.byteStream().use { input -> input.copyTo(output) }
                        }
                        if (tempFile.length() > 0) {
                            tempFile.renameTo(outputFile)
                            return@withContext playAudioFile(outputFile)
                        }
                    }
                }
                false
            } catch (t: Throwable) {
                Log.e(TAG, "ElevenLabs Exception", t)
                false
            }
        }
    }

    private suspend fun fetchAndPlayOpenAi(text: String, outputFile: File): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val streamUrl = "https://api.openai.com/v1/audio/speech"

                val jsonBody = JSONObject().apply {
                    put("model", "tts-1")
                    put("input", text)
                    put("voice", VoiceApiConfig.openAiVoice)
                }

                val body = jsonBody.toString().toRequestBody("application/json".toMediaType())
                val request = Request.Builder()
                    .url(streamUrl)
                    .header("Authorization", "Bearer ${VoiceApiConfig.openAiApiKey}")
                    .post(body)
                    .build()

                val response = okHttpClient.newCall(request).execute()
                if (response.isSuccessful) {
                    val respBody = response.body
                    if (respBody != null) {
                        val tempFile = File(cacheDir, "${outputFile.name}.tmp")
                        tempFile.outputStream().use { output ->
                            respBody.byteStream().use { input -> input.copyTo(output) }
                        }
                        if (tempFile.length() > 0) {
                            tempFile.renameTo(outputFile)
                            return@withContext playAudioFile(outputFile)
                        }
                    }
                }
                false
            } catch (t: Throwable) {
                Log.e(TAG, "OpenAI TTS Exception", t)
                false
            }
        }
    }

    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(5, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(7, java.util.concurrent.TimeUnit.SECONDS)
            .build()
    }

    private suspend fun fetchAndPlayEdgeNeuralStream(text: String, langCode: String, outputFile: File): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val encodedText = URLEncoder.encode(text, "UTF-8")
                val streamUrl = "https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=$langCode&q=$encodedText"

                val request = Request.Builder()
                    .url(streamUrl)
                    .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
                    .build()

                val response = okHttpClient.newCall(request).execute()
                if (response.isSuccessful) {
                    val body = response.body
                    if (body != null) {
                        val tempFile = File(cacheDir, "${outputFile.name}.tmp")
                        tempFile.outputStream().use { output ->
                            body.byteStream().use { input ->
                                input.copyTo(output)
                            }
                        }
                        if (tempFile.length() > 0) {
                            tempFile.renameTo(outputFile)
                            return@withContext playAudioFile(outputFile)
                        }
                    }
                }
                false
            } catch (t: Throwable) {
                Log.e(TAG, "Neural TTS Stream error", t)
                false
            }
        }
    }

    /**
     * Plays the audio file using Android MediaPlayer with strict lifecycle management & listener callbacks.
     */
    private suspend fun playAudioFile(file: File): Boolean {
        return withContext(Dispatchers.Main) {
            try {
                stopOnlinePlayer()
                setSpeakingState(true)

                val player = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    setDataSource(file.absolutePath)
                    setOnPreparedListener { mp ->
                        try {
                            mp.start()
                        } catch (t: Throwable) {
                            setSpeakingState(false)
                            triggerCompletionCallback()
                        }
                    }
                    setOnCompletionListener { mp ->
                        setSpeakingState(false)
                        triggerCompletionCallback()
                        try {
                            mp.reset()
                            mp.release()
                        } catch (t: Throwable) {}
                        if (onlineMediaPlayer == mp) onlineMediaPlayer = null
                    }
                    setOnErrorListener { mp, _, _ ->
                        setSpeakingState(false)
                        triggerCompletionCallback()
                        try {
                            mp.reset()
                            mp.release()
                        } catch (t: Throwable) {}
                        if (onlineMediaPlayer == mp) onlineMediaPlayer = null
                        true
                    }
                    prepareAsync()
                }
                onlineMediaPlayer = player
                true
            } catch (t: Throwable) {
                setSpeakingState(false)
                triggerCompletionCallback()
                false
            }
        }
    }

    @Synchronized
    private fun stopOnlinePlayer() {
        try {
            onlineMediaPlayer?.let { mp ->
                try {
                    if (mp.isPlaying) {
                        mp.stop()
                    }
                } catch (t: Throwable) {
                    // Ignore state errors during stop
                }
                mp.reset()
                mp.release()
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Error stopping online player", t)
        } finally {
            onlineMediaPlayer = null
            setSpeakingState(false)
        }
    }

    fun askAiVoiceInquiry(
        userQuery: String,
        gameStateContext: String,
        lang: AppLanguage = AppLanguage.AR,
        onResponse: (String) -> Unit
    ) {
        if (userQuery.isBlank()) return

        scope.launch {
            val isAr = lang == AppLanguage.AR
            var responseText: String

            try {
                if (networkObserver.isOnline.value) {
                    val aiResponse = geminiService.generateVoiceResponse(userQuery, gameStateContext)
                    responseText = if (!aiResponse.isNullOrBlank()) {
                        aiResponse
                    } else {
                        getOfflineFallbackAnswer(userQuery, gameStateContext, isAr)
                    }
                } else {
                    responseText = getOfflineFallbackAnswer(userQuery, gameStateContext, isAr)
                }
            } catch (t: Throwable) {
                responseText = getOfflineFallbackAnswer(userQuery, gameStateContext, isAr)
            }

            onResponse(responseText)
            speak(responseText, lang)
        }
    }

    private fun getOfflineFallbackAnswer(
        query: String,
        context: String,
        isAr: Boolean
    ): String {
        val q = query.lowercase()
        return when {
            q.contains("دور") || q.contains("الأدوار") || q.contains("role") -> {
                if (isAr) "تضم اللعبة: المافيا للقتل، الطبيب للإنقاذ، المحقق للكشف، والمواطنين للدفاع والتصويت."
                else "Roles include: Mafia to eliminate, Doctor to save, Detective to inspect, and Citizens to vote."
            }
            q.contains("من") || q.contains("قاتل") || q.contains("شبهة") || q.contains("who") -> {
                if (isAr) "حلل تصرفات وإجابات اللاعبين في مرحلة النقاش، وراقب من يتهرب من الأسئلة!"
                else "Analyze player responses during discussion and watch who avoids direct questions!"
            }
            q.contains("قوانين") || q.contains("كيف") || q.contains("rules") || q.contains("play") -> {
                if (isAr) "تبدأ اللعبة بالليل لتنفيذ الأدوار السرية، ثم النهار للنقاش والتصويت لإقصاء المشتبه به."
                else "Game starts at night for secret roles, followed by daytime discussion and voting."
            }
            else -> {
                if (isAr) "أنا مساعدك الصوتي التكتيكي في مافيا! استخدم قدراتك التحليلية وتابع مجريات اللعبة بذكاء."
                else "I am your voice assistant for MAFIAZ! Stay vigilant and analyze the game events."
            }
        }
    }

    fun startListening(
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        try {
            if (androidx.core.content.ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.RECORD_AUDIO
                ) != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                onError(if (currentLang == AppLanguage.AR) "يرجى منح إذن استخدام المايكرفون" else "Microphone permission is required")
                return
            }

            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                onError(if (currentLang == AppLanguage.AR) "التعرف على الصوت غير متاح على هذا الجهاز" else "Speech recognition not available")
                return
            }

            stop()
            speechRecognizer?.destroy()
            val attributionContext = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                context.createAttributionContext("default")
            } else {
                context
            }
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(attributionContext).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _isListening.value = true
                    }

                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {
                        _isListening.value = false
                    }

                    override fun onError(error: Int) {
                        _isListening.value = false
                        onError("خطأ في التقاط الصوت: $error")
                    }

                    override fun onResults(results: Bundle?) {
                        _isListening.value = false
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val spokenText = matches?.firstOrNull() ?: ""
                        if (spokenText.isNotBlank()) {
                            onResult(spokenText)
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "تحدث الآن مع المساعد الصوتي...")
            }

            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            _isListening.value = false
            onError("تعذر تشغيل المايكرفون")
        }
    }

    fun stopListening() {
        try {
            if (_isListening.value) {
                speechRecognizer?.stopListening()
                _isListening.value = false
            }
        } catch (t: Throwable) {
            _isListening.value = false
        }
    }

    fun repeat() {
        val text = _lastSpokenText.value
        if (text.isNotBlank()) {
            speak(text, currentLang)
        }
    }

    /**
     * Instantly interrupts speech generation, releases media player memory, stops speech recognition and resets ducking.
     */
    fun stopAudio() {
        stop()
    }

    fun stop() {
        try {
            activeSpeakJob?.cancel()
            activeSpeakJob = null
            currentCompletionCallback = null
            stopOnlinePlayer()
            stopListening()
            setSpeakingState(false)
        } catch (t: Throwable) {
            setSpeakingState(false)
        }
    }

    fun toggleMute() {
        _isMuted.value = !_isMuted.value
        if (_isMuted.value) {
            stop()
        }
    }

    fun shutdown() {
        try {
            stop()
            networkObserver.unregister()
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (t: Throwable) {
            // Safe teardown
        }
    }
}
