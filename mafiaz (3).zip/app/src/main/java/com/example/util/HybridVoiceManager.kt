package com.example.util

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.data.GeminiVoiceService
import com.example.model.AppLanguage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class HybridVoiceManager(private val context: Context) : TextToSpeech.OnInitListener {

    private val scope = CoroutineScope(Dispatchers.Main + Job())
    val networkObserver = NetworkObserver(context)
    private val geminiService = GeminiVoiceService()

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var speechRecognizer: SpeechRecognizer? = null

    private var isTtsInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _lastSpokenText = MutableStateFlow("")
    val lastSpokenText: StateFlow<String> = _lastSpokenText.asStateFlow()

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    val isOnline: StateFlow<Boolean> = networkObserver.isOnline

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsInitialized = true
            tts?.setSpeechRate(0.95f)
            tts?.setPitch(1.0f)
            setLanguage(AppLanguage.AR)

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                }
            })
        }
    }

    fun setLanguage(lang: AppLanguage) {
        if (!isTtsInitialized) return
        val locale = if (lang == AppLanguage.AR) Locale("ar") else Locale.US
        val result = tts?.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.language = Locale.getDefault()
        }
    }

    fun speak(
        text: String,
        lang: AppLanguage = AppLanguage.AR,
        enhanceWithAiIfOnline: Boolean = false,
        gameStateContext: String = ""
    ) {
        if (text.isBlank() || _isMuted.value) return

        scope.launch {
            var textToSpeak = text

            if (enhanceWithAiIfOnline && networkObserver.isOnline.value) {
                val aiEnhanced = geminiService.generateVoiceResponse(text, gameStateContext)
                if (!aiEnhanced.isNullOrBlank()) {
                    textToSpeak = aiEnhanced
                }
            }

            _lastSpokenText.value = textToSpeak

            if (isTtsInitialized) {
                tts?.stop()
                setLanguage(lang)
                val utteranceId = "utterance_${System.currentTimeMillis()}"
                tts?.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
            }
        }
    }

    fun askAiVoiceInquiry(
        userQuery: String,
        gameStateContext: String,
        lang: AppLanguage = AppLanguage.AR,
        onResponse: (String) -> Unit
    ) {
        if (userQuery.isBlank()) return

        scope.launch {
            val isAr = lang == AppLanguage.AR
            val responseText: String

            if (networkObserver.isOnline.value) {
                val aiResponse = geminiService.generateVoiceResponse(userQuery, gameStateContext)
                responseText = if (!aiResponse.isNullOrBlank()) {
                    aiResponse
                } else {
                    getOfflineFallbackAnswer(userQuery, gameStateContext, isAr)
                }
            } else {
                responseText = getOfflineFallbackAnswer(userQuery, gameStateContext, isAr)
            }

            onResponse(responseText)
            speak(responseText, lang)
        }
    }

    private fun getOfflineFallbackAnswer(
        query: String,
        context: String,
        isAr: Boolean
    ): String {
        val q = query.lowercase()
        return when {
            q.contains("دور") || q.contains("الأدوار") || q.contains("role") -> {
                if (isAr) "تضم اللعبة: المافيا للقتل، الطبيب للإنقاذ، المحقق للكشف، والمواطنين للدفاع والتصويت."
                else "Roles include: Mafia to eliminate, Doctor to save, Detective to inspect, and Citizens to vote."
            }
            q.contains("من") || q.contains("قاتل") || q.contains("شبهة") || q.contains("who") -> {
                if (isAr) "حلل تصرفات وإجابات اللاعبين في مرحلة النقاش، وراقب من يتهرب من الأسئلة!"
                else "Analyze player responses during discussion and watch who avoids direct questions!"
            }
            q.contains("قوانين") || q.contains("كيف") || q.contains("rules") || q.contains("play") -> {
                if (isAr) "تبدأ اللعبة بالليل لتنفيذ الأدوار السرية، ثم النهار للنقاش والتصويت لإقصاء المشتبه به."
                else "Game starts at night for secret roles, followed by daytime discussion and voting."
            }
            else -> {
                if (isAr) "أنا مساعدك الصوتي التكتيكي في مافيا! استخدم قدراتك التحليلية وتابع مجريات اللعبة بذكاء."
                else "I am your voice assistant for MAFIAZ! Stay vigilant and analyze the game events."
            }
        }
    }

    fun startListening(
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("التعرف على الصوت غير متاح على هذا الجهاز")
            return
        }

        stop()
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _isListening.value = true
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    _isListening.value = false
                }

                override fun onError(error: Int) {
                    _isListening.value = false
                    onError("خطأ في التقاط الصوت: $error")
                }

                override fun onResults(results: Bundle?) {
                    _isListening.value = false
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spokenText = matches?.firstOrNull() ?: ""
                    if (spokenText.isNotBlank()) {
                        onResult(spokenText)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "تحدث الآن مع المساعد الصوتي...")
        }

        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            _isListening.value = false
            onError("تعذر تشغيل المايكرفون")
        }
    }

    fun stopListening() {
        if (_isListening.value) {
            speechRecognizer?.stopListening()
            _isListening.value = false
        }
    }

    fun repeat() {
        val text = _lastSpokenText.value
        if (text.isNotBlank()) {
            speak(text)
        }
    }

    fun stop() {
        if (isTtsInitialized) {
            tts?.stop()
        }
        stopListening()
        _isSpeaking.value = false
    }

    fun toggleMute() {
        _isMuted.value = !_isMuted.value
        if (_isMuted.value) {
            stop()
        }
    }

    fun shutdown() {
        stop()
        networkObserver.unregister()
        if (isTtsInitialized) {
            tts?.shutdown()
            isTtsInitialized = false
        }
        speechRecognizer?.destroy()
        speechRecognizer = null
    }
}
