package com.example.util

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import com.example.data.GeminiVoiceService
import com.example.model.AppLanguage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.Locale

class HybridVoiceManager(private val context: Context) : TextToSpeech.OnInitListener {

    private val scope = CoroutineScope(Dispatchers.Main + Job())
    val networkObserver = NetworkObserver(context)
    private val geminiService = GeminiVoiceService()

    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null

    private var isTtsInitialized = false
    private var isEngineEnumerationStarted = false
    private val availableEngines = mutableListOf<String>()
    private var currentEngineIndex = -1

    private var hasShownToast = false
    private var onlineMediaPlayer: MediaPlayer? = null
    private var currentLang: AppLanguage = AppLanguage.AR

    private val cacheDir: File by lazy {
        File(context.cacheDir, "tts_cache").apply { if (!exists()) mkdirs() }
    }

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _lastSpokenText = MutableStateFlow("")
    val lastSpokenText: StateFlow<String> = _lastSpokenText.asStateFlow()

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    val isOnline: StateFlow<Boolean> = networkObserver.isOnline

    init {
        initializeTts()
    }

    private fun initializeTts(enginePackage: String? = null) {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (t: Throwable) {
            // Ignore teardown errors
        }

        try {
            tts = if (!enginePackage.isNullOrBlank()) {
                TextToSpeech(context.applicationContext, this, enginePackage)
            } else {
                TextToSpeech(context.applicationContext, this)
            }
        } catch (t: Throwable) {
            onInit(TextToSpeech.ERROR)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsInitialized = true
            try {
                tts?.setSpeechRate(0.92f)
                tts?.setPitch(1.0f)
                setLanguage(currentLang)

                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        setSpeakingState(true)
                    }

                    override fun onDone(utteranceId: String?) {
                        setSpeakingState(false)
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        setSpeakingState(false)
                    }
                })
            } catch (t: Throwable) {
                // Ignore listener attach failure on custom ROMs
            }
        } else {
            tryNextTtsEngine()
        }
    }

    private fun setSpeakingState(speaking: Boolean) {
        _isSpeaking.value = speaking
        SoundFxManager.setDucking(speaking)
    }

    private fun tryNextTtsEngine() {
        try {
            if (!isEngineEnumerationStarted) {
                isEngineEnumerationStarted = true
                availableEngines.clear()

                val installedEngines = tts?.engines
                if (!installedEngines.isNullOrEmpty()) {
                    val googleEngine = installedEngines.firstOrNull { it.name.contains("google", ignoreCase = true) }
                    if (googleEngine != null) {
                        availableEngines.add(googleEngine.name)
                    }
                    installedEngines.forEach { engine ->
                        if (!availableEngines.contains(engine.name)) {
                            availableEngines.add(engine.name)
                        }
                    }
                }
            }

            currentEngineIndex++
            if (currentEngineIndex < availableEngines.size) {
                initializeTts(availableEngines[currentEngineIndex])
            } else {
                isTtsInitialized = false
                showMissingTtsToast()
            }
        } catch (t: Throwable) {
            isTtsInitialized = false
            showMissingTtsToast()
        }
    }

    private fun showMissingTtsToast() {
        if (hasShownToast) return
        hasShownToast = true
        Handler(Looper.getMainLooper()).post {
            try {
                val msg = if (currentLang == AppLanguage.AR) {
                    "يرجى تثبيت أو تفعيل Google Speech Services لتشغيل المساعد الصوتي"
                } else {
                    "Please install or enable Google Speech Services for voice narration"
                }
                Toast.makeText(context.applicationContext, msg, Toast.LENGTH_LONG).show()
            } catch (t: Throwable) {
                // Ignore UI toast exceptions
            }
        }
    }

    fun setLanguage(lang: AppLanguage) {
        currentLang = lang
        if (!isTtsInitialized) return
        try {
            val locale = if (lang == AppLanguage.AR) Locale("ar") else Locale.US
            val result = tts?.setLanguage(locale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.getDefault()
            }

            val voices = tts?.voices
            if (!voices.isNullOrEmpty()) {
                val targetLang = if (lang == AppLanguage.AR) "ar" else "en"
                val bestVoice = voices.firstOrNull { voice ->
                    voice.locale.language == targetLang && !voice.isNetworkConnectionRequired
                } ?: voices.firstOrNull { voice -> voice.locale.language == targetLang }

                if (bestVoice != null) {
                    tts?.voice = bestVoice
                }
            }
        } catch (t: Throwable) {
            // Ignore voice selection exceptions on unsupported engines
        }
    }

    /**
     * Cleans, sanitizes, and adds light vocalization (diacritics) for ultra-fluent Arabic speech.
     */
    private fun sanitizeTextForSpeech(raw: String, isAr: Boolean): String {
        // 1. Remove all Emojis
        var result = raw.replace(
            Regex("[\\x{1F600}-\\x{1F64F}\\x{1F300}-\\x{1F5FF}\\x{1F680}-\\x{1F6FF}\\x{1F700}-\\x{1F77F}\\x{1F780}-\\x{1F7FF}\\x{1F800}-\\x{1F8FF}\\x{1F900}-\\x{1F9FF}\\x{1FA00}-\\x{1FA6F}\\x{1FA70}-\\x{1FAFF}\\x{2600}-\\x{26FF}\\x{2700}-\\x{27BF}]"),
            ""
        )
        // 2. Remove Markdown & formatting symbols
        result = result.replace(Regex("[•#*_~\\|\\[\\]()]"), " ")

        if (isAr) {
            // Replace standalone digits with spoken Arabic words
            val numberMap = mapOf(
                "0" to "صفر", "1" to "واحد", "2" to "اثنان", "3" to "ثلاثة",
                "4" to "أربعة", "5" to "خمسة", "6" to "ستة", "7" to "سبعة",
                "8" to "ثمانية", "9" to "تسعة", "10" to "عشرة", "11" to "أحد عشر",
                "12" to "اثنا عشر", "15" to "خمس عشرة دقيقة"
            )
            numberMap.forEach { (digit, word) ->
                result = result.replace(Regex("\\b$digit\\b"), word)
            }
            result = result.replace("٠", "صفر").replace("١", "واحد").replace("٢", "اثنان")
                .replace("٣", "ثلاثة").replace("٤", "أربعة").replace("٥", "خمسة")
                .replace("٦", "ستة").replace("٧", "سبعة").replace("٨", "ثمانية").replace("٩", "تسعة")

            // 3. Diacritics & Vocalization mapping for core Mafia game terms
            val ArabicPronunciationMap = mapOf(
                "المافيا" to "المَافِيَا",
                "مافيا" to "مَافِيَا",
                "المحقق" to "المُحَقِّق",
                "الطبيب" to "الطَّبِيب",
                "المواطن" to "المُوَاطِن",
                "المواطنين" to "المُوَاطِنِين",
                "التصويت" to "التَّصْوِيت",
                "تصويت" to "تَصْوِيت",
                "التحقيق" to "التَّحْقِيق",
                "الليل" to "اللَّيْل",
                "النهار" to "النَّهَار",
                "قتل" to "قَتْل",
                "إقصاء" to "إِقْصَاء",
                "فاز" to "فَازَ",
                "فازت" to "فَازَتْ"
            )
            ArabicPronunciationMap.forEach { (term, vocalized) ->
                result = result.replace(Regex("\\b$term\\b"), vocalized)
            }
        }
        return result.replace(Regex("\\s+"), " ").trim()
    }

    private fun getMd5Hash(input: String): String {
        return try {
            val md = MessageDigest.getInstance("MD5")
            val digest = md.digest(input.toByteArray())
            digest.joinToString("") { "%02x".format(it) }
        } catch (t: Throwable) {
            input.hashCode().toString()
        }
    }

    fun speak(
        text: String,
        lang: AppLanguage = AppLanguage.AR,
        enhanceWithAiIfOnline: Boolean = false,
        gameStateContext: String = ""
    ) {
        if (text.isBlank() || _isMuted.value) return
        currentLang = lang

        scope.launch {
            var textToSpeak = text

            if (enhanceWithAiIfOnline && networkObserver.isOnline.value) {
                try {
                    val aiEnhanced = geminiService.generateVoiceResponse(text, gameStateContext)
                    if (!aiEnhanced.isNullOrBlank()) {
                        textToSpeak = aiEnhanced
                    }
                } catch (t: Throwable) {
                    // Ignore Gemini service exceptions
                }
            }

            textToSpeak = sanitizeTextForSpeech(textToSpeak, lang == AppLanguage.AR)
            _lastSpokenText.value = textToSpeak

            if (textToSpeak.isBlank()) return@launch

            // Try Cloud AI Voice Stream first if online for high quality, or cached audio
            val playedCloudVoice = playCloudVoiceOrCache(textToSpeak, lang)

            if (!playedCloudVoice) {
                // Fallback to local TTS Engine if offline or Cloud Stream unavailable
                if (isTtsInitialized) {
                    try {
                        stopOnlinePlayer()
                        tts?.stop()
                        setLanguage(lang)
                        val utteranceId = "utterance_${System.currentTimeMillis()}"
                        val result = tts?.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
                        if (result != TextToSpeech.SUCCESS) {
                            showMissingTtsToast()
                        }
                    } catch (t: Throwable) {
                        showMissingTtsToast()
                    }
                } else {
                    showMissingTtsToast()
                }
            }
        }
    }

    private suspend fun playCloudVoiceOrCache(text: String, lang: AppLanguage): Boolean {
        val langCode = if (lang == AppLanguage.AR) "ar" else "en"
        val hash = getMd5Hash("$langCode:$text")
        val cachedFile = File(cacheDir, "$hash.mp3")

        // 1. Play from local audio cache if exists
        if (cachedFile.exists() && cachedFile.length() > 0) {
            val success = playAudioFile(cachedFile)
            if (success) return true
        }

        // 2. Stream online or download & cache audio
        if (!networkObserver.isOnline.value) return false

        return withContext(Dispatchers.IO) {
            try {
                val encodedText = URLEncoder.encode(text, "UTF-8")
                val streamUrl = "https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=$langCode&q=$encodedText"

                // Fetch & store in cache file
                val url = URL(streamUrl)
                val connection = url.openConnection() as HttpURLConnection
                connection.connectTimeout = 4000
                connection.readTimeout = 5000
                connection.setRequestProperty("User-Agent", "Mozilla/5.0")

                if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                    val tempFile = File(cacheDir, "${hash}_temp.mp3")
                    connection.inputStream.use { input ->
                        FileOutputStream(tempFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                    if (tempFile.length() > 0) {
                        tempFile.renameTo(cachedFile)
                        return@withContext playAudioFile(cachedFile)
                    }
                }
                false
            } catch (t: Throwable) {
                false
            }
        }
    }

    private suspend fun playAudioFile(file: File): Boolean {
        return withContext(Dispatchers.Main) {
            try {
                stopOnlinePlayer()
                setSpeakingState(true)

                onlineMediaPlayer = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    setDataSource(file.absolutePath)
                    setOnPreparedListener { mp ->
                        try {
                            mp.start()
                        } catch (t: Throwable) {
                            setSpeakingState(false)
                        }
                    }
                    setOnCompletionListener { mp ->
                        setSpeakingState(false)
                        try { mp.release() } catch (t: Throwable) {}
                        if (onlineMediaPlayer == mp) onlineMediaPlayer = null
                    }
                    setOnErrorListener { mp, _, _ ->
                        setSpeakingState(false)
                        try { mp.release() } catch (t: Throwable) {}
                        if (onlineMediaPlayer == mp) onlineMediaPlayer = null
                        false
                    }
                    prepareAsync()
                }
                true
            } catch (t: Throwable) {
                setSpeakingState(false)
                false
            }
        }
    }

    private fun stopOnlinePlayer() {
        try {
            onlineMediaPlayer?.stop()
            onlineMediaPlayer?.release()
        } catch (t: Throwable) {
            // Ignore
        } finally {
            onlineMediaPlayer = null
            setSpeakingState(false)
        }
    }

    fun askAiVoiceInquiry(
        userQuery: String,
        gameStateContext: String,
        lang: AppLanguage = AppLanguage.AR,
        onResponse: (String) -> Unit
    ) {
        if (userQuery.isBlank()) return

        scope.launch {
            val isAr = lang == AppLanguage.AR
            var responseText: String

            try {
                if (networkObserver.isOnline.value) {
                    val aiResponse = geminiService.generateVoiceResponse(userQuery, gameStateContext)
                    responseText = if (!aiResponse.isNullOrBlank()) {
                        aiResponse
                    } else {
                        getOfflineFallbackAnswer(userQuery, gameStateContext, isAr)
                    }
                } else {
                    responseText = getOfflineFallbackAnswer(userQuery, gameStateContext, isAr)
                }
            } catch (t: Throwable) {
                responseText = getOfflineFallbackAnswer(userQuery, gameStateContext, isAr)
            }

            onResponse(responseText)
            speak(responseText, lang)
        }
    }

    private fun getOfflineFallbackAnswer(
        query: String,
        context: String,
        isAr: Boolean
    ): String {
        val q = query.lowercase()
        return when {
            q.contains("دور") || q.contains("الأدوار") || q.contains("role") -> {
                if (isAr) "تضم اللعبة: المافيا للقتل، الطبيب للإنقاذ، المحقق للكشف، والمواطنين للدفاع والتصويت."
                else "Roles include: Mafia to eliminate, Doctor to save, Detective to inspect, and Citizens to vote."
            }
            q.contains("من") || q.contains("قاتل") || q.contains("شبهة") || q.contains("who") -> {
                if (isAr) "حلل تصرفات وإجابات اللاعبين في مرحلة النقاش، وراقب من يتهرب من الأسئلة!"
                else "Analyze player responses during discussion and watch who avoids direct questions!"
            }
            q.contains("قوانين") || q.contains("كيف") || q.contains("rules") || q.contains("play") -> {
                if (isAr) "تبدأ اللعبة بالليل لتنفيذ الأدوار السرية، ثم النهار للنقاش والتصويت لإقصاء المشتبه به."
                else "Game starts at night for secret roles, followed by daytime discussion and voting."
            }
            else -> {
                if (isAr) "أنا مساعدك الصوتي التكتيكي في مافيا! استخدم قدراتك التحليلية وتابع مجريات اللعبة بذكاء."
                else "I am your voice assistant for MAFIAZ! Stay vigilant and analyze the game events."
            }
        }
    }

    fun startListening(
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        try {
            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                onError("التعرف على الصوت غير متاح على هذا الجهاز")
                return
            }

            stop()
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _isListening.value = true
                    }

                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {
                        _isListening.value = false
                    }

                    override fun onError(error: Int) {
                        _isListening.value = false
                        onError("خطأ في التقاط الصوت: $error")
                    }

                    override fun onResults(results: Bundle?) {
                        _isListening.value = false
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val spokenText = matches?.firstOrNull() ?: ""
                        if (spokenText.isNotBlank()) {
                            onResult(spokenText)
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "تحدث الآن مع المساعد الصوتي...")
            }

            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            _isListening.value = false
            onError("تعذر تشغيل المايكرفون")
        }
    }

    fun stopListening() {
        try {
            if (_isListening.value) {
                speechRecognizer?.stopListening()
                _isListening.value = false
            }
        } catch (t: Throwable) {
            _isListening.value = false
        }
    }

    fun repeat() {
        val text = _lastSpokenText.value
        if (text.isNotBlank()) {
            speak(text, currentLang)
        }
    }

    fun stop() {
        try {
            if (isTtsInitialized) {
                tts?.stop()
            }
            stopOnlinePlayer()
            stopListening()
            setSpeakingState(false)
        } catch (t: Throwable) {
            setSpeakingState(false)
        }
    }

    fun toggleMute() {
        _isMuted.value = !_isMuted.value
        if (_isMuted.value) {
            stop()
        }
    }

    fun shutdown() {
        try {
            stop()
            networkObserver.unregister()
            if (isTtsInitialized) {
                tts?.shutdown()
                isTtsInitialized = false
            }
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (t: Throwable) {
            // Safe teardown
        }
    }
}
