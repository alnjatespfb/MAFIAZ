package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.GameStage
import com.example.ui.MainViewModel
import com.example.ui.screens.DayDiscussionScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.HowToPlayScreen
import com.example.ui.screens.MorningReportScreen
import com.example.ui.screens.NightPhaseScreen
import com.example.ui.screens.RoleDistributionScreen
import com.example.ui.screens.SetupScreen
import com.example.ui.screens.VictoryScreen
import com.example.ui.screens.VotingResultScreen
import com.example.ui.screens.VotingScreen
import com.example.ui.theme.MafaisTheme
import com.example.util.TtsHelper

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MafaisTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    MafaisGameApp(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun MafaisGameApp(
    modifier: Modifier = Modifier,
    viewModel: MainViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val ttsHelper = remember { TtsHelper(context) }

    DisposableEffect(Unit) {
        onDispose {
            ttsHelper.shutdown()
        }
    }

    LaunchedEffect(Unit) {
        viewModel.speechEvents.collect { text ->
            ttsHelper.speak(text, uiState.language)
        }
    }

    when (uiState.stage) {
        GameStage.HOME -> HomeScreen(
            currentLanguage = uiState.language,
            onLanguageToggle = { viewModel.toggleLanguage() },
            onStartGame = { viewModel.navigateTo(GameStage.SETUP) },
            onHowToPlay = { viewModel.navigateTo(GameStage.HOW_TO_PLAY) }
        )

        GameStage.HOW_TO_PLAY -> HowToPlayScreen(
            currentLanguage = uiState.language,
            onBackToHome = { viewModel.navigateTo(GameStage.HOME) }
        )

        GameStage.SETUP -> SetupScreen(
            currentLanguage = uiState.language,
            playerNames = uiState.playerNames,
            onPlayerCountChange = { viewModel.setPlayerCount(it) },
            onPlayerNameChange = { index, name -> viewModel.updatePlayerName(index, name) },
            onStartRoleDistribution = { viewModel.startRoleDistribution() },
            onBack = { viewModel.navigateTo(GameStage.HOME) }
        )

        GameStage.ROLE_DISTRIBUTION -> RoleDistributionScreen(
            currentLanguage = uiState.language,
            players = uiState.players,
            currentIndex = uiState.currentRoleRevealIndex,
            isCardFlipped = uiState.isCardFlipped,
            onCardFlip = { viewModel.flipCard() },
            onHideAndNext = { viewModel.hideRoleAndNextPlayer() }
        )

        GameStage.DAY_DISCUSSION -> DayDiscussionScreen(
            currentLanguage = uiState.language,
            currentQuestion = uiState.currentAiQuestion,
            timerRemainingSeconds = uiState.timerRemainingSeconds,
            isTimerRunning = uiState.isTimerRunning,
            onRefreshQuestion = { viewModel.generateNewQuestion() },
            onToggleTimer = { viewModel.toggleTimer() },
            onProceedToVoting = { viewModel.startVotingPhase() }
        )

        GameStage.VOTING -> VotingScreen(
            currentLanguage = uiState.language,
            livingPlayers = uiState.players.filter { it.isAlive },
            allPlayers = uiState.players,
            currentVoterIndex = uiState.currentVotingPlayerIndex,
            votesMap = uiState.votesMap,
            onCastVote = { targetId -> viewModel.castVote(targetId) }
        )

        GameStage.VOTING_RESULT -> VotingResultScreen(
            currentLanguage = uiState.language,
            eliminatedPlayer = uiState.votingEliminatedPlayer,
            isTieOrSkip = uiState.isVotingSkippedOrTie,
            onProceedToNight = { viewModel.startNightPhase() }
        )

        GameStage.NIGHT_PASS -> NightPhaseScreen(
            currentLanguage = uiState.language,
            livingPlayers = uiState.players.filter { it.isAlive },
            currentNightPlayerIndex = uiState.currentNightPlayerIndex,
            isPassReady = uiState.isNightPassReady,
            nightActions = uiState.nightActions,
            detectiveFeedback = uiState.detectiveInspectionFeedback,
            onConfirmPlayerReady = { viewModel.confirmNightPlayerReady() },
            onSubmitAction = { targetId -> viewModel.submitNightAction(targetId) },
            onAdvanceDetectiveAfterFeedback = { viewModel.advanceDetectiveAfterFeedback() }
        )

        GameStage.MORNING_REPORT -> MorningReportScreen(
            currentLanguage = uiState.language,
            reportMessage = uiState.morningReportMessage,
            eliminatedPlayer = uiState.morningEliminatedPlayer,
            isDoctorSaved = uiState.morningDoctorSaved,
            onProceed = { viewModel.proceedFromMorningReport() }
        )

        GameStage.VICTORY -> VictoryScreen(
            currentLanguage = uiState.language,
            winningTeam = uiState.winningTeam,
            players = uiState.players,
            stats = uiState.stats,
            onNewGame = { viewModel.resetGame() },
            onRematch = { viewModel.rematchSamePlayers() }
        )
    }
}
