package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.example.model.AppLanguage
import com.example.model.GameStage
import com.example.ui.MainViewModel
import com.example.ui.screens.DayDiscussionScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.HowToPlayScreen
import com.example.ui.screens.MorningReportScreen
import com.example.ui.screens.NightPhaseScreen
import com.example.ui.screens.RoleDistributionScreen
import com.example.ui.screens.SetupScreen
import com.example.ui.screens.VictoryScreen
import com.example.ui.screens.VotingResultScreen
import com.example.ui.screens.VotingScreen
import com.example.ui.theme.MafaisTheme
import com.example.util.TtsHelper
import com.example.ui.components.AnimatedVoiceBar
import com.example.util.HybridVoiceManager
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.collectAsState

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MafaisTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    MafaisGameApp(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun MafaisGameApp(
    modifier: Modifier = Modifier,
    viewModel: MainViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val voiceManager = remember { HybridVoiceManager(context) }

    val isSpeaking by voiceManager.isSpeaking.collectAsState()
    val isListening by voiceManager.isListening.collectAsState()
    val isOnline by voiceManager.isOnline.collectAsState()
    val isMuted by voiceManager.isMuted.collectAsState()
    val lastSpokenText by voiceManager.lastSpokenText.collectAsState()

    DisposableEffect(Unit) {
        onDispose {
            voiceManager.shutdown()
        }
    }

    LaunchedEffect(Unit) {
        viewModel.speechEvents.collect { text ->
            val gameStateCtx = "المرحلة: ${uiState.stage}, الجولة: ${uiState.stats.roundNumber}, الأحياء: ${uiState.players.filter { it.isAlive }.map { it.name }}"
            voiceManager.speak(
                text = text,
                lang = uiState.language,
                enhanceWithAiIfOnline = true,
                gameStateContext = gameStateCtx
            )
        }
    }

    val layoutDirection = if (uiState.language == AppLanguage.AR) LayoutDirection.Rtl else LayoutDirection.Ltr

    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        Column(modifier = modifier.fillMaxSize()) {
        AnimatedVoiceBar(
            isSpeaking = isSpeaking,
            isListening = isListening,
            isOnline = isOnline,
            isMuted = isMuted,
            lastSpokenText = lastSpokenText,
            currentLanguage = uiState.language,
            onRepeat = { voiceManager.repeat() },
            onStop = { voiceManager.stop() },
            onToggleMute = { voiceManager.toggleMute() },
            onAskAiInquiry = { question ->
                val gameStateCtx = "المرحلة: ${uiState.stage}, الجولة: ${uiState.stats.roundNumber}, اللاعبون: ${uiState.players.map { "${it.name} (${if(it.isAlive) "حي" else "ميت"})" }}"
                voiceManager.askAiVoiceInquiry(
                    userQuery = question,
                    gameStateContext = gameStateCtx,
                    lang = uiState.language,
                    onResponse = { response ->
                        // Voice response spoken automatically
                    }
                )
            },
            onStartVoiceListen = {
                voiceManager.startListening(
                    onResult = { spokenText ->
                        val gameStateCtx = "المرحلة: ${uiState.stage}, الجولة: ${uiState.stats.roundNumber}, الأحياء: ${uiState.players.filter { it.isAlive }.map { it.name }}"
                        voiceManager.askAiVoiceInquiry(
                            userQuery = spokenText,
                            gameStateContext = gameStateCtx,
                            lang = uiState.language,
                            onResponse = {}
                        )
                    },
                    onError = { err ->
                        voiceManager.speak(err, uiState.language)
                    }
                )
            }
        )

        Crossfade(
            targetState = uiState.stage,
            animationSpec = tween(durationMillis = 350),
            modifier = Modifier.weight(1f)
        ) { currentStage ->

        when (currentStage) {
            GameStage.HOME -> HomeScreen(
                currentLanguage = uiState.language,
                onLanguageToggle = {
                    voiceManager.stop()
                    viewModel.toggleLanguage()
                },
                onStartGame = { viewModel.navigateTo(GameStage.SETUP) },
                onHowToPlay = { viewModel.navigateTo(GameStage.HOW_TO_PLAY) }
            )

            GameStage.HOW_TO_PLAY -> HowToPlayScreen(
                currentLanguage = uiState.language,
                onBackToHome = { viewModel.navigateTo(GameStage.HOME) }
            )

            GameStage.SETUP -> SetupScreen(
                currentLanguage = uiState.language,
                playerNames = uiState.playerNames,
                onPlayerCountChange = { viewModel.setPlayerCount(it) },
                onPlayerNameChange = { index, name -> viewModel.updatePlayerName(index, name) },
                onStartRoleDistribution = { viewModel.startRoleDistribution() },
                onBack = { viewModel.navigateTo(GameStage.HOME) }
            )

            GameStage.ROLE_DISTRIBUTION -> RoleDistributionScreen(
                currentLanguage = uiState.language,
                players = uiState.players,
                currentIndex = uiState.currentRoleRevealIndex,
                isCardFlipped = uiState.isCardFlipped,
                onCardFlip = { viewModel.flipCard() },
                onHideAndNext = { viewModel.hideRoleAndNextPlayer() }
            )

            GameStage.DAY_DISCUSSION -> DayDiscussionScreen(
                currentLanguage = uiState.language,
                currentQuestion = uiState.currentAiQuestion,
                timerRemainingSeconds = uiState.timerRemainingSeconds,
                isTimerRunning = uiState.isTimerRunning,
                onRefreshQuestion = { viewModel.generateNewQuestion() },
                onToggleTimer = { viewModel.toggleTimer() },
                onProceedToVoting = { viewModel.startVotingPhase() }
            )

            GameStage.VOTING -> VotingScreen(
                currentLanguage = uiState.language,
                livingPlayers = uiState.players.filter { it.isAlive },
                allPlayers = uiState.players,
                currentVoterIndex = uiState.currentVotingPlayerIndex,
                votesMap = uiState.votesMap,
                onCastVote = { targetId -> viewModel.castVote(targetId) }
            )

            GameStage.VOTING_RESULT -> VotingResultScreen(
                currentLanguage = uiState.language,
                eliminatedPlayer = uiState.votingEliminatedPlayer,
                isTieOrSkip = uiState.isVotingSkippedOrTie,
                onProceedToNight = { viewModel.startNightPhase() }
            )

            GameStage.NIGHT_PASS -> NightPhaseScreen(
                currentLanguage = uiState.language,
                livingPlayers = uiState.players.filter { it.isAlive },
                currentNightPlayerIndex = uiState.currentNightPlayerIndex,
                isPassReady = uiState.isNightPassReady,
                nightActions = uiState.nightActions,
                detectiveFeedback = uiState.detectiveInspectionFeedback,
                onConfirmPlayerReady = { viewModel.confirmNightPlayerReady() },
                onSubmitAction = { targetId -> viewModel.submitNightAction(targetId) },
                onAdvanceDetectiveAfterFeedback = { viewModel.advanceDetectiveAfterFeedback() }
            )

            GameStage.MORNING_REPORT -> MorningReportScreen(
                currentLanguage = uiState.language,
                reportMessage = uiState.morningReportMessage,
                eliminatedPlayer = uiState.morningEliminatedPlayer,
                isDoctorSaved = uiState.morningDoctorSaved,
                onProceed = { viewModel.proceedFromMorningReport() }
            )

            GameStage.VICTORY -> VictoryScreen(
                currentLanguage = uiState.language,
                winningTeam = uiState.winningTeam,
                players = uiState.players,
                stats = uiState.stats,
                onNewGame = { viewModel.resetGame() },
                onRematch = { viewModel.rematchSamePlayers() }
            )
        }
    }
}
}
}


