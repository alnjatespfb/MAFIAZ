package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AiHostQuestions
import com.example.model.AppLanguage
import com.example.model.GameStage
import com.example.model.GameStats
import com.example.model.NightActionRecord
import com.example.model.Player
import com.example.model.Role
import com.example.model.Team
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MafaisUiState(
    val stage: GameStage = GameStage.HOME,
    val language: AppLanguage = AppLanguage.AR,
    val playerNames: List<String> = listOf("", "", "", ""),
    val players: List<Player> = emptyList(),
    
    // Role Distribution State
    val currentRoleRevealIndex: Int = 0,
    val isCardFlipped: Boolean = false,
    
    // Day Discussion State
    val discussionTimerSeconds: Int = 90,
    val timerRemainingSeconds: Int = 90,
    val isTimerRunning: Boolean = false,
    val currentAiQuestion: String = "",
    
    // Voting State
    val currentVotingPlayerIndex: Int = 0,
    val votesMap: Map<String, String?> = emptyMap(), // VoterId -> TargetPlayerId (null for skip)
    val votingEliminatedPlayer: Player? = null,
    val isVotingSkippedOrTie: Boolean = false,
    
    // Night Phase State
    val currentNightPlayerIndex: Int = 0,
    val isNightPassReady: Boolean = false,
    val nightActions: NightActionRecord = NightActionRecord(),
    val detectiveInspectionFeedback: String? = null,
    
    // Morning Report State
    val morningReportMessage: String = "",
    val morningEliminatedPlayer: Player? = null,
    val morningDoctorSaved: Boolean = false,
    
    // Victory & Stats
    val winningTeam: Team? = null,
    val stats: GameStats = GameStats()
)

class MainViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(MafaisUiState())
    val uiState: StateFlow<MafaisUiState> = _uiState.asStateFlow()

    private val _speechEvents = MutableSharedFlow<String>(extraBufferCapacity = 10)
    val speechEvents: SharedFlow<String> = _speechEvents.asSharedFlow()

    fun speak(text: String) {
        if (text.isNotBlank()) {
            _speechEvents.tryEmit(text)
        }
    }

    private var timerJob: Job? = null

    // --- Language Control ---
    fun toggleLanguage() {
        val nextLang = if (_uiState.value.language == AppLanguage.AR) AppLanguage.EN else AppLanguage.AR
        _uiState.update { it.copy(language = nextLang) }
        generateNewQuestion()
    }

    fun setLanguage(language: AppLanguage) {
        _uiState.update { it.copy(language = language) }
        generateNewQuestion()
    }

    // --- Navigation Controls ---
    fun navigateTo(stage: GameStage) {
        _uiState.update { it.copy(stage = stage) }
    }

    // --- Setup Controls ---
    fun setPlayerCount(count: Int) {
        val targetCount = count.coerceIn(4, 16)
        val currentNames = _uiState.value.playerNames.toMutableList()
        if (targetCount > currentNames.size) {
            for (i in currentNames.size until targetCount) {
                currentNames.add("")
            }
        } else if (targetCount < currentNames.size) {
            while (currentNames.size > targetCount) {
                currentNames.removeAt(currentNames.size - 1)
            }
        }
        _uiState.update { it.copy(playerNames = currentNames) }
    }

    fun updatePlayerName(index: Int, name: String) {
        val updatedNames = _uiState.value.playerNames.toMutableList()
        if (index in updatedNames.indices) {
            updatedNames[index] = name
            _uiState.update { it.copy(playerNames = updatedNames) }
        }
    }

    // --- Role Distribution ---
    fun startRoleDistribution() {
        val isAr = _uiState.value.language == AppLanguage.AR
        val names = _uiState.value.playerNames.mapIndexed { index, name ->
            name.ifBlank { if (isAr) "لاعب ${index + 1}" else "Player ${index + 1}" }.trim()
        }
        val count = names.size

        // Build role list based on player count according to dynamic rules
        val roles = mutableListOf<Role>()
        when {
            count in 4..5 -> {
                roles.add(Role.MAFIA)
                roles.add(Role.DOCTOR)
                roles.add(Role.DETECTIVE)
                for (i in 0 until (count - 3)) {
                    roles.add(Role.CITIZEN)
                }
            }
            count in 6..8 -> {
                roles.add(Role.MAFIA)
                roles.add(Role.MAFIA)
                roles.add(Role.DOCTOR)
                roles.add(Role.DETECTIVE)
                for (i in 0 until (count - 4)) {
                    roles.add(Role.CITIZEN)
                }
            }
            count in 9..12 -> {
                roles.add(Role.MAFIA)
                roles.add(Role.MAFIA)
                roles.add(Role.MAFIA)
                roles.add(Role.DOCTOR)
                roles.add(Role.DETECTIVE)
                for (i in 0 until (count - 5)) {
                    roles.add(Role.CITIZEN)
                }
            }
            else -> { // 13..16
                roles.add(Role.MAFIA)
                roles.add(Role.MAFIA)
                roles.add(Role.MAFIA)
                roles.add(Role.MAFIA)
                roles.add(Role.DOCTOR)
                roles.add(Role.DETECTIVE)
                for (i in 0 until (count - 6)) {
                    roles.add(Role.CITIZEN)
                }
            }
        }

        // Shuffle roles randomly with fresh random seed every time
        roles.shuffle(java.util.Random(System.currentTimeMillis() + System.nanoTime()))

        val firstMafiaIndex = roles.indexOf(Role.MAFIA)

        val playersList = names.mapIndexed { index, name ->
            Player(
                id = "p_${System.currentTimeMillis()}_$index",
                name = name,
                role = roles[index],
                isMafiaBoss = (index == firstMafiaIndex)
            )
        }

        _uiState.update {
            it.copy(
                players = playersList,
                currentRoleRevealIndex = 0,
                isCardFlipped = false,
                winningTeam = null,
                stats = GameStats(roundNumber = 1),
                stage = GameStage.ROLE_DISTRIBUTION
            )
        }
    }

    fun flipCard() {
        _uiState.update { it.copy(isCardFlipped = !it.isCardFlipped) }
    }

    fun hideRoleAndNextPlayer() {
        val currentIndex = _uiState.value.currentRoleRevealIndex
        val total = _uiState.value.players.size

        if (currentIndex < total - 1) {
            _uiState.update {
                it.copy(
                    currentRoleRevealIndex = currentIndex + 1,
                    isCardFlipped = false
                )
            }
        } else {
            // All players revealed secret role -> Start Day Discussion!
            startDayDiscussion()
        }
    }

    // --- Day Phase Discussion ---
    fun startDayDiscussion() {
        timerJob?.cancel()
        val livingPlayers = _uiState.value.players.filter { it.isAlive }
        val p1 = livingPlayers.randomOrNull()?.name
        val p2 = livingPlayers.filter { it.name != p1 }.randomOrNull()?.name

        val question = AiHostQuestions.getRandomQuestion(p1, p2, _uiState.value.language)
        val defaultTime = _uiState.value.discussionTimerSeconds

        _uiState.update {
            it.copy(
                currentAiQuestion = question,
                timerRemainingSeconds = defaultTime,
                isTimerRunning = true,
                stage = GameStage.DAY_DISCUSSION
            )
        }

        val isAr = _uiState.value.language == AppLanguage.AR
        speak(if (isAr) "سؤال التحقيق: $question" else "Investigation question: $question")

        runTimer()
    }

    fun generateNewQuestion() {
        val livingPlayers = _uiState.value.players.filter { it.isAlive }
        val p1 = livingPlayers.randomOrNull()?.name
        val p2 = livingPlayers.filter { it.name != p1 }.randomOrNull()?.name
        val question = AiHostQuestions.getRandomQuestion(p1, p2, _uiState.value.language)
        _uiState.update { it.copy(currentAiQuestion = question) }

        val isAr = _uiState.value.language == AppLanguage.AR
        speak(if (isAr) "سؤال التحقيق الجديد: $question" else "New investigation question: $question")
    }

    fun toggleTimer() {
        val running = _uiState.value.isTimerRunning
        if (running) {
            timerJob?.cancel()
            _uiState.update { it.copy(isTimerRunning = false) }
        } else {
            _uiState.update { it.copy(isTimerRunning = true) }
            runTimer()
        }
    }

    private fun runTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (_uiState.value.timerRemainingSeconds > 0 && _uiState.value.isTimerRunning) {
                delay(1000)
                _uiState.update {
                    val nextSec = it.timerRemainingSeconds - 1
                    it.copy(
                        timerRemainingSeconds = nextSec,
                        isTimerRunning = nextSec > 0
                    )
                }
            }
        }
    }

    // --- Voting Phase ---
    fun startVotingPhase() {
        timerJob?.cancel()
        _uiState.update {
            it.copy(
                currentVotingPlayerIndex = 0,
                votesMap = emptyMap(),
                stage = GameStage.VOTING
            )
        }
    }

    fun castVote(targetPlayerId: String?) {
        val state = _uiState.value
        val livingVoters = state.players.filter { it.isAlive }
        val currentVoter = livingVoters.getOrNull(state.currentVotingPlayerIndex) ?: return

        val updatedMap = state.votesMap.toMutableMap()
        updatedMap[currentVoter.id] = targetPlayerId

        val isAr = state.language == AppLanguage.AR
        if (targetPlayerId != null) {
            val targetPlayer = state.players.find { it.id == targetPlayerId }
            val targetName = targetPlayer?.name ?: ""
            speak(if (isAr) "${currentVoter.name} صوّت ضد $targetName!" else "${currentVoter.name} voted against $targetName!")
        } else {
            speak(if (isAr) "${currentVoter.name} اختار التخطي ولم يصوت لأحد." else "${currentVoter.name} chose to skip!")
        }

        val nextIndex = state.currentVotingPlayerIndex + 1
        if (nextIndex < livingVoters.size) {
            _uiState.update {
                it.copy(
                    votesMap = updatedMap,
                    currentVotingPlayerIndex = nextIndex
                )
            }
        } else {
            // Tally votes
            _uiState.update { it.copy(votesMap = updatedMap) }
            processVotingResults(updatedMap)
        }
    }

    private fun processVotingResults(votes: Map<String, String?>) {
        val tally = mutableMapOf<String, Int>()
        votes.values.forEach { targetId ->
            if (targetId != null) {
                tally[targetId] = (tally[targetId] ?: 0) + 1
            }
        }

        val isAr = _uiState.value.language == AppLanguage.AR

        if (tally.isEmpty()) {
            // Everyone skipped
            speak(if (isAr) "نتيجة التصويت: الجميع اختار التخطي، ولم يتم إبعاد أحد هذه الجولة." else "Voting result: Everyone skipped, no one was eliminated.")
            _uiState.update {
                it.copy(
                    votingEliminatedPlayer = null,
                    isVotingSkippedOrTie = true,
                    stage = GameStage.VOTING_RESULT
                )
            }
            return
        }

        val maxVotes = tally.values.maxOrNull() ?: 0
        val topTargets = tally.filter { it.value == maxVotes }.keys

        if (topTargets.size > 1 || maxVotes == 0) {
            // Tie or no majority
            speak(if (isAr) "نتيجة التصويت: تعادل في الأصوات، ولم يتم إبعاد أحد هذه الجولة." else "Voting result: Tie in votes, no one was eliminated this round.")
            _uiState.update {
                it.copy(
                    votingEliminatedPlayer = null,
                    isVotingSkippedOrTie = true,
                    stage = GameStage.VOTING_RESULT
                )
            }
        } else {
            val eliminatedId = topTargets.first()
            val eliminatedPlayer = _uiState.value.players.find { it.id == eliminatedId }

            if (eliminatedPlayer != null) {
                speak(if (isAr) "نتيجة التصويت: بأغلبية الأصوات، تم إقصاء ${eliminatedPlayer.name}!" else "Voting result: By majority vote, ${eliminatedPlayer.name} is eliminated!")

                val updatedPlayers = _uiState.value.players.map {
                    if (it.id == eliminatedId) it.copy(isAlive = false) else it
                }

                val currentStats = _uiState.value.stats
                val newHistory = currentStats.historyLog.toMutableList()
                newHistory.add("الجولة ${currentStats.roundNumber}: تم إقصاء ${eliminatedPlayer.name} بالتصويت (كان ${eliminatedPlayer.role.titleAr})")

                _uiState.update {
                    it.copy(
                        players = updatedPlayers,
                        votingEliminatedPlayer = eliminatedPlayer,
                        isVotingSkippedOrTie = false,
                        stats = currentStats.copy(
                            totalEliminated = currentStats.totalEliminated + 1,
                            historyLog = newHistory
                        ),
                        stage = GameStage.VOTING_RESULT
                    )
                }

                checkVictory()
            }
        }
    }

    // --- Night Phase ---
    fun startNightPhase() {
        if (checkVictory()) return

        _uiState.update {
            it.copy(
                currentNightPlayerIndex = 0,
                isNightPassReady = false,
                nightActions = NightActionRecord(),
                detectiveInspectionFeedback = null,
                stage = GameStage.NIGHT_PASS
            )
        }
    }

    fun confirmNightPlayerReady() {
        _uiState.update { it.copy(isNightPassReady = true) }
    }

    fun submitNightAction(targetPlayerId: String?) {
        val state = _uiState.value
        val livingPlayers = state.players.filter { it.isAlive }
        val currentPlayer = livingPlayers.getOrNull(state.currentNightPlayerIndex) ?: return

        var updatedActions = state.nightActions
        var feedback: String? = null

        when (currentPlayer.role) {
            Role.MAFIA -> {
                if (targetPlayerId != null) {
                    val livingMafiaCount = livingPlayers.count { it.role == Role.MAFIA }
                    if (currentPlayer.isMafiaBoss || livingMafiaCount <= 1) {
                        // Boss or single Mafia sets final assassination target
                        updatedActions = updatedActions.copy(mafiaTargetId = targetPlayerId)
                    } else {
                        // Assistant Mafia sets target proposal
                        updatedActions = updatedActions.copy(mafiaSuggestedTargetId = targetPlayerId)
                    }
                }
            }
            Role.DOCTOR -> {
                if (targetPlayerId != null) {
                    updatedActions = updatedActions.copy(doctorProtectedId = targetPlayerId)
                }
            }
            Role.DETECTIVE -> {
                if (targetPlayerId != null) {
                    val inspected = state.players.find { it.id == targetPlayerId }
                    val isMafia = inspected?.role == Role.MAFIA
                    updatedActions = updatedActions.copy(
                        detectiveCheckedId = targetPlayerId,
                        detectiveResultIsMafia = isMafia
                    )
                    val isAr = state.language == AppLanguage.AR
                    feedback = if (isMafia) {
                        if (isAr) "نتيجة التحري: ${inspected?.name} ينتمي للمافيا! 👿" else "Investigation result: ${inspected?.name} is MAFIA! 👿"
                    } else {
                        if (isAr) "نتيجة التحري: ${inspected?.name} مواطن بريء! 😇" else "Investigation result: ${inspected?.name} is an INNOCENT Citizen! 😇"
                    }
                }
            }
            Role.CITIZEN -> {
                // Citizen fake action recorded silently to prevent cheating
            }
        }

        val nextNightIndex = state.currentNightPlayerIndex + 1

        if (feedback != null && currentPlayer.role == Role.DETECTIVE && state.detectiveInspectionFeedback == null) {
            // Show Detective feedback first on card before advancing
            _uiState.update {
                it.copy(
                    nightActions = updatedActions,
                    detectiveInspectionFeedback = feedback
                )
            }
        } else {
            advanceNightPlayer(nextNightIndex, updatedActions, livingPlayers.size)
        }
    }

    fun advanceDetectiveAfterFeedback() {
        val state = _uiState.value
        val livingPlayers = state.players.filter { it.isAlive }
        val nextIndex = state.currentNightPlayerIndex + 1
        advanceNightPlayer(nextIndex, state.nightActions, livingPlayers.size)
    }

    private fun advanceNightPlayer(nextIndex: Int, actions: NightActionRecord, totalLiving: Int) {
        if (nextIndex < totalLiving) {
            _uiState.update {
                it.copy(
                    nightActions = actions,
                    currentNightPlayerIndex = nextIndex,
                    isNightPassReady = false,
                    detectiveInspectionFeedback = null
                )
            }
        } else {
            // All living players completed night phase -> Process Night Results!
            processNightResults(actions)
        }
    }

    private fun processNightResults(actions: NightActionRecord) {
        val state = _uiState.value
        val mafiaTargetId = actions.mafiaTargetId
        val doctorProtectedId = actions.doctorProtectedId

        var eliminatedPlayer: Player? = null
        var isSavedByDoctor = false

        if (mafiaTargetId != null) {
            if (mafiaTargetId == doctorProtectedId) {
                // Doctor saved the victim!
                isSavedByDoctor = true
            } else {
                // Victim assassinated
                eliminatedPlayer = state.players.find { it.id == mafiaTargetId }
            }
        }

        val updatedPlayers = state.players.map {
            if (eliminatedPlayer != null && it.id == eliminatedPlayer.id) {
                it.copy(isAlive = false)
            } else it
        }

        val currentStats = state.stats
        val newHistory = currentStats.historyLog.toMutableList()
        var reportMsg = ""

        val isAr = state.language == AppLanguage.AR
        if (isSavedByDoctor) {
            reportMsg = if (isAr) {
                "معجزة! حاول القاتل ارتكاب جريمة خلال الليل، لكن الطبيب أنقذ الضحية بنجاح ولم يمت أحد!"
            } else {
                "A miracle! The killer attempted an attack during the night, but the Doctor saved the victim and everyone survived!"
            }
            newHistory.add(if (isAr) "الجولة ${currentStats.roundNumber}: نجح الطبيب في إنقاذ الضحية من اغتيال المافيا!" else "Round ${currentStats.roundNumber}: Doctor saved the victim from Mafia assassination!")
        } else if (eliminatedPlayer != null) {
            reportMsg = if (isAr) {
                "للأسف، استيقظ الجميع على خبر فاجعة... تم اغتيال [${eliminatedPlayer.name}] خلال الليل!"
            } else {
                "Tragedy struck! Everyone woke up to find [${eliminatedPlayer.name}] assassinated during the night!"
            }
            val roleName = eliminatedPlayer.role.title(state.language)
            newHistory.add(if (isAr) "الجولة ${currentStats.roundNumber}: تم اغتيال ${eliminatedPlayer.name} ليلاً (كان $roleName)" else "Round ${currentStats.roundNumber}: ${eliminatedPlayer.name} was assassinated at night (was $roleName)")
        } else {
            reportMsg = if (isAr) {
                "مرت الليلة بهدوء حذر، ولم يُصب أحد بأذى!"
            } else {
                "The night passed in quiet peace, and no one was harmed!"
            }
            newHistory.add(if (isAr) "الجولة ${currentStats.roundNumber}: مرت الليلة بسلام دون ضحايا." else "Round ${currentStats.roundNumber}: The night passed peacefully without casualties.")
        }

        val updatedDoctorSaves = if (isSavedByDoctor) currentStats.successfulDoctorSaves + 1 else currentStats.successfulDoctorSaves
        val updatedDetectiveChecks = if (actions.detectiveCheckedId != null) currentStats.detectiveChecksCount + 1 else currentStats.detectiveChecksCount
        val updatedTotalElim = if (eliminatedPlayer != null) currentStats.totalEliminated + 1 else currentStats.totalEliminated

        speak(reportMsg)

        _uiState.update {
            it.copy(
                players = updatedPlayers,
                morningReportMessage = reportMsg,
                morningEliminatedPlayer = eliminatedPlayer,
                morningDoctorSaved = isSavedByDoctor,
                stats = currentStats.copy(
                    successfulDoctorSaves = updatedDoctorSaves,
                    detectiveChecksCount = updatedDetectiveChecks,
                    totalEliminated = updatedTotalElim,
                    historyLog = newHistory
                ),
                stage = GameStage.MORNING_REPORT
            )
        }

        checkVictory()
    }

    fun proceedFromMorningReport() {
        if (checkVictory()) return

        // Increment round number and start new day discussion
        val nextRound = _uiState.value.stats.roundNumber + 1
        _uiState.update {
            it.copy(stats = it.stats.copy(roundNumber = nextRound))
        }
        startDayDiscussion()
    }

    private fun checkVictory(): Boolean {
        val living = _uiState.value.players.filter { it.isAlive }
        val livingMafiaCount = living.count { it.role.team == Team.MAFIA }
        val livingCitizensCount = living.count { it.role.team == Team.CITIZENS }

        val winner = when {
            livingMafiaCount == 0 -> Team.CITIZENS
            livingMafiaCount >= livingCitizensCount -> Team.MAFIA
            else -> null
        }

        if (winner != null) {
            val isAr = _uiState.value.language == AppLanguage.AR
            val winnerMsg = if (winner == Team.CITIZENS) {
                if (isAr) "تمت تصفية جميع عناصر المافيا! انتصر المواطنون وبقيت البلدة آمنة! 🎉" else "All Mafia members eliminated! Citizens win and the town is safe! 🎉"
            } else {
                if (isAr) "سيطر القتلة على المدينة! فازت المافيا باللعبة! 🗡️" else "The killers took over the city! Mafia won the game! 🗡️"
            }
            speak(winnerMsg)

            val revealedPlayers = _uiState.value.players.map { it.copy(revealedRoleAtEnd = true) }
            _uiState.update {
                it.copy(
                    winningTeam = winner,
                    players = revealedPlayers,
                    stage = GameStage.VICTORY
                )
            }
            return true
        }
        return false
    }

    fun resetGame() {
        timerJob?.cancel()
        _uiState.update {
            MafaisUiState(
                playerNames = it.playerNames,
                stage = GameStage.HOME
            )
        }
    }

    fun rematchSamePlayers() {
        startRoleDistribution()
    }
}
