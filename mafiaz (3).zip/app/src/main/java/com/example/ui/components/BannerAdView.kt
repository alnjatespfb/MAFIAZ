package com.example.ui.components

import android.util.Log
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.GlassBorderGradient
import com.example.util.AdManager
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError

@Composable
fun BannerAdView(
    modifier: Modifier = Modifier,
    isVip: Boolean = false
) {
    if (isVip) return

    var isAdLoaded by remember { mutableStateOf(false) }

    if (isAdLoaded) {
        FrostedGlassCard(
            modifier = modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            shape = RoundedCornerShape(16.dp),
            borderBrush = GlassBorderGradient,
            backgroundColor = Color(0xCC131622)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                AndroidView(
                    factory = { context ->
                        AdView(context).apply {
                            setAdSize(AdSize.BANNER)
                            adUnitId = AdManager.BANNER_UNIT_ID
                            adListener = object : AdListener() {
                                override fun onAdLoaded() {
                                    Log.d("AdMobError", "Banner Ad Loaded Successfully")
                                    isAdLoaded = true
                                }

                                override fun onAdFailedToLoad(error: LoadAdError) {
                                    Log.e("AdMobError", "Banner Ad Failed: ${error.message}")
                                    isAdLoaded = false
                                }
                            }
                            try {
                                loadAd(AdRequest.Builder().build())
                            } catch (t: Throwable) {
                                Log.e("AdMobError", "Exception loading banner ad", t)
                                isAdLoaded = false
                            }
                        }
                    }
                )
            }
        }
    } else {
        // Invisible element to trigger ad load in background
        Box(
            modifier = Modifier.size(0.dp)
        ) {
            AndroidView(
                factory = { context ->
                    AdView(context).apply {
                        setAdSize(AdSize.BANNER)
                        adUnitId = AdManager.BANNER_UNIT_ID
                        adListener = object : AdListener() {
                            override fun onAdLoaded() {
                                Log.d("AdMobError", "Banner Ad Loaded Successfully")
                                isAdLoaded = true
                            }

                            override fun onAdFailedToLoad(error: LoadAdError) {
                                Log.e("AdMobError", "Banner Ad Failed: ${error.message}")
                                isAdLoaded = false
                            }
                        }
                        try {
                            loadAd(AdRequest.Builder().build())
                        } catch (t: Throwable) {
                            Log.e("AdMobError", "Exception loading banner ad", t)
                            isAdLoaded = false
                        }
                    }
                }
            )
        }
    }
}
