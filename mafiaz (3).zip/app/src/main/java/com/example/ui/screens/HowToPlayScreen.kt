package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.Role
import com.example.ui.components.FrostedGlassCard
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.GlassBorderGradient
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.MoodyBackgroundGradient
import com.example.ui.theme.NoirBorder

@Composable
fun HowToPlayScreen(
    currentLanguage: AppLanguage = AppLanguage.AR,
    onBackToHome: () -> Unit
) {
    val isAr = currentLanguage == AppLanguage.AR

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MoodyBackgroundGradient)
    ) {
        // Neon ambient radial glow effect
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF7C3AED).copy(alpha = 0.35f),
                            Color(0xFF06B6D4).copy(alpha = 0.2f),
                            Color.Transparent
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                IconButton(
                    onClick = onBackToHome,
                    modifier = Modifier.testTag("btn_back_home")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = if (isAr) "طريقة اللعب والأدوار 📜" else "How to Play & Roles 📜",
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
            }

            // Scrollable Content
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Game Concept
                FrostedGlassCard(
                    shape = RoundedCornerShape(24.dp),
                    borderBrush = GlassBorderGradient
                ) {
                    Column(modifier = Modifier.padding(6.dp)) {
                        Text(
                            text = if (isAr) "💡 فكرة اللعبة" else "💡 Game Concept",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = CrimsonPrimary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isAr) 
                                "مافياز هي لعبة طاولات اجتماعية حماسية (من 4 إلى 10 لاعبين). يتم تمرير هاتف واحد بين اللاعبين في سرية لتكتشف دورك المخفي، ثم يبدأ النهار بالتحقيق والنقاش بأسئلة ذكية يقدمها الـ AI Host لتحديد القاتل المشتبه به!"
                            else 
                                "MAFIAZ is an exciting social tabletop game (4 to 10 players). Pass a single phone secretly to view your assigned role, then begin the day with AI Host investigation questions to catch the Mafia!",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFECEFF1)
                        )
                    }
                }

                // Roles Breakdown
                Text(
                    text = if (isAr) "🎭 أدوار اللاعبين:" else "🎭 Player Roles:",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = GoldAccent
                )

                RoleCardItem(role = Role.MAFIA, lang = currentLanguage)
                RoleCardItem(role = Role.DOCTOR, lang = currentLanguage)
                RoleCardItem(role = Role.DETECTIVE, lang = currentLanguage)
                RoleCardItem(role = Role.CITIZEN, lang = currentLanguage)

                // Anti-Cheating Section
                FrostedGlassCard(
                    shape = RoundedCornerShape(24.dp),
                    borderBrush = GlassBorderGradient
                ) {
                    Column(modifier = Modifier.padding(6.dp)) {
                        Text(
                            text = if (isAr) "🕵️‍♂️ نظام منع الغش (Anti-Cheating)" else "🕵️‍♂️ Anti-Cheating System",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = GoldAccent
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isAr)
                                "خلال مرحلة الليل، يمر الهاتف على كل الأفراد (حتى المواطن العادي!). للمواطن تظهر أزرار تفاعلية وهمية ليقوم بالنقر عليها حتى لا يعرف أحد الجالسين من صاحب الدور الحقيقي من حركة الأصابع أو الوقت!"
                            else
                                "During the night, the phone passes to everyone—even Citizens! Innocent Citizens receive fake interactive buttons to tap so others sitting nearby cannot guess anyone's real role from finger gestures or time taken!",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFECEFF1)
                        )
                    }
                }

                // Victory Conditions
                FrostedGlassCard(
                    shape = RoundedCornerShape(24.dp),
                    borderBrush = GlassBorderGradient
                ) {
                    Column(modifier = Modifier.padding(6.dp)) {
                        Text(
                            text = if (isAr) "🏆 شروط الفوز" else "🏆 Win Conditions",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isAr)
                                "• فوز المواطنين: كشف وإبعاد جميع أعضاء المافيا بالتصويت.\n• فوز المافيا: عندما يصبح عدد المافيا مساوياً أو أكبر من عدد المواطنين الأحياء."
                            else
                                "• Citizens Victory: Eliminate all Mafia members via voting.\n• Mafia Victory: When Mafia count equals or exceeds remaining living Citizens.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFECEFF1)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // Bottom Button
            Button(
                onClick = onBackToHome,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("btn_understand_rules"),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                shape = RoundedCornerShape(20.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(Color(0xFFDC2626), Color(0xFFEF4444), Color(0xFFF59E0B))
                            ),
                            shape = RoundedCornerShape(20.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isAr) "فهمت القواعد! العودة للرئيسية 🚀" else "Got it! Back to Home 🚀",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        ),
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun RoleCardItem(role: Role, lang: AppLanguage) {
    FrostedGlassCard(
        shape = RoundedCornerShape(20.dp),
        borderBrush = GlassBorderGradient,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(4.dp),
            verticalAlignment = Alignment.Top
        ) {
            Text(
                text = role.badgeIcon,
                fontSize = 32.sp
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(
                    text = role.title(lang),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = role.description(lang),
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFCBD5E1)
                )
            }
        }
    }
}

