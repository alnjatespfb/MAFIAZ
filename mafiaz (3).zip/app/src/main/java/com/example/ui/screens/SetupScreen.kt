package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.CityId
import com.example.model.CityTheme
import com.example.model.CityThemes
import com.example.ui.components.FrostedGlassCard
import com.example.ui.theme.GlassBorderGradient
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.MoodyBackgroundGradient
import com.example.util.SoundFxManager

@Composable
fun SetupScreen(
    currentLanguage: AppLanguage = AppLanguage.AR,
    playerNames: List<String>,
    investigationMinutes: Int = 3,
    selectedCity: CityId = CityId.DARK_CITY,
    isVip: Boolean = false,
    unlockedCities: Set<CityId> = setOf(CityId.DARK_CITY),
    useAiBots: Boolean = false,
    onPlayerCountChange: (Int) -> Unit,
    onPlayerNameChange: (Int, String) -> Unit,
    onInvestigationMinutesChange: (Int) -> Unit = {},
    onCitySelect: (CityId) -> Unit = {},
    onToggleAiBots: () -> Unit = {},
    onOpenStore: () -> Unit = {},
    onStartRoleDistribution: () -> Unit,
    onBack: () -> Unit
) {
    val isAr = currentLanguage == AppLanguage.AR
    val context = LocalContext.current
    val playerCount = playerNames.size
    var showEmptyNameError by remember { mutableStateOf(false) }
    var showVolumeDialog by remember { mutableStateOf(false) }
    var showQuickStoreDialog by remember { mutableStateOf(false) }
    var pendingCityToUnlock by remember { mutableStateOf<CityTheme?>(null) }

    val currentCityTheme = CityThemes.getTheme(selectedCity)

    // Motion State
    var isVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        isVisible = true
    }

    val infiniteTransition = rememberInfiniteTransition(label = "ctaPulse")
    val ctaScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ctaPulseScale"
    )

    // Quick Store Pop-up Dialog
    if (showQuickStoreDialog) {
        AlertDialog(
            onDismissRequest = { showQuickStoreDialog = false },
            icon = {
                Text(text = pendingCityToUnlock?.iconEmoji ?: "👑", fontSize = 36.sp)
            },
            title = {
                Text(
                    text = if (isAr) "فتح المدينة والاشتراك 👑" else "Unlock City & VIP 👑",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = GoldAccent
                )
            },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = pendingCityToUnlock?.let {
                            if (isAr) "مدينة [${it.nameAr}] مقفولة. اختر طريقة الفتح المفضلّة:"
                            else "[${it.nameEn}] is locked. Choose your preferred unlock option:"
                        } ?: if (isAr) "هذه الميزة حصرياً لمشتركي VIP الملكي 👑" else "This feature is exclusive to Royal VIP subscribers 👑",
                        style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 20.sp),
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0x40000000),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (isAr) "👑 اشتراك VIP: يفتح جميع المدن + إزالة الإعلانات + اللعب مع AI\n💵 أو الشراء المباشر لهذه المدينة لمرة واحدة"
                            else "👑 VIP Subscription: Unlocks all cities + No Ads + AI Bots\n💵 Or purchase this map once forever",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp, lineHeight = 16.sp),
                            color = Color(0xFFCBD5E1),
                            modifier = Modifier.padding(10.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showQuickStoreDialog = false
                        onOpenStore()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = Color.Black),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isAr) "الانتقال للمتجر 🛒" else "Go to Store 🛒",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            },
            dismissButton = {
                Button(
                    onClick = { showQuickStoreDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0x33FFFFFF), contentColor = Color.White),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(text = if (isAr) "إلغاء" else "Cancel")
                }
            },
            containerColor = Color(0xF11A0D1E),
            shape = RoundedCornerShape(24.dp)
        )
    }

    if (showVolumeDialog) {
        AlertDialog(
            onDismissRequest = { showVolumeDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.VolumeUp,
                    contentDescription = "Volume Notice",
                    tint = GoldAccent,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = if (isAr) "🔊 تنبيه رفع مستوى الصوت" else "🔊 Volume Level Notice",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    ),
                    color = GoldAccent
                )
            },
            text = {
                Text(
                    text = if (isAr)
                        "يرجى التأكد من رفع مستوى صوت جهازك الآن للاستماع بوضوح إلى الراوي الصوتي والمؤثرات السينمائية أثناء اللعب"
                    else
                        "Please make sure to raise your device volume now to clearly hear the AI narrator and cinematic sound effects during play.",
                    style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 20.sp),
                    color = Color(0xFFE2E8F0),
                    textAlign = TextAlign.Center
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showVolumeDialog = false
                        SoundFxManager.playGameStartCinematic(context)
                        onStartRoleDistribution()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    contentPadding = PaddingValues(0.dp),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("btn_ready_start_game")
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = currentCityTheme.buttonGradient
                                ),
                                shape = RoundedCornerShape(16.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isAr) "جاهز، ابدأ اللعبة الآن 🎮" else "Ready, Start Game Now 🎮",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                    }
                }
            },
            containerColor = Color(0xF1131625),
            shape = RoundedCornerShape(24.dp)
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(colors = currentCityTheme.bgColors)
            )
            .statusBarsPadding()
            .navigationBarsPadding(),
        contentAlignment = Alignment.Center
    ) {
        AnimatedVisibility(
            visible = isVisible,
            enter = fadeIn(animationSpec = tween(500)) + slideInVertically(
                initialOffsetY = { it / 10 },
                animationSpec = tween(500, easing = FastOutSlowInEasing)
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 600.dp)
                    .imePadding()
                    .padding(16.dp)
            ) {
                // Scrollable Top/Content Section
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    // 1. Transparent Header
                    FrostedGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(22.dp),
                        borderBrush = GlassBorderGradient,
                        backgroundColor = currentCityTheme.cardBg
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            IconButton(
                                onClick = onBack,
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(Color(0x33000000))
                                    .testTag("btn_setup_back")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back",
                                    tint = Color.White
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Setup Icon",
                                tint = currentCityTheme.primaryAccent,
                                modifier = Modifier.size(22.dp)
                            )

                            Spacer(modifier = Modifier.width(8.dp))

                            Text(
                                text = if (isAr) "إعداد الجولة واللاعبين" else "Game & Player Setup",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 19.sp
                                ),
                                color = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 1.5 Horizontal City Theme Carousel
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (isAr) "🌆 اختر المدينة والثيم:" else "🌆 Select City Theme:",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 16.sp),
                            color = Color.White
                        )
                        Surface(
                            onClick = onOpenStore,
                            shape = RoundedCornerShape(10.dp),
                            color = GoldAccent.copy(alpha = 0.2f),
                            border = BorderStroke(1.dp, GoldAccent)
                        ) {
                            Text(
                                text = if (isAr) "المتجر 🛒" else "Store 🛒",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = GoldAccent,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp)
                    ) {
                        items(CityThemes.ALL_THEMES) { theme ->
                            val isSelected = theme.id == selectedCity
                            val isUnlocked = theme.isFree || isVip || unlockedCities.contains(theme.id)

                            Surface(
                                onClick = {
                                    if (isUnlocked) {
                                        onCitySelect(theme.id)
                                    } else {
                                        pendingCityToUnlock = theme
                                        showQuickStoreDialog = true
                                    }
                                },
                                shape = RoundedCornerShape(20.dp),
                                color = if (isSelected) theme.cardBg else Color(0x66131622),
                                border = BorderStroke(
                                    if (isSelected) 2.dp else 1.dp,
                                    if (isSelected) theme.primaryAccent else if (isUnlocked) Color(0x40FFFFFF) else GoldAccent
                                ),
                                modifier = Modifier
                                    .width(155.dp)
                                    .testTag("city_item_${theme.id}")
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(text = theme.iconEmoji, fontSize = 30.sp)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = if (isAr) theme.nameAr else theme.nameEn,
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        ),
                                        color = Color.White,
                                        textAlign = TextAlign.Center,
                                        maxLines = 1
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))

                                    when {
                                        isUnlocked -> {
                                            Text(
                                                text = if (isAr) "مفتوحة ✓" else "Unlocked ✓",
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                                color = Color(0xFF10B981)
                                            )
                                        }
                                        theme.isVipExclusive -> {
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = GoldAccent.copy(alpha = 0.2f),
                                                border = BorderStroke(1.dp, GoldAccent)
                                            ) {
                                                Text(
                                                    text = "👑 VIP",
                                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                                    color = GoldAccent,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                        theme.standalonePrice != null -> {
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = theme.primaryAccent.copy(alpha = 0.2f),
                                                border = BorderStroke(1.dp, theme.primaryAccent)
                                            ) {
                                                Text(
                                                    text = theme.standalonePrice,
                                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                                    color = theme.primaryAccent,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // AI Bots Auto-Fill Option Card
                    FrostedGlassCard(
                        shape = RoundedCornerShape(20.dp),
                        borderBrush = GlassBorderGradient,
                        backgroundColor = currentCityTheme.cardBg,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(text = "🤖", fontSize = 24.sp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = if (isAr) "إكمال بالذكاء الاصطناعي" else "AI Bots Auto-Fill",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 15.sp),
                                            color = Color.White
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "👑 VIP",
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = GoldAccent
                                        )
                                    }
                                    Text(
                                        text = if (isAr) "ملء الأسماء الفارغة ببوتات ذكية" else "Auto-fills empty slots with bots",
                                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                                        color = Color(0xFFCBD5E1)
                                    )
                                }
                            }

                            Switch(
                                checked = useAiBots,
                                onCheckedChange = {
                                    if (isVip) {
                                        onToggleAiBots()
                                    } else {
                                        pendingCityToUnlock = null
                                        showQuickStoreDialog = true
                                    }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = GoldAccent,
                                    checkedTrackColor = Color(0xFF7C3AED)
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 2. Player Count Selector
                    FrostedGlassCard(
                        shape = RoundedCornerShape(26.dp),
                        borderBrush = Brush.horizontalGradient(
                            colors = listOf(
                                currentCityTheme.primaryAccent,
                                currentCityTheme.secondaryAccent
                            )
                        ),
                        backgroundColor = currentCityTheme.cardBg,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = if (isAr) "عدد اللاعبين (من 4 إلى 16 لاعباً):" else "Number of Players (4 to 16):",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                                color = Color(0xFFCBD5E1),
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Surface(
                                    onClick = {
                                        if (playerCount > 4) {
                                            showEmptyNameError = false
                                            onPlayerCountChange(playerCount - 1)
                                        }
                                    },
                                    enabled = playerCount > 4,
                                    shape = CircleShape,
                                    color = if (playerCount > 4) Color(0x66991B1B) else Color(0x22424761),
                                    border = BorderStroke(
                                        1.dp,
                                        if (playerCount > 4) Color(0xFFEF4444) else Color(0x33FFFFFF)
                                    ),
                                    modifier = Modifier.testTag("btn_decrease_players")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Remove,
                                        contentDescription = "Decrease",
                                        tint = if (playerCount > 4) Color.White else Color(0x66FFFFFF),
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(24.dp))

                                Text(
                                    text = if (isAr) "$playerCount لاعبين" else "$playerCount Players",
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        fontWeight = FontWeight.Black,
                                        fontSize = 24.sp
                                    ),
                                    color = currentCityTheme.primaryAccent
                                )

                                Spacer(modifier = Modifier.width(24.dp))

                                Surface(
                                    onClick = {
                                        if (playerCount < 16) {
                                            showEmptyNameError = false
                                            onPlayerCountChange(playerCount + 1)
                                        }
                                    },
                                    enabled = playerCount < 16,
                                    shape = CircleShape,
                                    color = Color.Transparent,
                                    modifier = Modifier.testTag("btn_increase_players")
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .background(
                                                if (playerCount < 16)
                                                    Brush.horizontalGradient(currentCityTheme.buttonGradient)
                                                else
                                                    Brush.horizontalGradient(listOf(Color(0x33424761), Color(0x33424761)))
                                            )
                                            .padding(12.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Add,
                                            contentDescription = "Increase",
                                            tint = if (playerCount < 16) Color.White else Color(0x66FFFFFF)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Roles Breakdown summary
                            val mName = if (isAr) currentCityTheme.mafiaTitleAr else currentCityTheme.mafiaTitleEn
                            val dName = if (isAr) currentCityTheme.doctorTitleAr else currentCityTheme.doctorTitleEn
                            val detName = if (isAr) currentCityTheme.detectiveTitleAr else currentCityTheme.detectiveTitleEn
                            val cName = if (isAr) currentCityTheme.citizenTitleAr else currentCityTheme.citizenTitleEn

                            val roleSummary = when (playerCount) {
                                4 -> "😈 $mName (1) • 🩺 $dName (1) • 🔍 $detName (1) • 👔 $cName (1)"
                                5 -> "😈 $mName (1) • 🩺 $dName (1) • 🔍 $detName (1) • 👔 $cName (2)"
                                6 -> "😈 $mName (2) • 🩺 $dName (1) • 🔍 $detName (1) • 👔 $cName (2)"
                                7 -> "😈 $mName (2) • 🩺 $dName (1) • 🔍 $detName (1) • 👔 $cName (3)"
                                8 -> "😈 $mName (2) • 🩺 $dName (1) • 🔍 $detName (1) • 👔 $cName (4)"
                                in 9..12 -> "😈 $mName (3) • 🩺 $dName (1) • 🔍 $detName (1) • 👔 $cName (${playerCount - 5})"
                                else -> "😈 $mName (4) • 🩺 $dName (1) • 🔍 $detName (1) • 👔 $cName (${playerCount - 6})"
                            }

                            Surface(
                                color = Color(0x66000000),
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.dp, Color(0x22FFFFFF)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = if (isAr) "أدوار [${currentCityTheme.nameAr}]:\n$roleSummary" else "[${currentCityTheme.nameEn}] Roles:\n$roleSummary",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 12.sp,
                                        lineHeight = 18.sp
                                    ),
                                    color = Color(0xFF94A3B8),
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 2.5 Investigation Time Selector
                    FrostedGlassCard(
                        shape = RoundedCornerShape(26.dp),
                        borderBrush = GlassBorderGradient,
                        backgroundColor = currentCityTheme.cardBg,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = if (isAr) "⏱️ وقت التحقيق والمناقشة:" else "⏱️ Investigation Time:",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                                color = Color(0xFFCBD5E1),
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Surface(
                                    onClick = {
                                        if (investigationMinutes > 2) {
                                            SoundFxManager.playGlassClick(context)
                                            onInvestigationMinutesChange(investigationMinutes - 1)
                                        }
                                    },
                                    enabled = investigationMinutes > 2,
                                    shape = CircleShape,
                                    color = if (investigationMinutes > 2) Color(0x661E293B) else Color(0x22424761),
                                    border = BorderStroke(
                                        1.dp,
                                        if (investigationMinutes > 2) currentCityTheme.primaryAccent else Color(0x33FFFFFF)
                                    ),
                                    modifier = Modifier.testTag("btn_decrease_investigation_time")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Remove,
                                        contentDescription = "Decrease Time",
                                        tint = if (investigationMinutes > 2) Color.White else Color(0x66FFFFFF),
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(20.dp))

                                Text(
                                    text = if (isAr) "$investigationMinutes دقائق ⏳" else "$investigationMinutes Minutes ⏳",
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        fontWeight = FontWeight.Black,
                                        fontSize = 22.sp
                                    ),
                                    color = currentCityTheme.primaryAccent
                                )

                                Spacer(modifier = Modifier.width(20.dp))

                                Surface(
                                    onClick = {
                                        if (investigationMinutes < 15) {
                                            SoundFxManager.playGlassClick(context)
                                            onInvestigationMinutesChange(investigationMinutes + 1)
                                        }
                                    },
                                    enabled = investigationMinutes < 15,
                                    shape = CircleShape,
                                    color = Color.Transparent,
                                    modifier = Modifier.testTag("btn_increase_investigation_time")
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .background(
                                                if (investigationMinutes < 15)
                                                    Brush.horizontalGradient(currentCityTheme.buttonGradient)
                                                else
                                                    Brush.horizontalGradient(listOf(Color(0x33424761), Color(0x33424761)))
                                            )
                                            .padding(10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Add,
                                            contentDescription = "Increase Time",
                                            tint = if (investigationMinutes < 15) Color.White else Color(0x66FFFFFF)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(bottom = 8.dp)
                    ) {
                        Text(
                            text = if (isAr) "أسماء اللاعبين:" else "Player Names:",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            ),
                            color = Color.White
                        )
                    }

                    if (showEmptyNameError && !useAiBots) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xEE450A0A)),
                            border = BorderStroke(1.dp, Color(0xFFEF4444)),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 10.dp)
                        ) {
                            Text(
                                text = if (isAr)
                                    "⚠️ يرجى تعبئة جميع الأسماء أو تفعيل خيار البوتات 🤖!"
                                else
                                    "⚠️ Enter all names or toggle AI Bots 🤖!",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color(0xFFFCA5A5),
                                modifier = Modifier.padding(12.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    // 3. Player Name Input Fields
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        playerNames.forEachIndexed { index, name ->
                            val isThisNameEmpty = name.isBlank() && showEmptyNameError && !useAiBots
                            OutlinedTextField(
                                value = name,
                                onValueChange = {
                                    showEmptyNameError = false
                                    onPlayerNameChange(index, it)
                                },
                                label = {
                                    Text(
                                        text = if (isAr) "اسم اللاعب ${index + 1}" else "Player ${index + 1} Name",
                                        fontSize = 13.sp
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = "Player Name",
                                        tint = if (isThisNameEmpty) Color(0xFFEF4444) else currentCityTheme.primaryAccent
                                    )
                                },
                                placeholder = {
                                    if (useAiBots && name.isBlank()) {
                                        Text(
                                            text = if (isAr) "سيُملأ بـ AI Bot تلقائياً 🤖" else "Will auto-fill with AI Bot 🤖",
                                            color = GoldAccent.copy(alpha = 0.7f),
                                            fontSize = 12.sp
                                        )
                                    }
                                },
                                isError = isThisNameEmpty,
                                textStyle = androidx.compose.ui.text.TextStyle(
                                    textAlign = if (isAr) TextAlign.Right else TextAlign.Left,
                                    textDirection = androidx.compose.ui.text.style.TextDirection.ContentOrRtl
                                ),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = currentCityTheme.primaryAccent,
                                    unfocusedBorderColor = if (isThisNameEmpty) Color(0xFFEF4444) else Color(0x40FFFFFF),
                                    focusedContainerColor = Color(0xCC181C2E),
                                    unfocusedContainerColor = Color(0x88121524),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedLabelColor = currentCityTheme.primaryAccent,
                                    unfocusedLabelColor = if (isThisNameEmpty) Color(0xFFFCA5A5) else Color(0xFF94A3B8)
                                ),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_player_name_$index")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 4. CTA Action Button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .scale(ctaScale)
                ) {
                    Button(
                        onClick = {
                            if (playerNames.any { it.isBlank() } && !useAiBots) {
                                showEmptyNameError = true
                            } else {
                                showEmptyNameError = false
                                SoundFxManager.playHeartbeat(context)
                                showVolumeDialog = true
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .testTag("btn_confirm_setup"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        contentPadding = PaddingValues(0.dp),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.horizontalGradient(currentCityTheme.buttonGradient),
                                    shape = RoundedCornerShape(20.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Distribute Roles",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isAr) "توزيع الأدوار وبدء اللعبة 🔒" else "Distribute Secret Roles 🔒",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    ),
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
