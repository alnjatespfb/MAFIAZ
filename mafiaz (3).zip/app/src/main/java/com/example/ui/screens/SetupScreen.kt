package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NoirBackground
import com.example.ui.theme.NoirBorder
import com.example.ui.theme.NoirSurface

@Composable
fun SetupScreen(
    currentLanguage: AppLanguage = AppLanguage.AR,
    playerNames: List<String>,
    onPlayerCountChange: (Int) -> Unit,
    onPlayerNameChange: (Int, String) -> Unit,
    onStartRoleDistribution: () -> Unit,
    onBack: () -> Unit
) {
    val isAr = currentLanguage == AppLanguage.AR
    val playerCount = playerNames.size
    var showEmptyNameError by remember { mutableStateOf(false) }
    var showVolumeDialog by remember { mutableStateOf(false) }

    if (showVolumeDialog) {
        AlertDialog(
            onDismissRequest = { showVolumeDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.VolumeUp,
                    contentDescription = "Volume Notice",
                    tint = GoldAccent,
                    modifier = Modifier.padding(8.dp)
                )
            },
            title = {
                Text(
                    text = if (isAr) "🔊 تنبيه رفع مستوى الصوت" else "🔊 Volume Level Notice",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = GoldAccent
                )
            },
            text = {
                Text(
                    text = if (isAr)
                        "يرجى التأكد من رفع مستوى صوت جهازك الآن للاستماع بوضوح إلى الراوي الصوتي والمؤثرات السينمائية أثناء اللعب"
                    else
                        "Please make sure to raise your device volume now to clearly hear the AI narrator and cinematic sound effects during play.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showVolumeDialog = false
                        onStartRoleDistribution()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("btn_ready_start_game")
                ) {
                    Text(
                        text = if (isAr) "جاهز، ابدأ اللعبة الآن 🎮" else "Ready, Start Game Now 🎮",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            },
            containerColor = NoirSurface,
            shape = RoundedCornerShape(24.dp)
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NoirBackground)
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Top Bar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("btn_setup_back")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = if (isAr) "إعداد الجولة واللاعبين ⚙️" else "Game & Player Setup ⚙️",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
            }

            // Player Count Selector
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = NoirSurface),
                border = BorderStroke(1.dp, CrimsonPrimary.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isAr) "عدد اللاعبين (من 4 إلى 16 لاعباً):" else "Number of Players (4 to 16):",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFFB0BEC5)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Surface(
                            onClick = {
                                if (playerCount > 4) {
                                    showEmptyNameError = false
                                    onPlayerCountChange(playerCount - 1)
                                }
                            },
                            enabled = playerCount > 4,
                            shape = CircleShape,
                            color = if (playerCount > 4) CrimsonPrimary else Color(0x33424761),
                            modifier = Modifier.testTag("btn_decrease_players")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Remove,
                                contentDescription = "Decrease",
                                tint = Color.White,
                                modifier = Modifier.padding(12.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(24.dp))

                        Text(
                            text = if (isAr) "$playerCount لاعبين" else "$playerCount Players",
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black),
                            color = GoldAccent
                        )

                        Spacer(modifier = Modifier.width(24.dp))

                        Surface(
                            onClick = {
                                if (playerCount < 16) {
                                    showEmptyNameError = false
                                    onPlayerCountChange(playerCount + 1)
                                }
                            },
                            enabled = playerCount < 16,
                            shape = CircleShape,
                            color = if (playerCount < 16) CrimsonPrimary else Color(0x33424761),
                            modifier = Modifier.testTag("btn_increase_players")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Increase",
                                tint = Color.White,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Roles distribution preview
                    val roleSummary = if (isAr) {
                        when (playerCount) {
                            4 -> "😈 مافيا (1) • 🩺 طبيب (1) • 🔍 محقق (1) • 👔 مواطن (1)"
                            5 -> "😈 مافيا (1) • 🩺 طبيب (1) • 🔍 محقق (1) • 👔 مواطنين (2)"
                            6 -> "😈 مافيا (2) • 🩺 طبيب (1) • 🔍 محقق (1) • 👔 مواطنين (2)"
                            7 -> "😈 مافيا (2) • 🩺 طبيب (1) • 🔍 محقق (1) • 👔 مواطنين (3)"
                            8 -> "😈 مافيا (2) • 🩺 طبيب (1) • 🔍 محقق (1) • 👔 مواطنين (4)"
                            in 9..12 -> "😈 مافيا (3) • 🩺 طبيب (1) • 🔍 محقق (1) • 👔 مواطنين (${playerCount - 5})"
                            else -> "😈 مافيا (4) • 🩺 طبيب (1) • 🔍 محقق (1) • 👔 مواطنين (${playerCount - 6})"
                        }
                    } else {
                        when (playerCount) {
                            4 -> "😈 Mafia (1) • 🩺 Doctor (1) • 🔍 Detective (1) • 👔 Citizen (1)"
                            5 -> "😈 Mafia (1) • 🩺 Doctor (1) • 🔍 Detective (1) • 👔 Citizens (2)"
                            6 -> "😈 Mafia (2) • 🩺 Doctor (1) • 🔍 Detective (1) • 👔 Citizens (2)"
                            7 -> "😈 Mafia (2) • 🩺 Doctor (1) • 🔍 Detective (1) • 👔 Citizens (3)"
                            8 -> "😈 Mafia (2) • 🩺 Doctor (1) • 🔍 Detective (1) • 👔 Citizens (4)"
                            in 9..12 -> "😈 Mafia (3) • 🩺 Doctor (1) • 🔍 Detective (1) • 👔 Citizens (${playerCount - 5})"
                            else -> "😈 Mafia (4) • 🩺 Doctor (1) • 🔍 Detective (1) • 👔 Citizens (${playerCount - 6})"
                        }
                    }

                    Text(
                        text = if (isAr) "التوزيع المتوقع بالأدوار:\n$roleSummary" else "Expected Role Breakdown:\n$roleSummary",
                        style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp),
                        color = Color(0xFF90A4AE),
                        modifier = Modifier.padding(top = 4.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = if (isAr) "أدخل أسماء جميع اللاعبين (إجباري):" else "Enter Player Names (Mandatory):",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            if (showEmptyNameError) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF3B1218)),
                    border = BorderStroke(1.dp, CrimsonPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                ) {
                    Text(
                        text = if (isAr)
                            "⚠️ يرجى تعبئة جميع أسماء اللاعبين أولاً قبل بدء اللعبة!"
                        else
                            "⚠️ Please enter all player names before starting!",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = CrimsonPrimary,
                        modifier = Modifier.padding(12.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }

            // Player Name Input Fields List
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(playerNames) { index, name ->
                    val isThisNameEmpty = name.isBlank() && showEmptyNameError
                    OutlinedTextField(
                        value = name,
                        onValueChange = {
                            showEmptyNameError = false
                            onPlayerNameChange(index, it)
                        },
                        label = { Text(if (isAr) "اسم اللاعب ${index + 1}" else "Player ${index + 1} Name") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = "Player Name",
                                tint = if (isThisNameEmpty) CrimsonPrimary else Color(0xFF90A4AE)
                            )
                        },
                        isError = isThisNameEmpty,
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CrimsonPrimary,
                            unfocusedBorderColor = if (isThisNameEmpty) CrimsonPrimary else NoirBorder,
                            focusedContainerColor = NoirSurface,
                            unfocusedContainerColor = NoirSurface,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedLabelColor = CrimsonPrimary,
                            unfocusedLabelColor = if (isThisNameEmpty) CrimsonPrimary else Color(0xFF78909C)
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_player_name_$index")
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Start Game Button
            Button(
                onClick = {
                    if (playerNames.any { it.isBlank() }) {
                        showEmptyNameError = true
                    } else {
                        showEmptyNameError = false
                        showVolumeDialog = true
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("btn_confirm_setup"),
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Distribute Roles",
                        modifier = Modifier.padding(end = 8.dp)
                    )
                    Text(
                        text = if (isAr) "بدء توزيع الأدوار السري 🔒" else "Distribute Secret Roles 🔒",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}
