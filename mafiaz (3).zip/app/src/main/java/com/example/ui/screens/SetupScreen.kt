package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.util.SoundFxManager
import com.example.ui.components.FrostedGlassCard
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.GlassBorderGradient
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.MoodyBackgroundGradient
import com.example.ui.theme.NoirBorder
import com.example.ui.theme.NoirSurface

@Composable
fun SetupScreen(
    currentLanguage: AppLanguage = AppLanguage.AR,
    playerNames: List<String>,
    onPlayerCountChange: (Int) -> Unit,
    onPlayerNameChange: (Int, String) -> Unit,
    onStartRoleDistribution: () -> Unit,
    onBack: () -> Unit
) {
    val isAr = currentLanguage == AppLanguage.AR
    val context = androidx.compose.ui.platform.LocalContext.current
    val playerCount = playerNames.size
    var showEmptyNameError by remember { mutableStateOf(false) }
    var showVolumeDialog by remember { mutableStateOf(false) }

    // Screen Entry Motion
    var isVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        isVisible = true
    }

    // Pulse animation for the primary Start Game CTA button
    val infiniteTransition = rememberInfiniteTransition(label = "ctaPulse")
    val ctaScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ctaPulseScale"
    )

    // Glowing animation for background elements
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.55f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "neonGlow"
    )

    if (showVolumeDialog) {
        AlertDialog(
            onDismissRequest = { showVolumeDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.VolumeUp,
                    contentDescription = "Volume Notice",
                    tint = GoldAccent,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = if (isAr) "🔊 تنبيه رفع مستوى الصوت" else "🔊 Volume Level Notice",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    ),
                    color = GoldAccent
                )
            },
            text = {
                Text(
                    text = if (isAr)
                        "يرجى التأكد من رفع مستوى صوت جهازك الآن للاستماع بوضوح إلى الراوي الصوتي والمؤثرات السينمائية أثناء اللعب"
                    else
                        "Please make sure to raise your device volume now to clearly hear the AI narrator and cinematic sound effects during play.",
                    style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 20.sp),
                    color = Color(0xFFE2E8F0),
                    textAlign = TextAlign.Center
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showVolumeDialog = false
                        SoundFxManager.playGameStartCinematic(context)
                        onStartRoleDistribution()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("btn_ready_start_game")
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(Color(0xFFDC2626), Color(0xFF7C3AED))
                                ),
                                shape = RoundedCornerShape(16.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isAr) "جاهز، ابدأ اللعبة الآن 🎮" else "Ready, Start Game Now 🎮",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                    }
                }
            },
            containerColor = Color(0xF1131625),
            shape = RoundedCornerShape(24.dp)
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MoodyBackgroundGradient)
    ) {
        // Neon ambient background glow behind elements
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF7C3AED).copy(alpha = glowAlpha * 0.4f),
                            Color(0xFF06B6D4).copy(alpha = glowAlpha * 0.2f),
                            Color.Transparent
                        )
                    )
                )
        )

        AnimatedVisibility(
            visible = isVisible,
            enter = fadeIn(animationSpec = tween(500)) + slideInVertically(
                initialOffsetY = { it / 10 },
                animationSpec = tween(500, easing = FastOutSlowInEasing)
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // 1. Transparent Header with Acrylic Look
                FrostedGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    borderBrush = GlassBorderGradient,
                    backgroundColor = Color(0xCC131622)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color(0x33000000))
                                .testTag("btn_setup_back")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Setup Icon",
                            tint = GoldAccent,
                            modifier = Modifier.size(22.dp)
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Text(
                            text = if (isAr) "إعداد الجولة واللاعبين" else "Game & Player Setup",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 19.sp
                            ),
                            color = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 2. Player Count Selector in Frosted Glass Container with Subtle Neon Border
                FrostedGlassCard(
                    shape = RoundedCornerShape(26.dp),
                    borderBrush = Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xFFDC2626).copy(alpha = 0.8f),
                            Color(0xFF8B5CF6).copy(alpha = 0.8f),
                            Color(0xFF06B6D4).copy(alpha = 0.8f)
                        )
                    ),
                    backgroundColor = Color(0xCC151828),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (isAr) "عدد اللاعبين (من 4 إلى 16 لاعباً):" else "Number of Players (4 to 16):",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                            color = Color(0xFFCBD5E1)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            // (-) Decrease Button
                            Surface(
                                onClick = {
                                    if (playerCount > 4) {
                                        showEmptyNameError = false
                                        onPlayerCountChange(playerCount - 1)
                                    }
                                },
                                enabled = playerCount > 4,
                                shape = CircleShape,
                                color = if (playerCount > 4) Color(0x66991B1B) else Color(0x22424761),
                                border = BorderStroke(
                                    1.dp,
                                    if (playerCount > 4) Color(0xFFEF4444) else Color(0x33FFFFFF)
                                ),
                                modifier = Modifier.testTag("btn_decrease_players")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Remove,
                                    contentDescription = "Decrease",
                                    tint = if (playerCount > 4) Color.White else Color(0x66FFFFFF),
                                    modifier = Modifier.padding(12.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(24.dp))

                            Text(
                                text = if (isAr) "$playerCount لاعبين" else "$playerCount Players",
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    fontSize = 24.sp
                                ),
                                color = GoldAccent
                            )

                            Spacer(modifier = Modifier.width(24.dp))

                            // (+) Increase Button with Neon Gradient
                            Surface(
                                onClick = {
                                    if (playerCount < 16) {
                                        showEmptyNameError = false
                                        onPlayerCountChange(playerCount + 1)
                                    }
                                },
                                enabled = playerCount < 16,
                                shape = CircleShape,
                                color = Color.Transparent,
                                modifier = Modifier.testTag("btn_increase_players")
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(
                                            if (playerCount < 16)
                                                Brush.horizontalGradient(listOf(Color(0xFFDC2626), Color(0xFF7C3AED)))
                                            else
                                                Brush.horizontalGradient(listOf(Color(0x33424761), Color(0x33424761)))
                                        )
                                        .padding(12.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Increase",
                                        tint = if (playerCount < 16) Color.White else Color(0x66FFFFFF)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Roles distribution preview sub-card
                        val roleSummary = if (isAr) {
                            when (playerCount) {
                                4 -> "😈 مافيا (1) • 🩺 طبيب (1) • 🔍 محقق (1) • 👔 مواطن (1)"
                                5 -> "😈 مافيا (1) • 🩺 طبيب (1) • 🔍 محقق (1) • 👔 مواطنين (2)"
                                6 -> "😈 مافيا (2) • 🩺 طبيب (1) • 🔍 محقق (1) • 👔 مواطنين (2)"
                                7 -> "😈 مافيا (2) • 🩺 طبيب (1) • 🔍 محقق (1) • 👔 مواطنين (3)"
                                8 -> "😈 مافيا (2) • 🩺 طبيب (1) • 🔍 محقق (1) • 👔 مواطنين (4)"
                                in 9..12 -> "😈 مافيا (3) • 🩺 طبيب (1) • 🔍 محقق (1) • 👔 مواطنين (${playerCount - 5})"
                                else -> "😈 مافيا (4) • 🩺 طبيب (1) • 🔍 محقق (1) • 👔 مواطنين (${playerCount - 6})"
                            }
                        } else {
                            when (playerCount) {
                                4 -> "😈 Mafia (1) • 🩺 Doctor (1) • 🔍 Detective (1) • 👔 Citizen (1)"
                                5 -> "😈 Mafia (1) • 🩺 Doctor (1) • 🔍 Detective (1) • 👔 Citizens (2)"
                                6 -> "😈 Mafia (2) • 🩺 Doctor (1) • 🔍 Detective (1) • 👔 Citizens (2)"
                                7 -> "😈 Mafia (2) • 🩺 Doctor (1) • 🔍 Detective (1) • 👔 Citizens (3)"
                                8 -> "😈 Mafia (2) • 🩺 Doctor (1) • 🔍 Detective (1) • 👔 Citizens (4)"
                                in 9..12 -> "😈 Mafia (3) • 🩺 Doctor (1) • 🔍 Detective (1) • 👔 Citizens (${playerCount - 5})"
                                else -> "😈 Mafia (4) • 🩺 Doctor (1) • 🔍 Detective (1) • 👔 Citizens (${playerCount - 6})"
                            }
                        }

                        Surface(
                            color = Color(0x66000000),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, Color(0x22FFFFFF)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (isAr) "توزيع الأدوار المتوقع:\n$roleSummary" else "Expected Role Breakdown:\n$roleSummary",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 12.sp,
                                    lineHeight = 18.sp
                                ),
                                color = Color(0xFF94A3B8),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    Text(
                        text = if (isAr) "أدخل أسماء جميع اللاعبين (إجباري):" else "Enter Player Names (Mandatory):",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        ),
                        color = Color.White
                    )
                }

                if (showEmptyNameError) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xEE450A0A)),
                        border = BorderStroke(1.dp, Color(0xFFEF4444)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                    ) {
                        Text(
                            text = if (isAr)
                                "⚠️ يرجى تعبئة جميع أسماء اللاعبين أولاً قبل بدء اللعبة!"
                            else
                                "⚠️ Please enter all player names before starting!",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color(0xFFFCA5A5),
                            modifier = Modifier.padding(12.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // 3. Player Name Input Fields List (Sleek Glass Bars)
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    itemsIndexed(playerNames) { index, name ->
                        val isThisNameEmpty = name.isBlank() && showEmptyNameError
                        OutlinedTextField(
                            value = name,
                            onValueChange = {
                                showEmptyNameError = false
                                onPlayerNameChange(index, it)
                            },
                            label = {
                                Text(
                                    text = if (isAr) "اسم اللاعب ${index + 1}" else "Player ${index + 1} Name",
                                    fontSize = 13.sp
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = "Player Name",
                                    tint = if (isThisNameEmpty) Color(0xFFEF4444) else Color(0xFF38BDF8)
                                )
                            },
                            isError = isThisNameEmpty,
                            textStyle = androidx.compose.ui.text.TextStyle(
                                textAlign = if (isAr) androidx.compose.ui.text.style.TextAlign.Right else androidx.compose.ui.text.style.TextAlign.Left,
                                textDirection = androidx.compose.ui.text.style.TextDirection.ContentOrRtl
                            ),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF8B5CF6),
                                unfocusedBorderColor = if (isThisNameEmpty) Color(0xFFEF4444) else Color(0x40FFFFFF),
                                focusedContainerColor = Color(0xCC181C2E),
                                unfocusedContainerColor = Color(0x88121524),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedLabelColor = Color(0xFFA78BFA),
                                unfocusedLabelColor = if (isThisNameEmpty) Color(0xFFFCA5A5) else Color(0xFF94A3B8)
                            ),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_player_name_$index")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 4. Glowing Pulsing CTA Action Button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .scale(ctaScale)
                ) {
                    // Soft glow behind button
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        Color(0xFFDC2626).copy(alpha = glowAlpha * 0.5f),
                                        Color(0xFF7C3AED).copy(alpha = glowAlpha * 0.5f)
                                    )
                                )
                            )
                    )

                    Button(
                        onClick = {
                            if (playerNames.any { it.isBlank() }) {
                                showEmptyNameError = true
                            } else {
                                showEmptyNameError = false
                                SoundFxManager.playHeartbeat(context)
                                showVolumeDialog = true
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .testTag("btn_confirm_setup"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            Color(0xFFDC2626), // Crimson
                                            Color(0xFF7C3AED), // Amethyst Purple
                                            Color(0xFFF59E0B)  // Gold Accent
                                        )
                                    ),
                                    shape = RoundedCornerShape(20.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Distribute Roles",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isAr) "توزيع الأدوار وبدء اللعبة 🔒" else "Distribute Secret Roles 🔒",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    ),
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

