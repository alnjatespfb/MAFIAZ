package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val MafaisDarkColorScheme = darkColorScheme(
    primary = CrimsonPrimary,
    onPrimary = TextPrimary,
    primaryContainer = CrimsonContainer,
    onPrimaryContainer = TextPrimary,
    secondary = GoldAccent,
    onSecondary = NoirBackground,
    secondaryContainer = GoldContainer,
    onSecondaryContainer = GoldAccentLight,
    tertiary = DetectiveBlue,
    background = NoirBackground,
    onBackground = TextPrimary,
    surface = NoirSurface,
    onSurface = TextPrimary,
    surfaceVariant = NoirSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = NoirBorder
)

@Composable
fun MafaisTheme(
    darkTheme: Boolean = true, // Default to dramatic dark noir
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = NoirBackground.toArgb()
            window.navigationBarColor = NoirBackground.toArgb()
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = false
                isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = MafaisDarkColorScheme,
        typography = Typography,
        content = content
    )
}
