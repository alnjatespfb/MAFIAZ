package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Player
import com.example.model.Role
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NoirBorder
import com.example.ui.theme.NoirSurface
import com.example.ui.theme.NoirSurfaceVariant

import com.example.model.AppLanguage

@Composable
fun FlippableRoleCard(
    player: Player,
    isFlipped: Boolean,
    onCardClick: () -> Unit,
    lang: AppLanguage = AppLanguage.AR,
    modifier: Modifier = Modifier
) {
    var isDealt by androidx.compose.runtime.remember(player.id) { androidx.compose.runtime.mutableStateOf(false) }

    androidx.compose.runtime.LaunchedEffect(player.id) {
        isDealt = true
    }

    val dealOffsetY by animateFloatAsState(
        targetValue = if (isDealt) 0f else -50f,
        animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing),
        label = "CardDealOffsetY"
    )

    val dealScale by animateFloatAsState(
        targetValue = if (isDealt) 1f else 0.94f,
        animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing),
        label = "CardDealScale"
    )

    val rotation by animateFloatAsState(
        targetValue = if (isFlipped) 180f else 0f,
        animationSpec = tween(durationMillis = 500, easing = FastOutSlowInEasing),
        label = "CardFlipAnimation"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(340.dp)
            .graphicsLayer {
                rotationY = rotation
                cameraDistance = 14f * density
                translationY = dealOffsetY
                scaleX = dealScale
                scaleY = dealScale
            }
            .clickable { onCardClick() }
            .testTag("role_card_${player.id}"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = NoirSurface),
        border = BorderStroke(
            width = 2.dp,
            brush = if (isFlipped) {
                Brush.linearGradient(listOf(CrimsonPrimary, GoldAccent))
            } else {
                Brush.linearGradient(listOf(NoirBorder, Color(0xFF424761)))
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
    ) {
        val isShowBack = isFlipped && rotation > 90f
        if (isShowBack) {
            // Opened Secret Role Back
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { rotationY = 180f } // Mirror horizontally back to normal text
            ) {
                CardBackRoleDetail(player = player, lang = lang)
            }
        } else {
            // Closed Card Front
            CardFrontCover(playerName = player.name, lang = lang)
        }
    }
}

@Composable
private fun CardFrontCover(playerName: String, lang: AppLanguage) {
    val isAr = lang == AppLanguage.AR
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        NoirSurfaceVariant,
                        Color(0xFF13151F),
                        NoirSurface
                    )
                )
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                shape = RoundedCornerShape(50),
                color = Color(0x33E53935),
                border = BorderStroke(1.dp, CrimsonPrimary),
                modifier = Modifier.size(80.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Secret Card",
                        tint = CrimsonPrimary,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = if (isAr) "بطاقة الدور السرية" else "Secret Role Card",
                style = MaterialTheme.typography.labelMedium,
                color = Color(0xFFB0BEC5)
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = playerName,
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 26.sp
                ),
                color = Color.White
            )

            Spacer(modifier = Modifier.height(16.dp))

            Surface(
                color = Color(0x22FFFFFF),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.padding(horizontal = 12.dp)
            ) {
                Text(
                    text = if (isAr) "👇 اضغط على البطاقة لقلبها واكتشاف دورك" else "👇 Tap card to flip and reveal role",
                    style = MaterialTheme.typography.bodySmall,
                    color = GoldAccent,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun CardBackRoleDetail(player: Player, lang: AppLanguage) {
    val role = player.role
    val isAr = lang == AppLanguage.AR

    val roleBgColor = when (role) {
        Role.MAFIA -> Color(0xFF2A0A0D)
        Role.DOCTOR -> Color(0xFF092321)
        Role.DETECTIVE -> Color(0xFF082230)
        Role.CITIZEN -> Color(0xFF1B2313)
    }

    val roleAccentColor = when (role) {
        Role.MAFIA -> CrimsonPrimary
        Role.DOCTOR -> Color(0xFF26A69A)
        Role.DETECTIVE -> Color(0xFF29B6F6)
        Role.CITIZEN -> Color(0xFF7CB342)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        roleBgColor,
                        NoirSurface
                    )
                )
            )
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxSize()
        ) {
            Text(
                text = if (isAr) "الدور الخاص بـ: ${player.name}" else "Role assigned to: ${player.name}",
                style = MaterialTheme.typography.titleMedium,
                color = Color(0xFFB0BEC5)
            )

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = role.badgeIcon,
                    fontSize = 58.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = role.title(lang),
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 28.sp
                    ),
                    color = roleAccentColor
                )

                Spacer(modifier = Modifier.height(8.dp))

                Surface(
                    color = roleAccentColor.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, roleAccentColor.copy(alpha = 0.4f))
                ) {
                    Text(
                        text = role.secretGuidance(lang),
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                    )
                }
            }

            Text(
                text = if (isAr) "⚠️ لا تدع أحداً يرى شاشتك!" else "⚠️ Do not let anyone see your screen!",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFFF8A80)
            )
        }
    }
}
