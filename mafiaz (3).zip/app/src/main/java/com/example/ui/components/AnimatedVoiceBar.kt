package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.DoctorEmerald
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NoirBorder
import com.example.ui.theme.NoirSurface

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnimatedVoiceBar(
    isSpeaking: Boolean,
    isListening: Boolean,
    isOnline: Boolean,
    isMuted: Boolean,
    lastSpokenText: String,
    currentLanguage: AppLanguage,
    onRepeat: () -> Unit,
    onStop: () -> Unit,
    onToggleMute: () -> Unit,
    onAskAiInquiry: (String) -> Unit,
    onStartVoiceListen: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isAr = currentLanguage == AppLanguage.AR
    var showInquirySheet by remember { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "VoiceWave")

    // Animated Heights for Voice Waveform Bars
    val bar1Scale by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "b1"
    )

    val bar2Scale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(350, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "b2"
    )

    val bar3Scale by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "b3"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("animated_voice_bar"),
        colors = CardDefaults.cardColors(
            containerColor = NoirSurface.copy(alpha = 0.92f)
        ),
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSpeaking) CrimsonPrimary.copy(alpha = 0.8f) else NoirBorder
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            // Top Row: Network Status Indicator + Waveform / Action Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Network Mode Badge (Online AI vs Offline)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(
                            color = if (isOnline) DoctorEmerald.copy(alpha = 0.15f) else GoldAccent.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .border(
                            width = 0.8.dp,
                            color = if (isOnline) DoctorEmerald.copy(alpha = 0.4f) else GoldAccent.copy(alpha = 0.4f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(
                                color = if (isOnline) DoctorEmerald else GoldAccent,
                                shape = CircleShape
                            )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isOnline) {
                            if (isAr) "صوت الذكاء الاصطناعي (أونلاين) 🌐" else "AI Voice (Online) 🌐"
                        } else {
                            if (isAr) "صوت محلي (أوفلاين) 📡" else "Local TTS (Offline) 📡"
                        },
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        ),
                        color = if (isOnline) DoctorEmerald else GoldAccent
                    )
                }

                // Waveform Animation Visualizer when Speaking or Listening
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    modifier = Modifier.height(20.dp)
                ) {
                    if (isSpeaking || isListening) {
                        val activeColor = if (isListening) GoldAccent else CrimsonPrimary
                        val scales = listOf(bar1Scale, bar2Scale, bar3Scale, bar1Scale, bar2Scale)

                        scales.forEach { scale ->
                            Box(
                                modifier = Modifier
                                    .width(3.5.dp)
                                    .height((18 * scale).dp)
                                    .background(activeColor, shape = RoundedCornerShape(2.dp))
                            )
                        }
                    }
                }

                // Control Buttons
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    // Ask AI Voice Button
                    IconButton(
                        onClick = { showInquirySheet = true },
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                brush = Brush.linearGradient(
                                    listOf(Color(0xFF8B5CF6), Color(0xFF6366F1))
                                ),
                                shape = CircleShape
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Ask AI Voice",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Repeat Button
                    IconButton(
                        onClick = onRepeat,
                        enabled = lastSpokenText.isNotBlank(),
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Replay,
                            contentDescription = "Repeat",
                            tint = if (lastSpokenText.isNotBlank()) GoldAccent else Color.Gray,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Stop Button
                    if (isSpeaking) {
                        IconButton(
                            onClick = onStop,
                            modifier = Modifier
                                .size(34.dp)
                                .background(CrimsonPrimary.copy(alpha = 0.2f), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = "Stop",
                                tint = CrimsonPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Mute / Unmute Button
                    IconButton(
                        onClick = onToggleMute,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = if (isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                            contentDescription = "Mute",
                            tint = if (isMuted) Color.Red else Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Bottom Text Caption showing current spoken line if active
            AnimatedVisibility(
                visible = isSpeaking && lastSpokenText.isNotBlank(),
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Text(
                    text = "🗣️ $lastSpokenText",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    ),
                    color = Color.LightGray,
                    maxLines = 2,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }

    // Modal Sheet for Quick Voice / AI Inquiry
    if (showInquirySheet) {
        val sheetState = rememberModalBottomSheetState()
        var customQuery by remember { mutableStateOf("") }

        ModalBottomSheet(
            onDismissRequest = { showInquirySheet = false },
            sheetState = sheetState,
            containerColor = NoirSurface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (isAr) "استفسار المساعد الصوتي 🎙️" else "Ask AI Voice Assistant 🎙️",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = GoldAccent
                    )
                    IconButton(
                        onClick = onStartVoiceListen,
                        modifier = Modifier
                            .scale(if (isListening) pulseScale else 1.0f)
                            .background(
                                if (isListening) CrimsonPrimary else GoldAccent,
                                CircleShape
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Listen",
                            tint = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = if (isAr) "أسئلة سريعة مجهزة:" else "Quick Questions:",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(8.dp))

                val quickQuestions = if (isAr) listOf(
                    "من هو المشتبه به الرئيس؟",
                    "شرح دور الطبيب والمحقق",
                    "نصيحة تكتيكية للجولة",
                    "ملخص قواعد اللعبة"
                ) else listOf(
                    "Who is the main suspect?",
                    "Explain Doctor & Detective roles",
                    "Tactical tip for this round",
                    "Game rules summary"
                )

                quickQuestions.forEach { question ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF242A38))
                            .clickable {
                                onAskAiInquiry(question)
                                showInquirySheet = false
                            }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = "💡 $question",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = customQuery,
                    onValueChange = { customQuery = it },
                    placeholder = {
                        Text(
                            text = if (isAr) "أو اكتب سؤالك هنا..." else "Or type your question...",
                            color = Color.Gray
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldAccent,
                        unfocusedBorderColor = NoirBorder
                    ),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                TextButton(
                    onClick = {
                        if (customQuery.isNotBlank()) {
                            onAskAiInquiry(customQuery)
                            showInquirySheet = false
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(GoldAccent, RoundedCornerShape(12.dp))
                ) {
                    Text(
                        text = if (isAr) "إرسال واستماع للإجابة 🔊" else "Ask & Listen 🔊",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
