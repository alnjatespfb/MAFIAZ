package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.CityId
import com.example.model.CityTheme
import com.example.model.CityThemes
import com.example.ui.components.FrostedGlassCard
import com.example.ui.theme.GlassBorderGradient
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.MoodyBackgroundGradient
import com.example.util.SoundFxManager

@Composable
fun StoreScreen(
    currentLanguage: AppLanguage = AppLanguage.AR,
    isVip: Boolean = false,
    unlockedCities: Set<CityId> = setOf(CityId.DARK_CITY),
    storeMessage: String? = null,
    onClearMessage: () -> Unit = {},
    onSubscribeVip: () -> Unit,
    onBuyCity: (CityId) -> Unit,
    onRedeemPromoCode: (String) -> Unit = {},
    onRestorePurchases: () -> Unit,
    onBack: () -> Unit
) {
    val isAr = currentLanguage == AppLanguage.AR
    val context = LocalContext.current
    var promoCodeInput by remember { mutableStateOf("") }

    LaunchedEffect(storeMessage) {
        if (!storeMessage.isNullOrBlank()) {
            Toast.makeText(context, storeMessage, Toast.LENGTH_SHORT).show()
            onClearMessage()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MoodyBackgroundGradient)
    ) {
        // Glowing Background Accent
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFFFFD700).copy(alpha = 0.15f),
                            Color(0xFF7C3AED).copy(alpha = 0.12f),
                            Color.Transparent
                        )
                    )
                )
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Spacer(modifier = Modifier.height(16.dp))

                // Top Navigation Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0x40000000))
                            .testTag("btn_store_back")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (isAr) "متجر MAFIAZ 👑" else "MAFIAZ Store 👑",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                fontSize = 22.sp
                            ),
                            color = GoldAccent
                        )
                    }

                    Spacer(modifier = Modifier.width(44.dp))
                }

                Spacer(modifier = Modifier.height(20.dp))

                // 1. VIP Subscription Banner Card
                FrostedGlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("card_vip_subscription"),
                    shape = RoundedCornerShape(26.dp),
                    borderBrush = Brush.linearGradient(
                        listOf(Color(0xFFFFD700), Color(0xFFB8860B), Color(0xFFFFD700))
                    ),
                    backgroundColor = Color(0xEE2A0A12)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Badge
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = GoldAccent,
                            modifier = Modifier.padding(bottom = 12.dp)
                        ) {
                            Text(
                                text = if (isAr) "👑 الأكثر شعبية - العضوية الملكية" else "👑 Most Popular - Royal VIP",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.Black,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }

                        Text(
                            text = if (isAr) "اشتراك VIP الشهري" else "Monthly VIP Subscription",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 24.sp
                            ),
                            color = Color.White
                        )

                        Text(
                            text = if (isAr) "$2.99 / شهرياً" else "$2.99 / Month",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp
                            ),
                            color = GoldAccent,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Features List
                        VipFeatureRow(if (isAr) "إزالة جميع الإعلانات بالكامل (البانر والإعلانات البينية) 🚫" else "Complete Ad-free experience (Banner & Interstitials)")
                        VipFeatureRow(if (isAr) "ميزة اللعب مع الـ AI (إكمال اللاعبين بالبوتات عند نقص العدد) 🤖" else "Play with AI Bots (Auto-fill missing players)")
                        VipFeatureRow(if (isAr) "بادج التوثيق الملكي 👑 بجانب اسمك في جميع الجولات" else "Royal Verification Badge 👑 next to your name")
                        VipFeatureRow(if (isAr) "فتح جميع مدن وثيمات الـ VIP تلقائياً (قصر المافيا الذهبي، السيبربنك...) 🏰" else "Unlock all VIP Cities automatically (Golden Mansion, Cyberpunk...)")

                        Spacer(modifier = Modifier.height(16.dp))

                        // Action Button
                        Button(
                            onClick = {
                                SoundFxManager.playHeartbeat(context)
                                onSubscribeVip()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("btn_subscribe_vip"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isVip) Color(0xFF10B981) else GoldAccent,
                                contentColor = Color.Black
                            )
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (isVip) Icons.Default.Check else Icons.Default.Star,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isVip) {
                                        if (isAr) "مشترك حالياً ✓ (مفعل)" else "Currently Subscribed ✓"
                                    } else {
                                        if (isAr) "اشترك الآن 👑" else "Subscribe Now 👑"
                                    },
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // 2. Promo Code Redemption Section (Galaxy Store / APK Promo System)
                FrostedGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    borderBrush = androidx.compose.ui.graphics.SolidColor(GoldAccent.copy(alpha = 0.5f)),
                    backgroundColor = Color(0xCC1A0E26)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = "Promo Code",
                                tint = GoldAccent,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isAr) "🎁 تفعيل الكود السري / Promo Code" else "🎁 Redeem Promo Code",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                ),
                                color = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = promoCodeInput,
                                onValueChange = { promoCodeInput = it },
                                placeholder = {
                                    Text(
                                        text = if (isAr) "أدخل الكود هنا (مثال: ZEYAD_DEV_2026)" else "Enter code here",
                                        color = Color(0xFF94A3B8),
                                        fontSize = 13.sp
                                    )
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GoldAccent,
                                    unfocusedBorderColor = Color(0x40FFFFFF),
                                    focusedContainerColor = Color(0x9910121F),
                                    unfocusedContainerColor = Color(0x6610121F),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("input_promo_code")
                            )

                            Spacer(modifier = Modifier.width(10.dp))

                            Button(
                                onClick = {
                                    if (promoCodeInput.isNotBlank()) {
                                        SoundFxManager.playGlassClick(context)
                                        onRedeemPromoCode(promoCodeInput)
                                        promoCodeInput = ""
                                    }
                                },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = GoldAccent,
                                    contentColor = Color.Black
                                ),
                                modifier = Modifier
                                    .height(54.dp)
                                    .testTag("btn_redeem_promo")
                            ) {
                                Text(
                                    text = if (isAr) "تفعيل الكود" else "Redeem",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Section Title: Standalone Cities
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isAr) "🏛️ المدن والثيمات المستقلة" else "🏛️ Cities & Themes",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        ),
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
            }

            // Cities List
            items(CityThemes.ALL_THEMES) { cityTheme ->
                val isUnlocked = cityTheme.isFree || isVip || unlockedCities.contains(cityTheme.id)

                CityStoreCard(
                    cityTheme = cityTheme,
                    isUnlocked = isUnlocked,
                    isAr = isAr,
                    onBuy = { onBuyCity(cityTheme.id) },
                    onSubscribeVip = onSubscribeVip
                )

                Spacer(modifier = Modifier.height(14.dp))
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))

                // Restore Purchases Button (Galaxy Store & Local Multi-Storage)
                OutlinedButton(
                    onClick = {
                        SoundFxManager.playGlassClick(context)
                        onRestorePurchases()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("btn_restore_purchases"),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.5.dp, GlassBorderGradient),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = Color(0x40131622),
                        contentColor = Color(0xFFE2E8F0)
                    )
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Restore Purchases",
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isAr) "استعادة المشتريات / Galaxy Store 🔄" else "Restore Purchases / Galaxy Store 🔄",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
private fun VipFeatureRow(text: String) {
    Row(
        verticalAlignment = Alignment.Top,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Check,
            contentDescription = null,
            tint = GoldAccent,
            modifier = Modifier
                .size(18.dp)
                .padding(top = 2.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 14.sp, lineHeight = 20.sp),
            color = Color(0xFFE2E8F0)
        )
    }
}

@Composable
private fun CityStoreCard(
    cityTheme: CityTheme,
    isUnlocked: Boolean,
    isAr: Boolean,
    onBuy: () -> Unit,
    onSubscribeVip: () -> Unit
) {
    FrostedGlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        borderBrush = Brush.linearGradient(
            listOf(cityTheme.cardBorder, cityTheme.cardBorder.copy(alpha = 0.4f))
        ),
        backgroundColor = cityTheme.cardBg
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = cityTheme.iconEmoji,
                        fontSize = 28.sp,
                        modifier = Modifier.padding(end = 10.dp)
                    )
                    Column {
                        Text(
                            text = if (isAr) cityTheme.nameAr else cityTheme.nameEn,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            ),
                            color = Color.White
                        )
                        if (cityTheme.specialRoleNameAr != null) {
                            Text(
                                text = "${cityTheme.specialRoleBadge ?: ""} ${if (isAr) cityTheme.specialRoleNameAr else cityTheme.specialRoleNameEn}",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = cityTheme.primaryAccent
                            )
                        }
                    }
                }

                // Status Badge or Buy Button
                when {
                    isUnlocked -> {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF10B981).copy(alpha = 0.2f),
                            border = BorderStroke(1.dp, Color(0xFF10B981))
                        ) {
                            Text(
                                text = if (isAr) "مفتوحة ✓" else "Unlocked ✓",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color(0xFF10B981),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                    cityTheme.isVipExclusive -> {
                        Button(
                            onClick = onSubscribeVip,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = GoldAccent,
                                contentColor = Color.Black
                            ),
                            modifier = Modifier.height(38.dp)
                        ) {
                            Text(
                                text = if (isAr) "فتح بالـ VIP 👑" else "Unlock VIP 👑",
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                    cityTheme.standalonePrice != null -> {
                        Button(
                            onClick = onBuy,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = cityTheme.primaryAccent,
                                contentColor = Color.White
                            ),
                            modifier = Modifier.height(38.dp)
                        ) {
                            Text(
                                text = "${if (isAr) "شراء بـ" else "Buy"} ${cityTheme.standalonePrice}",
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (isAr) cityTheme.taglineAr else cityTheme.taglineEn,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp),
                color = Color(0xFFCBD5E1)
            )

            if (cityTheme.specialRoleDescAr != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0x30000000),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "⭐ ${if (isAr) "الدور الخارق:" else "Super Role:"} ${if (isAr) cityTheme.specialRoleDescAr else cityTheme.specialRoleDescEn}",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp, lineHeight = 16.sp),
                        color = Color(0xFFFFE082),
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }
    }
}
