package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.Player
import com.example.ui.components.FlippableRoleCard
import com.example.ui.components.FrostedGlassCard
import com.example.ui.theme.GlassBorderGradient
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.MoodyBackgroundGradient
import com.example.util.SoundFxManager

@Composable
fun RoleDistributionScreen(
    currentLanguage: AppLanguage = AppLanguage.AR,
    players: List<Player>,
    currentIndex: Int,
    isCardFlipped: Boolean,
    onCardFlip: () -> Unit,
    onHideAndNext: () -> Unit
) {
    val isAr = currentLanguage == AppLanguage.AR
    val context = androidx.compose.ui.platform.LocalContext.current
    val voiceManager = remember(context) { com.example.util.HybridVoiceManager(context) }
    val currentPlayer = players.getOrNull(currentIndex) ?: return
    val totalPlayers = players.size

    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose { voiceManager.stop() }
    }

    androidx.compose.runtime.LaunchedEffect(currentPlayer.id) {
        val textToSpeak = if (isAr) "سلم الهاتف لـ ${currentPlayer.name}" else "Pass phone to ${currentPlayer.name}"
        voiceManager.speak(textToSpeak, lang = currentLanguage)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MoodyBackgroundGradient)
            .statusBarsPadding()
            .navigationBarsPadding(),
        contentAlignment = Alignment.Center
    ) {
        // Neon ambient radial background glow
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF7C3AED).copy(alpha = 0.35f),
                            Color(0xFF06B6D4).copy(alpha = 0.2f),
                            Color.Transparent
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 600.dp)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Pass-the-phone Host Guidance
            FrostedGlassCard(
                shape = RoundedCornerShape(26.dp),
                borderBrush = GlassBorderGradient,
                backgroundColor = Color(0xCC131622),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = GoldAccent.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhoneAndroid,
                            contentDescription = "Pass phone",
                            tint = GoldAccent,
                            modifier = Modifier
                                .padding(10.dp)
                                .size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Text(
                            text = if (isAr) "مرروا الهاتف الآن سرّاً لـ:" else "Pass the phone secretly to:",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFCBD5E1)
                        )
                        Text(
                            text = if (isAr) "👤 ${currentPlayer.name} (${currentIndex + 1} من $totalPlayers)" else "👤 ${currentPlayer.name} (${currentIndex + 1} of $totalPlayers)",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 22.sp
                            ),
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Interactive 3D Role Card
            FlippableRoleCard(
                player = currentPlayer,
                isFlipped = isCardFlipped,
                onCardClick = {
                    SoundFxManager.playMysteriousWhisper(context)
                    onCardFlip()
                },
                lang = currentLanguage,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Bottom Hide Role & Continue Button
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isCardFlipped) {
                    Button(
                        onClick = {
                            SoundFxManager.playGlassClick(context)
                            onHideAndNext()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp)
                            .testTag("btn_hide_role_continue"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(Color(0xFFDC2626), Color(0xFFEF4444), Color(0xFFF59E0B))
                                    ),
                                    shape = RoundedCornerShape(20.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.VisibilityOff,
                                    contentDescription = "Hide",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (currentIndex < totalPlayers - 1) {
                                        if (isAr) "✅ فهمت دوري، اخفِ البطاقة ومرّر الهاتف" else "✅ Got my role, hide card & pass phone"
                                    } else {
                                        if (isAr) "✅ فهمت دوري، وبدء النهار ☀️" else "✅ Got my role, start Day ☀️"
                                    },
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp
                                    ),
                                    color = Color.White
                                )
                            }
                        }
                    }
                } else {
                    Surface(
                        color = Color(0x22FFFFFF),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(
                            text = if (isAr) "اضغط على بطاقة ${currentPlayer.name} أعلاه لفتحها" else "Tap ${currentPlayer.name}'s card above to reveal role",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFECEFF1),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
                        )
                    }
                }
            }
        }
    }
}

