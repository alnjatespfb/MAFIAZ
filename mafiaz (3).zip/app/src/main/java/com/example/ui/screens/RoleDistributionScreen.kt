package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Player
import com.example.ui.components.FlippableRoleCard
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NoirBackground
import com.example.ui.theme.NoirSurface

import com.example.model.AppLanguage

@Composable
fun RoleDistributionScreen(
    currentLanguage: AppLanguage = AppLanguage.AR,
    players: List<Player>,
    currentIndex: Int,
    isCardFlipped: Boolean,
    onCardFlip: () -> Unit,
    onHideAndNext: () -> Unit
) {
    val isAr = currentLanguage == AppLanguage.AR
    val currentPlayer = players.getOrNull(currentIndex) ?: return
    val totalPlayers = players.size

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NoirBackground)
            .padding(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Pass-the-phone Host Guidance
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = NoirSurface),
                border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = GoldAccent.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhoneAndroid,
                            contentDescription = "Pass phone",
                            tint = GoldAccent,
                            modifier = Modifier
                                .padding(10.dp)
                                .size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Text(
                            text = if (isAr) "مرروا الهاتف الآن سرّاً لـ:" else "Pass the phone secretly to:",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFB0BEC5)
                        )
                        Text(
                            text = if (isAr) "👤 ${currentPlayer.name} (${currentIndex + 1} من $totalPlayers)" else "👤 ${currentPlayer.name} (${currentIndex + 1} of $totalPlayers)",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 22.sp
                            ),
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Interactive 3D Role Card
            FlippableRoleCard(
                player = currentPlayer,
                isFlipped = isCardFlipped,
                onCardClick = onCardFlip,
                lang = currentLanguage,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Bottom Hide Role & Continue Button
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isCardFlipped) {
                    Button(
                        onClick = onHideAndNext,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("btn_hide_role_continue"),
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.VisibilityOff,
                                contentDescription = "Hide",
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (currentIndex < totalPlayers - 1) {
                                    if (isAr) "✅ فهمت دوري، اخفِ البطاقة ومرّر الهاتف" else "✅ Got my role, hide card & pass phone"
                                } else {
                                    if (isAr) "✅ فهمت دوري، وبدء النهار ☀️" else "✅ Got my role, start Day ☀️"
                                },
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                } else {
                    Surface(
                        color = Color(0x22FFFFFF),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(
                            text = if (isAr) "اضغط على بطاقة ${currentPlayer.name} أعلاه لفتحها" else "Tap ${currentPlayer.name}'s card above to reveal role",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFECEFF1),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
                        )
                    }
                }
            }
        }
    }
}
