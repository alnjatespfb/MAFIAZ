package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Player
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.DoctorEmerald
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NoirBackground
import com.example.ui.theme.NoirSurface

import com.example.model.AppLanguage

@Composable
fun MorningReportScreen(
    currentLanguage: AppLanguage = AppLanguage.AR,
    reportMessage: String,
    eliminatedPlayer: Player?,
    isDoctorSaved: Boolean,
    onProceed: () -> Unit
) {
    val isAr = currentLanguage == AppLanguage.AR

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NoirBackground)
            .padding(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            Card(
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isDoctorSaved) Color(0xFF092321) else if (eliminatedPlayer != null) Color(0xFF2A0A0D) else NoirSurface
                ),
                border = BorderStroke(
                    2.dp,
                    if (isDoctorSaved) DoctorEmerald else if (eliminatedPlayer != null) CrimsonPrimary else GoldAccent
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.WbSunny,
                        contentDescription = "Morning",
                        tint = GoldAccent,
                        modifier = Modifier.size(48.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (isAr) "☀️ استيقظ الجميع!" else "☀️ Everyone Woke Up!",
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                        color = GoldAccent
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = reportMessage,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 22.sp,
                            lineHeight = 32.sp
                        ),
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )

                    if (eliminatedPlayer != null) {
                        Spacer(modifier = Modifier.height(16.dp))

                        Surface(
                            color = CrimsonPrimary.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, CrimsonPrimary)
                        ) {
                            Text(
                                text = if (isAr) 
                                    "دور الضحية الإجباري المغادر: ${eliminatedPlayer.role.badgeIcon} ${eliminatedPlayer.role.title(currentLanguage)}"
                                else
                                    "Role of eliminated victim: ${eliminatedPlayer.role.badgeIcon} ${eliminatedPlayer.role.title(currentLanguage)}",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onProceed,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("btn_morning_proceed"),
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                shape = RoundedCornerShape(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (isAr) "المتابعة للجولة التالية 🚀" else "Proceed to Next Round 🚀",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Next",
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
