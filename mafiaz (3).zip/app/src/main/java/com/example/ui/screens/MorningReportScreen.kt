package com.example.ui.screens

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.Player
import com.example.ui.components.CinematicTextSwitcher
import com.example.ui.components.FrostedGlassCard
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.DoctorEmerald
import com.example.ui.theme.GlassBorderGradient
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.MoodyBackgroundGradient
import com.example.ui.theme.NoirSurface
import com.example.util.SoundFxManager

@Composable
fun MorningReportScreen(
    currentLanguage: AppLanguage = AppLanguage.AR,
    reportMessage: String,
    eliminatedPlayer: Player?,
    isDoctorSaved: Boolean,
    onProceed: () -> Unit
) {
    val isAr = currentLanguage == AppLanguage.AR
    val context = androidx.compose.ui.platform.LocalContext.current

    androidx.compose.runtime.LaunchedEffect(eliminatedPlayer) {
        if (eliminatedPlayer != null) {
            SoundFxManager.playSuddenEventSound(context)
        } else {
            SoundFxManager.playMysteriousWhisper(context)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MoodyBackgroundGradient)
    ) {
        // Neon ambient radial background glow
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFFF59E0B).copy(alpha = 0.3f),
                            Color(0xFFDC2626).copy(alpha = 0.2f),
                            Color.Transparent
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            FrostedGlassCard(
                shape = RoundedCornerShape(26.dp),
                borderBrush = GlassBorderGradient,
                backgroundColor = if (isDoctorSaved) Color(0xCC092321) else if (eliminatedPlayer != null) Color(0xCC2A0A0D) else Color(0xCC131622),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.WbSunny,
                        contentDescription = "Morning",
                        tint = GoldAccent,
                        modifier = Modifier.size(48.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (isAr) "☀️ استيقظ الجميع!" else "☀️ Everyone Woke Up!",
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                        color = GoldAccent
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    CinematicTextSwitcher(
                        text = reportMessage,
                        autoPlay = true,
                        typewriterSpeedMs = 30L,
                        beatIntervalMs = 3000L
                    )


                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = {
                    SoundFxManager.playHeartbeat(context)
                    onProceed()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .testTag("btn_morning_proceed"),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                shape = RoundedCornerShape(20.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(Color(0xFFDC2626), Color(0xFFEF4444), Color(0xFFF59E0B))
                            ),
                            shape = RoundedCornerShape(20.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (isAr) "المتابعة للجولة التالية 🚀" else "Proceed to Next Round 🚀",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            ),
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = "Next",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

