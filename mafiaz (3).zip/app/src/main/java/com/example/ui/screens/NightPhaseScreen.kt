package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.NightActionRecord
import com.example.model.Player
import com.example.model.Role
import com.example.ui.components.FrostedGlassCard
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.DetectiveCyan
import com.example.ui.theme.DoctorEmerald
import com.example.ui.theme.GlassBorderGradient
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.MoodyBackgroundGradient
import com.example.ui.theme.NoirSurface
import com.example.util.SoundFxManager

@Composable
fun NightPhaseScreen(
    currentLanguage: AppLanguage = AppLanguage.AR,
    livingPlayers: List<Player>,
    currentNightPlayerIndex: Int,
    isPassReady: Boolean,
    nightActions: NightActionRecord = NightActionRecord(),
    detectiveFeedback: String?,
    onConfirmPlayerReady: () -> Unit,
    onSubmitAction: (targetPlayerId: String?) -> Unit,
    onAdvanceDetectiveAfterFeedback: () -> Unit
) {
    val currentPlayer = livingPlayers.getOrNull(currentNightPlayerIndex) ?: return
    val localContext = androidx.compose.ui.platform.LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MoodyBackgroundGradient)
    ) {
        // Neon ambient radial glow effect
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF7C3AED).copy(alpha = 0.35f),
                            Color(0xFFDC2626).copy(alpha = 0.2f),
                            Color.Transparent
                        )
                    )
                )
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
        if (!isPassReady) {
            // Pass phone secretly step
            NightPassPhoneStep(
                currentLanguage = currentLanguage,
                player = currentPlayer,
                currentIndex = currentNightPlayerIndex + 1,
                totalPlayers = livingPlayers.size,
                onReadyClick = onConfirmPlayerReady
            )
        } else if (detectiveFeedback != null) {
            // Detective Inspection Result Pop-up
            DetectiveResultStep(
                currentLanguage = currentLanguage,
                feedback = detectiveFeedback,
                onContinue = onAdvanceDetectiveAfterFeedback
            )
        } else {
            // Role specific action or Fake Deception Action
            when (currentPlayer.role) {
                Role.MAFIA -> MafiaNightActionStep(
                    currentLanguage = currentLanguage,
                    currentPlayer = currentPlayer,
                    livingPlayers = livingPlayers,
                    candidates = livingPlayers.filter { it.role != Role.MAFIA },
                    nightActions = nightActions,
                    onSubmit = onSubmitAction
                )
                Role.DOCTOR -> DoctorNightActionStep(
                    currentLanguage = currentLanguage,
                    currentPlayer = currentPlayer,
                    candidates = livingPlayers,
                    onSubmit = onSubmitAction
                )
                Role.DETECTIVE -> DetectiveNightActionStep(
                    currentLanguage = currentLanguage,
                    currentPlayer = currentPlayer,
                    candidates = livingPlayers.filter { it.id != currentPlayer.id },
                    onSubmit = onSubmitAction
                )
                Role.CITIZEN -> CitizenFakeDeceptionStep(
                    currentLanguage = currentLanguage,
                    currentPlayer = currentPlayer,
                    onSubmit = { onSubmitAction(null) }
                )
            }
        }
    }
}
}

@Composable
private fun NightPassPhoneStep(
    currentLanguage: AppLanguage,
    player: Player,
    currentIndex: Int,
    totalPlayers: Int,
    onReadyClick: () -> Unit
) {
    val isAr = currentLanguage == AppLanguage.AR
    val localContext = androidx.compose.ui.platform.LocalContext.current
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        FrostedGlassCard(
            shape = RoundedCornerShape(26.dp),
            borderBrush = GlassBorderGradient,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Nightlight,
                    contentDescription = "Night",
                    tint = GoldAccent,
                    modifier = Modifier.size(48.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = if (isAr) "حل الليل وساد الصمت... 🌙" else "Night falls in silence... 🌙",
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = GoldAccent,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (isAr) "أغلقوا أعينكم جميعاً، ومرروا الهاتف صامتاً إلى:" else "Close your eyes, and pass the phone silently to:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFFCBD5E1),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(14.dp))

                Surface(
                    color = Color(0x33E53935),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, CrimsonPrimary)
                ) {
                    Text(
                        text = if (isAr) "👤 ${player.name} ($currentIndex من $totalPlayers)" else "👤 ${player.name} ($currentIndex of $totalPlayers)",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Black,
                            fontSize = 26.sp
                        ),
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                SoundFxManager.playMysteriousWhisper(localContext)
                onReadyClick()
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp)
                .testTag("btn_night_pass_ready"),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
            shape = RoundedCornerShape(20.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(Color(0xFFDC2626), Color(0xFFEF4444), Color(0xFFF59E0B))
                        ),
                        shape = RoundedCornerShape(20.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isAr) "أنا [${player.name}] - فتحت عينَي واضغط للمتابعة 👁️" else "I am [${player.name}] - Open eyes & Continue 👁️",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    ),
                    color = Color.White
                )
            }
        }
    }
}

@Composable
private fun MafiaNightActionStep(
    currentLanguage: AppLanguage,
    currentPlayer: Player,
    livingPlayers: List<Player>,
    candidates: List<Player>,
    nightActions: NightActionRecord,
    onSubmit: (targetId: String?) -> Unit
) {
    val isAr = currentLanguage == AppLanguage.AR
    val livingMafiaCount = livingPlayers.count { it.role == Role.MAFIA }
    val isMultiMafia = livingMafiaCount > 1
    val isBoss = currentPlayer.isMafiaBoss || !isMultiMafia

    val suggestedTargetPlayer = if (isBoss && nightActions.mafiaSuggestedTargetId != null) {
        livingPlayers.find { it.id == nightActions.mafiaSuggestedTargetId }
    } else null

    var selectedId by remember {
        mutableStateOf<String?>(
            if (isBoss && nightActions.mafiaSuggestedTargetId != null) nightActions.mafiaSuggestedTargetId else null
        )
    }

    Column(modifier = Modifier.fillMaxSize()) {
        FrostedGlassCard(
            shape = RoundedCornerShape(24.dp),
            borderBrush = GlassBorderGradient,
            backgroundColor = Color(0xCC2A0A0D),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isBoss) {
                        if (isAr) "👑 أنت زعيم المافيا (${currentPlayer.name})" else "👑 You are Mafia Boss (${currentPlayer.name})"
                    } else {
                        if (isAr) "🗡️ أنت مساعد المافيا (${currentPlayer.name})" else "🗡️ You are Mafia Assistant (${currentPlayer.name})"
                    },
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = CrimsonPrimary
                )
                Spacer(modifier = Modifier.height(6.dp))

                if (suggestedTargetPlayer != null) {
                    FrostedGlassCard(
                        backgroundColor = Color(0xCC3B1218),
                        borderBrush = Brush.horizontalGradient(listOf(GoldAccent, Color.White)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Text(
                            text = if (isAr) {
                                "📩 رسالة سرية لزعيم المافيا:\nزميلك في المافيا يقترح قتل [${suggestedTargetPlayer.name}]. ما هو قرارك النهائي؟"
                            } else {
                                "📩 Secret Message for Mafia Boss:\nYour partner suggests killing [${suggestedTargetPlayer.name}]. What is your final decision?"
                            },
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = GoldAccent,
                            modifier = Modifier.padding(12.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    Text(
                        text = if (isBoss) {
                            if (isAr) "حدد القرار النهائي الفعلي للاغتيال خلال الليل:" else "Select the final assassination decision tonight:"
                        } else {
                            if (isAr) "اختر الضحية التي ترغب في اقتراحها على زعيم المافيا:" else "Select the victim you suggest to the Mafia Boss:"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(candidates) { candidate ->
                val isSelected = selectedId == candidate.id
                FrostedGlassCard(
                    backgroundColor = if (isSelected) Color(0xCC4A0E17) else NoirSurface,
                    shape = RoundedCornerShape(16.dp),
                    borderBrush = if (isSelected) Brush.horizontalGradient(listOf(CrimsonPrimary, GoldAccent)) else GlassBorderGradient,
                    onClick = { selectedId = candidate.id },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("mafia_target_${candidate.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = candidate.name,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            ),
                            color = Color.White
                        )
                        Icon(
                            imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                            contentDescription = "Select",
                            tint = if (isSelected) CrimsonPrimary else Color(0xFF546E7A)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = { onSubmit(selectedId) },
            enabled = selectedId != null,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("btn_mafia_submit"),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
            shape = RoundedCornerShape(20.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(Color(0xFFDC2626), Color(0xFFEF4444), Color(0xFFF59E0B))
                        ),
                        shape = RoundedCornerShape(20.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isBoss) {
                        if (isAr) "تأكيد القرار النهائي لزعيم المافيا 🔪" else "Confirm Mafia Boss Final Decision 🔪"
                    } else {
                        if (isAr) "تأكيد اقتراح المساعد 🗡️" else "Confirm Assistant Suggestion 🗡️"
                    },
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    ),
                    color = Color.White
                )
            }
        }
    }
}

@Composable
private fun DoctorNightActionStep(
    currentLanguage: AppLanguage,
    currentPlayer: Player,
    candidates: List<Player>,
    onSubmit: (targetId: String?) -> Unit
) {
    val isAr = currentLanguage == AppLanguage.AR
    var selectedId by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        FrostedGlassCard(
            shape = RoundedCornerShape(24.dp),
            borderBrush = GlassBorderGradient,
            backgroundColor = Color(0xCC092321),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isAr) "🩺 أنت الطبيب (${currentPlayer.name})" else "🩺 You are Doctor (${currentPlayer.name})",
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = DoctorEmerald
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isAr) "اختر لاعباً واحداً لحمايته وانقاذه من طلقات المافيا الليلة:" else "Choose one player to protect and heal tonight:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(candidates) { candidate ->
                val isSelected = selectedId == candidate.id
                FrostedGlassCard(
                    backgroundColor = if (isSelected) Color(0xCC0D3B37) else NoirSurface,
                    shape = RoundedCornerShape(16.dp),
                    borderBrush = if (isSelected) Brush.horizontalGradient(listOf(DoctorEmerald, Color.White)) else GlassBorderGradient,
                    onClick = { selectedId = candidate.id },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("doctor_target_${candidate.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = candidate.name + if (candidate.id == currentPlayer.id) (if (isAr) " (حماية نفسك)" else " (Protect Yourself)") else "",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            ),
                            color = Color.White
                        )
                        Icon(
                            imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                            contentDescription = "Select",
                            tint = if (isSelected) DoctorEmerald else Color(0xFF546E7A)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = { onSubmit(selectedId) },
            enabled = selectedId != null,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("btn_doctor_submit"),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
            shape = RoundedCornerShape(20.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(Color(0xFF10B981), Color(0xFF059669))
                        ),
                        shape = RoundedCornerShape(20.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isAr) "تأكيد تفعيل الحماية 🛡️" else "Confirm Protection 🛡️",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    ),
                    color = Color.White
                )
            }
        }
    }
}

@Composable
private fun DetectiveNightActionStep(
    currentLanguage: AppLanguage,
    currentPlayer: Player,
    candidates: List<Player>,
    onSubmit: (targetId: String?) -> Unit
) {
    val isAr = currentLanguage == AppLanguage.AR
    var selectedId by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        FrostedGlassCard(
            shape = RoundedCornerShape(24.dp),
            borderBrush = GlassBorderGradient,
            backgroundColor = Color(0xCC082230),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isAr) "🔍 أنت المحقق (${currentPlayer.name})" else "🔍 You are Detective (${currentPlayer.name})",
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = DetectiveCyan
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isAr) "اختر لاعباً واحداً للتحري والتحقق من هويته السرية الليلة:" else "Select one player to investigate their role tonight:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(candidates) { candidate ->
                val isSelected = selectedId == candidate.id
                FrostedGlassCard(
                    backgroundColor = if (isSelected) Color(0xCC0D3C52) else NoirSurface,
                    shape = RoundedCornerShape(16.dp),
                    borderBrush = if (isSelected) Brush.horizontalGradient(listOf(DetectiveCyan, Color.White)) else GlassBorderGradient,
                    onClick = { selectedId = candidate.id },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("detective_target_${candidate.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = candidate.name,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            ),
                            color = Color.White
                        )
                        Icon(
                            imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                            contentDescription = "Select",
                            tint = if (isSelected) DetectiveCyan else Color(0xFF546E7A)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = { onSubmit(selectedId) },
            enabled = selectedId != null,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("btn_detective_submit"),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
            shape = RoundedCornerShape(20.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(Color(0xFF06B6D4), Color(0xFF0284C7))
                        ),
                        shape = RoundedCornerShape(20.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isAr) "التحري والتحقق السري 🔎" else "Investigate Target 🔎",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    ),
                    color = Color.White
                )
            }
        }
    }
}

@Composable
private fun DetectiveResultStep(
    currentLanguage: AppLanguage,
    feedback: String,
    onContinue: () -> Unit
) {
    val isAr = currentLanguage == AppLanguage.AR
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        FrostedGlassCard(
            shape = RoundedCornerShape(24.dp),
            borderBrush = GlassBorderGradient,
            backgroundColor = Color(0xCC082230),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isAr) "🔎 النتيجة السرية للمحقق" else "🔎 Detective Investigation Result",
                    style = MaterialTheme.typography.titleMedium,
                    color = GoldAccent
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = feedback,
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp,
                        lineHeight = 34.sp
                    ),
                    color = Color.White,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = if (isAr) "⚠️ احفظ هذه النتيجة سرّاً ولا تخبر أحداً الآن!" else "⚠️ Keep this secret and don't tell anyone now!",
                    style = MaterialTheme.typography.bodySmall,
                    color = CrimsonPrimary
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onContinue,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("btn_detective_continue"),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
            shape = RoundedCornerShape(20.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(Color(0xFF06B6D4), Color(0xFF0284C7))
                        ),
                        shape = RoundedCornerShape(20.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isAr) "فهمت النتيجة - إخفاء وتمرير الهاتف 🔒" else "Got it - Hide & Pass Phone 🔒",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    ),
                    color = Color.White
                )
            }
        }
    }
}

@Composable
private fun CitizenFakeDeceptionStep(
    currentLanguage: AppLanguage,
    currentPlayer: Player,
    onSubmit: () -> Unit
) {
    val isAr = currentLanguage == AppLanguage.AR
    var fakeTapsCount by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        FrostedGlassCard(
            shape = RoundedCornerShape(24.dp),
            borderBrush = GlassBorderGradient,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "Cover",
                        tint = GoldAccent,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isAr) "شاشة التمويه والتضليل (منع الغش) 🕵️‍♂️" else "Anti-Cheating Deception Screen 🕵️‍♂️",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = GoldAccent
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = if (isAr) 
                        "أنت مواطن بريء (${currentPlayer.name}). تظاهر بالتفكير واضغط على الأزرار الوهمية أدناه لتمثيل دور حقيقي أمام الآخرين لحماية هويتك!"
                    else
                        "You are an innocent Citizen (${currentPlayer.name}). Pretend to think and tap the fake buttons below to camouflage your role!",
                    style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
                    color = Color.White,
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Fake Interactive Buttons
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = { fakeTapsCount++ },
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFF424761)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("btn_fake_1")
            ) {
                Text(
                    text = if (isAr) "🔍 مسح النطاق الوهمي (تفاعل وهمي)" else "🔍 Scan Fake Perimeter (Dummy Tap)",
                    color = Color.White,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            OutlinedButton(
                onClick = { fakeTapsCount++ },
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFF424761)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("btn_fake_2")
            ) {
                Text(
                    text = if (isAr) "🛡️ تفعيل الحماية الصامتة (زر وهمي)" else "🛡️ Activate Silent Defense (Dummy Tap)",
                    color = Color.White,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            OutlinedButton(
                onClick = { fakeTapsCount++ },
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFF424761)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("btn_fake_3")
            ) {
                Text(
                    text = if (isAr) "⚡ إخفاء الأثر الصامت (زر وهمي)" else "⚡ Cover Silent Tracks (Dummy Tap)",
                    color = Color.White,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            if (fakeTapsCount > 0) {
                Text(
                    text = if (isAr) "تم تسجيل التفاعل الوهمي لتمويه الجالسين ($fakeTapsCount مرات) 👍" else "Fake taps recorded for camouflage ($fakeTapsCount times) 👍",
                    style = MaterialTheme.typography.bodySmall,
                    color = GoldAccent,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = onSubmit,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("btn_citizen_finish_fake"),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
            shape = RoundedCornerShape(20.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(Color(0xFFDC2626), Color(0xFFEF4444), Color(0xFFF59E0B))
                        ),
                        shape = RoundedCornerShape(20.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isAr) "إنهاء تمثيل الدور السري وتمرير الهاتف 🔒" else "Finish Camouflage & Pass Phone 🔒",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    ),
                    color = Color.White
                )
            }
        }
    }
}

