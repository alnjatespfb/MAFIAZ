package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.NavigateNext
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.GoldAccent
import com.example.util.SoundFxManager
import kotlinx.coroutines.delay

/**
 * A cinematic dynamic Text Switcher that splits storytelling text into sequential dramatic beats,
 * gradually revealing text with smooth animated transitions, character typewriter effect, and interactive beat navigation.
 */
@OptIn(ExperimentalAnimationApi::class)
@Composable
fun CinematicTextSwitcher(
    text: String,
    modifier: Modifier = Modifier,
    autoPlay: Boolean = true,
    typewriterSpeedMs: Long = 35L,
    beatIntervalMs: Long = 3500L,
    onComplete: (() -> Unit)? = null
) {
    val context = LocalContext.current

    // Parse full story text into dynamic story sentences/beats
    val beats = remember(text) {
        text.split(Regex("(?<=[.!?\n])\\s+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .ifEmpty { listOf(text) }
    }

    var currentBeatIndex by remember(text) { mutableIntStateOf(0) }
    var displayedText by remember(text) { mutableStateOf("") }
    var isTypewriterFinished by remember(text) { mutableStateOf(false) }

    val currentFullBeat = beats.getOrElse(currentBeatIndex) { "" }

    // Typewriter gradual character reveal effect
    LaunchedEffect(currentBeatIndex, text) {
        displayedText = ""
        isTypewriterFinished = false
        val beatToType = currentFullBeat
        for (i in 1..beatToType.length) {
            displayedText = beatToType.substring(0, i)
            delay(typewriterSpeedMs)
        }
        isTypewriterFinished = true

        if (autoPlay && currentBeatIndex < beats.size - 1) {
            delay(beatIntervalMs)
            currentBeatIndex++
            SoundFxManager.playGlassClick(context)
        } else if (currentBeatIndex == beats.size - 1) {
            onComplete?.invoke()
        }
    }

    FrostedGlassCard(
        shape = RoundedCornerShape(24.dp),
        borderBrush = Brush.horizontalGradient(
            colors = listOf(CrimsonPrimary.copy(alpha = 0.6f), GoldAccent.copy(alpha = 0.6f))
        ),
        backgroundColor = Color(0xF20D0F18),
        modifier = modifier
            .fillMaxWidth()
            .testTag("cinematic_text_switcher")
    ) {
        Column(
            modifier = Modifier
                .padding(20.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Indicator: "سرد الأحداث السينمائي / GAME STORY"
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (isTypewriterFinished) GoldAccent else CrimsonPrimary)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "🎬 STORY & EVENTS",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp,
                        fontSize = 11.sp
                    ),
                    color = GoldAccent.copy(alpha = 0.9f)
                )
            }

            // Animated Text Switcher Display
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .clickable {
                        // Instant complete current beat on click, or move to next
                        if (!isTypewriterFinished) {
                            displayedText = currentFullBeat
                            isTypewriterFinished = true
                        } else if (currentBeatIndex < beats.size - 1) {
                            currentBeatIndex++
                            SoundFxManager.playGlassClick(context)
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                AnimatedContent(
                    targetState = currentBeatIndex,
                    transitionSpec = {
                        (fadeIn(animationSpec = tween(400)) + scaleIn(initialScale = 0.92f)) togetherWith
                                (fadeOut(animationSpec = tween(300)) + scaleOut(targetScale = 1.05f))
                    },
                    label = "TextSwitcherBeat"
                ) { index ->
                    Text(
                        text = displayedText,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 20.sp,
                            lineHeight = 30.sp,
                            fontFamily = FontFamily.Default
                        ),
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Story Progression Dots & Quick Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Replay or Reset Story
                IconButton(
                    onClick = {
                        currentBeatIndex = 0
                        SoundFxManager.playGlassClick(context)
                    },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Replay,
                        contentDescription = "Replay Story",
                        tint = Color.White.copy(alpha = 0.6f),
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Beat Progress Dots
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    beats.indices.forEach { index ->
                        val isCurrent = index == currentBeatIndex
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 3.dp)
                                .height(6.dp)
                                .width(if (isCurrent) 22.dp else 6.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isCurrent) GoldAccent else Color.White.copy(alpha = 0.25f)
                                )
                                .clickable {
                                    currentBeatIndex = index
                                    SoundFxManager.playGlassClick(context)
                                }
                        )
                    }
                }

                // Fast Forward / Instant Reveal All
                IconButton(
                    onClick = {
                        if (currentBeatIndex < beats.size - 1) {
                            currentBeatIndex++
                        } else {
                            displayedText = currentFullBeat
                            isTypewriterFinished = true
                        }
                        SoundFxManager.playGlassClick(context)
                    },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = if (currentBeatIndex < beats.size - 1) Icons.Default.NavigateNext else Icons.Default.FastForward,
                        contentDescription = "Next Beat",
                        tint = GoldAccent,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}
