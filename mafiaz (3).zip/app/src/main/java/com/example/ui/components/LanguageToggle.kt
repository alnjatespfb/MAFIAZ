package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NoirBorder
import com.example.ui.theme.NoirSurface

@Composable
fun LanguageToggle(
    currentLanguage: AppLanguage,
    onLanguageToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onLanguageToggle,
        shape = RoundedCornerShape(50),
        color = NoirSurface,
        border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.6f)),
        modifier = modifier.testTag("btn_language_toggle")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (currentLanguage == AppLanguage.AR) "🇸🇦 العربية" else "🇬🇧 English",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = GoldAccent
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "🌐",
                fontSize = 14.sp
            )
        }
    }
}
