package com.example.ui.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.theme.GlassBorderGradient
import com.example.ui.theme.GoldAccent

@Composable
fun LanguageToggle(
    currentLanguage: AppLanguage,
    onLanguageToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    FrostedGlassCard(
        onClick = onLanguageToggle,
        shape = RoundedCornerShape(50),
        borderBrush = GlassBorderGradient,
        borderWidth = 1.dp,
        backgroundColor = Color(0xCC1A1D2B),
        modifier = modifier.testTag("btn_language_toggle")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (currentLanguage == AppLanguage.AR) "🇸🇦 العربية" else "🇬🇧 English",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = GoldAccent
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "🌐",
                fontSize = 14.sp
            )
        }
    }
}

