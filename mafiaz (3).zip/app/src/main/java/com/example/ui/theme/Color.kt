package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Moody Glassmorphism Theme Color Tokens for MAFIAZ
val ObsidianBackground = Color(0xFF0D0E15)
val MidnightBlue = Color(0xFF131722)
val NoirBackground = Color(0xFF0D0E15)
val NoirBackgroundSecondary = Color(0xFF151926)
val NoirSurface = Color(0xCC1A1F2D) // 80% opacity for glass effect
val NoirSurfaceVariant = Color(0xAA242A3C)
val NoirGlassOverlay = Color(0x661A1F2D)
val NoirBorder = Color(0x33FFFFFF)
val NoirBorderSubtle = Color(0x1AFFFFFF)

// Core Accents & Moody Neon Colors
val ElectricCyan = Color(0xFF06B6D4)
val ElectricCyanLight = Color(0xFF22D3EE)
val AmethystPurple = Color(0xFF9333EA)
val AmethystPurpleLight = Color(0xFFC084FC)

val CrimsonPrimary = Color(0xFFEF4444) // Mafia Red
val CrimsonPrimaryDark = Color(0xFFDC2626)
val CrimsonContainer = Color(0xFF3B1218)

val GoldAccent = Color(0xFFF59E0B) // Amber / Gold
val GoldAccentLight = Color(0xFFFBBF24)
val GoldContainer = Color(0xFF3E2808)

val DetectiveBlue = ElectricCyan
val DetectiveCyan = ElectricCyan
val DetectiveBlueLight = ElectricCyanLight
val DetectiveContainer = Color(0xFF082F49)

val DoctorEmerald = Color(0xFF10B981) // Doctor Green
val DoctorEmeraldLight = Color(0xFF34D399)
val DoctorContainer = Color(0xFF064E3B)

val CitizenPurple = AmethystPurple
val CitizenInnocent = AmethystPurple
val CitizenPurpleLight = AmethystPurpleLight

// Text Tokens
val TextPrimary = Color(0xFFF9FAFB)
val TextSecondary = Color(0xFFCBD5E1)
val TextMuted = Color(0xFF94A3B8)

// Mysterious Gradients
val MoodyBackgroundGradient = Brush.verticalGradient(
    colors = listOf(
        ObsidianBackground,
        MidnightBlue,
        Color(0xFF090A0F)
    )
)

val GlassBorderGradient = Brush.linearGradient(
    colors = listOf(
        ElectricCyan.copy(alpha = 0.6f),
        AmethystPurple.copy(alpha = 0.4f),
        Color.White.copy(alpha = 0.1f)
    )
)

val GlassCardGradient = Brush.linearGradient(
    colors = listOf(
        Color(0x2EFFFFFF),
        Color(0x0DFFFFFF)
    )
)

val CyberGlowGradient = Brush.horizontalGradient(
    colors = listOf(ElectricCyan, AmethystPurple)
)

val GoldGradient = Brush.horizontalGradient(
    colors = listOf(GoldAccent, GoldAccentLight)
)

val CrimsonGradient = Brush.horizontalGradient(
    colors = listOf(CrimsonPrimaryDark, CrimsonPrimary)
)

val BackgroundNoirGradient = MoodyBackgroundGradient

