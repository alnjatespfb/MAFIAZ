package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Noir Theme Color Tokens for Mafais (مافيس)
val NoirBackground = Color(0xFF0C0D12)
val NoirSurface = Color(0xFF161822)
val NoirSurfaceVariant = Color(0xFF222536)
val NoirBorder = Color(0xFF33384F)

val CrimsonPrimary = Color(0xFFE53935)
val CrimsonPrimaryContainer = Color(0xFF4A0E17)
val CrimsonOnContainer = Color(0xFFFFCDD2)

val GoldAccent = Color(0xFFFFB300)
val GoldContainer = Color(0xFF3E2723)

val DetectiveCyan = Color(0xFF29B6F6)
val DoctorEmerald = Color(0xFF26A69A)
val CitizenInnocent = Color(0xFF7CB342)

val TextPrimary = Color(0xFFF5F5F7)
val TextSecondary = Color(0xFFB0BEC5)
val TextMuted = Color(0xFF78909C)
