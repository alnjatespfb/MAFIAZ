package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.GameStats
import com.example.model.Player
import com.example.model.Team
import com.example.ui.components.FrostedGlassCard
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.DoctorEmerald
import com.example.ui.theme.GlassBorderGradient
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.MoodyBackgroundGradient
import com.example.ui.theme.NoirSurface
import com.example.util.SoundFxManager

@Composable
fun VictoryScreen(
    currentLanguage: AppLanguage = AppLanguage.AR,
    winningTeam: Team?,
    players: List<Player>,
    stats: GameStats,
    onNewGame: () -> Unit,
    onRematch: () -> Unit
) {
    val isAr = currentLanguage == AppLanguage.AR
    val context = androidx.compose.ui.platform.LocalContext.current
    val isCitizensWinner = winningTeam == Team.CITIZENS

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MoodyBackgroundGradient)
    ) {
        // Neon ambient radial background glow
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            if (isCitizensWinner) Color(0xFF10B981).copy(alpha = 0.35f) else Color(0xFFDC2626).copy(alpha = 0.35f),
                            Color(0xFF7C3AED).copy(alpha = 0.2f),
                            Color.Transparent
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Victory Banner
            FrostedGlassCard(
                shape = RoundedCornerShape(26.dp),
                borderBrush = GlassBorderGradient,
                backgroundColor = if (isCitizensWinner) Color(0xCC0D2B1B) else Color(0xCC38080C),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = "Trophy",
                        tint = GoldAccent,
                        modifier = Modifier.size(54.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (isAr) "🏆 نهاية اللعبة والفوز لـ:" else "🏆 Game Over - Victory For:",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color(0xFFCBD5E1)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = if (isCitizensWinner) 
                            (if (isAr) "فريق المواطنين الأبرياء! 😇" else "Innocent Citizens Team! 😇")
                        else 
                            (if (isAr) "فريق المافيا الأشرار! 😈" else "Mafia Team! 😈"),
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Black,
                            fontSize = 30.sp
                        ),
                        color = if (isCitizensWinner) DoctorEmerald else CrimsonPrimary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (isCitizensWinner) 
                            (if (isAr) "تمت تصفية جميع عناصر المافيا! انتصر المواطنون وبقيت البلدة آمنة! 🎉" else "All Mafia members eliminated! Citizens win and the town is safe! 🎉")
                        else 
                            (if (isAr) "سيطر القتلة على المدينة! فازت المافيا باللعبة! 🗡️" else "The killers took over the city! Mafia won the game! 🗡️"),
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Round Stats Summary
            FrostedGlassCard(
                shape = RoundedCornerShape(18.dp),
                borderBrush = GlassBorderGradient,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(4.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatMetricItem(label = if (isAr) "الجولات" else "Rounds", value = "${stats.roundNumber}")
                    StatMetricItem(label = if (isAr) "المُبعدين" else "Eliminated", value = "${stats.totalEliminated}")
                    StatMetricItem(label = if (isAr) "إنقاذ الطبيب" else "Doctor Saves", value = "${stats.successfulDoctorSaves}")
                    StatMetricItem(label = if (isAr) "تحري المحقق" else "Detective Checks", value = "${stats.detectiveChecksCount}")
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = if (isAr) "📜 كشف الأدوار السرية لجميع اللاعبين:" else "📜 Secret Roles Revealed:",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = GoldAccent,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // Players Role Reveal Table
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(players) { player ->
                    FrostedGlassCard(
                        shape = RoundedCornerShape(14.dp),
                        borderBrush = GlassBorderGradient,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = player.role.badgeIcon,
                                    fontSize = 24.sp
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = player.name + if (!player.isAlive) (if (isAr) " ❌ (تم إقصاؤه)" else " ❌ (Eliminated)") else (if (isAr) " ✅ (حي)" else " ✅ (Alive)"),
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = Color.White
                                    )
                                    Text(
                                        text = player.role.title(currentLanguage),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (player.role.team == Team.MAFIA) CrimsonPrimary else DoctorEmerald
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        SoundFxManager.playHeartbeat(context)
                        onRematch()
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("btn_rematch"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(Color(0xFFDC2626), Color(0xFFEF4444))
                                ),
                                shape = RoundedCornerShape(16.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Replay,
                                contentDescription = "Rematch",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isAr) "إعادة التشكيل" else "Rematch",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                        }
                    }
                }

                OutlinedButton(
                    onClick = {
                        SoundFxManager.playGlassClick(context)
                        onNewGame()
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("btn_new_game"),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, GoldAccent),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldAccent)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "New Game",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isAr) "لعبة جديدة" else "New Game",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StatMetricItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black),
            color = GoldAccent
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFF90A4AE)
        )
    }
}

