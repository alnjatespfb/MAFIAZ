package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HowToVote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.Player
import com.example.ui.components.FrostedGlassCard
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.GlassBorderGradient
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.MoodyBackgroundGradient
import com.example.ui.theme.NoirBorder
import com.example.ui.theme.NoirSurface
import com.example.util.SoundFxManager

@Composable
fun VotingScreen(
    currentLanguage: AppLanguage = AppLanguage.AR,
    livingPlayers: List<Player>,
    allPlayers: List<Player>,
    currentVoterIndex: Int,
    votesMap: Map<String, String?>,
    onCastVote: (targetPlayerId: String?) -> Unit
) {
    val isAr = currentLanguage == AppLanguage.AR
    val context = androidx.compose.ui.platform.LocalContext.current
    val currentVoter = livingPlayers.getOrNull(currentVoterIndex) ?: return
    val candidates = livingPlayers.filter { it.id != currentVoter.id }

    var selectedTargetId by remember(currentVoterIndex) { mutableStateOf<String?>(null) }
    var isSkipSelected by remember(currentVoterIndex) { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MoodyBackgroundGradient)
    ) {
        // Neon ambient radial glow effect
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFFDC2626).copy(alpha = 0.35f),
                            Color(0xFF7C3AED).copy(alpha = 0.2f),
                            Color.Transparent
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header Instruction Card
            FrostedGlassCard(
                shape = RoundedCornerShape(26.dp),
                borderBrush = GlassBorderGradient,
                backgroundColor = Color(0xCC131622),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isAr) "📢 مرحلة التصويت العلني المباشر" else "📢 Live Public Voting Phase",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = CrimsonPrimary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = if (isAr) "الآن دور اللاعب: ${currentVoter.name}" else "Now voting: ${currentVoter.name}",
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                        color = GoldAccent
                    )

                    Text(
                        text = if (isAr) "اختر من تصوت ضده علناً، وسيقوم الـ AI Host بإعلان صوتك للجميع!" else "Choose who to vote against publicly, AI Host will speak your vote!",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFCBD5E1)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Public Votes Feed so far
            if (votesMap.isNotEmpty()) {
                FrostedGlassCard(
                    shape = RoundedCornerShape(16.dp),
                    borderBrush = GlassBorderGradient,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(4.dp)) {
                        Text(
                            text = if (isAr) "📋 سجل التصويت العلني الحكيم حتى الآن:" else "📋 Live Public Vote Log:",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = GoldAccent
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        votesMap.forEach { (voterId, targetId) ->
                            val voterName = allPlayers.find { it.id == voterId }?.name ?: voterId
                            val targetName = if (targetId != null) (allPlayers.find { it.id == targetId }?.name ?: targetId) else (if (isAr) "تخطي" else "Skip")
                            Text(
                                text = "• $voterName 🗳️ ➔ $targetName",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Candidates List
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(candidates) { candidate ->
                    val isSelected = selectedTargetId == candidate.id && !isSkipSelected

                    FrostedGlassCard(
                        backgroundColor = if (isSelected) Color(0xCC3B1218) else NoirSurface,
                        shape = RoundedCornerShape(16.dp),
                        borderBrush = if (isSelected) Brush.horizontalGradient(listOf(CrimsonPrimary, GoldAccent)) else GlassBorderGradient,
                        onClick = {
                            selectedTargetId = candidate.id
                            isSkipSelected = false
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("candidate_vote_${candidate.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = candidate.name,
                                    tint = if (isSelected) CrimsonPrimary else Color(0xFF90A4AE)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = candidate.name,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    ),
                                    color = Color.White
                                )
                            }

                            Icon(
                                imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                contentDescription = "Select",
                                tint = if (isSelected) CrimsonPrimary else Color(0xFF546E7A)
                            )
                        }
                    }
                }

                item {
                    // Skip Option
                    FrostedGlassCard(
                        backgroundColor = if (isSkipSelected) Color(0xCC262010) else NoirSurface,
                        shape = RoundedCornerShape(16.dp),
                        borderBrush = if (isSkipSelected) Brush.horizontalGradient(listOf(GoldAccent, Color.White)) else GlassBorderGradient,
                        onClick = {
                            isSkipSelected = true
                            selectedTargetId = null
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("option_skip_vote")
                    ) {
                        Row(
                            modifier = Modifier.padding(4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.SkipNext,
                                    contentDescription = "Skip",
                                    tint = GoldAccent
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = if (isAr) "امتناع عن التصويت ⚪" else "Abstain / Skip Vote ⚪",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = if (isSkipSelected) FontWeight.Bold else FontWeight.Normal
                                    ),
                                    color = GoldAccent
                                )
                            }

                            Icon(
                                imageVector = if (isSkipSelected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                contentDescription = "Select Skip",
                                tint = if (isSkipSelected) GoldAccent else Color(0xFF546E7A)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Confirm Vote Button
            Button(
                onClick = {
                    SoundFxManager.playGlassClick(context)
                    if (isSkipSelected) {
                        onCastVote(null)
                    } else if (selectedTargetId != null) {
                        onCastVote(selectedTargetId)
                    }
                },
                enabled = isSkipSelected || selectedTargetId != null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("btn_confirm_vote"),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                shape = RoundedCornerShape(20.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(Color(0xFFDC2626), Color(0xFFEF4444), Color(0xFFF59E0B))
                            ),
                            shape = RoundedCornerShape(20.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isAr) "إعلان التصويت علناً ونطقه 📢" else "Announce Public Vote & Speak 📢",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        ),
                        color = Color.White
                    )
                }
            }
        }
    }
}

