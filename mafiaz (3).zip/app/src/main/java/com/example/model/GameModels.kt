package com.example.model

enum class Team(
    val titleAr: String,
    val titleEn: String
) {
    MAFIA("فريق المافيا 😈", "Mafia Team 😈"),
    CITIZENS("فريق المواطنين 😇", "Citizens Team 😇");

    fun title(lang: AppLanguage): String = if (lang == AppLanguage.AR) titleAr else titleEn
}

enum class Role(
    val titleAr: String,
    val titleEn: String,
    val descriptionAr: String,
    val descriptionEn: String,
    val secretGuidanceAr: String,
    val secretGuidanceEn: String,
    val badgeIcon: String,
    val team: Team,
    val isSpecialRole: Boolean = true
) {
    MAFIA(
        titleAr = "المافيا",
        titleEn = "Mafia",
        descriptionAr = "أنت القاتل الخفي في الظلال. تخطط وتغتال الأهداف صمتاً دون أن يُكشف أمرك.",
        descriptionEn = "You operate in the shadows. Silently eliminate targets without getting caught.",
        secretGuidanceAr = "أنت المافيا! هدفك القضاء على الجميع دون كشفك.",
        secretGuidanceEn = "You are Mafia! Your goal is to eliminate everyone quietly.",
        badgeIcon = "😈",
        team = Team.MAFIA
    ),
    DOCTOR(
        titleAr = "الطبيب",
        titleEn = "Doctor",
        descriptionAr = "حارس الحياة وحامي الأبرياء. اختر لاعباً واحداً كل ليلة لحمايته من طلقات المافيا.",
        descriptionEn = "Guardian of innocent lives. Protect one player each night from Mafia attacks.",
        secretGuidanceAr = "أنت الطبيب! مهمتك حماية شخص واحد كل ليلة.",
        secretGuidanceEn = "You are the Doctor! Protect one person each night.",
        badgeIcon = "🩺",
        team = Team.CITIZENS
    ),
    DETECTIVE(
        titleAr = "المحقق",
        titleEn = "Detective",
        descriptionAr = "عين العدالة التي لا تنام. اختر لاعباً كل ليلة للتحري عن هويته الحقيقية.",
        descriptionEn = "Sleepless eye of justice. Inspect one player each night to learn their alignment.",
        secretGuidanceAr = "أنت المحقق! يمكنك التحري عن هوية لاعب واحد كل ليلة.",
        secretGuidanceEn = "You are the Detective! Inspect one player's identity each night.",
        badgeIcon = "🔍",
        team = Team.CITIZENS
    ),
    CITIZEN(
        titleAr = "المواطن البريء",
        titleEn = "Innocent Citizen",
        descriptionAr = "مواطن صلب يعتمد على الذكاء والملاحظة وقوة النقاش لكشف الخونة بالتصويت.",
        descriptionEn = "Rely on logic, observation, and debate to uncover traitors through voting.",
        secretGuidanceAr = "أنت مواطن بريء! هدفك النقاش وكشف المافيا بالتصويت.",
        secretGuidanceEn = "You are an Innocent Citizen! Debate and vote out the Mafia.",
        badgeIcon = "👔",
        team = Team.CITIZENS,
        isSpecialRole = false
    );

    fun title(lang: AppLanguage): String = if (lang == AppLanguage.AR) titleAr else titleEn
    fun description(lang: AppLanguage): String = if (lang == AppLanguage.AR) descriptionAr else descriptionEn
    fun secretGuidance(lang: AppLanguage): String = if (lang == AppLanguage.AR) secretGuidanceAr else secretGuidanceEn
}

data class Player(
    val id: String,
    val name: String,
    val role: Role,
    val isAlive: Boolean = true,
    val votesCount: Int = 0,
    val revealedRoleAtEnd: Boolean = false,
    val isMafiaBoss: Boolean = false
)

enum class GameStage {
    HOME,               // الشاشة الرئيسية
    HOW_TO_PLAY,        // شرح القواعد والأدوار
    SETUP,              // إعداد عدد وأسماء اللاعبين
    ROLE_DISTRIBUTION,  // كشف البطاقات والممرات السرية
    DAY_DISCUSSION,     // مرحلة النهار والتحقيق أسئلة الـ AI Host
    VOTING,             // مرحلة التصويت العلني
    VOTING_RESULT,      // نتائج التصويت والإقصاء
    NIGHT_PASS,         // مرحلة الليل لمنع الغش (مربوطة بالتضليل للمواطن)
    MORNING_REPORT,     // إعلان نتائج الليل (المرتبطة باختيارات المافيا والطبيب)
    VICTORY             // شاشة الفوز الملونة والنتائج النهائية
}

data class NightActionRecord(
    val mafiaSuggestedTargetId: String? = null,
    val mafiaTargetId: String? = null,
    val doctorProtectedId: String? = null,
    val detectiveCheckedId: String? = null,
    val detectiveResultIsMafia: Boolean? = null
)

data class GameStats(
    val roundNumber: Int = 1,
    val totalEliminated: Int = 0,
    val successfulDoctorSaves: Int = 0,
    val detectiveChecksCount: Int = 0,
    val historyLog: List<String> = emptyList()
)
