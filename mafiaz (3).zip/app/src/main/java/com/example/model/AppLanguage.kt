package com.example.model

enum class AppLanguage {
    AR,
    EN
}
