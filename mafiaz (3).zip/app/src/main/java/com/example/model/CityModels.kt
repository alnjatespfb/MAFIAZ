package com.example.model

import androidx.compose.ui.graphics.Color

enum class CityId {
    DARK_CITY,       // مدينة العتمة (مجانية)
    GOLDEN_MANSION,  // قصر المافيا الذهبي (VIP)
    TOKYO_NIGHT,     // طوكيو الليلية (شراء / VIP)
    CHICAGO_1930S,   // شيكاغو الثلاثينيات (شراء / VIP)
    CYBERPUNK_SLUMS  // السيبربنك (VIP)
}

data class CityTheme(
    val id: CityId,
    val nameAr: String,
    val nameEn: String,
    val isFree: Boolean = false,
    val isVipExclusive: Boolean = false,
    val standalonePrice: String? = null,
    val iconEmoji: String,
    val taglineAr: String,
    val taglineEn: String,
    // Custom Role Titles for this theme
    val mafiaTitleAr: String,
    val mafiaTitleEn: String,
    val citizenTitleAr: String,
    val citizenTitleEn: String,
    val doctorTitleAr: String,
    val doctorTitleEn: String,
    val detectiveTitleAr: String,
    val detectiveTitleEn: String,
    // Special/Super Role
    val specialRoleNameAr: String?,
    val specialRoleNameEn: String?,
    val specialRoleDescAr: String?,
    val specialRoleDescEn: String?,
    val specialRoleBadge: String?,
    // Visual styling
    val bgColors: List<Color>,
    val cardBg: Color,
    val cardBorder: Color,
    val primaryAccent: Color,
    val secondaryAccent: Color,
    val buttonGradient: List<Color>,
    val textColor: Color = Color.White
)

object CityThemes {
    val DARK_CITY = CityTheme(
        id = CityId.DARK_CITY,
        nameAr = "مدينة العتمة",
        nameEn = "Dark City",
        isFree = true,
        iconEmoji = "🌃",
        taglineAr = "النسخة الأصلية الكلاسيكية من صراع المافيا والمواطنين.",
        taglineEn = "The original classic clash between Mafia and Citizens.",
        mafiaTitleAr = "المافيا",
        mafiaTitleEn = "Mafia",
        citizenTitleAr = "المواطن البريء",
        citizenTitleEn = "Innocent Citizen",
        doctorTitleAr = "الطبيب",
        doctorTitleEn = "Doctor",
        detectiveTitleAr = "المحقق",
        detectiveTitleEn = "Detective",
        specialRoleNameAr = null,
        specialRoleNameEn = null,
        specialRoleDescAr = null,
        specialRoleDescEn = null,
        specialRoleBadge = null,
        bgColors = listOf(Color(0xFF0F0F1A), Color(0xFF131622), Color(0xFF000000)),
        cardBg = Color(0xCC131622),
        cardBorder = Color(0x667C3AED),
        primaryAccent = Color(0xFFDC2626),
        secondaryAccent = Color(0xFF7C3AED),
        buttonGradient = listOf(Color(0xFFDC2626), Color(0xFF7C3AED), Color(0xFFF59E0B))
    )

    val GOLDEN_MANSION = CityTheme(
        id = CityId.GOLDEN_MANSION,
        nameAr = "قصر المافيا الذهبي",
        nameEn = "Golden Mansion",
        isVipExclusive = true,
        iconEmoji = "🏰",
        taglineAr = "فخامة مخملية حمراء مع إطارات ذهبية وأجواء ملكية ساحرة.",
        taglineEn = "Velvet red luxury with gold accents and royal atmosphere.",
        mafiaTitleAr = "العرّاب",
        mafiaTitleEn = "The Godfather",
        citizenTitleAr = "الخادم",
        citizenTitleEn = "Servant",
        doctorTitleAr = "الترياق",
        doctorTitleEn = "Antidote",
        detectiveTitleAr = "الحارس الملكي",
        detectiveTitleEn = "Royal Guard",
        specialRoleNameAr = "المحامي الخائن",
        specialRoleNameEn = "Corrupt Lawyer",
        specialRoleDescAr = "يضلل المحقق في الليل إذا تم الكشف عليه ويظهر كمواطن بريء.",
        specialRoleDescEn = "Misleads the Detective at night during inspection to appear as innocent.",
        specialRoleBadge = "⚖️",
        bgColors = listOf(Color(0xFF2B080C), Color(0xFF4A0E17), Color(0xFF180305)),
        cardBg = Color(0xCC3D0B12),
        cardBorder = Color(0xFFFFD700),
        primaryAccent = Color(0xFFFFD700),
        secondaryAccent = Color(0xFFD4AF37),
        buttonGradient = listOf(Color(0xFFFFD700), Color(0xFFB8860B), Color(0xFF8B0000))
    )

    val TOKYO_NIGHT = CityTheme(
        id = CityId.TOKYO_NIGHT,
        nameAr = "طوكيو الليلية",
        nameEn = "Tokyo Underground",
        standalonePrice = "$0.99",
        iconEmoji = "🌸",
        taglineAr = "أضواء النيون البفسفورية وأشجار الكرز مع أسلوب الساموراي والياكوزا.",
        taglineEn = "Phosphor neon lights and cherry blossoms with Samurai style.",
        mafiaTitleAr = "الياكوزا",
        mafiaTitleEn = "Yakuza",
        citizenTitleAr = "القروي",
        citizenTitleEn = "Villager",
        doctorTitleAr = "العشّاب",
        doctorTitleEn = "Herbalist",
        detectiveTitleAr = "الساموراي",
        detectiveTitleEn = "Samurai",
        specialRoleNameAr = "النينجا السري",
        specialRoleNameEn = "Shinobi",
        specialRoleDescAr = "ينجو من أول محاولة قتل من الياكوزا وينتقم بقتل أحدهم في الليلة التالية.",
        specialRoleDescEn = "Survives first assassination attempt and retaliates the next night.",
        specialRoleBadge = "🥷",
        bgColors = listOf(Color(0xFF0A192F), Color(0xFF172A45), Color(0xFF020C1B)),
        cardBg = Color(0xCC0A2540),
        cardBorder = Color(0xFF00F5D4),
        primaryAccent = Color(0xFF00F5D4),
        secondaryAccent = Color(0xFFFF70A6),
        buttonGradient = listOf(Color(0xFF00F5D4), Color(0xFF00B4D8), Color(0xFFFF70A6))
    )

    val CHICAGO_1930S = CityTheme(
        id = CityId.CHICAGO_1930S,
        nameAr = "شيكاغو الثلاثينيات",
        nameEn = "Vintage Chicago 1930s",
        standalonePrice = "$0.99",
        iconEmoji = "🎷",
        taglineAr = "طابع ريترو بالأبيض والأسود مع لمسات الخشب الداكن وحقبة الجاز.",
        taglineEn = "Retro black & white tones with rich dark mahogany aesthetics.",
        mafiaTitleAr = "العصابة",
        mafiaTitleEn = "Gangster",
        citizenTitleAr = "المواطن الصالح",
        citizenTitleEn = "Good Citizen",
        doctorTitleAr = "المسعف",
        doctorTitleEn = "Paramedic",
        detectiveTitleAr = "المفتش",
        detectiveTitleEn = "Inspector",
        specialRoleNameAr = "الجاسوس",
        specialRoleNameEn = "Informant",
        specialRoleDescAr = "يستطيع التنصت ومعرفة جزء من حوار العصابة ليلة واحدة فقط.",
        specialRoleDescEn = "Can eavesdrop and learn part of gang chatter for 1 night.",
        specialRoleBadge = "🕵️",
        bgColors = listOf(Color(0xFF1A1412), Color(0xFF3D2B1F), Color(0xFF0E0A08)),
        cardBg = Color(0xCC2A1E18),
        cardBorder = Color(0xFFD4A373),
        primaryAccent = Color(0xFFD4A373),
        secondaryAccent = Color(0xFFFAEDCD),
        buttonGradient = listOf(Color(0xFFD4A373), Color(0xFFA3704C), Color(0xFF523A28))
    )

    val CYBERPUNK_SLUMS = CityTheme(
        id = CityId.CYBERPUNK_SLUMS,
        nameAr = "السيبربنك",
        nameEn = "Cyberpunk Slums",
        isVipExclusive = true,
        iconEmoji = "🤖",
        taglineAr = "هولوغرام مستقبلي وشبكات المشفّرين مع تأثيرات الشاشات التكنولوجية.",
        taglineEn = "Futuristic hologram cyan & purple grids with cyberpunk UI.",
        mafiaTitleAr = "الهكر",
        mafiaTitleEn = "Hacker",
        citizenTitleAr = "المستكشف",
        citizenTitleEn = "Explorer",
        doctorTitleAr = "برنامج الحماية",
        doctorTitleEn = "Firewall",
        detectiveTitleAr = "المشفّر",
        detectiveTitleEn = "Decrypter",
        specialRoleNameAr = "الذكاء الاصطناعي الثائر",
        specialRoleNameEn = "Rogue AI",
        specialRoleDescAr = "يجمّد تصويت أحد اللاعبين في النهار ومنعه من النقاش لجميع الأدوار.",
        specialRoleDescEn = "Freezes a player's vote during the day phase and prevents discussion.",
        specialRoleBadge = "⚡",
        bgColors = listOf(Color(0xFF0D0221), Color(0xFF240046), Color(0xFF03001E)),
        cardBg = Color(0xCC180A3A),
        cardBorder = Color(0xFF00F0FF),
        primaryAccent = Color(0xFF00F0FF),
        secondaryAccent = Color(0xFF7B2CBF),
        buttonGradient = listOf(Color(0xFF00F0FF), Color(0xFF7B2CBF), Color(0xFFC77DFF))
    )

    val ALL_THEMES = listOf(DARK_CITY, GOLDEN_MANSION, TOKYO_NIGHT, CHICAGO_1930S, CYBERPUNK_SLUMS)

    fun getTheme(id: CityId): CityTheme {
        return ALL_THEMES.find { it.id == id } ?: DARK_CITY
    }
}
