package com.example.data

import com.example.model.AppLanguage

object AiHostQuestions {
    val investigativeQuestionsAr = listOf(
        "من في رأيك كان يبتسم أو يتردد بشكل مشبوه عند استلام الهاتف وتفقد دوره؟",
        "سؤال موجه للجميع: لو كنت المافيا في هذه الجولة، من هو أول لاعب ستسعى للتخلص منه ولماذا؟",
        "اطلبوا من {P1} أن يقدم دليلاً أو تحليلاً يبرئ فيه {P2} أمام الطاولة!",
        "انظروا في عيني {P1} لمدة 5 ثوانٍ... هل تجدون هدوء براءة أم صمت قاتل خفي؟",
        "من هو الأكثر هدوءاً بشكل غير عادي اليوم؟ هل الهدوء استراتيجية مافيا أم براءة مواطن؟",
        "استجوبوا {P1}: ما هو سبب ارتباكك أو ثقتك الزائدة عند بدء مرحلة النقاش؟",
        "تحدي خاطف: عدوا حتى 3 واشروا جميعاً بنفس اللحظة نحو الشخص الأشد اشتباهًا!",
        "سؤال ذكي: إذا ثبت أن {P1} مواطن بريء، فمن سيكون شريك الجريمة الأول في القائمة؟",
        "اطلبوا من {P1} و {P2} تبادل الاتهامات المباشرة لمدة 30 ثانية لتحديد الصادق منهما!",
        "من منكم يعتقد أن هدوء {P1} يذكرنا بالقصص الدرامية المشبوهة؟",
        "اسألوا {P1}: إذا كشفت المافيا اليوم، من تتوقع أن يكون الطبيب الذي يحميكم؟",
        "يا جماعة، لاحظتم نبرة صوت {P1}؟ ناقشوه في أدلته قبل انتهاء الوقت!"
    )

    val investigativeQuestionsEn = listOf(
        "Who do you think was smiling or hesitating suspiciously when checking their secret role?",
        "Question for everyone: If you were Mafia this round, who is the first player you would eliminate and why?",
        "Ask {P1} to provide proof or an argument defending {P2} in front of everyone!",
        "Look into {P1}'s eyes for 5 seconds... Do you see innocent calm or a hidden killer?",
        "Who is unusually quiet today? Is silence a Mafia strategy or innocent citizen calm?",
        "Interrogate {P1}: What is the reason for your nervousness or overconfidence during discussion?",
        "Quick challenge: Count to 3 and everyone point simultaneously at the most suspicious person!",
        "Smart question: If {P1} turns out to be an innocent citizen, who is first on your suspect list?",
        "Ask {P1} and {P2} to exchange direct accusations for 30 seconds to reveal the truth!",
        "Who thinks {P1}'s quiet demeanor resembles a drama movie suspect?",
        "Ask {P1}: If Mafia is exposed today, who do you expect is the Doctor protecting you?",
        "Did anyone notice {P1}'s tone of voice? Discuss their statements before time runs out!"
    )

    fun getRandomQuestion(p1Name: String? = null, p2Name: String? = null, language: AppLanguage = AppLanguage.AR): String {
        val list = if (language == AppLanguage.AR) investigativeQuestionsAr else investigativeQuestionsEn
        val defaultP1 = if (language == AppLanguage.AR) "أحد اللاعبين" else "a player"
        val defaultP2 = if (language == AppLanguage.AR) "مشتبه به آخر" else "another suspect"

        val raw = list.random()
        return raw.replace("{P1}", p1Name ?: defaultP1)
            .replace("{P2}", p2Name ?: defaultP2)
    }
}
