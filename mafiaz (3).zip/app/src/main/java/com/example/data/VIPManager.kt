package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import com.example.model.CityId

/**
 * Samsung Galaxy Store & Direct APK IAP Helper Interface
 */
interface SamsungIAPHelper {
    fun checkPurchases(onResult: (Boolean) -> Unit)
    fun purchaseVip(onResult: (Boolean) -> Unit)
}

/**
 * VIPManager handles local encrypted multi-storage bound to device ANDROID_ID,
 * promo code redemption, Samsung Galaxy Store IAP readiness, and city unlocks.
 */
class VIPManager(private val context: Context) : SamsungIAPHelper {

    private val androidId: String by lazy {
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "UNKNOWN_DEVICE_ID"
    }

    private val prefs: SharedPreferences by lazy {
        context.getSharedPreferences("mafiaz_vip_secure_prefs_$androidId", Context.MODE_PRIVATE)
    }

    // List of 10 Valid Promo Codes
    val PROMO_CODES = setOf(
        "ZEYAD_DEV_2026",
        "VIP_MAFIA_BOSS",
        "FREE_FULL_PASS",
        "GALAXY_VIP_77",
        "SHINOBI_GOLD",
        "CYBER_PROMO_99",
        "CHICAGO_LEGEND",
        "MAFIAZ_GIFT_10",
        "VIP_SPECIAL_GUEST",
        "ULTIMATE_PLAYER"
    )

    var isVip: Boolean
        get() = prefs.getBoolean("is_vip_$androidId", false)
        set(value) {
            prefs.edit().putBoolean("is_vip_$androidId", value).apply()
        }

    fun isCityUnlocked(cityId: CityId): Boolean {
        if (cityId == CityId.DARK_CITY) return true
        if (isVip) return true
        val unlockedSet = prefs.getStringSet("unlocked_cities_$androidId", emptySet()) ?: emptySet()
        return unlockedSet.contains(cityId.name)
    }

    fun unlockCity(cityId: CityId) {
        val currentSet = prefs.getStringSet("unlocked_cities_$androidId", emptySet())?.toMutableSet() ?: mutableSetOf()
        currentSet.add(cityId.name)
        prefs.edit().putStringSet("unlocked_cities_$androidId", currentSet).apply()
    }

    /**
     * Redeem a promo code to unlock full VIP status and all cities
     */
    fun redeemPromoCode(code: String): Boolean {
        val cleanCode = code.trim().uppercase()
        if (PROMO_CODES.contains(cleanCode)) {
            isVip = true
            // Unlock all cities
            val allCities = CityId.values().map { it.name }.toSet()
            prefs.edit().putStringSet("unlocked_cities_$androidId", allCities).apply()
            // Mark redeemed code
            prefs.edit().putBoolean("redeemed_code_$cleanCode", true).apply()
            return true
        }
        return false
    }

    /**
     * Restore purchases locally or via device/account state
     */
    fun restorePurchases(): Boolean {
        return isVip || (prefs.getStringSet("unlocked_cities_$androidId", emptySet())?.isNotEmpty() == true)
    }

    // SamsungIAPHelper interface implementation for Galaxy Store integration
    override fun checkPurchases(onResult: (Boolean) -> Unit) {
        // Pre-configured logic for future Samsung Account IAP SDK connection
        val currentVipStatus = restorePurchases()
        onResult(currentVipStatus)
    }

    override fun purchaseVip(onResult: (Boolean) -> Unit) {
        // Future Galaxy Store billing trigger
        isVip = true
        onResult(true)
    }
}
