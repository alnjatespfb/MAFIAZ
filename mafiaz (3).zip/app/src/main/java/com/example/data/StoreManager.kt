package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.CityId

class StoreManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("mafiaz_store_prefs", Context.MODE_PRIVATE)

    var isVip: Boolean
        get() = prefs.getBoolean("is_vip", false)
        set(value) {
            prefs.edit().putBoolean("is_vip", value).apply()
        }

    fun isCityUnlocked(cityId: CityId): Boolean {
        if (cityId == CityId.DARK_CITY) return true
        if (isVip) return true
        val unlockedSet = prefs.getStringSet("unlocked_cities", emptySet()) ?: emptySet()
        return unlockedSet.contains(cityId.name)
    }

    fun unlockCity(cityId: CityId) {
        val currentSet = prefs.getStringSet("unlocked_cities", emptySet())?.toMutableSet() ?: mutableSetOf()
        currentSet.add(cityId.name)
        prefs.edit().putStringSet("unlocked_cities", currentSet).apply()
    }

    fun restorePurchases(): Boolean {
        // Keeps VIP or restores cities
        return isVip || (prefs.getStringSet("unlocked_cities", emptySet())?.isNotEmpty() == true)
    }
}
