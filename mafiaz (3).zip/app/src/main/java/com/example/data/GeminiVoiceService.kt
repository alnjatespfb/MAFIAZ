package com.example.data

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiVoiceService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .build()

    private val SYSTEM_INSTRUCTION = """
        أنت المساعد الصوتي الذكي والراوي الدرامي للعبة مافيا (MAFIAZ).
        دورك هو إلقاء التوجيهات وإجابة أسئلة اللاعبين بأسلوب سينمائي حماسي ومشوق.
        القواعد الأساسية:
        1. الإجابات يجب أن تكون قصيرة ومباشرة (جملة أو جملتين فقط) لتناسب الإلقاء الصوتي.
        2. يمكنك استخدام اللغة العربية الفصحى المبسطة أو العامية المصرية المحببة.
        3. حافظ على أسلوب الإثارة والغموض بدون كشف أسرار وأدوار اللاعبين المحفوظة بالسرية!
    """.trimIndent()

    suspend fun generateVoiceResponse(
        prompt: String,
        gameStateContext: String = ""
    ): String? = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext null
        }

        try {
            val fullPrompt = if (gameStateContext.isNotBlank()) {
                "سياق اللعبة الحالية: [$gameStateContext]\nسؤال/طلب اللاعب: $prompt"
            } else {
                prompt
            }

            val jsonBody = JSONObject().apply {
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_INSTRUCTION)))
                })
                put("contents", JSONArray().put(
                    JSONObject().apply {
                        put("parts", JSONArray().put(JSONObject().put("text", fullPrompt)))
                    }
                ))
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.7)
                    put("maxOutputTokens", 150)
                })
            }

            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
            val requestBody = jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType())

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@use null
                val bodyStr = response.body?.string() ?: return@use null
                val jsonResponse = JSONObject(bodyStr)
                val candidates = jsonResponse.optJSONArray("candidates") ?: return@use null
                if (candidates.length() == 0) return@use null
                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.optJSONObject("content") ?: return@use null
                val parts = content.optJSONArray("parts") ?: return@use null
                if (parts.length() == 0) return@use null
                val text = parts.getJSONObject(0).optString("text", "").trim()
                if (text.isNotBlank()) text else null
            }
        } catch (e: Exception) {
            null
        }
    }
}
