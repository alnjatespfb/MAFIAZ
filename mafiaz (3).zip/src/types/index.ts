export type DeviceType = 'POS' | 'SCANNER';
export type DeviceStatus = 'PENDING' | 'APPROVED' | 'DISABLED' | 'REJECTED';
export type EmployeeRole = 'ADMIN' | 'MANAGER' | 'CASHIER' | 'INVENTORY' | 'admin' | 'manager' | 'cashier';
export type PaymentMethod = 'CASH' | 'KNET' | 'CARD' | 'SPLIT';

export type EmployeePermission =
  | 'VIEW_PRODUCTS'
  | 'CREATE_PRODUCTS'
  | 'EDIT_PRODUCTS'
  | 'DELETE_PRODUCTS'
  | 'ADJUST_STOCK'
  | 'CREATE_SALE'
  | 'VIEW_SALES'
  | 'VIEW_REPORTS'
  | 'MANAGE_EMPLOYEES'
  | 'MANAGE_DEVICES'
  | 'MANAGE_STORE';

export const ALL_PERMISSIONS: { key: EmployeePermission; label: string; description: string }[] = [
  { key: 'VIEW_PRODUCTS', label: 'View Products', description: 'Can view product list and prices' },
  { key: 'CREATE_PRODUCTS', label: 'Create Products', description: 'Can add new products to store' },
  { key: 'EDIT_PRODUCTS', label: 'Edit Products', description: 'Can modify product details' },
  { key: 'DELETE_PRODUCTS', label: 'Delete Products', description: 'Can remove or deactivate products' },
  { key: 'ADJUST_STOCK', label: 'Adjust Stock', description: 'Can update inventory on-hand count' },
  { key: 'CREATE_SALE', label: 'Process Sales (POS)', description: 'Can operate POS register and ring transactions' },
  { key: 'VIEW_SALES', label: 'View Sales History', description: 'Can view completed sales audit logs' },
  { key: 'VIEW_REPORTS', label: 'View Reports', description: 'Can access analytics and revenue reports' },
  { key: 'MANAGE_EMPLOYEES', label: 'Manage Employees', description: 'Can add/edit staff and roles' },
  { key: 'MANAGE_DEVICES', label: 'Manage Devices', description: 'Can approve/reject POS and scanner terminals' },
  { key: 'MANAGE_STORE', label: 'Manage Store Profile', description: 'Can edit store settings and tax rates' },
];

export interface UserProfile {
  userId: string;
  email: string;
  displayName: string;
  ownedStoreIds: string[];
  createdAt: string;
}

export interface Store {
  storeId: string;
  ownerId: string;
  name: string;
  logo?: string;
  country: string;
  currency: string;
  address?: string;
  phone?: string;
  taxRate: number;
  createdAt: string;
  updatedAt?: string;
  serverCreatedAt?: any;
}

export interface Product {
  productId: string;
  storeId: string;
  barcode: string;
  name: string;
  category: string;
  sellingPrice: number;
  price?: number; // Backward compatibility alias
  costPrice?: number;
  quantity: number;
  stockQuantity?: number; // Backward compatibility alias
  minimumStock?: number;
  minStockAlert?: number; // Backward compatibility alias
  image?: string;
  active: boolean;
  sku?: string;
  createdAt?: string;
  updatedAt: string;
}

export interface Device {
  deviceId: string;
  storeId: string;
  name: string;
  deviceName?: string; // Alias
  type: DeviceType;
  deviceType?: DeviceType; // Alias
  status: DeviceStatus;
  pairedPosDeviceId?: string;
  registeredBy?: string;
  pairedAt?: string;
  lastSeen?: string;
  lastActiveAt?: string; // Alias
  assignedEmployee?: string;
  createdAt: string;
}

export interface Employee {
  employeeId: string;
  storeId: string;
  name: string;
  email?: string;
  role: EmployeeRole;
  pinCode: string;
  permissions: EmployeePermission[];
  canSell?: boolean;
  canManageInventory?: boolean;
  canManageDevices?: boolean;
  canViewReports?: boolean;
  active: boolean;
  createdAt: string;
}

export interface SaleItem {
  productId: string;
  barcode?: string;
  name: string;
  sku?: string;
  price: number;
  unitPrice?: number; // Alias
  quantity: number;
  total: number;
  totalPrice?: number; // Alias
}

export interface Sale {
  saleId: string;
  transactionId: string;
  storeId: string;
  employeeId: string;
  employeeName: string;
  deviceId: string;
  items: SaleItem[];
  subtotal: number;
  discount?: number;
  taxTotal: number;
  total: number;
  paymentMethod: PaymentMethod;
  amountTendered?: number;
  changeDue?: number;
  notes?: string;
  referenceNumber?: string; // e.g. KNET approval code
  createdAt: string;
  syncStatus?: 'SYNCED' | 'PENDING' | 'FAILED';
  offlineQueued?: boolean;
}

export interface OfflinePendingSale {
  transactionId: string;
  storeId: string;
  saleData: Omit<Sale, 'saleId'>;
  queuedAt: number;
  retryCount: number;
  lastError?: string;
}

export interface ScanEvent {
  eventId: string;
  storeId: string;
  scannerDeviceId: string;
  targetPosDeviceId: string;
  barcode: string;
  processed: boolean;
  createdAt: string;
}

export interface AccessRequest {
  requestId: string;
  storeId: string;
  requesterName: string;
  deviceId: string;
  deviceName: string;
  requestedPermission: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  createdAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
}

export interface POSSession {
  sessionId: string;
  storeId: string;
  employeeId: string;
  employeeName: string;
  deviceId: string;
  loginTime: string;
  logoutTime?: string;
  status: 'ACTIVE' | 'CLOSED';
}
