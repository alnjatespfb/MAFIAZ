import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { StoreProvider, useStore } from './context/StoreContext';
import { DeviceProvider, useDevice } from './context/DeviceContext';
import { TopBar } from './components/TopBar/TopBar';
import { Sidebar, NavTab } from './components/Sidebar/Sidebar';
import { OfflineNotice } from './components/OfflineNotice';
import { AuthScreen } from './components/Auth/AuthScreen';
import { CreateStoreModal } from './components/StoreSelector/CreateStoreModal';
import { DeviceEnrollmentModal } from './components/Devices/DeviceEnrollmentModal';

// Functional Views
import { AdminDashboard } from './components/Dashboard/AdminDashboard';
import { PosTerminal } from './components/POS/PosTerminal';
import { ProductManager } from './components/Products/ProductManager';
import { InventoryManager } from './components/Inventory/InventoryManager';
import { EmployeeManager } from './components/Employees/EmployeeManager';
import { DeviceManager } from './components/Devices/DeviceManager';
import { SalesAudit } from './components/Sales/SalesAudit';
import { ReportsManager } from './components/Reports/ReportsManager';
import { StoreSettings } from './components/StoreSettings/StoreSettings';

import { Store as StoreIcon, Plus, Loader2 } from 'lucide-react';

const MainLayout: React.FC = () => {
  const { user, loading: authLoading } = useAuth();
  const { stores, activeStore, loading: storesLoading } = useStore();
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [createStoreOpen, setCreateStoreOpen] = useState(false);
  const [deviceEnrollmentOpen, setDeviceEnrollmentOpen] = useState(false);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-400">
        <Loader2 className="w-8 h-8 text-emerald-500 animate-spin mb-3" />
        <span className="text-sm font-medium">Initializing Cloud POS engine...</span>
      </div>
    );
  }

  if (!user) {
    return <AuthScreen />;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Top Header */}
      <TopBar
        onOpenCreateStore={() => setCreateStoreOpen(true)}
        onOpenDeviceEnrollment={() => setDeviceEnrollmentOpen(true)}
        onNavigateToTab={(tab) => setCurrentTab(tab as NavTab)}
        onToggleSidebar={() => setSidebarOpen((prev) => !prev)}
      />

      {/* Offline Status & Sync Alert Banner */}
      <OfflineNotice />

      {/* Main View Shell with Responsive Sidebar */}
      <div className="flex-1 flex overflow-hidden">
        <Sidebar
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          onOpenDeviceEnrollment={() => setDeviceEnrollmentOpen(true)}
        />

        {/* Content Viewport */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto">
            {storesLoading ? (
              <div className="py-24 text-center text-slate-400">
                <Loader2 className="w-8 h-8 text-emerald-500 animate-spin mx-auto mb-3" />
                <p className="text-sm">Loading store database...</p>
              </div>
            ) : stores.length === 0 ? (
              /* Empty Store Welcome Screen */
              <div className="max-w-md mx-auto my-16 bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center shadow-2xl space-y-4">
                <div className="w-16 h-16 rounded-2xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center mx-auto">
                  <StoreIcon className="w-9 h-9" />
                </div>
                <h2 className="text-2xl font-bold text-white">Create Your First Store</h2>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Welcome to CorePOS, <span className="text-slate-200 font-semibold">{user.displayName || user.email}</span>. To start managing products, ringing sales, and pairing Android phone scanners, register your first retail location.
                </p>
                <button
                  id="initial-create-store-button"
                  onClick={() => setCreateStoreOpen(true)}
                  className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-950 transition flex items-center justify-center space-x-2"
                >
                  <Plus className="w-4 h-4" />
                  <span>Create Retail Store</span>
                </button>
              </div>
            ) : (
              /* Render Active Functional Module */
              <div className="animate-in fade-in duration-100">
                {currentTab === 'dashboard' && (
                  <AdminDashboard
                    onNavigate={(tab) => setCurrentTab(tab as NavTab)}
                    onOpenEnrollment={() => setDeviceEnrollmentOpen(true)}
                  />
                )}
                {currentTab === 'pos' && (
                  <PosTerminal onOpenEnrollment={() => setDeviceEnrollmentOpen(true)} />
                )}
                {currentTab === 'products' && <ProductManager />}
                {currentTab === 'inventory' && <InventoryManager />}
                {currentTab === 'employees' && <EmployeeManager />}
                {currentTab === 'devices' && (
                  <DeviceManager onOpenEnrollment={() => setDeviceEnrollmentOpen(true)} />
                )}
                {currentTab === 'sales' && <SalesAudit />}
                {currentTab === 'reports' && <ReportsManager />}
                {currentTab === 'settings' && <StoreSettings />}
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Global Dialog Modals */}
      <CreateStoreModal
        isOpen={createStoreOpen}
        onClose={() => setCreateStoreOpen(false)}
      />

      <DeviceEnrollmentModal
        isOpen={deviceEnrollmentOpen}
        onClose={() => setDeviceEnrollmentOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <StoreProvider>
        <DeviceProvider>
          <MainLayout />
        </DeviceProvider>
      </StoreProvider>
    </AuthProvider>
  );
}
