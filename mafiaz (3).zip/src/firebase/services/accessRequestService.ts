import {
  collection,
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy,
  Unsubscribe,
} from 'firebase/firestore';
import { db, auth } from '../config';
import { AccessRequest } from '../../types';
import { handleFirestoreError, OperationType } from '../errors';

export async function createAccessRequest(
  storeId: string,
  input: {
    requesterName: string;
    deviceId: string;
    deviceName: string;
    requestedPermission: string;
  }
): Promise<AccessRequest> {
  const requestId = `req_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const path = `stores/${storeId}/accessRequests/${requestId}`;

  const request: AccessRequest = {
    requestId,
    storeId,
    requesterName: input.requesterName.trim(),
    deviceId: input.deviceId,
    deviceName: input.deviceName.trim(),
    requestedPermission: input.requestedPermission.trim(),
    status: 'PENDING',
    createdAt: new Date().toISOString(),
  };

  try {
    await setDoc(doc(db, 'stores', storeId, 'accessRequests', requestId), request);
    return request;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export function subscribeToAccessRequests(
  storeId: string,
  onUpdate: (requests: AccessRequest[]) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  const path = `stores/${storeId}/accessRequests`;
  const q = query(collection(db, 'stores', storeId, 'accessRequests'), orderBy('createdAt', 'desc'));

  return onSnapshot(
    q,
    (snapshot) => {
      const requests: AccessRequest[] = [];
      snapshot.forEach((d) => {
        requests.push(d.data() as AccessRequest);
      });
      onUpdate(requests);
    },
    (error) => {
      if (onError) onError(error);
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

export async function reviewAccessRequest(
  storeId: string,
  requestId: string,
  status: 'APPROVED' | 'REJECTED'
): Promise<void> {
  const currentUser = auth.currentUser;
  const path = `stores/${storeId}/accessRequests/${requestId}`;
  try {
    await updateDoc(doc(db, 'stores', storeId, 'accessRequests', requestId), {
      status,
      reviewedAt: new Date().toISOString(),
      reviewedBy: currentUser?.uid || 'admin',
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteAccessRequest(storeId: string, requestId: string): Promise<void> {
  const path = `stores/${storeId}/accessRequests/${requestId}`;
  try {
    await deleteDoc(doc(db, 'stores', storeId, 'accessRequests', requestId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}
