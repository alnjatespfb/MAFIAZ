import {
  collection,
  doc,
  runTransaction,
  query,
  orderBy,
  limit,
  onSnapshot,
  Unsubscribe,
} from 'firebase/firestore';
import { db } from '../config';
import { Sale, OfflinePendingSale } from '../../types';
import { handleFirestoreError, OperationType } from '../errors';

const OFFLINE_SALES_KEY = 'pos_offline_pending_sales';

// Local storage helpers strictly for offline queue
export function getOfflineSalesQueue(storeId?: string): OfflinePendingSale[] {
  try {
    const raw = localStorage.getItem(OFFLINE_SALES_KEY);
    if (!raw) return [];
    const all: OfflinePendingSale[] = JSON.parse(raw);
    if (storeId) {
      return all.filter((s) => s.storeId === storeId);
    }
    return all;
  } catch (e) {
    console.error('Failed to parse offline sales queue:', e);
    return [];
  }
}

export function saveToOfflineQueue(pendingSale: OfflinePendingSale): void {
  try {
    const queue = getOfflineSalesQueue();
    // Idempotent check in queue
    const exists = queue.some((q) => q.transactionId === pendingSale.transactionId);
    if (!exists) {
      queue.push(pendingSale);
      localStorage.setItem(OFFLINE_SALES_KEY, JSON.stringify(queue));
    }
  } catch (e) {
    console.error('Failed to save to offline queue:', e);
  }
}

export function removeFromOfflineQueue(transactionId: string): void {
  try {
    const queue = getOfflineSalesQueue();
    const filtered = queue.filter((q) => q.transactionId !== transactionId);
    localStorage.setItem(OFFLINE_SALES_KEY, JSON.stringify(filtered));
  } catch (e) {
    console.error('Failed to update offline queue:', e);
  }
}

// Atomic Sale Execution with Inventory Concurrency Protection & Idempotent Transaction Key
export async function executeSale(
  storeId: string,
  saleInput: Omit<Sale, 'saleId'>
): Promise<Sale> {
  const transactionId = saleInput.transactionId;
  const saleDocRef = doc(db, 'stores', storeId, 'sales', transactionId);
  const path = `stores/${storeId}/sales/${transactionId}`;

  try {
    const completedSale = await runTransaction(db, async (transaction) => {
      // 1. Idempotency Check: Check if this sale was already written
      const existingSaleDoc = await transaction.get(saleDocRef);
      if (existingSaleDoc.exists()) {
        console.warn(`Idempotent sale detection: Transaction ${transactionId} already processed.`);
        return existingSaleDoc.data() as Sale;
      }

      // 2. Concurrency & Inventory Integrity: Read all products and check stock
      const productDocs: { ref: any; currentStock: number; newStock: number; name: string }[] = [];

      for (const item of saleInput.items) {
        const prodRef = doc(db, 'stores', storeId, 'products', item.productId);
        const prodSnap = await transaction.get(prodRef);

        if (!prodSnap.exists()) {
          throw new Error(`Product "${item.name}" (ID: ${item.productId}) not found in inventory.`);
        }

        const data = prodSnap.data();
        const currentStock = Number(data.quantity ?? data.stockQuantity ?? 0);

        if (currentStock < item.quantity) {
          throw new Error(
            `Insufficient inventory for "${item.name}". Available: ${currentStock}, Requested: ${item.quantity}.`
          );
        }

        productDocs.push({
          ref: prodRef,
          currentStock,
          newStock: currentStock - item.quantity,
          name: item.name,
        });
      }

      // 3. Atomically decrement stock for all items
      const nowIso = new Date().toISOString();
      for (const p of productDocs) {
        transaction.update(p.ref, {
          quantity: p.newStock,
          stockQuantity: p.newStock,
          updatedAt: nowIso,
        });
      }

      // 4. Create Immutable Sale Audit Record
      const newSale: Sale = {
        ...saleInput,
        saleId: transactionId,
        syncStatus: 'SYNCED',
        createdAt: saleInput.createdAt || nowIso,
      };

      transaction.set(saleDocRef, newSale);
      return newSale;
    });

    // If sale was in offline queue, remove it now
    removeFromOfflineQueue(transactionId);
    return completedSale;
  } catch (error) {
    // If client is offline or network fails, queue for background sync
    if (
      !navigator.onLine ||
      (error instanceof Error &&
        (error.message.includes('offline') ||
          error.message.includes('network') ||
          error.message.includes('unavailable')))
    ) {
      saveToOfflineQueue({
        transactionId,
        storeId,
        saleData: {
          ...saleInput,
          syncStatus: 'PENDING',
        },
        queuedAt: Date.now(),
        retryCount: 0,
        lastError: error instanceof Error ? error.message : 'Network failure',
      });
      throw new Error('OFFLINE_QUEUED');
    }

    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// Background / Triggered Synchronization for Offline Queue
export async function syncOfflineSales(
  storeId: string,
  onSyncResult?: (syncedCount: number, failedCount: number) => void
): Promise<{ synced: number; failed: number }> {
  if (!navigator.onLine) {
    return { synced: 0, failed: 0 };
  }

  const queue = getOfflineSalesQueue(storeId);
  if (queue.length === 0) {
    return { synced: 0, failed: 0 };
  }

  let synced = 0;
  let failed = 0;

  for (const pending of queue) {
    try {
      await executeSale(storeId, {
        ...pending.saleData,
        offlineQueued: true,
        syncStatus: 'SYNCED',
      });
      removeFromOfflineQueue(pending.transactionId);
      synced++;
    } catch (e: any) {
      if (e.message === 'OFFLINE_QUEUED') {
        // Still offline
        break;
      }
      console.error(`Offline sync failed for transaction ${pending.transactionId}:`, e);
      failed++;
    }
  }

  if (onSyncResult) onSyncResult(synced, failed);
  return { synced, failed };
}

export function subscribeToStoreSales(
  storeId: string,
  onUpdate: (sales: Sale[]) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  const path = `stores/${storeId}/sales`;
  const q = query(collection(db, 'stores', storeId, 'sales'), orderBy('createdAt', 'desc'), limit(150));

  return onSnapshot(
    q,
    (snapshot) => {
      const sales: Sale[] = [];
      snapshot.forEach((d) => {
        sales.push(d.data() as Sale);
      });
      onUpdate(sales);
    },
    (error) => {
      if (onError) onError(error);
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}
