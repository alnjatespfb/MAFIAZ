import {
  collection,
  doc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  onSnapshot,
  Unsubscribe,
} from 'firebase/firestore';
import { db } from '../config';
import { Employee, EmployeeRole, EmployeePermission } from '../../types';
import { handleFirestoreError, OperationType } from '../errors';

export function getDefaultPermissionsForRole(role: EmployeeRole): EmployeePermission[] {
  const normalizedRole = role.toUpperCase();
  switch (normalizedRole) {
    case 'ADMIN':
      return [
        'VIEW_PRODUCTS',
        'CREATE_PRODUCTS',
        'EDIT_PRODUCTS',
        'DELETE_PRODUCTS',
        'ADJUST_STOCK',
        'CREATE_SALE',
        'VIEW_SALES',
        'VIEW_REPORTS',
        'MANAGE_EMPLOYEES',
        'MANAGE_DEVICES',
        'MANAGE_STORE',
      ];
    case 'MANAGER':
      return [
        'VIEW_PRODUCTS',
        'CREATE_PRODUCTS',
        'EDIT_PRODUCTS',
        'ADJUST_STOCK',
        'CREATE_SALE',
        'VIEW_SALES',
        'VIEW_REPORTS',
        'MANAGE_DEVICES',
      ];
    case 'INVENTORY':
      return [
        'VIEW_PRODUCTS',
        'CREATE_PRODUCTS',
        'EDIT_PRODUCTS',
        'ADJUST_STOCK',
      ];
    case 'CASHIER':
    default:
      return ['VIEW_PRODUCTS', 'CREATE_SALE'];
  }
}

export async function addEmployee(
  storeId: string,
  input: {
    name: string;
    email?: string;
    role: EmployeeRole;
    pinCode: string;
    permissions?: EmployeePermission[];
    canSell?: boolean;
    canManageInventory?: boolean;
    canManageDevices?: boolean;
    canViewReports?: boolean;
  }
): Promise<Employee> {
  const employeeId = `emp_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const path = `stores/${storeId}/employees/${employeeId}`;

  let permissions =
    input.permissions && input.permissions.length > 0
      ? [...input.permissions]
      : getDefaultPermissionsForRole(input.role);

  // If explicit boolean overrides were passed, respect them
  if (input.canSell !== undefined) {
    if (input.canSell && !permissions.includes('CREATE_SALE')) permissions.push('CREATE_SALE');
    if (!input.canSell) permissions = permissions.filter((p) => p !== 'CREATE_SALE');
  }
  if (input.canManageInventory !== undefined) {
    if (input.canManageInventory) {
      if (!permissions.includes('ADJUST_STOCK')) permissions.push('ADJUST_STOCK');
      if (!permissions.includes('EDIT_PRODUCTS')) permissions.push('EDIT_PRODUCTS');
    } else {
      permissions = permissions.filter((p) => p !== 'ADJUST_STOCK' && p !== 'EDIT_PRODUCTS');
    }
  }
  if (input.canManageDevices !== undefined) {
    if (input.canManageDevices && !permissions.includes('MANAGE_DEVICES')) permissions.push('MANAGE_DEVICES');
    if (!input.canManageDevices) permissions = permissions.filter((p) => p !== 'MANAGE_DEVICES');
  }
  if (input.canViewReports !== undefined) {
    if (input.canViewReports && !permissions.includes('VIEW_REPORTS')) permissions.push('VIEW_REPORTS');
    if (!input.canViewReports) permissions = permissions.filter((p) => p !== 'VIEW_REPORTS');
  }

  const newEmployee: Employee = {
    employeeId,
    storeId,
    name: input.name.trim(),
    email: input.email?.trim() || '',
    role: input.role,
    pinCode: input.pinCode.trim(),
    permissions,
    canSell: permissions.includes('CREATE_SALE'),
    canManageInventory: permissions.includes('ADJUST_STOCK') || permissions.includes('EDIT_PRODUCTS'),
    canManageDevices: permissions.includes('MANAGE_DEVICES'),
    canViewReports: permissions.includes('VIEW_REPORTS'),
    active: true,
    createdAt: new Date().toISOString(),
  };

  try {
    await setDoc(doc(db, 'stores', storeId, 'employees', employeeId), newEmployee);
    return newEmployee;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export function subscribeToStoreEmployees(
  storeId: string,
  onUpdate: (employees: Employee[]) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  const path = `stores/${storeId}/employees`;
  const q = collection(db, 'stores', storeId, 'employees');

  return onSnapshot(
    q,
    (snapshot) => {
      const employees: Employee[] = [];
      snapshot.forEach((d) => {
        const data = d.data() as Employee;
        const permissions = data.permissions || getDefaultPermissionsForRole(data.role);
        employees.push({
          ...data,
          permissions,
          canSell: permissions.includes('CREATE_SALE'),
          canManageInventory: permissions.includes('ADJUST_STOCK') || permissions.includes('EDIT_PRODUCTS'),
          canManageDevices: permissions.includes('MANAGE_DEVICES'),
          canViewReports: permissions.includes('VIEW_REPORTS'),
        });
      });
      employees.sort((a, b) => a.name.localeCompare(b.name));
      onUpdate(employees);
    },
    (error) => {
      if (onError) onError(error);
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

export async function updateEmployee(
  storeId: string,
  employeeId: string,
  updates: Partial<Employee>
): Promise<void> {
  const path = `stores/${storeId}/employees/${employeeId}`;
  try {
    const updatedData: any = { ...updates };
    if (updates.permissions) {
      updatedData.canSell = updates.permissions.includes('CREATE_SALE');
      updatedData.canManageInventory =
        updates.permissions.includes('ADJUST_STOCK') || updates.permissions.includes('EDIT_PRODUCTS');
      updatedData.canManageDevices = updates.permissions.includes('MANAGE_DEVICES');
      updatedData.canViewReports = updates.permissions.includes('VIEW_REPORTS');
    }
    await updateDoc(doc(db, 'stores', storeId, 'employees', employeeId), updatedData);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteEmployee(storeId: string, employeeId: string): Promise<void> {
  const path = `stores/${storeId}/employees/${employeeId}`;
  try {
    await deleteDoc(doc(db, 'stores', storeId, 'employees', employeeId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function verifyEmployeePin(
  storeId: string,
  pin: string
): Promise<Employee | null> {
  const cleanPin = pin.trim();
  if (!cleanPin) return null;

  const path = `stores/${storeId}/employees`;
  try {
    const q = query(
      collection(db, 'stores', storeId, 'employees'),
      where('pinCode', '==', cleanPin),
      where('active', '==', true)
    );
    const snapshot = await getDocs(q);
    if (snapshot.empty) return null;
    const data = snapshot.docs[0].data() as Employee;
    const permissions = data.permissions || getDefaultPermissionsForRole(data.role);
    return {
      ...data,
      permissions,
      canSell: permissions.includes('CREATE_SALE'),
      canManageInventory: permissions.includes('ADJUST_STOCK') || permissions.includes('EDIT_PRODUCTS'),
      canManageDevices: permissions.includes('MANAGE_DEVICES'),
      canViewReports: permissions.includes('VIEW_REPORTS'),
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}
