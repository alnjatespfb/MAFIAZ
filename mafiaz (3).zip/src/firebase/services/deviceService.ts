import {
  collection,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  Unsubscribe,
} from 'firebase/firestore';
import { db, auth } from '../config';
import { Device, DeviceStatus, DeviceType } from '../../types';
import { handleFirestoreError, OperationType } from '../errors';

export async function registerDevice(
  storeId: string,
  input: {
    deviceId: string;
    name: string;
    type: DeviceType;
    pairedPosDeviceId?: string;
    assignedEmployee?: string;
  }
): Promise<Device> {
  const currentUser = auth.currentUser;
  const path = `stores/${storeId}/devices/${input.deviceId}`;

  const newDevice: Device = {
    deviceId: input.deviceId,
    storeId,
    name: input.name.trim(),
    deviceName: input.name.trim(),
    type: input.type,
    deviceType: input.type,
    status: 'PENDING',
    pairedPosDeviceId: input.pairedPosDeviceId || '',
    assignedEmployee: input.assignedEmployee || '',
    registeredBy: currentUser?.uid || 'anonymous-device',
    lastSeen: new Date().toISOString(),
    lastActiveAt: new Date().toISOString(),
    createdAt: new Date().toISOString(),
  };

  try {
    const docSnap = await getDoc(doc(db, 'stores', storeId, 'devices', input.deviceId));
    if (docSnap.exists()) {
      const existing = docSnap.data() as Device;
      await updateDoc(doc(db, 'stores', storeId, 'devices', input.deviceId), {
        name: newDevice.name,
        deviceName: newDevice.name,
        type: newDevice.type,
        deviceType: newDevice.type,
        lastSeen: new Date().toISOString(),
        lastActiveAt: new Date().toISOString(),
      });
      return existing;
    }

    await setDoc(doc(db, 'stores', storeId, 'devices', input.deviceId), newDevice);
    return newDevice;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export function subscribeToStoreDevices(
  storeId: string,
  onUpdate: (devices: Device[]) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  const path = `stores/${storeId}/devices`;
  const q = collection(db, 'stores', storeId, 'devices');

  return onSnapshot(
    q,
    (snapshot) => {
      const devices: Device[] = [];
      snapshot.forEach((d) => {
        const data = d.data() as Device;
        devices.push({
          ...data,
          name: data.name || data.deviceName || 'Unnamed Device',
          type: data.type || data.deviceType || 'POS',
          lastSeen: data.lastSeen || data.lastActiveAt || data.createdAt,
        });
      });
      devices.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      onUpdate(devices);
    },
    (error) => {
      if (onError) onError(error);
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

export async function updateDeviceStatus(
  storeId: string,
  deviceId: string,
  status: DeviceStatus
): Promise<void> {
  const path = `stores/${storeId}/devices/${deviceId}`;
  const now = new Date().toISOString();
  try {
    const updates: any = {
      status,
      lastSeen: now,
      lastActiveAt: now,
    };
    if (status === 'APPROVED') {
      updates.pairedAt = now;
    }
    await updateDoc(doc(db, 'stores', storeId, 'devices', deviceId), updates);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function updateDeviceHeartbeat(
  storeId: string,
  deviceId: string,
  pairedPosDeviceId?: string
): Promise<void> {
  const path = `stores/${storeId}/devices/${deviceId}`;
  const now = new Date().toISOString();
  try {
    const updates: Record<string, string> = {
      lastSeen: now,
      lastActiveAt: now,
    };
    if (pairedPosDeviceId !== undefined) {
      updates.pairedPosDeviceId = pairedPosDeviceId;
    }
    await updateDoc(doc(db, 'stores', storeId, 'devices', deviceId), updates);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteDevice(storeId: string, deviceId: string): Promise<void> {
  const path = `stores/${storeId}/devices/${deviceId}`;
  try {
    await deleteDoc(doc(db, 'stores', storeId, 'devices', deviceId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}
