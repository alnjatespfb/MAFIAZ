import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  serverTimestamp,
} from 'firebase/firestore';
import { db, auth } from '../config';
import { Store, UserProfile } from '../../types';
import { handleFirestoreError, OperationType } from '../errors';

export async function createStore(storeInput: {
  name: string;
  logo?: string;
  country?: string;
  currency?: string;
  address?: string;
  phone?: string;
  taxRate?: number;
}): Promise<Store> {
  const currentUser = auth.currentUser;
  if (!currentUser) {
    throw new Error('You must be signed in to create a store.');
  }

  const storeId = `store_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const storePath = `stores/${storeId}`;

  const newStore: Store = {
    storeId,
    name: storeInput.name.trim(),
    ownerId: currentUser.uid,
    logo: storeInput.logo?.trim() || '',
    country: storeInput.country?.trim() || 'Kuwait',
    currency: storeInput.currency?.toUpperCase().trim() || 'KWD',
    address: storeInput.address?.trim() || '',
    phone: storeInput.phone?.trim() || '',
    taxRate: storeInput.taxRate !== undefined ? Number(storeInput.taxRate) : 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  try {
    await setDoc(doc(db, 'stores', storeId), {
      ...newStore,
      serverCreatedAt: serverTimestamp(),
    });

    // Also ensure user profile tracks this store
    const userDocRef = doc(db, 'users', currentUser.uid);
    const userSnap = await getDoc(userDocRef);
    if (userSnap.exists()) {
      const data = userSnap.data() as UserProfile;
      const currentStores = data.ownedStoreIds || [];
      if (!currentStores.includes(storeId)) {
        await updateDoc(userDocRef, {
          ownedStoreIds: [...currentStores, storeId],
        });
      }
    } else {
      await setDoc(userDocRef, {
        userId: currentUser.uid,
        email: currentUser.email || '',
        displayName: currentUser.displayName || currentUser.email?.split('@')[0] || 'Store Owner',
        ownedStoreIds: [storeId],
        createdAt: new Date().toISOString(),
      });
    }

    return newStore;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, storePath);
  }
}

export async function fetchUserStores(): Promise<Store[]> {
  const currentUser = auth.currentUser;
  if (!currentUser) return [];

  const storePath = 'stores';
  try {
    const q = query(collection(db, storePath), where('ownerId', '==', currentUser.uid));
    const snapshot = await getDocs(q);
    const stores: Store[] = [];
    snapshot.forEach((docSnap) => {
      stores.push(docSnap.data() as Store);
    });
    return stores;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, storePath);
  }
}

export async function getStore(storeId: string): Promise<Store | null> {
  const storePath = `stores/${storeId}`;
  try {
    const docSnap = await getDoc(doc(db, 'stores', storeId));
    if (!docSnap.exists()) return null;
    return docSnap.data() as Store;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, storePath);
  }
}

export async function updateStore(storeId: string, updates: Partial<Store>): Promise<void> {
  const storePath = `stores/${storeId}`;
  try {
    await updateDoc(doc(db, 'stores', storeId), {
      ...updates,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, storePath);
  }
}

export const updateStoreProfile = updateStore;

export async function deleteStore(storeId: string): Promise<void> {
  const storePath = `stores/${storeId}`;
  try {
    await deleteDoc(doc(db, 'stores', storeId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, storePath);
  }
}
