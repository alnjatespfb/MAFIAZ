import {
  collection,
  doc,
  setDoc,
  updateDoc,
  onSnapshot,
  query,
  orderBy,
  limit,
  Unsubscribe,
} from 'firebase/firestore';
import { db } from '../config';
import { POSSession } from '../../types';
import { handleFirestoreError, OperationType } from '../errors';

export async function startEmployeeSession(
  storeId: string,
  input: {
    employeeId: string;
    employeeName: string;
    deviceId: string;
  }
): Promise<POSSession> {
  const sessionId = `sess_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const path = `stores/${storeId}/sessions/${sessionId}`;

  const session: POSSession = {
    sessionId,
    storeId,
    employeeId: input.employeeId,
    employeeName: input.employeeName,
    deviceId: input.deviceId,
    loginTime: new Date().toISOString(),
    status: 'ACTIVE',
  };

  try {
    await setDoc(doc(db, 'stores', storeId, 'sessions', sessionId), session);
    return session;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function endEmployeeSession(
  storeId: string,
  sessionId: string
): Promise<void> {
  const path = `stores/${storeId}/sessions/${sessionId}`;
  try {
    await updateDoc(doc(db, 'stores', storeId, 'sessions', sessionId), {
      logoutTime: new Date().toISOString(),
      status: 'CLOSED',
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export const startSession = async (
  storeId: string,
  employeeId: string,
  employeeName: string,
  deviceId: string,
  openingCash?: number
): Promise<POSSession> => {
  return startEmployeeSession(storeId, { employeeId, employeeName, deviceId });
};

export const closeSession = async (
  storeId: string,
  sessionId: string,
  closingCash?: number
): Promise<void> => {
  return endEmployeeSession(storeId, sessionId);
};

export function subscribeToStoreSessions(
  storeId: string,
  onUpdate: (sessions: POSSession[]) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  const path = `stores/${storeId}/sessions`;
  const q = query(collection(db, 'stores', storeId, 'sessions'), orderBy('loginTime', 'desc'), limit(50));

  return onSnapshot(
    q,
    (snapshot) => {
      const sessions: POSSession[] = [];
      snapshot.forEach((d) => {
        sessions.push(d.data() as POSSession);
      });
      onUpdate(sessions);
    },
    (error) => {
      if (onError) onError(error);
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}
