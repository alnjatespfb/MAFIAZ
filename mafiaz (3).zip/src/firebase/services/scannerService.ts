import {
  collection,
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  onSnapshot,
  Unsubscribe,
} from 'firebase/firestore';
import { db } from '../config';
import { ScanEvent } from '../../types';
import { handleFirestoreError, OperationType } from '../errors';

export async function sendScanEvent(
  storeId: string,
  scannerDeviceId: string,
  targetPosDeviceId: string,
  barcode: string
): Promise<ScanEvent> {
  const eventId = `scan_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const path = `stores/${storeId}/scanEvents/${eventId}`;

  const event: ScanEvent = {
    eventId,
    storeId,
    scannerDeviceId,
    targetPosDeviceId,
    barcode: barcode.trim(),
    processed: false,
    createdAt: new Date().toISOString(),
  };

  try {
    await setDoc(doc(db, 'stores', storeId, 'scanEvents', eventId), event);
    return event;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export const broadcastBarcodeScan = async (
  storeId: string,
  scannerDeviceId: string,
  barcode: string,
  targetPosDeviceId: string
): Promise<ScanEvent> => {
  return sendScanEvent(storeId, scannerDeviceId, targetPosDeviceId, barcode);
};

export function subscribeToPosScanEvents(
  storeId: string,
  posDeviceId: string,
  onScanReceived: (barcode: string, event: ScanEvent) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  const path = `stores/${storeId}/scanEvents`;
  const q = query(
    collection(db, 'stores', storeId, 'scanEvents'),
    where('targetPosDeviceId', '==', posDeviceId),
    where('processed', '==', false)
  );

  return onSnapshot(
    q,
    async (snapshot) => {
      for (const change of snapshot.docChanges()) {
        if (change.type === 'added') {
          const event = change.doc.data() as ScanEvent;
          if (!event.processed) {
            // Process scan in POS
            onScanReceived(event.barcode, event);

            // Mark event as processed to prevent double consumption
            try {
              await updateDoc(doc(db, 'stores', storeId, 'scanEvents', event.eventId), {
                processed: true,
              });
            } catch (e) {
              console.error('Failed to mark scan event as processed:', e);
            }
          }
        }
      }
    },
    (error) => {
      if (onError) onError(error);
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

export function subscribeToIncomingScans(
  storeId: string,
  posDeviceId: string,
  onScanReceived: (event: ScanEvent) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  return subscribeToPosScanEvents(
    storeId,
    posDeviceId,
    (_barcode, event) => onScanReceived(event),
    onError
  );
}

export async function removeProcessedScanEvent(storeId: string, eventId: string): Promise<void> {
  const path = `stores/${storeId}/scanEvents/${eventId}`;
  try {
    await deleteDoc(doc(db, 'stores', storeId, 'scanEvents', eventId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}
