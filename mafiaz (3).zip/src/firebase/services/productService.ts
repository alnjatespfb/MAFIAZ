import {
  collection,
  doc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  onSnapshot,
  runTransaction,
  Unsubscribe,
} from 'firebase/firestore';
import { db } from '../config';
import { Product } from '../../types';
import { handleFirestoreError, OperationType } from '../errors';

export async function addProduct(
  storeId: string,
  input: {
    name: string;
    barcode: string;
    category?: string;
    sellingPrice: number;
    costPrice?: number;
    quantity: number;
    minimumStock?: number;
    image?: string;
    sku?: string;
  }
): Promise<Product> {
  const cleanBarcode = input.barcode.trim();
  const path = `stores/${storeId}/products`;

  // Enforce barcode uniqueness inside the store if barcode is provided
  if (cleanBarcode) {
    const existing = await findProductByBarcode(storeId, cleanBarcode);
    if (existing) {
      throw new Error(`A product with barcode "${cleanBarcode}" already exists: "${existing.name}".`);
    }
  }

  const productId = `prod_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const prodDocPath = `stores/${storeId}/products/${productId}`;

  const sellingPrice = Number(input.sellingPrice);
  const costPrice = input.costPrice !== undefined ? Number(input.costPrice) : undefined;
  const quantity = Number(input.quantity);
  const minimumStock = input.minimumStock !== undefined ? Number(input.minimumStock) : 5;

  const product: Product = {
    productId,
    storeId,
    name: input.name.trim(),
    barcode: cleanBarcode,
    category: input.category?.trim() || 'General',
    sellingPrice,
    price: sellingPrice,
    costPrice,
    quantity,
    stockQuantity: quantity,
    minimumStock,
    minStockAlert: minimumStock,
    image: input.image?.trim() || '',
    sku: input.sku?.trim() || `SKU-${Date.now().toString().slice(-6)}`,
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  try {
    await setDoc(doc(db, 'stores', storeId, 'products', productId), product);
    return product;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, prodDocPath);
  }
}

export function subscribeToStoreProducts(
  storeId: string,
  onUpdate: (products: Product[]) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  const path = `stores/${storeId}/products`;
  const q = collection(db, 'stores', storeId, 'products');

  return onSnapshot(
    q,
    (snapshot) => {
      const products: Product[] = [];
      snapshot.forEach((d) => {
        const data = d.data() as Product;
        // Normalize fields for consistency
        const sellingPrice = data.sellingPrice ?? data.price ?? 0;
        const quantity = data.quantity ?? data.stockQuantity ?? 0;
        const minimumStock = data.minimumStock ?? data.minStockAlert ?? 5;

        products.push({
          ...data,
          sellingPrice,
          price: sellingPrice,
          quantity,
          stockQuantity: quantity,
          minimumStock,
          minStockAlert: minimumStock,
          active: data.active !== false,
        });
      });
      // Sort alphabetically by name
      products.sort((a, b) => a.name.localeCompare(b.name));
      onUpdate(products);
    },
    (error) => {
      if (onError) onError(error);
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

export async function updateProduct(
  storeId: string,
  productId: string,
  updates: Partial<Product>
): Promise<void> {
  const path = `stores/${storeId}/products/${productId}`;

  // If barcode is being updated, verify uniqueness
  if (updates.barcode !== undefined) {
    const cleanBarcode = updates.barcode.trim();
    if (cleanBarcode) {
      const existing = await findProductByBarcode(storeId, cleanBarcode);
      if (existing && existing.productId !== productId) {
        throw new Error(`Barcode "${cleanBarcode}" is already in use by "${existing.name}".`);
      }
    }
  }

  const normalizedUpdates: any = {
    ...updates,
    updatedAt: new Date().toISOString(),
  };

  if (updates.sellingPrice !== undefined) {
    normalizedUpdates.sellingPrice = Number(updates.sellingPrice);
    normalizedUpdates.price = Number(updates.sellingPrice);
  } else if (updates.price !== undefined) {
    normalizedUpdates.sellingPrice = Number(updates.price);
    normalizedUpdates.price = Number(updates.price);
  }

  if (updates.quantity !== undefined) {
    normalizedUpdates.quantity = Number(updates.quantity);
    normalizedUpdates.stockQuantity = Number(updates.quantity);
  } else if (updates.stockQuantity !== undefined) {
    normalizedUpdates.quantity = Number(updates.stockQuantity);
    normalizedUpdates.stockQuantity = Number(updates.stockQuantity);
  }

  if (updates.minimumStock !== undefined) {
    normalizedUpdates.minimumStock = Number(updates.minimumStock);
    normalizedUpdates.minStockAlert = Number(updates.minimumStock);
  }

  try {
    await updateDoc(doc(db, 'stores', storeId, 'products', productId), normalizedUpdates);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteProduct(storeId: string, productId: string): Promise<void> {
  const path = `stores/${storeId}/products/${productId}`;
  try {
    await deleteDoc(doc(db, 'stores', storeId, 'products', productId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function toggleProductActive(
  storeId: string,
  productId: string,
  currentStatus: boolean
): Promise<void> {
  return updateProduct(storeId, productId, { active: !currentStatus });
}

// Atomic stock adjustment using runTransaction to prevent race conditions
export async function adjustProductStock(
  storeId: string,
  productId: string,
  adjustmentDelta: number
): Promise<number> {
  const path = `stores/${storeId}/products/${productId}`;
  const prodRef = doc(db, 'stores', storeId, 'products', productId);

  try {
    return await runTransaction(db, async (transaction) => {
      const prodSnap = await transaction.get(prodRef);
      if (!prodSnap.exists()) {
        throw new Error(`Product not found: ${productId}`);
      }

      const data = prodSnap.data();
      const currentStock = Number(data.quantity ?? data.stockQuantity ?? 0);
      const newStock = currentStock + adjustmentDelta;
      if (newStock < 0) {
        throw new Error(`Insufficient stock for product. Available: ${currentStock}, adjustment: ${adjustmentDelta}`);
      }

      const nowIso = new Date().toISOString();
      transaction.update(prodRef, {
        quantity: newStock,
        stockQuantity: newStock,
        updatedAt: nowIso,
      });

      return newStock;
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function setProductStockDirect(
  storeId: string,
  productId: string,
  newStock: number
): Promise<number> {
  const path = `stores/${storeId}/products/${productId}`;
  const prodRef = doc(db, 'stores', storeId, 'products', productId);

  if (newStock < 0) {
    throw new Error('Stock cannot be negative.');
  }

  try {
    await updateDoc(prodRef, {
      quantity: newStock,
      stockQuantity: newStock,
      updatedAt: new Date().toISOString(),
    });
    return newStock;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function findProductByBarcode(storeId: string, barcode: string): Promise<Product | null> {
  const cleanBarcode = barcode.trim();
  if (!cleanBarcode) return null;

  const path = `stores/${storeId}/products`;
  try {
    const q = query(collection(db, 'stores', storeId, 'products'), where('barcode', '==', cleanBarcode));
    const snapshot = await getDocs(q);
    if (snapshot.empty) return null;
    const data = snapshot.docs[0].data() as Product;
    const sellingPrice = data.sellingPrice ?? data.price ?? 0;
    const quantity = data.quantity ?? data.stockQuantity ?? 0;
    return {
      ...data,
      sellingPrice,
      price: sellingPrice,
      quantity,
      stockQuantity: quantity,
      minimumStock: data.minimumStock ?? data.minStockAlert ?? 5,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}
