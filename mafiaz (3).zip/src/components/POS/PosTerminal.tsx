import React, { useState, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import { useDevice } from '../../context/DeviceContext';
import { useAuth } from '../../context/AuthContext';
import { Product, SaleItem, Employee, Sale, POSSession } from '../../types';
import { subscribeToStoreProducts } from '../../firebase/services/productService';
import { subscribeToStoreEmployees, verifyEmployeePin } from '../../firebase/services/employeeService';
import { executeSale } from '../../firebase/services/saleService';
import { subscribeToIncomingScans } from '../../firebase/services/scannerService';
import { startSession, closeSession } from '../../firebase/services/sessionService';
import { playChime } from '../../utils/feedback';
import {
  Monitor,
  Search,
  Barcode,
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  DollarSign,
  CreditCard,
  Banknote,
  Lock,
  Unlock,
  AlertTriangle,
  CheckCircle,
  Clock,
  Printer,
  X,
  User,
  Radio,
  Zap,
  RotateCcw,
} from 'lucide-react';

interface PosTerminalProps {
  onOpenEnrollment: () => void;
}

export const PosTerminal: React.FC<PosTerminalProps> = ({ onOpenEnrollment }) => {
  const { activeStore } = useStore();
  const { currentDeviceId, deviceStatus, isOnline } = useDevice();
  const { user } = useAuth();

  // Inventory & Employees
  const [products, setProducts] = useState<Product[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [activeEmployee, setActiveEmployee] = useState<Employee | null>(null);
  const [currentSession, setCurrentSession] = useState<POSSession | null>(null);

  // Cart
  const [cart, setCart] = useState<SaleItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [barcodeQuery, setBarcodeQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  // Checkout modal
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'CASH' | 'KNET'>('CASH');
  const [amountTendered, setAmountTendered] = useState('');
  const [knetApprovalCode, setKnetApprovalCode] = useState('');
  const [isProcessingSale, setIsProcessingSale] = useState(false);
  const [saleError, setSaleError] = useState<string | null>(null);

  // Completed sale receipt
  const [completedSale, setCompletedSale] = useState<Sale | null>(null);

  // PIN lock modal
  const [pinModalOpen, setPinModalOpen] = useState(false);
  const [selectedEmpForPin, setSelectedEmpForPin] = useState<Employee | null>(null);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState<string | null>(null);

  // Real-time scan incoming notification flash
  const [incomingScanAlert, setIncomingScanAlert] = useState<string | null>(null);

  const currency = activeStore?.currency || 'KWD';

  // Subscribe to Products
  useEffect(() => {
    if (!activeStore) return;
    const unsub = subscribeToStoreProducts(activeStore.storeId, (prods) => {
      setProducts(prods);
    });
    return () => unsub();
  }, [activeStore]);

  // Subscribe to Employees
  useEffect(() => {
    if (!activeStore) return;
    const unsub = subscribeToStoreEmployees(activeStore.storeId, (empList) => {
      const activeEmps = empList.filter((e) => e.active !== false);
      setEmployees(activeEmps);
      if (!activeEmployee && activeEmps.length > 0) {
        setActiveEmployee(activeEmps[0]);
      }
    });
    return () => unsub();
  }, [activeStore, activeEmployee]);

  // Real-time Bridge: Subscribe to incoming scans sent from Mobile Scanners targeted to this POS
  useEffect(() => {
    if (!activeStore || !currentDeviceId || deviceStatus !== 'APPROVED') return;

    const unsub = subscribeToIncomingScans(
      activeStore.storeId,
      currentDeviceId,
      (scanEvent) => {
        const cleanBarcode = scanEvent.barcode?.trim().toLowerCase();
        const matched = products.find(
          (p) =>
            p.barcode?.toLowerCase() === cleanBarcode ||
            p.sku?.toLowerCase() === cleanBarcode
        );

        if (matched) {
          playChime('beep');
          addToCart(matched);
          setIncomingScanAlert(`Scanned from Phone: "${matched.name}"`);
        } else {
          playChime('alert');
          setIncomingScanAlert(`Unknown barcode scanned: "${scanEvent.barcode}"`);
        }

        setTimeout(() => setIncomingScanAlert(null), 3500);
      }
    );

    return () => unsub();
  }, [activeStore, currentDeviceId, deviceStatus, products]);

  const addToCart = (product: Product) => {
    const itemPrice = product.sellingPrice ?? product.price ?? 0;
    playChime('beep');
    setCart((prev) => {
      const existing = prev.find((item) => item.productId === product.productId);
      if (existing) {
        return prev.map((item) =>
          item.productId === product.productId
            ? { ...item, quantity: item.quantity + 1, total: (item.quantity + 1) * item.price }
            : item
        );
      } else {
        return [
          ...prev,
          {
            productId: product.productId,
            name: product.name,
            sku: product.sku || '',
            price: itemPrice,
            quantity: 1,
            total: itemPrice,
          },
        ];
      }
    });
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.productId === productId) {
            const newQty = item.quantity + delta;
            if (newQty <= 0) return null;
            return { ...item, quantity: newQty, total: newQty * item.price };
          }
          return item;
        })
        .filter((item): item is SaleItem => item !== null)
    );
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.productId !== productId));
  };

  const clearCart = () => {
    setCart([]);
  };

  // Barcode manual quick scan handler
  const handleBarcodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = barcodeQuery.trim().toLowerCase();
    if (!clean) return;

    const matched = products.find(
      (p) => p.barcode?.toLowerCase() === clean || p.sku?.toLowerCase() === clean
    );

    if (matched) {
      addToCart(matched);
      setBarcodeQuery('');
    } else {
      playChime('alert');
      alert(`No product found with barcode or SKU "${barcodeQuery}".`);
    }
  };

  // Totals calculations
  const subtotal = cart.reduce((sum, item) => sum + item.total, 0);
  const taxRate = activeStore?.taxRate ?? 0;
  const taxTotal = parseFloat(((subtotal * taxRate) / 100).toFixed(3));
  const grandTotal = parseFloat((subtotal + taxTotal).toFixed(3));

  // Switch Cashier with PIN & Shift Session
  const handleSwitchCashierClick = (emp: Employee) => {
    setSelectedEmpForPin(emp);
    setPinInput('');
    setPinError(null);
    setPinModalOpen(true);
  };

  const handleVerifyPin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEmpForPin || !activeStore) return;

    try {
      const verifiedEmployee = await verifyEmployeePin(
        activeStore.storeId,
        pinInput
      );

      if (verifiedEmployee && verifiedEmployee.employeeId === selectedEmpForPin.employeeId) {
        // Close prior session if exists
        if (currentSession) {
          await closeSession(activeStore.storeId, currentSession.sessionId, 0);
        }

        // Start new shift session
        const session = await startSession(
          activeStore.storeId,
          verifiedEmployee.employeeId,
          verifiedEmployee.name,
          currentDeviceId,
          0
        );

        setCurrentSession(session);
        setActiveEmployee(verifiedEmployee);
        setPinModalOpen(false);
        playChime('success');
      } else {
        setPinError('Incorrect security PIN. Please try again.');
        playChime('alert');
      }
    } catch (err: any) {
      setPinError(err.message || 'Verification error.');
    }
  };

  // Open Checkout
  const handleOpenCheckout = () => {
    if (cart.length === 0) return;
    setAmountTendered(grandTotal.toFixed(3));
    setKnetApprovalCode(`KNET-${Math.floor(100000 + Math.random() * 900000)}`);
    setSaleError(null);
    setCheckoutOpen(true);
  };

  // Submit Sale with Concurrency and Atomic Firestore Transactions
  const handleFinalizeSale = async () => {
    if (!activeStore || !activeEmployee) return;

    const tenderedNum = paymentMethod === 'CASH' ? parseFloat(amountTendered) : grandTotal;
    if (paymentMethod === 'CASH' && (isNaN(tenderedNum) || tenderedNum < grandTotal)) {
      setSaleError(`Tendered amount must be at least ${currency} ${grandTotal.toFixed(3)}`);
      return;
    }

    const changeDue = paymentMethod === 'CASH' ? tenderedNum - grandTotal : 0;
    const txId = `TX-${Date.now().toString().slice(-6)}-${Math.floor(100 + Math.random() * 900)}`;

    try {
      setIsProcessingSale(true);
      setSaleError(null);

      const saleResult = await executeSale(
        activeStore.storeId,
        {
          transactionId: txId,
          storeId: activeStore.storeId,
          employeeId: activeEmployee.employeeId,
          employeeName: activeEmployee.name,
          deviceId: currentDeviceId,
          items: cart,
          subtotal,
          taxTotal,
          total: grandTotal,
          paymentMethod,
          amountTendered: paymentMethod === 'CASH' ? tenderedNum : undefined,
          changeDue: paymentMethod === 'CASH' ? changeDue : undefined,
          createdAt: new Date().toISOString(),
        }
      );

      playChime('success');
      setCompletedSale(saleResult);
      setCheckoutOpen(false);
      setCart([]);
    } catch (err: any) {
      console.error('Sale execution error:', err);
      playChime('alert');
      setSaleError(err.message || 'Transaction failed. Check stock availability.');
    } finally {
      setIsProcessingSale(false);
    }
  };

  // Quick tender amount clickers
  const addQuickTender = (val: number) => {
    const current = parseFloat(amountTendered) || 0;
    setAmountTendered((current + val).toFixed(3));
  };

  if (!activeStore) {
    return (
      <div className="p-12 text-center text-slate-400">
        <Monitor className="w-12 h-12 mx-auto text-slate-600 mb-3" />
        <p className="text-base font-medium">Please select or create a store first.</p>
      </div>
    );
  }

  // Device authorization enforcement (Rule 11 & 14)
  if (deviceStatus === 'UNREGISTERED') {
    return (
      <div className="max-w-md mx-auto my-12 p-8 bg-slate-900 border border-slate-800 rounded-3xl text-center space-y-4 shadow-xl">
        <div className="w-14 h-14 rounded-2xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center mx-auto">
          <Monitor className="w-8 h-8" />
        </div>
        <h2 className="text-lg font-bold text-white">POS Terminal Registration Required</h2>
        <p className="text-xs text-slate-400">
          This browser device is not enrolled as an authorized POS terminal in {activeStore.name}.
        </p>
        <button
          onClick={onOpenEnrollment}
          className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-lg transition"
        >
          Enroll This Browser as POS Terminal
        </button>
      </div>
    );
  }

  if (deviceStatus === 'PENDING') {
    return (
      <div className="max-w-md mx-auto my-12 p-8 bg-amber-950/40 border border-amber-800/80 rounded-3xl text-center space-y-4 shadow-xl">
        <Clock className="w-12 h-12 mx-auto text-amber-400 animate-pulse" />
        <h2 className="text-lg font-bold text-amber-200">Terminal Awaiting Administrator Approval</h2>
        <p className="text-xs text-amber-300/90 font-mono">
          Terminal ID: {currentDeviceId}
        </p>
        <p className="text-xs text-slate-400">
          An administrator must approve this POS terminal in the "Devices" tab or Top Notifications before sales can be rung.
        </p>
      </div>
    );
  }

  if (deviceStatus === 'DISABLED' || deviceStatus === 'REJECTED') {
    return (
      <div className="max-w-md mx-auto my-12 p-8 bg-rose-950/40 border border-rose-800/80 rounded-3xl text-center space-y-4 shadow-xl">
        <AlertTriangle className="w-12 h-12 mx-auto text-rose-400" />
        <h2 className="text-lg font-bold text-rose-200">Terminal Deactivated ({deviceStatus})</h2>
        <p className="text-xs text-slate-400">
          This register has been disabled by store management. Contact an administrator to re-enable access.
        </p>
      </div>
    );
  }

  const categories = ['ALL', ...Array.from(new Set(products.map((p) => p.category || 'General')))];

  const filteredProducts = products.filter((p) => {
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !q ||
      p.name.toLowerCase().includes(q) ||
      (p.sku && p.sku.toLowerCase().includes(q)) ||
      (p.barcode && p.barcode.toLowerCase().includes(q));
    const matchesCategory = selectedCategory === 'ALL' || (p.category || 'General') === selectedCategory;
    const isActive = p.active !== false;
    return matchesSearch && matchesCategory && isActive;
  });

  return (
    <div className="space-y-4 animate-in fade-in duration-150">
      {/* Top Register Status Strip */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-sm">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-2xl bg-emerald-600/20 text-emerald-400">
            <Monitor className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-bold text-white text-base">{activeStore.name}</span>
              <span className="text-[11px] font-mono text-emerald-300 bg-slate-800 border border-slate-700 px-2 py-0.5 rounded-lg">
                POS: {currentDeviceId.slice(-6).toUpperCase()}
              </span>
            </div>
            <div className="text-[11px] text-slate-400 flex items-center space-x-2 mt-0.5">
              <span>Tax: {activeStore.taxRate}%</span>
              <span>•</span>
              <span className="text-emerald-400 flex items-center space-x-1">
                <Radio className="w-3 h-3 animate-pulse" />
                <span>Phone scanner listener ready</span>
              </span>
            </div>
          </div>
        </div>

        {/* Cashier Shift Switcher */}
        <div className="flex items-center space-x-3">
          {activeEmployee ? (
            <div className="flex items-center space-x-2 bg-slate-800/80 px-3 py-1.5 rounded-2xl border border-slate-700">
              <div className="w-7 h-7 rounded-xl bg-purple-600/30 text-purple-300 flex items-center justify-center font-bold text-xs">
                {activeEmployee.name.charAt(0).toUpperCase()}
              </div>
              <div className="text-xs text-left">
                <div className="font-semibold text-white leading-none">{activeEmployee.name}</div>
                <div className="text-[10px] text-slate-400 uppercase mt-0.5">
                  {activeEmployee.role}
                </div>
              </div>
              <button
                onClick={() => handleSwitchCashierClick(activeEmployee)}
                className="ml-2 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700 transition"
                title="Switch cashier / lock terminal"
              >
                <Lock className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : employees.length > 0 ? (
            <button
              onClick={() => handleSwitchCashierClick(employees[0])}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold"
            >
              Sign In Cashier
            </button>
          ) : (
            <div className="text-xs text-amber-300">No employees registered.</div>
          )}
        </div>
      </div>

      {/* Remote Scanner Flash Alert */}
      {incomingScanAlert && (
        <div className="p-3 bg-emerald-950/80 border border-emerald-500 rounded-2xl text-emerald-200 text-xs font-medium flex items-center space-x-2 animate-in fade-in">
          <Zap className="w-4 h-4 text-emerald-400" />
          <span>{incomingScanAlert}</span>
        </div>
      )}

      {/* Main Touchscreen Grid: Left Catalog / Right Cart */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Product Selection & Catalog (7 cols) */}
        <div className="lg:col-span-7 space-y-3">
          {/* Barcode Quick Scan & Search Inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <form onSubmit={handleBarcodeSubmit} className="relative">
              <Barcode className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                id="pos-barcode-input"
                type="text"
                value={barcodeQuery}
                onChange={(e) => setBarcodeQuery(e.target.value)}
                placeholder="Scan or enter barcode / UPC..."
                className="w-full pl-9 pr-3 py-2.5 bg-slate-900 border border-slate-800 rounded-2xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 font-mono"
              />
            </form>

            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                id="pos-product-search"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search catalog items..."
                className="w-full pl-9 pr-3 py-2.5 bg-slate-900 border border-slate-800 rounded-2xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Categories Pill Bar */}
          {categories.length > 0 && (
            <div className="flex items-center space-x-2 overflow-x-auto pb-1">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                    selectedCategory === cat
                      ? 'bg-emerald-600 text-white shadow'
                      : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {cat === 'ALL' ? 'All Items' : cat}
                </button>
              ))}
            </div>
          )}

          {/* Touchscreen Products Grid */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 min-h-[400px] max-h-[540px] overflow-y-auto shadow-xl">
            {filteredProducts.length === 0 ? (
              <div className="py-24 text-center text-slate-500 text-xs">
                {products.length === 0
                  ? 'No products in catalog. Add items in the Products or Inventory tab.'
                  : 'No active products match your search.'}
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {filteredProducts.map((prod) => {
                  const qty = prod.quantity ?? prod.stockQuantity ?? 0;
                  const isOutOfStock = qty <= 0;
                  const price = prod.sellingPrice ?? prod.price ?? 0;

                  return (
                    <button
                      key={prod.productId}
                      id={`pos-item-${prod.productId}`}
                      disabled={isOutOfStock}
                      onClick={() => addToCart(prod)}
                      className={`p-3.5 rounded-2xl border text-left flex flex-col justify-between transition relative active:scale-95 ${
                        isOutOfStock
                          ? 'bg-slate-800/30 border-slate-800/60 opacity-40 cursor-not-allowed'
                          : 'bg-slate-800/80 border-slate-700/70 hover:border-emerald-500/80 hover:bg-slate-800 shadow-sm'
                      }`}
                    >
                      <div>
                        <div className="font-semibold text-white text-xs line-clamp-2 leading-snug">
                          {prod.name}
                        </div>
                        <div className="text-[10px] text-slate-400 mt-1 font-mono">
                          {prod.barcode || prod.sku || '—'}
                        </div>
                      </div>

                      <div className="mt-3 flex items-center justify-between">
                        <span className="font-mono text-xs font-bold text-emerald-400">
                          {price.toFixed(3)} {currency}
                        </span>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold ${
                            isOutOfStock
                              ? 'bg-rose-950 text-rose-300'
                              : qty <= 5
                              ? 'bg-amber-950 text-amber-300'
                              : 'bg-slate-700 text-slate-300'
                          }`}
                        >
                          {qty} left
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Active Cart & Register Controls (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-3xl flex flex-col justify-between shadow-xl overflow-hidden">
          {/* Cart Header */}
          <div className="px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <ShoppingCart className="w-4 h-4 text-emerald-400" />
              <span className="text-sm font-bold text-white">Active Order</span>
              <span className="text-xs bg-slate-800 text-emerald-300 px-2 py-0.5 rounded-full font-mono font-bold border border-slate-700">
                {cart.reduce((s, i) => s + i.quantity, 0)} items
              </span>
            </div>

            {cart.length > 0 && (
              <button
                onClick={clearCart}
                className="text-xs text-slate-400 hover:text-rose-400 transition"
              >
                Clear Cart
              </button>
            )}
          </div>

          {/* Cart Items List */}
          <div className="flex-1 p-4 max-h-[340px] overflow-y-auto space-y-2 divide-y divide-slate-800/60">
            {cart.length === 0 ? (
              <div className="py-24 text-center text-slate-500 text-xs">
                Cart is empty. Tap items or scan barcodes to begin sale.
              </div>
            ) : (
              cart.map((item) => (
                <div key={item.productId} className="pt-2 flex items-center justify-between text-xs">
                  <div className="flex-1 pr-2">
                    <div className="font-semibold text-white line-clamp-1">{item.name}</div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      {item.price.toFixed(3)} {currency}
                    </div>
                  </div>

                  {/* Touch Quantity Controls */}
                  <div className="flex items-center space-x-1.5 bg-slate-800 px-2 py-1 rounded-xl border border-slate-700">
                    <button
                      onClick={() => updateQuantity(item.productId, -1)}
                      className="text-slate-400 hover:text-white p-1"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="font-mono font-bold text-xs text-white px-1">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateQuantity(item.productId, 1)}
                      className="text-slate-400 hover:text-white p-1"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Line Total & Remove */}
                  <div className="w-20 text-right font-mono font-bold text-emerald-400">
                    {item.total.toFixed(3)}
                  </div>
                  <button
                    onClick={() => removeFromCart(item.productId)}
                    className="p-1 text-slate-500 hover:text-rose-400 ml-1 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Totals & Checkout Button */}
          <div className="p-4 bg-slate-950/60 border-t border-slate-800 space-y-3">
            <div className="space-y-1.5 text-xs text-slate-400 font-mono">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>{subtotal.toFixed(3)} {currency}</span>
              </div>
              <div className="flex justify-between">
                <span>Tax ({activeStore.taxRate}%):</span>
                <span>{taxTotal.toFixed(3)} {currency}</span>
              </div>
              <div className="flex justify-between font-bold text-base text-white border-t border-slate-800 pt-2">
                <span>Total Amount:</span>
                <span className="text-emerald-400 font-mono">
                  {grandTotal.toFixed(3)} {currency}
                </span>
              </div>
            </div>

            <button
              id="charge-checkout-button"
              disabled={cart.length === 0}
              onClick={handleOpenCheckout}
              className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-bold rounded-2xl shadow-lg shadow-emerald-950 transition flex items-center justify-center space-x-2"
            >
              <DollarSign className="w-5 h-5" />
              <span>Charge {grandTotal.toFixed(3)} {currency}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Checkout / Tender Modal (Requirement 8: Cash & KNET) */}
      {checkoutOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden animate-in fade-in">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
              <div className="flex items-center space-x-2">
                <DollarSign className="w-5 h-5 text-emerald-400" />
                <h3 className="text-base font-bold text-white">Payment Tender</h3>
              </div>
              <button
                onClick={() => setCheckoutOpen(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {saleError && (
              <div className="mx-6 mt-4 p-3 rounded-2xl bg-rose-950/60 border border-rose-800 text-rose-200 text-xs flex items-center space-x-2">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{saleError}</span>
              </div>
            )}

            <div className="p-6 space-y-4">
              <div className="p-4 bg-slate-800/80 rounded-2xl text-center">
                <div className="text-xs text-slate-400 font-medium">Grand Total Due</div>
                <div className="text-3xl font-extrabold text-emerald-400 font-mono mt-1">
                  {grandTotal.toFixed(3)} <span className="text-base font-normal">{currency}</span>
                </div>
              </div>

              {/* Payment Method Switcher: CASH vs KNET */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">
                  Select Payment Method
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('CASH')}
                    className={`flex items-center justify-center space-x-2 p-3 rounded-2xl border text-sm font-bold transition ${
                      paymentMethod === 'CASH'
                        ? 'bg-emerald-600/20 border-emerald-500 text-white shadow'
                        : 'bg-slate-800 border-slate-700 text-slate-400'
                    }`}
                  >
                    <Banknote className="w-4 h-4 text-emerald-400" />
                    <span>CASH</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('KNET')}
                    className={`flex items-center justify-center space-x-2 p-3 rounded-2xl border text-sm font-bold transition ${
                      paymentMethod === 'KNET'
                        ? 'bg-blue-600/20 border-blue-500 text-white shadow'
                        : 'bg-slate-800 border-slate-700 text-slate-400'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 text-blue-400" />
                    <span>KNET / CARD</span>
                  </button>
                </div>
              </div>

              {/* Cash Tender & Change Calculations */}
              {paymentMethod === 'CASH' ? (
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Cash Received ({currency})
                    </label>
                    <input
                      id="cash-tendered-input"
                      type="number"
                      step="0.001"
                      value={amountTendered}
                      onChange={(e) => setAmountTendered(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-lg font-mono font-bold text-white focus:outline-none focus:border-emerald-500 text-center"
                    />
                  </div>

                  {/* Quick bill additions */}
                  <div className="flex items-center justify-center space-x-2">
                    <button
                      type="button"
                      onClick={() => setAmountTendered(grandTotal.toFixed(3))}
                      className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded-lg text-xs font-mono font-bold"
                    >
                      Exact
                    </button>
                    {[5, 10, 20, 50].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => addQuickTender(amt)}
                        className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded-lg text-xs font-mono"
                      >
                        +{amt}
                      </button>
                    ))}
                  </div>

                  {/* Change Due Display */}
                  <div className="p-3 bg-slate-950 rounded-2xl flex items-center justify-between text-xs font-mono border border-slate-800">
                    <span className="text-slate-400">Change Due:</span>
                    <span className="text-base font-bold text-emerald-400">
                      {Math.max(0, (parseFloat(amountTendered) || 0) - grandTotal).toFixed(3)} {currency}
                    </span>
                  </div>
                </div>
              ) : (
                /* KNET Reference Display */
                <div className="p-4 bg-slate-950/80 rounded-2xl border border-blue-900/40 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">POS Terminal Ref:</span>
                    <span className="font-mono text-white font-bold">{knetApprovalCode}</span>
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Swipe or tap debit card on the connected POS terminal device.
                  </div>
                </div>
              )}

              <div className="pt-2">
                <button
                  id="confirm-complete-sale"
                  disabled={isProcessingSale}
                  onClick={handleFinalizeSale}
                  className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold rounded-2xl text-sm shadow-lg shadow-emerald-950 transition"
                >
                  {isProcessingSale ? 'Executing Atomic Sale...' : `Complete Sale (${grandTotal.toFixed(3)} ${currency})`}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sale Completed Printable Receipt Modal */}
      {completedSale && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-6 text-center space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle className="w-8 h-8" />
            </div>

            <div>
              <h2 className="text-xl font-bold text-white">Sale Successfully Completed</h2>
              <p className="text-xs text-slate-400 mt-1 font-mono">
                Receipt ID: {completedSale.transactionId}
              </p>
              {completedSale.offlineQueued && (
                <span className="mt-1.5 inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-800">
                  QUEUED FOR OFFLINE SYNC
                </span>
              )}
            </div>

            {/* Printable Receipt Block */}
            <div
              id="printable-pos-receipt"
              className="bg-slate-950 p-4 rounded-2xl text-left text-xs font-mono space-y-2 border border-slate-800 text-slate-300"
            >
              <div className="text-center pb-2 border-b border-slate-800">
                <p className="font-bold text-white text-sm">{activeStore.name}</p>
                <p className="text-[10px] text-slate-500">{activeStore.address || 'Kuwait'}</p>
                <p className="text-[10px] text-slate-500">{new Date(completedSale.createdAt).toLocaleString()}</p>
              </div>

              <div className="space-y-1 py-1 border-b border-slate-800">
                {completedSale.items.map((item, i) => (
                  <div key={i} className="flex justify-between">
                    <span>{item.quantity}x {item.name}</span>
                    <span>{item.total.toFixed(3)}</span>
                  </div>
                ))}
              </div>

              <div className="flex justify-between text-slate-400 pt-1">
                <span>Subtotal:</span>
                <span>{completedSale.subtotal.toFixed(3)} {currency}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Tax:</span>
                <span>{completedSale.taxTotal.toFixed(3)} {currency}</span>
              </div>
              <div className="flex justify-between text-white font-bold text-sm pt-1 border-t border-slate-800">
                <span>TOTAL:</span>
                <span className="text-emerald-400">{completedSale.total.toFixed(3)} {currency}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Payment:</span>
                <span>{completedSale.paymentMethod}</span>
              </div>
              {completedSale.changeDue !== undefined && (
                <div className="flex justify-between text-emerald-400 font-bold border-t border-slate-800 pt-1">
                  <span>Change Given:</span>
                  <span>{completedSale.changeDue.toFixed(3)} {currency}</span>
                </div>
              )}
            </div>

            <div className="flex items-center justify-center space-x-3 pt-2">
              <button
                onClick={() => window.print()}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold transition flex items-center space-x-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>Print Receipt</span>
              </button>

              <button
                id="next-transaction-button"
                onClick={() => setCompletedSale(null)}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition shadow-lg"
              >
                Next Sale
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cashier PIN Unlock Modal */}
      {pinModalOpen && selectedEmpForPin && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-6 space-y-4">
            <div className="text-center">
              <div className="w-12 h-12 rounded-2xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center mx-auto mb-2">
                <Lock className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white">Cashier Security PIN</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Authenticating: <span className="text-white font-semibold">{selectedEmpForPin.name}</span>
              </p>
            </div>

            {pinError && (
              <div className="p-2.5 rounded-xl bg-rose-950/60 border border-rose-800 text-rose-300 text-xs text-center">
                {pinError}
              </div>
            )}

            <form onSubmit={handleVerifyPin} className="space-y-4">
              <input
                id="cashier-pin-input"
                type="password"
                maxLength={8}
                autoFocus
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value.replace(/\D/g, ''))}
                placeholder="Enter 4-digit PIN"
                className="w-full px-3.5 py-3 bg-slate-800 border border-slate-700 rounded-xl text-center text-2xl tracking-widest font-mono text-white focus:outline-none focus:border-emerald-500"
              />

              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={() => setPinModalOpen(false)}
                  className="w-1/2 py-2.5 text-xs text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow transition"
                >
                  Unlock Shift
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
