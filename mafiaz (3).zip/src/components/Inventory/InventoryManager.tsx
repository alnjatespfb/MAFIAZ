import React, { useState, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import { Product } from '../../types';
import {
  subscribeToStoreProducts,
  adjustProductStock,
  deleteProduct,
} from '../../firebase/services/productService';
import {
  Boxes,
  Plus,
  Minus,
  Search,
  AlertTriangle,
  ArrowUpDown,
  Barcode,
  DollarSign,
  TrendingDown,
  CheckCircle2,
  Package,
} from 'lucide-react';
import { ProductModal } from '../Products/ProductModal';

export const InventoryManager: React.FC = () => {
  const { activeStore } = useStore();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [stockFilter, setStockFilter] = useState<'ALL' | 'LOW' | 'OUT' | 'HEALTHY'>('ALL');

  // Quick stock adjustment state
  const [adjustingProductId, setAdjustingProductId] = useState<string | null>(null);
  const [adjustmentDelta, setAdjustmentDelta] = useState<number>(0);
  const [modalOpen, setModalOpen] = useState(false);
  const [productToEdit, setProductToEdit] = useState<Product | null>(null);

  useEffect(() => {
    if (!activeStore) {
      setProducts([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    const unsub = subscribeToStoreProducts(
      activeStore.storeId,
      (prods) => {
        setProducts(prods);
        setLoading(false);
      },
      (err) => {
        console.error('Products subscription error:', err);
        setLoading(false);
      }
    );

    return () => unsub();
  }, [activeStore]);

  const currency = activeStore?.currency || 'KWD';

  const handleApplyAdjustment = async (productId: string, delta: number) => {
    if (!activeStore || delta === 0) return;
    try {
      await adjustProductStock(activeStore.storeId, productId, delta);
      setAdjustingProductId(null);
      setAdjustmentDelta(0);
    } catch (err: any) {
      alert(`Stock adjustment error: ${err.message}`);
    }
  };

  const categories = ['ALL', ...Array.from(new Set(products.map((p) => p.category || 'General')))];

  // Filter products
  const filteredProducts = products.filter((p) => {
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !q ||
      p.name.toLowerCase().includes(q) ||
      (p.barcode && p.barcode.toLowerCase().includes(q)) ||
      (p.sku && p.sku.toLowerCase().includes(q));

    const matchesCategory = selectedCategory === 'ALL' || (p.category || 'General') === selectedCategory;

    const qty = p.quantity ?? p.stockQuantity ?? 0;
    const minAlert = p.minimumStock ?? p.minStockAlert ?? 5;

    const matchesStock =
      stockFilter === 'ALL' ||
      (stockFilter === 'OUT' && qty <= 0) ||
      (stockFilter === 'LOW' && qty > 0 && qty <= minAlert) ||
      (stockFilter === 'HEALTHY' && qty > minAlert);

    return matchesSearch && matchesCategory && matchesStock;
  });

  // Summary figures
  const totalStockUnits = products.reduce((acc, p) => acc + (p.quantity ?? p.stockQuantity ?? 0), 0);
  const totalRetailValuation = products.reduce(
    (acc, p) => acc + (p.quantity ?? p.stockQuantity ?? 0) * (p.sellingPrice ?? p.price ?? 0),
    0
  );
  const lowStockCount = products.filter(
    (p) =>
      (p.quantity ?? p.stockQuantity ?? 0) <= (p.minimumStock ?? p.minStockAlert ?? 5) &&
      (p.quantity ?? p.stockQuantity ?? 0) > 0
  ).length;
  const outOfStockCount = products.filter((p) => (p.quantity ?? p.stockQuantity ?? 0) <= 0).length;

  if (!activeStore) {
    return (
      <div className="p-12 text-center text-slate-400">
        <Boxes className="w-12 h-12 mx-auto text-slate-600 mb-3" />
        <p className="text-base font-medium">Please select or create a store first.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-150">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center space-x-2">
            <Boxes className="w-6 h-6 text-emerald-400" />
            <span>Inventory Management</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Store: <strong className="text-slate-200">{activeStore.name}</strong> • Real-time stock on hand, inventory valuation, and replenishment alerts.
          </p>
        </div>

        <button
          id="inventory-add-product-btn"
          onClick={() => {
            setProductToEdit(null);
            setModalOpen(true);
          }}
          className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl text-xs font-bold shadow-lg shadow-emerald-950 flex items-center space-x-2 transition shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Add Inventory Item</span>
        </button>
      </div>

      {/* Stock Health Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Units */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg">
          <span className="text-xs font-medium uppercase tracking-wider text-slate-400 block mb-1">
            Total Units on Hand
          </span>
          <div className="text-2xl font-black text-white">
            {totalStockUnits.toLocaleString()}{' '}
            <span className="text-xs font-normal text-slate-400">units</span>
          </div>
          <p className="text-xs text-slate-400 mt-2">Across {products.length} registered SKUs</p>
        </div>

        {/* Total Valuation */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg">
          <span className="text-xs font-medium uppercase tracking-wider text-slate-400 block mb-1">
            Retail Valuation
          </span>
          <div className="text-2xl font-black text-emerald-400 font-mono">
            {totalRetailValuation.toFixed(3)}{' '}
            <span className="text-xs font-normal text-slate-400">{currency}</span>
          </div>
          <p className="text-xs text-slate-400 mt-2">Current inventory sales value</p>
        </div>

        {/* Low Stock Warning */}
        <div
          onClick={() => setStockFilter(stockFilter === 'LOW' ? 'ALL' : 'LOW')}
          className={`bg-slate-900 border rounded-3xl p-5 shadow-lg cursor-pointer transition ${
            lowStockCount > 0
              ? 'border-amber-800/80 bg-amber-950/20 hover:border-amber-600'
              : 'border-slate-800'
          }`}
        >
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium uppercase tracking-wider">Low-Stock Alert</span>
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-amber-300">
            {lowStockCount} <span className="text-xs font-normal text-slate-400">items</span>
          </div>
          <p className="text-xs text-amber-400/80 mt-2">At or below reorder threshold</p>
        </div>

        {/* Out of Stock */}
        <div
          onClick={() => setStockFilter(stockFilter === 'OUT' ? 'ALL' : 'OUT')}
          className={`bg-slate-900 border rounded-3xl p-5 shadow-lg cursor-pointer transition ${
            outOfStockCount > 0
              ? 'border-rose-800/80 bg-rose-950/20 hover:border-rose-600'
              : 'border-slate-800'
          }`}
        >
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium uppercase tracking-wider">Out of Stock</span>
            <TrendingDown className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-black text-rose-400">
            {outOfStockCount} <span className="text-xs font-normal text-slate-400">items</span>
          </div>
          <p className="text-xs text-rose-400/80 mt-2">Immediate restock required</p>
        </div>
      </div>

      {/* Search and Filters Toolbar */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-xl space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              id="inventory-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search product name, barcode, SKU..."
              className="w-full pl-9 pr-4 py-2.5 bg-slate-800 border border-slate-700/80 rounded-2xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
            />
          </div>

          <div>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700/80 rounded-2xl text-xs text-white focus:outline-none focus:border-emerald-500 transition"
            >
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c === 'ALL' ? 'All Categories' : c}
                </option>
              ))}
            </select>
          </div>

          <div>
            <select
              value={stockFilter}
              onChange={(e) => setStockFilter(e.target.value as any)}
              className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700/80 rounded-2xl text-xs text-white focus:outline-none focus:border-emerald-500 transition"
            >
              <option value="ALL">Stock Status: All Items</option>
              <option value="LOW">Low Stock Items ({lowStockCount})</option>
              <option value="OUT">Out of Stock ({outOfStockCount})</option>
              <option value="HEALTHY">Healthy Stock Levels</option>
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between text-xs text-slate-400 px-1 pt-1">
          <span>
            Displaying <strong className="text-white">{filteredProducts.length}</strong> inventory records
          </span>
          {(searchQuery || selectedCategory !== 'ALL' || stockFilter !== 'ALL') && (
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('ALL');
                setStockFilter('ALL');
              }}
              className="text-emerald-400 hover:underline"
            >
              Clear filters
            </button>
          )}
        </div>
      </div>

      {/* Inventory Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/60 border-b border-slate-800 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              <tr>
                <th className="px-5 py-3.5">Product & SKU</th>
                <th className="px-4 py-3.5">Category</th>
                <th className="px-4 py-3.5 text-right">Retail Price</th>
                <th className="px-4 py-3.5 text-center">Stock on Hand</th>
                <th className="px-4 py-3.5 text-center">Reorder Alert</th>
                <th className="px-6 py-3.5 text-center">Quick Stock Adjust</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {loading ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-slate-400">
                    Loading inventory records...
                  </td>
                </tr>
              ) : filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-slate-400">
                    <Package className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                    No products match the selected criteria.
                  </td>
                </tr>
              ) : (
                filteredProducts.map((prod) => {
                  const qty = prod.quantity ?? prod.stockQuantity ?? 0;
                  const minAlert = prod.minimumStock ?? prod.minStockAlert ?? 5;
                  const isLow = qty <= minAlert;
                  const isOut = qty <= 0;
                  const price = prod.sellingPrice ?? prod.price ?? 0;
                  const isAdjusting = adjustingProductId === prod.productId;

                  return (
                    <tr key={prod.productId} className="hover:bg-slate-800/40 transition">
                      <td className="px-5 py-3.5 font-medium text-white">
                        <div className="font-semibold text-sm text-slate-100">{prod.name}</div>
                        <div className="flex items-center space-x-2 text-[11px] text-slate-400 font-mono mt-0.5">
                          {prod.barcode && <span>Code: {prod.barcode}</span>}
                          {prod.sku && <span>SKU: {prod.sku}</span>}
                        </div>
                      </td>

                      <td className="px-4 py-3.5">
                        <span className="px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 text-[11px]">
                          {prod.category || 'General'}
                        </span>
                      </td>

                      <td className="px-4 py-3.5 text-right font-mono font-bold text-white">
                        {price.toFixed(3)} <span className="text-[10px] text-emerald-400">{currency}</span>
                      </td>

                      <td className="px-4 py-3.5 text-center">
                        <span
                          className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-bold font-mono ${
                            isOut
                              ? 'bg-rose-950 border border-rose-800 text-rose-300'
                              : isLow
                              ? 'bg-amber-950 border border-amber-800 text-amber-300'
                              : 'bg-emerald-950/60 border border-emerald-800 text-emerald-300'
                          }`}
                        >
                          {isLow && <AlertTriangle className="w-3 h-3 shrink-0" />}
                          <span>{qty} units</span>
                        </span>
                      </td>

                      <td className="px-4 py-3.5 text-center font-mono text-slate-400">
                        Min: {minAlert}
                      </td>

                      {/* Immediate Atomic Stock Adjust (+ / -) */}
                      <td className="px-6 py-3.5 text-center">
                        {isAdjusting ? (
                          <div className="flex items-center justify-center space-x-1">
                            <input
                              type="number"
                              value={adjustmentDelta}
                              onChange={(e) => setAdjustmentDelta(parseInt(e.target.value) || 0)}
                              placeholder="+/-"
                              className="w-16 px-2 py-1 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white text-center font-mono"
                            />
                            <button
                              onClick={() => handleApplyAdjustment(prod.productId, adjustmentDelta)}
                              className="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold"
                            >
                              Save
                            </button>
                            <button
                              onClick={() => {
                                setAdjustingProductId(null);
                                setAdjustmentDelta(0);
                              }}
                              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-400 rounded-lg text-xs"
                            >
                              ✕
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center justify-center space-x-1.5">
                            <button
                              onClick={() => handleApplyAdjustment(prod.productId, -1)}
                              disabled={qty <= 0}
                              className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-rose-400 transition"
                              title="Decrease stock by 1"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => {
                                setAdjustingProductId(prod.productId);
                                setAdjustmentDelta(0);
                              }}
                              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium border border-slate-700 transition"
                              title="Set custom adjustment"
                            >
                              <ArrowUpDown className="w-3 h-3 inline mr-1" />
                              <span>Adjust</span>
                            </button>
                            <button
                              onClick={() => handleApplyAdjustment(prod.productId, 1)}
                              className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-400 transition"
                              title="Increase stock by 1"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </td>

                      <td className="px-5 py-3.5 text-right">
                        <button
                          onClick={() => {
                            setProductToEdit(prod);
                            setModalOpen(true);
                          }}
                          className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-xl transition"
                        >
                          Edit Item
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {activeStore && (
        <ProductModal
          isOpen={modalOpen}
          storeId={activeStore.storeId}
          currency={currency}
          productToEdit={productToEdit}
          onClose={() => setModalOpen(false)}
          onSaved={() => {}}
        />
      )}
    </div>
  );
};
