import React from 'react';
import {
  LayoutDashboard,
  Store as PosIcon,
  Package,
  Boxes,
  Users,
  Smartphone,
  Receipt,
  BarChart3,
  Settings,
  X,
  ShieldCheck,
  Monitor,
} from 'lucide-react';
import { useDevice } from '../../context/DeviceContext';
import { useStore } from '../../context/StoreContext';

export type NavTab =
  | 'dashboard'
  | 'pos'
  | 'products'
  | 'inventory'
  | 'employees'
  | 'devices'
  | 'sales'
  | 'reports'
  | 'settings';

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  isOpen: boolean;
  onClose: () => void;
  pendingDevicesCount?: number;
  lowStockCount?: number;
  onOpenDeviceEnrollment?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  isOpen,
  onClose,
  pendingDevicesCount = 0,
  lowStockCount = 0,
  onOpenDeviceEnrollment,
}) => {
  const { currentDevice, deviceStatus, deviceType } = useDevice();
  const { activeStore } = useStore();

  const navItems = [
    { id: 'dashboard' as NavTab, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'pos' as NavTab, label: 'POS Terminal', icon: PosIcon, highlight: true },
    { id: 'products' as NavTab, label: 'Products', icon: Package },
    {
      id: 'inventory' as NavTab,
      label: 'Inventory',
      icon: Boxes,
      badge: lowStockCount > 0 ? `${lowStockCount} Low` : undefined,
      badgeColor: 'bg-rose-950 border-rose-800 text-rose-300',
    },
    { id: 'employees' as NavTab, label: 'Employees', icon: Users },
    {
      id: 'devices' as NavTab,
      label: 'Devices',
      icon: Smartphone,
      badge: pendingDevicesCount > 0 ? `${pendingDevicesCount} New` : undefined,
      badgeColor: 'bg-amber-950 border-amber-800 text-amber-300',
    },
    { id: 'sales' as NavTab, label: 'Sales Audit', icon: Receipt },
    { id: 'reports' as NavTab, label: 'Reports', icon: BarChart3 },
    { id: 'settings' as NavTab, label: 'Store Settings', icon: Settings },
  ];

  const handleNavClick = (tab: NavTab) => {
    onSelectTab(tab);
    if (window.innerWidth < 1024) {
      onClose();
    }
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden transition-opacity"
        />
      )}

      {/* Sidebar Drawer / Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-64 bg-slate-900 border-r border-slate-800 flex flex-col transition-transform duration-200 ease-in-out lg:translate-x-0 lg:static ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="h-16 px-6 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-600 flex items-center justify-center font-black text-white text-base shadow-sm">
              P
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-white text-base tracking-tight leading-none">
                CorePOS
              </span>
              <span className="text-[10px] text-emerald-400 font-semibold tracking-wider uppercase mt-0.5">
                Cloud Retail
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation List */}
        <div className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Navigation
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                id={`sidebar-nav-${item.id}`}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition group ${
                  isActive
                    ? 'bg-emerald-600 text-white font-semibold shadow-md shadow-emerald-950'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <Icon
                    className={`w-4 h-4 transition ${
                      isActive ? 'text-white' : 'text-slate-400 group-hover:text-emerald-400'
                    }`}
                  />
                  <span>{item.label}</span>
                </div>

                {item.badge && (
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${item.badgeColor}`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Hardware Status Footer */}
        <div className="p-3 border-t border-slate-800 bg-slate-950/40">
          <div
            onClick={onOpenDeviceEnrollment}
            className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/80 hover:border-slate-600 cursor-pointer transition flex items-center space-x-3"
            title="Manage this browser/terminal registration"
          >
            <div
              className={`p-2 rounded-lg shrink-0 ${
                deviceStatus === 'APPROVED'
                  ? 'bg-emerald-600/20 text-emerald-400'
                  : deviceStatus === 'PENDING'
                  ? 'bg-amber-600/20 text-amber-400'
                  : 'bg-slate-700 text-slate-300'
              }`}
            >
              {deviceType === 'POS' ? (
                <Monitor className="w-4 h-4" />
              ) : (
                <Smartphone className="w-4 h-4" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-white truncate">
                {currentDevice?.name || 'Local Terminal'}
              </p>
              <div className="flex items-center space-x-1.5 mt-0.5">
                <span
                  className={`w-1.5 h-1.5 rounded-full ${
                    deviceStatus === 'APPROVED'
                      ? 'bg-emerald-400'
                      : deviceStatus === 'PENDING'
                      ? 'bg-amber-400'
                      : 'bg-slate-500'
                  }`}
                />
                <span className="text-[11px] text-slate-400 capitalize">
                  {deviceStatus.toLowerCase()} ({deviceType})
                </span>
              </div>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
