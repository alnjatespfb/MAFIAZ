import React from 'react';
import { WifiOff, RefreshCw, AlertCircle } from 'lucide-react';
import { useDevice } from '../context/DeviceContext';

export const OfflineNotice: React.FC = () => {
  const { isOnline, offlineQueueCount, isSyncing, triggerOfflineSync } = useDevice();

  if (isOnline && offlineQueueCount === 0) {
    return null;
  }

  return (
    <div className="bg-amber-950/80 border-b border-amber-800/80 text-amber-200 px-4 py-2.5 text-sm transition-all shadow-inner">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center space-x-2.5">
          {!isOnline ? (
            <WifiOff className="w-5 h-5 text-amber-400 shrink-0 animate-pulse" />
          ) : (
            <AlertCircle className="w-5 h-5 text-amber-400 shrink-0" />
          )}
          <div>
            {!isOnline ? (
              <span className="font-medium">
                Offline — pending operations will sync when connection returns.
              </span>
            ) : (
              <span className="font-medium">
                Connection restored. {offlineQueueCount} pending transaction{offlineQueueCount > 1 ? 's' : ''} queued.
              </span>
            )}
            {offlineQueueCount > 0 && (
              <span className="ml-2 text-xs bg-amber-900 px-2 py-0.5 rounded-full border border-amber-700">
                {offlineQueueCount} in local queue
              </span>
            )}
          </div>
        </div>

        {isOnline && offlineQueueCount > 0 && (
          <button
            id="banner-sync-button"
            onClick={triggerOfflineSync}
            disabled={isSyncing}
            className="flex items-center space-x-1.5 px-3 py-1 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold shadow transition"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Synchronizing...' : 'Sync Now'}</span>
          </button>
        )}
      </div>
    </div>
  );
};
