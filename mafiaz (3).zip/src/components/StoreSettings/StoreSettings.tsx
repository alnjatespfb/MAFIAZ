import React, { useState, useEffect } from 'react';
import {
  Settings,
  Store as StoreIcon,
  Smartphone,
  Copy,
  Check,
  QrCode,
  Trash2,
  AlertTriangle,
  Save,
  Loader2,
  ExternalLink,
} from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { updateStoreProfile, deleteStore } from '../../firebase/services/storeService';
import { firebaseConfig } from '../../firebase/config';

export const StoreSettings: React.FC = () => {
  const { activeStore, setActiveStore, stores } = useStore();

  const [name, setName] = useState('');
  const [country, setCountry] = useState('Kuwait');
  const [currency, setCurrency] = useState('KWD');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [logo, setLogo] = useState('');
  const [taxRate, setTaxRate] = useState('0');

  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [copiedStoreId, setCopiedStoreId] = useState(false);
  const [copiedProjectId, setCopiedProjectId] = useState(false);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    if (activeStore) {
      setName(activeStore.name || '');
      setCountry(activeStore.country || 'Kuwait');
      setCurrency(activeStore.currency || 'KWD');
      setAddress(activeStore.address || '');
      setPhone(activeStore.phone || '');
      setLogo(activeStore.logo || '');
      setTaxRate(String(activeStore.taxRate ?? 0));
    }
  }, [activeStore]);

  if (!activeStore) {
    return (
      <div className="p-12 text-center text-slate-400">
        <StoreIcon className="w-12 h-12 mx-auto text-slate-600 mb-3" />
        <p className="text-base font-medium">Please select a store first.</p>
      </div>
    );
  }

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Store name is required.');
      return;
    }

    try {
      setSaving(true);
      setError(null);
      await updateStoreProfile(activeStore.storeId, {
        name: name.trim(),
        country: country.trim(),
        currency: currency.trim(),
        address: address.trim(),
        phone: phone.trim(),
        logo: logo.trim(),
        taxRate: parseFloat(taxRate) || 0,
      });

      // Update activeStore local copy
      setActiveStore({
        ...activeStore,
        name: name.trim(),
        country: country.trim(),
        currency: currency.trim(),
        address: address.trim(),
        phone: phone.trim(),
        logo: logo.trim(),
        taxRate: parseFloat(taxRate) || 0,
      });

      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 4000);
    } catch (err: any) {
      setError(err.message || 'Failed to update store settings.');
    } finally {
      setSaving(false);
    }
  };

  const handleCopy = (text: string, type: 'STORE' | 'PROJECT') => {
    navigator.clipboard.writeText(text);
    if (type === 'STORE') {
      setCopiedStoreId(true);
      setTimeout(() => setCopiedStoreId(false), 2000);
    } else {
      setCopiedProjectId(true);
      setTimeout(() => setCopiedProjectId(false), 2000);
    }
  };

  const handleDeleteStore = async () => {
    if (deleteConfirmText !== activeStore.name) {
      alert(`Please type "${activeStore.name}" exactly to confirm deletion.`);
      return;
    }

    try {
      setDeleting(true);
      await deleteStore(activeStore.storeId);
      setDeleteModalOpen(false);
      // Fallback to another store if exists
      const remaining = stores.filter((s) => s.storeId !== activeStore.storeId);
      if (remaining.length > 0) {
        setActiveStore(remaining[0]);
      } else {
        window.location.reload();
      }
    } catch (err: any) {
      alert(`Failed to delete store: ${err.message}`);
    } finally {
      setDeleting(false);
    }
  };

  // QR code encoded data for Android companion app
  const androidPairingPayload = JSON.stringify({
    storeId: activeStore.storeId,
    storeName: activeStore.name,
    projectId: firebaseConfig.projectId,
    currency: activeStore.currency,
  });

  const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(
    androidPairingPayload
  )}&bgcolor=0f172a&color=10b981`;

  return (
    <div className="space-y-6 max-w-4xl mx-auto animate-in fade-in duration-150">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white flex items-center space-x-2">
          <Settings className="w-6 h-6 text-emerald-400" />
          <span>Store Settings & Configuration</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Manage store identity, operational parameters, and Android barcode scanner pairing.
        </p>
      </div>

      {saveSuccess && (
        <div className="p-3.5 rounded-2xl bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-xs flex items-center space-x-2 animate-in fade-in">
          <Check className="w-4 h-4" />
          <span>Store profile successfully updated!</span>
        </div>
      )}

      {error && (
        <div className="p-3.5 rounded-2xl bg-rose-950/60 border border-rose-800 text-rose-200 text-xs flex items-center space-x-2">
          <AlertTriangle className="w-4 h-4 text-rose-400" />
          <span>{error}</span>
        </div>
      )}

      {/* Form: Store Profile */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
        <h2 className="text-base font-bold text-white mb-4 flex items-center space-x-2">
          <StoreIcon className="w-5 h-5 text-emerald-400" />
          <span>Store Profile</span>
        </h2>

        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Store Name *
              </label>
              <input
                id="settings-store-name-input"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-emerald-500 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Country
              </label>
              <input
                id="settings-store-country-input"
                type="text"
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                placeholder="Kuwait"
                className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-emerald-500 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Store Currency Code
              </label>
              <select
                id="settings-store-currency-select"
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-emerald-500 transition"
              >
                <option value="KWD">Kuwaiti Dinar (KWD)</option>
                <option value="SAR">Saudi Riyal (SAR)</option>
                <option value="AED">UAE Dirham (AED)</option>
                <option value="QAR">Qatari Riyal (QAR)</option>
                <option value="BHD">Bahraini Dinar (BHD)</option>
                <option value="OMR">Omani Rial (OMR)</option>
                <option value="USD">US Dollar (USD)</option>
                <option value="EUR">Euro (EUR)</option>
                <option value="GBP">British Pound (GBP)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Tax Rate (%)
              </label>
              <input
                id="settings-store-tax-input"
                type="number"
                step="0.1"
                min="0"
                value={taxRate}
                onChange={(e) => setTaxRate(e.target.value)}
                placeholder="0"
                className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-emerald-500 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Contact Phone
              </label>
              <input
                id="settings-store-phone-input"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+965 2200 0000"
                className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-emerald-500 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Logo Image URL
              </label>
              <input
                id="settings-store-logo-input"
                type="url"
                value={logo}
                onChange={(e) => setLogo(e.target.value)}
                placeholder="https://example.com/logo.png"
                className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-emerald-500 transition"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Store Street Address
              </label>
              <input
                id="settings-store-address-input"
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Salmiya, Block 4, Salem Al-Mubarak St, Kuwait"
                className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-emerald-500 transition"
              />
            </div>
          </div>

          <div className="pt-3 flex justify-end">
            <button
              id="save-store-settings-button"
              type="submit"
              disabled={saving}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-lg flex items-center space-x-2 transition"
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              <span>Save Changes</span>
            </button>
          </div>
        </form>
      </div>

      {/* Android Application Integration Section (Requirement 18) */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-xl bg-blue-600/20 text-blue-400">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white leading-none">
              Android Barcode Scanner Integration
            </h2>
            <p className="text-[11px] text-slate-400 mt-1">
              Connect your Android scanner application to the same Firebase store database.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
          {/* QR Code */}
          <div className="flex flex-col items-center justify-center p-4 rounded-2xl bg-slate-950/60 border border-slate-800 text-center">
            <img
              src={qrImageUrl}
              alt="Scan to Connect"
              className="w-44 h-44 rounded-xl shadow-md border border-slate-800"
            />
            <span className="text-[11px] text-slate-400 font-medium mt-2 flex items-center space-x-1">
              <QrCode className="w-3.5 h-3.5 text-emerald-400" />
              <span>Scan with Android Scanner App</span>
            </span>
          </div>

          {/* Credentials to enter on Phone */}
          <div className="md:col-span-2 space-y-4 flex flex-col justify-center">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">
                Store ID (Unique Key)
              </label>
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  readOnly
                  value={activeStore.storeId}
                  className="flex-1 px-3.5 py-2 bg-slate-800/80 border border-slate-700 rounded-xl text-xs text-slate-200 font-mono"
                />
                <button
                  type="button"
                  onClick={() => handleCopy(activeStore.storeId, 'STORE')}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-medium flex items-center space-x-1 border border-slate-700 transition"
                >
                  {copiedStoreId ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedStoreId ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">
                Firebase Project ID
              </label>
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  readOnly
                  value={firebaseConfig.projectId}
                  className="flex-1 px-3.5 py-2 bg-slate-800/80 border border-slate-700 rounded-xl text-xs text-slate-200 font-mono"
                />
                <button
                  type="button"
                  onClick={() => handleCopy(firebaseConfig.projectId, 'PROJECT')}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-medium flex items-center space-x-1 border border-slate-700 transition"
                >
                  {copiedProjectId ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedProjectId ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/60 text-xs text-slate-300 space-y-1">
              <p className="font-semibold text-white">How Pairing Works:</p>
              <p className="text-[11px] text-slate-400">
                1. Launch the Android scanner app on your phone.
                <br />
                2. Scan the QR code above or manually enter the Store ID.
                <br />
                3. The Android app sends an enrollment request, which appears in your Notifications and Devices tab.
                <br />
                4. Click <strong>Approve</strong> in the web app to grant scanner access.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Danger Zone: Delete Store */}
      <div className="bg-slate-900 border border-rose-900/40 rounded-3xl p-6 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-rose-400 flex items-center space-x-2">
              <Trash2 className="w-4 h-4" />
              <span>Delete Store</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Permanently remove this store and decouple registered terminals. This action cannot be undone.
            </p>
          </div>

          <button
            id="open-delete-store-modal-button"
            onClick={() => setDeleteModalOpen(true)}
            className="px-4 py-2 bg-rose-950/60 hover:bg-rose-900 text-rose-300 border border-rose-800 rounded-xl text-xs font-bold transition"
          >
            Delete Store...
          </button>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-md bg-slate-900 border border-rose-800 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-950 border border-rose-800 text-rose-400 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="text-center">
              <h3 className="text-lg font-bold text-white">Delete "{activeStore.name}"?</h3>
              <p className="text-xs text-slate-400 mt-1">
                To confirm deletion, please type the exact store name:
              </p>
              <div className="mt-2 font-mono font-bold text-sm text-rose-300 bg-slate-950 py-1 px-3 rounded-lg border border-slate-800 inline-block">
                {activeStore.name}
              </div>
            </div>

            <input
              type="text"
              value={deleteConfirmText}
              onChange={(e) => setDeleteConfirmText(e.target.value)}
              placeholder="Type store name to confirm"
              className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-rose-500"
            />

            <div className="flex items-center space-x-3 pt-2">
              <button
                type="button"
                onClick={() => setDeleteModalOpen(false)}
                className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                id="confirm-delete-store-button"
                type="button"
                onClick={handleDeleteStore}
                disabled={deleteConfirmText !== activeStore.name || deleting}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-white rounded-xl text-xs font-bold shadow transition"
              >
                {deleting ? 'Deleting...' : 'Permanently Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
