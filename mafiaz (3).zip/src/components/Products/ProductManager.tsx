import React, { useState, useEffect } from 'react';
import {
  Package,
  Plus,
  Search,
  Filter,
  ArrowUpDown,
  Edit2,
  Trash2,
  QrCode,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Eye,
  EyeOff,
  Boxes,
} from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import {
  subscribeToStoreProducts,
  deleteProduct,
  toggleProductActive,
} from '../../firebase/services/productService';
import { Product } from '../../types';
import { ProductModal } from './ProductModal';
import { ScanToAddModal } from './ScanToAddModal';

export const ProductManager: React.FC = () => {
  const { activeStore } = useStore();
  const [products, setProducts] = useState<Product[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'INACTIVE' | 'LOW_STOCK'>('ALL');
  const [sortBy, setSortBy] = useState<'NAME' | 'PRICE_ASC' | 'PRICE_DESC' | 'STOCK_ASC' | 'STOCK_DESC'>('NAME');

  const [modalOpen, setModalOpen] = useState(false);
  const [productToEdit, setProductToEdit] = useState<Product | null>(null);
  const [scanModalOpen, setScanModalOpen] = useState(false);
  const [prefilledBarcode, setPrefilledBarcode] = useState<string>('');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  useEffect(() => {
    if (!activeStore) return;
    const unsub = subscribeToStoreProducts(activeStore.storeId, (data) => {
      setProducts(data);
    });
    return () => unsub();
  }, [activeStore]);

  const currency = activeStore?.currency || 'KWD';

  // Categories list
  const categories = ['ALL', ...Array.from(new Set(products.map((p) => p.category || 'General')))];

  // Filter and sort logic
  const filteredProducts = products.filter((p) => {
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !q ||
      p.name.toLowerCase().includes(q) ||
      (p.barcode && p.barcode.toLowerCase().includes(q)) ||
      (p.sku && p.sku.toLowerCase().includes(q)) ||
      (p.category && p.category.toLowerCase().includes(q));

    const matchesCategory = selectedCategory === 'ALL' || (p.category || 'General') === selectedCategory;

    const qty = p.quantity ?? p.stockQuantity ?? 0;
    const minAlert = p.minimumStock ?? p.minStockAlert ?? 5;
    const matchesStatus =
      statusFilter === 'ALL' ||
      (statusFilter === 'ACTIVE' && p.active !== false) ||
      (statusFilter === 'INACTIVE' && p.active === false) ||
      (statusFilter === 'LOW_STOCK' && qty <= minAlert);

    return matchesSearch && matchesCategory && matchesStatus;
  });

  filteredProducts.sort((a, b) => {
    const aPrice = a.sellingPrice ?? a.price ?? 0;
    const bPrice = b.sellingPrice ?? b.price ?? 0;
    const aStock = a.quantity ?? a.stockQuantity ?? 0;
    const bStock = b.quantity ?? b.stockQuantity ?? 0;

    if (sortBy === 'NAME') return a.name.localeCompare(b.name);
    if (sortBy === 'PRICE_ASC') return aPrice - bPrice;
    if (sortBy === 'PRICE_DESC') return bPrice - aPrice;
    if (sortBy === 'STOCK_ASC') return aStock - bStock;
    if (sortBy === 'STOCK_DESC') return bStock - aStock;
    return 0;
  });

  const handleDelete = async (productId: string) => {
    if (!activeStore) return;
    try {
      await deleteProduct(activeStore.storeId, productId);
      setDeleteConfirmId(null);
    } catch (err) {
      console.error('Failed to delete product:', err);
    }
  };

  const handleToggleStatus = async (product: Product) => {
    if (!activeStore) return;
    try {
      await toggleProductActive(activeStore.storeId, product.productId, product.active !== false);
    } catch (err) {
      console.error('Failed to toggle status:', err);
    }
  };

  const handleScanBarcodeDetected = (barcode: string, existing?: Product | null) => {
    if (existing) {
      setProductToEdit(existing);
      setPrefilledBarcode('');
      setModalOpen(true);
    } else {
      setProductToEdit(null);
      setPrefilledBarcode(barcode);
      setModalOpen(true);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-150">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center space-x-2">
            <Package className="w-6 h-6 text-emerald-400" />
            <span>Products Catalog</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Manage store merchandise, barcodes, retail pricing, and categories.
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          {/* Requirement 7: Scan Barcode button */}
          <button
            id="scan-barcode-add-product-button"
            onClick={() => setScanModalOpen(true)}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-emerald-500/30 hover:border-emerald-500/60 rounded-2xl text-xs font-bold shadow transition flex items-center space-x-2"
            title="Scan barcode with phone or hardware scanner"
          >
            <QrCode className="w-4 h-4" />
            <span>Scan to Add</span>
          </button>

          <button
            id="add-product-button"
            onClick={() => {
              setProductToEdit(null);
              setPrefilledBarcode('');
              setModalOpen(true);
            }}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl text-xs font-bold shadow-lg shadow-emerald-950 flex items-center space-x-2 transition"
          >
            <Plus className="w-4 h-4" />
            <span>New Product</span>
          </button>
        </div>
      </div>

      {/* Filters & Search Toolbar */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-xl space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              id="search-products-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search title, barcode, SKU..."
              className="w-full pl-9 pr-3.5 py-2.5 bg-slate-800 border border-slate-700/80 rounded-2xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
            />
          </div>

          {/* Category Filter */}
          <div>
            <select
              id="filter-category-select"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700/80 rounded-2xl text-xs text-white focus:outline-none focus:border-emerald-500 transition"
            >
              {categories.map((c) => (
                <option key={c} value={c}>
                  Category: {c}
                </option>
              ))}
            </select>
          </div>

          {/* Stock & Status Filter */}
          <div>
            <select
              id="filter-status-select"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700/80 rounded-2xl text-xs text-white focus:outline-none focus:border-emerald-500 transition"
            >
              <option value="ALL">Status: All Products ({products.length})</option>
              <option value="ACTIVE">Active in POS</option>
              <option value="INACTIVE">Deactivated</option>
              <option value="LOW_STOCK">Low Stock Alert</option>
            </select>
          </div>

          {/* Sort By */}
          <div>
            <select
              id="sort-products-select"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700/80 rounded-2xl text-xs text-white focus:outline-none focus:border-emerald-500 transition"
            >
              <option value="NAME">Sort by Name (A-Z)</option>
              <option value="PRICE_ASC">Price: Low to High</option>
              <option value="PRICE_DESC">Price: High to Low</option>
              <option value="STOCK_ASC">Stock: Low to High</option>
              <option value="STOCK_DESC">Stock: High to Low</option>
            </select>
          </div>
        </div>

        {/* Active Filters Summary */}
        <div className="flex items-center justify-between text-xs text-slate-400 px-1 pt-1">
          <span>
            Showing <strong className="text-white">{filteredProducts.length}</strong> of {products.length} products
          </span>
          {(searchQuery || selectedCategory !== 'ALL' || statusFilter !== 'ALL') && (
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('ALL');
                setStatusFilter('ALL');
              }}
              className="text-emerald-400 hover:underline"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/60 border-b border-slate-800 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              <tr>
                <th className="px-5 py-3.5">Product</th>
                <th className="px-4 py-3.5">Barcode / SKU</th>
                <th className="px-4 py-3.5">Category</th>
                <th className="px-4 py-3.5 text-right">Selling Price</th>
                <th className="px-4 py-3.5 text-right">Cost Price</th>
                <th className="px-4 py-3.5 text-center">Stock</th>
                <th className="px-4 py-3.5 text-center">Status</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-6 py-12 text-center text-slate-400">
                    <Boxes className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                    No products found matching your search.
                  </td>
                </tr>
              ) : (
                filteredProducts.map((prod) => {
                  const qty = prod.quantity ?? prod.stockQuantity ?? 0;
                  const minAlert = prod.minimumStock ?? prod.minStockAlert ?? 5;
                  const isLow = qty <= minAlert;
                  const isOut = qty <= 0;
                  const price = prod.sellingPrice ?? prod.price ?? 0;

                  return (
                    <tr key={prod.productId} className="hover:bg-slate-800/40 transition">
                      {/* Product Name & Image */}
                      <td className="px-5 py-3.5 font-medium text-white">
                        <div className="flex items-center space-x-3">
                          {prod.image ? (
                            <img
                              src={prod.image}
                              alt={prod.name}
                              referrerPolicy="no-referrer"
                              className="w-9 h-9 rounded-xl object-cover bg-slate-800 border border-slate-700 shrink-0"
                            />
                          ) : (
                            <div className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700/60 flex items-center justify-center text-slate-400 font-bold shrink-0">
                              {prod.name.charAt(0).toUpperCase()}
                            </div>
                          )}
                          <div className="truncate max-w-[200px]">
                            <span className="font-semibold block truncate text-slate-100">
                              {prod.name}
                            </span>
                            <span className="text-[10px] text-slate-400">ID: {prod.productId}</span>
                          </div>
                        </div>
                      </td>

                      {/* Barcode & SKU */}
                      <td className="px-4 py-3.5 font-mono text-slate-300">
                        {prod.barcode ? (
                          <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700/60 text-emerald-300 text-[11px]">
                            {prod.barcode}
                          </span>
                        ) : (
                          <span className="text-slate-500 italic">No barcode</span>
                        )}
                        {prod.sku && <div className="text-[10px] text-slate-400 mt-0.5">{prod.sku}</div>}
                      </td>

                      {/* Category */}
                      <td className="px-4 py-3.5">
                        <span className="px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 text-[11px]">
                          {prod.category || 'General'}
                        </span>
                      </td>

                      {/* Selling Price */}
                      <td className="px-4 py-3.5 text-right font-mono font-bold text-white">
                        {price.toFixed(3)} <span className="text-[10px] text-emerald-400">{currency}</span>
                      </td>

                      {/* Cost Price */}
                      <td className="px-4 py-3.5 text-right font-mono text-slate-400">
                        {prod.costPrice !== undefined ? (
                          `${prod.costPrice.toFixed(3)} ${currency}`
                        ) : (
                          <span className="text-slate-600">—</span>
                        )}
                      </td>

                      {/* Stock on Hand */}
                      <td className="px-4 py-3.5 text-center">
                        <span
                          className={`inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-[11px] font-bold ${
                            isOut
                              ? 'bg-rose-950 border border-rose-800 text-rose-300'
                              : isLow
                              ? 'bg-amber-950 border border-amber-800 text-amber-300'
                              : 'bg-emerald-950/60 border border-emerald-800 text-emerald-300'
                          }`}
                        >
                          {isLow && <AlertTriangle className="w-3 h-3 shrink-0" />}
                          <span>{qty}</span>
                        </span>
                      </td>

                      {/* Status */}
                      <td className="px-4 py-3.5 text-center">
                        <button
                          onClick={() => handleToggleStatus(prod)}
                          className={`px-2.5 py-1 rounded-full text-[11px] font-medium transition ${
                            prod.active !== false
                              ? 'bg-emerald-950/40 text-emerald-300 hover:bg-emerald-900/60'
                              : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                          }`}
                          title="Click to toggle active status"
                        >
                          {prod.active !== false ? 'Active' : 'Deactivated'}
                        </button>
                      </td>

                      {/* Actions */}
                      <td className="px-5 py-3.5 text-right">
                        <div className="flex items-center justify-end space-x-1.5">
                          <button
                            onClick={() => {
                              setProductToEdit(prod);
                              setPrefilledBarcode('');
                              setModalOpen(true);
                            }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                            title="Edit product"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          {deleteConfirmId === prod.productId ? (
                            <div className="flex items-center space-x-1">
                              <button
                                onClick={() => handleDelete(prod.productId)}
                                className="px-2 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded text-[10px] font-bold"
                              >
                                Confirm
                              </button>
                              <button
                                onClick={() => setDeleteConfirmId(null)}
                                className="px-2 py-1 bg-slate-800 text-slate-300 rounded text-[10px]"
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => setDeleteConfirmId(prod.productId)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition"
                              title="Delete product"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modals */}
      {activeStore && (
        <>
          <ProductModal
            isOpen={modalOpen}
            storeId={activeStore.storeId}
            currency={currency}
            productToEdit={productToEdit}
            initialBarcode={prefilledBarcode}
            onClose={() => setModalOpen(false)}
            onSaved={() => {}}
          />

          <ScanToAddModal
            isOpen={scanModalOpen}
            storeId={activeStore.storeId}
            onClose={() => setScanModalOpen(false)}
            onBarcodeDetected={handleScanBarcodeDetected}
          />
        </>
      )}
    </div>
  );
};
