import React, { useState, useEffect } from 'react';
import { X, Package, AlertCircle } from 'lucide-react';
import { Product } from '../../types';
import { addProduct, updateProduct } from '../../firebase/services/productService';

interface ProductModalProps {
  isOpen: boolean;
  storeId: string;
  currency: string;
  productToEdit?: Product | null;
  initialBarcode?: string;
  onClose: () => void;
  onSaved: (product: Product) => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  isOpen,
  storeId,
  currency,
  productToEdit,
  initialBarcode,
  onClose,
  onSaved,
}) => {
  const [name, setName] = useState('');
  const [barcode, setBarcode] = useState('');
  const [category, setCategory] = useState('General');
  const [sellingPrice, setSellingPrice] = useState('');
  const [costPrice, setCostPrice] = useState('');
  const [quantity, setQuantity] = useState('10');
  const [minimumStock, setMinimumStock] = useState('5');
  const [image, setImage] = useState('');
  const [active, setActive] = useState(true);

  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (productToEdit) {
      setName(productToEdit.name || '');
      setBarcode(productToEdit.barcode || '');
      setCategory(productToEdit.category || 'General');
      setSellingPrice(String(productToEdit.sellingPrice ?? productToEdit.price ?? ''));
      setCostPrice(productToEdit.costPrice !== undefined ? String(productToEdit.costPrice) : '');
      setQuantity(String(productToEdit.quantity ?? productToEdit.stockQuantity ?? 0));
      setMinimumStock(String(productToEdit.minimumStock ?? productToEdit.minStockAlert ?? 5));
      setImage(productToEdit.image || '');
      setActive(productToEdit.active !== false);
    } else {
      setName('');
      setBarcode(initialBarcode || '');
      setCategory('General');
      setSellingPrice('');
      setCostPrice('');
      setQuantity('10');
      setMinimumStock('5');
      setImage('');
      setActive(true);
    }
    setError(null);
  }, [productToEdit, initialBarcode, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Product name is required.');
      return;
    }
    const priceNum = parseFloat(sellingPrice);
    if (isNaN(priceNum) || priceNum < 0) {
      setError('Please provide a valid selling price.');
      return;
    }
    const qtyNum = parseInt(quantity, 10);
    if (isNaN(qtyNum) || qtyNum < 0) {
      setError('Please provide a valid stock quantity.');
      return;
    }

    try {
      setSaving(true);
      setError(null);

      const costNum = costPrice ? parseFloat(costPrice) : undefined;
      const minStockNum = minimumStock ? parseInt(minimumStock, 10) : 5;

      if (productToEdit) {
        await updateProduct(storeId, productToEdit.productId, {
          name: name.trim(),
          barcode: barcode.trim(),
          category: category.trim(),
          sellingPrice: priceNum,
          costPrice: costNum,
          quantity: qtyNum,
          minimumStock: minStockNum,
          image: image.trim(),
          active,
        });
        onSaved({
          ...productToEdit,
          name: name.trim(),
          barcode: barcode.trim(),
          category: category.trim(),
          sellingPrice: priceNum,
          costPrice: costNum,
          quantity: qtyNum,
          minimumStock: minStockNum,
          image: image.trim(),
          active,
          updatedAt: new Date().toISOString(),
        });
      } else {
        const created = await addProduct(storeId, {
          name: name.trim(),
          barcode: barcode.trim(),
          category: category.trim(),
          sellingPrice: priceNum,
          costPrice: costNum,
          quantity: qtyNum,
          minimumStock: minStockNum,
          image: image.trim(),
        });
        onSaved(created);
      }
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save product.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden my-8">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-emerald-600/20 text-emerald-400">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white leading-none">
                {productToEdit ? 'Edit Product' : 'Add New Product'}
              </h2>
              <p className="text-[11px] text-slate-400 mt-1">
                Store Catalog & Inventory Record
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3 rounded-2xl bg-rose-950/60 border border-rose-800 text-rose-200 text-xs flex items-start space-x-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Product Title *
              </label>
              <input
                id="product-name-input"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Premium Arabica Coffee Beans 250g"
                className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Barcode / EAN (Unique in Store)
              </label>
              <input
                id="product-barcode-input"
                type="text"
                value={barcode}
                onChange={(e) => setBarcode(e.target.value)}
                placeholder="e.g. 6281001234567"
                className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white font-mono placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Category
              </label>
              <input
                id="product-category-input"
                type="text"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                placeholder="e.g. Beverages, Snacks, Electronics"
                className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Selling Price ({currency}) *
              </label>
              <input
                id="product-price-input"
                type="number"
                step="0.001"
                min="0"
                required
                value={sellingPrice}
                onChange={(e) => setSellingPrice(e.target.value)}
                placeholder="2.500"
                className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Cost Price ({currency})
              </label>
              <input
                id="product-cost-input"
                type="number"
                step="0.001"
                min="0"
                value={costPrice}
                onChange={(e) => setCostPrice(e.target.value)}
                placeholder="1.200"
                className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Quantity on Hand *
              </label>
              <input
                id="product-quantity-input"
                type="number"
                min="0"
                required
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                placeholder="20"
                className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Minimum Stock Alert Level
              </label>
              <input
                id="product-min-stock-input"
                type="number"
                min="0"
                value={minimumStock}
                onChange={(e) => setMinimumStock(e.target.value)}
                placeholder="5"
                className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition font-mono"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Image URL (Optional)
              </label>
              <input
                id="product-image-input"
                type="url"
                value={image}
                onChange={(e) => setImage(e.target.value)}
                placeholder="https://..."
                className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
              />
            </div>

            <div className="sm:col-span-2 flex items-center justify-between p-3 rounded-xl bg-slate-800/50 border border-slate-700/60">
              <div>
                <span className="text-xs font-semibold text-white block">Active Status</span>
                <span className="text-[11px] text-slate-400">
                  Inactive products are hidden from the POS register.
                </span>
              </div>
              <input
                type="checkbox"
                checked={active}
                onChange={(e) => setActive(e.target.checked)}
                className="w-5 h-5 rounded text-emerald-600 focus:ring-emerald-500 bg-slate-700 border-slate-600"
              />
            </div>
          </div>

          <div className="pt-4 flex items-center justify-end space-x-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
            >
              Cancel
            </button>
            <button
              id="save-product-button"
              type="submit"
              disabled={saving}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold rounded-xl shadow-lg transition"
            >
              {saving ? 'Saving...' : productToEdit ? 'Save Changes' : 'Create Product'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
