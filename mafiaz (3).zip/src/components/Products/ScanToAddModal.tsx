import React, { useState, useEffect } from 'react';
import {
  QrCode,
  Smartphone,
  CheckCircle2,
  AlertCircle,
  X,
  Loader2,
  ArrowRight,
  RefreshCw,
  Search,
} from 'lucide-react';
import { Device, Product } from '../../types';
import { subscribeToStoreDevices } from '../../firebase/services/deviceService';
import { subscribeToIncomingScans } from '../../firebase/services/scannerService';
import { findProductByBarcode } from '../../firebase/services/productService';
import { playChime } from '../../utils/feedback';

interface ScanToAddModalProps {
  isOpen: boolean;
  storeId: string;
  onClose: () => void;
  onBarcodeDetected: (barcode: string, existingProduct?: Product | null) => void;
}

export const ScanToAddModal: React.FC<ScanToAddModalProps> = ({
  isOpen,
  storeId,
  onClose,
  onBarcodeDetected,
}) => {
  const [devices, setDevices] = useState<Device[]>([]);
  const [selectedScannerId, setSelectedScannerId] = useState<string>('ALL');
  const [manualBarcode, setManualBarcode] = useState<string>('');
  const [statusText, setStatusText] = useState<string>('Listening for barcode scans...');
  const [checking, setChecking] = useState<boolean>(false);
  const [detectedBarcode, setDetectedBarcode] = useState<string | null>(null);
  const [existingProductMatch, setExistingProductMatch] = useState<Product | null>(null);

  // Load available approved scanner devices
  useEffect(() => {
    if (!isOpen || !storeId) return;

    const unsubDevices = subscribeToStoreDevices(storeId, (allDevices) => {
      const scanners = allDevices.filter(
        (d) =>
          (d.type === 'SCANNER' || d.deviceType === 'SCANNER') &&
          d.status === 'APPROVED'
      );
      setDevices(scanners);
    });

    return () => unsubDevices();
  }, [isOpen, storeId]);

  // Subscribe to real-time scans
  useEffect(() => {
    if (!isOpen || !storeId) return;

    const unsubScans = subscribeToIncomingScans(
      storeId,
      '', // Listen across scanners
      async (scanEvent) => {
        // If user selected a specific scanner, filter by scannerDeviceId
        if (
          selectedScannerId !== 'ALL' &&
          scanEvent.scannerDeviceId !== selectedScannerId
        ) {
          return;
        }

        const barcode = scanEvent.barcode.trim();
        if (!barcode) return;

        playChime('beep');
        setDetectedBarcode(barcode);
        setStatusText(`Barcode received from scanner: ${barcode}`);
        setChecking(true);

        try {
          const match = await findProductByBarcode(storeId, barcode);
          setExistingProductMatch(match);
        } catch (e) {
          console.error('Error checking barcode match:', e);
        } finally {
          setChecking(false);
        }
      }
    );

    return () => unsubScans();
  }, [isOpen, storeId, selectedScannerId]);

  if (!isOpen) return null;

  const handleProceed = () => {
    if (!detectedBarcode) return;
    onBarcodeDetected(detectedBarcode, existingProductMatch);
    onClose();
  };

  const handleManualLookup = async (e: React.FormEvent) => {
    e.preventDefault();
    const barcode = manualBarcode.trim();
    if (!barcode) return;

    playChime('beep');
    setDetectedBarcode(barcode);
    setChecking(true);
    try {
      const match = await findProductByBarcode(storeId, barcode);
      setExistingProductMatch(match);
    } catch (e) {
      console.error('Error finding barcode:', e);
    } finally {
      setChecking(false);
    }
  };

  const handleReset = () => {
    setDetectedBarcode(null);
    setExistingProductMatch(null);
    setStatusText('Listening for barcode scans...');
    setManualBarcode('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-emerald-600/20 text-emerald-400">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white leading-none">
                Scan Barcode to Add Product
              </h2>
              <p className="text-[11px] text-slate-400 mt-1">
                Real-time scanner bridge workflow
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {/* Step 1: Select Scanner Device */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Listening to Scanner Device:
            </label>
            <select
              id="select-scanner-for-add-product"
              value={selectedScannerId}
              onChange={(e) => setSelectedScannerId(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-emerald-500 transition"
            >
              <option value="ALL">Any Approved Scanner Device ({devices.length} paired)</option>
              {devices.map((d) => (
                <option key={d.deviceId} value={d.deviceId}>
                  {d.name} ({d.deviceId})
                </option>
              ))}
            </select>
            {devices.length === 0 && (
              <p className="text-[11px] text-amber-400 mt-1.5 flex items-center space-x-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>No phone scanners currently paired. You can also test with the manual input below.</span>
              </p>
            )}
          </div>

          {/* Scanner Pulse Area */}
          {!detectedBarcode ? (
            <div className="p-6 rounded-2xl bg-slate-950/60 border border-slate-800 text-center space-y-3 relative overflow-hidden">
              <div className="w-16 h-16 rounded-2xl bg-emerald-600/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto animate-pulse">
                <Smartphone className="w-8 h-8" />
              </div>
              <div>
                <p className="text-sm font-semibold text-white">
                  Point Android or Phone Scanner at Product Barcode
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  The scanned code will instantly register here over Firestore cloud sync.
                </p>
              </div>

              {/* Or manual entry fallback */}
              <form onSubmit={handleManualLookup} className="pt-2 flex items-center space-x-2">
                <input
                  id="manual-barcode-entry-input"
                  type="text"
                  value={manualBarcode}
                  onChange={(e) => setManualBarcode(e.target.value)}
                  placeholder="Or enter barcode directly (e.g. 6281001234567)"
                  className="flex-1 px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
                <button
                  type="submit"
                  className="px-3 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-xl text-xs font-semibold"
                >
                  Submit
                </button>
              </form>
            </div>
          ) : (
            /* Barcode Detected Result Card */
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-800 text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-emerald-400 font-semibold uppercase tracking-wider text-[10px]">
                    Barcode Ingested
                  </span>
                  <span className="font-mono text-white text-sm font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                    {detectedBarcode}
                  </span>
                </div>

                {checking ? (
                  <div className="flex items-center space-x-2 text-slate-400 py-2">
                    <Loader2 className="w-4 h-4 animate-spin text-emerald-400" />
                    <span>Checking inventory database...</span>
                  </div>
                ) : existingProductMatch ? (
                  /* Case A: Barcode already exists */
                  <div className="p-3 rounded-xl bg-amber-950/60 border border-amber-800 text-amber-200 mt-2 space-y-1">
                    <p className="font-bold text-sm text-white flex items-center space-x-1.5">
                      <AlertCircle className="w-4 h-4 text-amber-400" />
                      <span>Product Already Exists</span>
                    </p>
                    <p className="text-xs">
                      "{existingProductMatch.name}" is already registered with this barcode.
                    </p>
                    <div className="text-[11px] text-amber-300 pt-1 flex items-center space-x-3">
                      <span>Price: {existingProductMatch.sellingPrice ?? existingProductMatch.price} {existingProductMatch.storeId}</span>
                      <span>Stock: {existingProductMatch.quantity ?? existingProductMatch.stockQuantity} units</span>
                    </div>
                  </div>
                ) : (
                  /* Case B: New product */
                  <div className="p-3 rounded-xl bg-emerald-900/30 border border-emerald-800/60 text-emerald-200 mt-2 space-y-1">
                    <p className="font-bold text-sm text-white flex items-center space-x-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span>New Product Barcode</span>
                    </p>
                    <p className="text-xs text-slate-300">
                      This barcode is not in your catalog yet. Click proceed to enter the product details with barcode pre-filled.
                    </p>
                  </div>
                )}
              </div>

              <div className="flex items-center space-x-3">
                <button
                  type="button"
                  onClick={handleReset}
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold flex items-center space-x-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Scan Different Code</span>
                </button>
                <button
                  type="button"
                  onClick={handleProceed}
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-lg flex items-center justify-center space-x-1.5 transition"
                >
                  <span>
                    {existingProductMatch ? 'View / Edit Product' : 'Create Product with Barcode'}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
