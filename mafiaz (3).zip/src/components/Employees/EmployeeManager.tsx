import React, { useState, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import { Employee, EmployeeRole } from '../../types';
import {
  subscribeToStoreEmployees,
  addEmployee,
  updateEmployee,
  deleteEmployee,
} from '../../firebase/services/employeeService';
import {
  Users,
  Plus,
  Shield,
  KeyRound,
  CheckCircle,
  XCircle,
  Edit2,
  Trash2,
  X,
  AlertCircle,
  Lock,
} from 'lucide-react';

export const EmployeeManager: React.FC = () => {
  const { activeStore } = useStore();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<EmployeeRole>('cashier');
  const [pinCode, setPinCode] = useState('');
  const [canSell, setCanSell] = useState(true);
  const [canManageInventory, setCanManageInventory] = useState(false);
  const [canManageDevices, setCanManageDevices] = useState(false);
  const [canViewReports, setCanViewReports] = useState(false);
  const [active, setActive] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!activeStore) {
      setEmployees([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    const unsub = subscribeToStoreEmployees(
      activeStore.storeId,
      (empList) => {
        setEmployees(empList);
        setLoading(false);
      },
      (err) => {
        console.error('Employees subscription error:', err);
        setLoading(false);
      }
    );

    return () => unsub();
  }, [activeStore]);

  const openAddModal = () => {
    setEditingEmployee(null);
    setName('');
    setEmail('');
    setRole('cashier');
    setPinCode('');
    setCanSell(true);
    setCanManageInventory(false);
    setCanManageDevices(false);
    setCanViewReports(false);
    setActive(true);
    setError(null);
    setModalOpen(true);
  };

  const openEditModal = (emp: Employee) => {
    setEditingEmployee(emp);
    setName(emp.name);
    setEmail(emp.email || '');
    setRole(emp.role);
    setPinCode(emp.pinCode);
    setCanSell(emp.canSell);
    setCanManageInventory(emp.canManageInventory);
    setCanManageDevices(emp.canManageDevices);
    setCanViewReports(emp.canViewReports);
    setActive(emp.active);
    setError(null);
    setModalOpen(true);
  };

  const handleRoleChange = (newRole: EmployeeRole) => {
    setRole(newRole);
    if (newRole === 'admin') {
      setCanSell(true);
      setCanManageInventory(true);
      setCanManageDevices(true);
      setCanViewReports(true);
    } else if (newRole === 'manager') {
      setCanSell(true);
      setCanManageInventory(true);
      setCanManageDevices(false);
      setCanViewReports(true);
    } else {
      setCanSell(true);
      setCanManageInventory(false);
      setCanManageDevices(false);
      setCanViewReports(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeStore) return;

    if (!name.trim()) {
      setError('Employee name is required.');
      return;
    }
    if (!pinCode.trim() || pinCode.trim().length < 4) {
      setError('PIN code must be at least 4 digits.');
      return;
    }

    try {
      setSubmitting(true);
      setError(null);

      if (editingEmployee) {
        await updateEmployee(activeStore.storeId, editingEmployee.employeeId, {
          name: name.trim(),
          email: email.trim(),
          role,
          pinCode: pinCode.trim(),
          canSell,
          canManageInventory,
          canManageDevices,
          canViewReports,
          active,
        });
      } else {
        await addEmployee(activeStore.storeId, {
          name: name.trim(),
          email: email.trim() || undefined,
          role,
          pinCode: pinCode.trim(),
          canSell,
          canManageInventory,
          canManageDevices,
          canViewReports,
        });
      }

      setModalOpen(false);
    } catch (err: any) {
      setError(err.message || 'Failed to save employee.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (emp: Employee) => {
    if (!activeStore) return;
    const confirmed = window.confirm(`Remove employee "${emp.name}" from store records?`);
    if (!confirmed) return;

    try {
      await deleteEmployee(activeStore.storeId, emp.employeeId);
    } catch (err: any) {
      alert(`Failed to delete employee: ${err.message}`);
    }
  };

  if (!activeStore) {
    return (
      <div className="p-12 text-center text-slate-400">
        <Users className="w-12 h-12 mx-auto text-slate-600 mb-3" />
        <p className="text-base font-medium">Please select or create a store first.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2.5">
            <Users className="w-6 h-6 text-emerald-400" />
            <span>Staff & Access Control</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Store: <span className="text-slate-200 font-semibold">{activeStore.name}</span> — Cashiers, managers, and POS access PINs.
          </p>
        </div>

        <button
          id="add-employee-button"
          onClick={openAddModal}
          className="flex items-center space-x-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-sm font-medium shadow transition shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Add Employee</span>
        </button>
      </div>

      {/* Employees Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-400">Loading staff records...</div>
        ) : employees.length === 0 ? (
          <div className="p-16 text-center text-slate-400">
            <Users className="w-12 h-12 mx-auto text-slate-600 mb-3" />
            <p className="text-base font-medium text-slate-300">No employees registered yet.</p>
            <p className="text-xs text-slate-500 mt-1">
              Click "Add Employee" to create cashier profiles and POS unlock PIN codes.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-300">
              <thead className="bg-slate-800/60 text-xs uppercase tracking-wider text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="px-6 py-3.5">Name</th>
                  <th className="px-6 py-3.5">Role</th>
                  <th className="px-6 py-3.5">PIN Code</th>
                  <th className="px-6 py-3.5">Permissions</th>
                  <th className="px-6 py-3.5">Status</th>
                  <th className="px-6 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {employees.map((emp) => (
                  <tr key={emp.employeeId} className="hover:bg-slate-800/40 transition">
                    <td className="px-6 py-4 font-medium text-white">
                      <div className="font-semibold text-sm">{emp.name}</div>
                      {emp.email && <div className="text-xs text-slate-500">{emp.email}</div>}
                    </td>

                    <td className="px-6 py-4">
                      <span
                        className={`px-2.5 py-1 rounded-full text-xs font-semibold border ${
                          emp.role === 'admin'
                            ? 'bg-rose-950 text-rose-300 border-rose-800'
                            : emp.role === 'manager'
                            ? 'bg-purple-950 text-purple-300 border-purple-800'
                            : 'bg-emerald-950 text-emerald-300 border-emerald-800'
                        }`}
                      >
                        {emp.role.toUpperCase()}
                      </span>
                    </td>

                    <td className="px-6 py-4 font-mono text-xs text-slate-400 flex items-center space-x-1">
                      <KeyRound className="w-3.5 h-3.5 text-slate-500" />
                      <span>•••• ({emp.pinCode.slice(-2)})</span>
                    </td>

                    <td className="px-6 py-4 text-xs text-slate-400 space-x-1.5">
                      {emp.canSell && (
                        <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                          POS
                        </span>
                      )}
                      {emp.canManageInventory && (
                        <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                          Inventory
                        </span>
                      )}
                      {emp.canManageDevices && (
                        <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                          Devices
                        </span>
                      )}
                      {emp.canViewReports && (
                        <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                          Reports
                        </span>
                      )}
                    </td>

                    <td className="px-6 py-4">
                      <span
                        className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded text-xs font-semibold ${
                          emp.active
                            ? 'bg-emerald-900/40 text-emerald-300 border border-emerald-800'
                            : 'bg-slate-800 text-slate-500 border border-slate-700'
                        }`}
                      >
                        {emp.active ? 'Active' : 'Inactive'}
                      </span>
                    </td>

                    <td className="px-6 py-4 text-right space-x-2">
                      <button
                        id={`edit-employee-${emp.employeeId}`}
                        onClick={() => openEditModal(emp)}
                        className="p-1.5 text-slate-400 hover:text-emerald-400 hover:bg-slate-800 rounded-lg transition"
                        title="Edit employee"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        id={`delete-employee-${emp.employeeId}`}
                        onClick={() => handleDelete(emp)}
                        className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition"
                        title="Remove employee"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add / Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 rounded-lg bg-emerald-600/20 text-emerald-400">
                  <Users className="w-5 h-5" />
                </div>
                <h2 className="text-lg font-semibold text-white">
                  {editingEmployee ? 'Edit Employee' : 'Add Store Employee'}
                </h2>
              </div>
              <button
                onClick={() => setModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {error && (
              <div className="mx-6 mt-4 p-3 rounded-xl bg-rose-950/60 border border-rose-800 text-rose-200 text-xs flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSave} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Full Name *</label>
                <input
                  id="employee-name-input"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Alex Morgan"
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Email (Optional)</label>
                <input
                  id="employee-email-input"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="alex@example.com"
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Role</label>
                  <select
                    id="employee-role-select"
                    value={role}
                    onChange={(e) => handleRoleChange(e.target.value as EmployeeRole)}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-emerald-500 transition"
                  >
                    <option value="cashier">Cashier</option>
                    <option value="manager">Manager</option>
                    <option value="admin">Administrator</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Terminal PIN (Min 4 digits) *
                  </label>
                  <input
                    id="employee-pin-input"
                    type="password"
                    maxLength={8}
                    required
                    value={pinCode}
                    onChange={(e) => setPinCode(e.target.value.replace(/\D/g, ''))}
                    placeholder="1234"
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
                  />
                </div>
              </div>

              {/* Permissions checkboxes */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-2">Permissions</label>
                <div className="space-y-2 bg-slate-800/60 p-3 rounded-xl border border-slate-700 text-xs">
                  <label className="flex items-center space-x-2 text-slate-200 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={canSell}
                      onChange={(e) => setCanSell(e.target.checked)}
                      className="rounded border-slate-700 text-emerald-600 focus:ring-emerald-500"
                    />
                    <span>Ring sales and operate POS terminal</span>
                  </label>

                  <label className="flex items-center space-x-2 text-slate-200 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={canManageInventory}
                      onChange={(e) => setCanManageInventory(e.target.checked)}
                      className="rounded border-slate-700 text-emerald-600 focus:ring-emerald-500"
                    />
                    <span>Manage inventory, prices, and stock</span>
                  </label>

                  <label className="flex items-center space-x-2 text-slate-200 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={canManageDevices}
                      onChange={(e) => setCanManageDevices(e.target.checked)}
                      className="rounded border-slate-700 text-emerald-600 focus:ring-emerald-500"
                    />
                    <span>Authorize and manage hardware devices</span>
                  </label>

                  <label className="flex items-center space-x-2 text-slate-200 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={canViewReports}
                      onChange={(e) => setCanViewReports(e.target.checked)}
                      className="rounded border-slate-700 text-emerald-600 focus:ring-emerald-500"
                    />
                    <span>View sales ledger and financial audits</span>
                  </label>
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-sm text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
                >
                  Cancel
                </button>
                <button
                  id="submit-employee-button"
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-sm font-medium rounded-xl shadow transition"
                >
                  {submitting ? 'Saving...' : editingEmployee ? 'Update Employee' : 'Add Employee'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
