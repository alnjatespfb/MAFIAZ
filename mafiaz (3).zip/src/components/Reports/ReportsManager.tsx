import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  Calendar,
  DollarSign,
  ShoppingCart,
  CreditCard,
  Banknote,
  Users,
  AlertTriangle,
  TrendingUp,
  Download,
} from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { subscribeToStoreSales } from '../../firebase/services/saleService';
import { subscribeToStoreProducts } from '../../firebase/services/productService';
import { subscribeToStoreEmployees } from '../../firebase/services/employeeService';
import { Sale, Product, Employee } from '../../types';

type DateRangeOption = 'TODAY' | 'YESTERDAY' | 'LAST_7_DAYS' | 'LAST_30_DAYS' | 'ALL_TIME';

export const ReportsManager: React.FC = () => {
  const { activeStore } = useStore();
  const [sales, setSales] = useState<Sale[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [dateRange, setDateRange] = useState<DateRangeOption>('LAST_7_DAYS');

  useEffect(() => {
    if (!activeStore) return;

    const unsubSales = subscribeToStoreSales(activeStore.storeId, (s) => setSales(s));
    const unsubProducts = subscribeToStoreProducts(activeStore.storeId, (p) => setProducts(p));
    const unsubEmployees = subscribeToStoreEmployees(activeStore.storeId, (e) => setEmployees(e));

    return () => {
      unsubSales();
      unsubProducts();
      unsubEmployees();
    };
  }, [activeStore]);

  const currency = activeStore?.currency || 'KWD';

  // Filter sales based on selected date range
  const now = new Date();
  const filteredSales = sales.filter((sale) => {
    const saleDate = new Date(sale.createdAt);

    if (dateRange === 'TODAY') {
      return saleDate.toDateString() === now.toDateString();
    }
    if (dateRange === 'YESTERDAY') {
      const yesterday = new Date();
      yesterday.setDate(now.getDate() - 1);
      return saleDate.toDateString() === yesterday.toDateString();
    }
    if (dateRange === 'LAST_7_DAYS') {
      const cutoff = new Date();
      cutoff.setDate(now.getDate() - 7);
      return saleDate >= cutoff;
    }
    if (dateRange === 'LAST_30_DAYS') {
      const cutoff = new Date();
      cutoff.setDate(now.getDate() - 30);
      return saleDate >= cutoff;
    }
    return true; // ALL_TIME
  });

  // Aggregated Report Metrics
  const totalRevenue = filteredSales.reduce((acc, s) => acc + (s.total || 0), 0);
  const totalTransactions = filteredSales.length;
  const averageTicket = totalTransactions > 0 ? totalRevenue / totalTransactions : 0;

  // Payment Breakdown: CASH vs KNET
  const cashSales = filteredSales.filter((s) => s.paymentMethod === 'CASH');
  const knetSales = filteredSales.filter((s) => s.paymentMethod === 'KNET');
  const cashTotal = cashSales.reduce((acc, s) => acc + (s.total || 0), 0);
  const knetTotal = knetSales.reduce((acc, s) => acc + (s.total || 0), 0);
  const cashPct = totalRevenue > 0 ? Math.round((cashTotal / totalRevenue) * 100) : 0;
  const knetPct = totalRevenue > 0 ? 100 - cashPct : 0;

  // Best-selling products
  const productAggregation = new Map<string, { name: string; units: number; revenue: number }>();
  filteredSales.forEach((s) => {
    s.items.forEach((item) => {
      const cur = productAggregation.get(item.productId) || {
        name: item.name,
        units: 0,
        revenue: 0,
      };
      cur.units += item.quantity;
      cur.revenue += item.total || item.price * item.quantity;
      productAggregation.set(item.productId, cur);
    });
  });

  const bestSellers = Array.from(productAggregation.values())
    .sort((a, b) => b.units - a.units)
    .slice(0, 8);
  const maxUnits = Math.max(...bestSellers.map((b) => b.units), 1);

  // Sales by Employee
  const employeeAggregation = new Map<
    string,
    { name: string; salesCount: number; totalRevenue: number }
  >();

  // Pre-seed with store employees
  employees.forEach((emp) => {
    employeeAggregation.set(emp.employeeId, {
      name: emp.name,
      salesCount: 0,
      totalRevenue: 0,
    });
  });

  filteredSales.forEach((s) => {
    const empId = s.employeeId || 'unknown';
    const cur = employeeAggregation.get(empId) || {
      name: s.employeeName || 'Cashier',
      salesCount: 0,
      totalRevenue: 0,
    };
    cur.salesCount += 1;
    cur.totalRevenue += s.total || 0;
    employeeAggregation.set(empId, cur);
  });

  const employeePerformance = Array.from(employeeAggregation.values()).sort(
    (a, b) => b.totalRevenue - a.totalRevenue
  );

  // Low-stock products list
  const lowStockProducts = products.filter(
    (p) => (p.quantity ?? p.stockQuantity ?? 0) <= (p.minimumStock ?? p.minStockAlert ?? 5)
  );

  // Export CSV
  const handleExportCSV = () => {
    const headers = ['Sale ID', 'Date', 'Cashier', 'Payment Method', 'Items Count', 'Total Amount'];
    const rows = filteredSales.map((s) => [
      s.saleId,
      new Date(s.createdAt).toLocaleString(),
      s.employeeName || 'Staff',
      s.paymentMethod,
      s.items.reduce((sum, item) => sum + item.quantity, 0),
      s.total.toFixed(3),
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `sales_report_${activeStore?.name}_${dateRange}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-150">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center space-x-2">
            <BarChart3 className="w-6 h-6 text-emerald-400" />
            <span>Sales Reports & Analytics</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Store performance metrics computed from genuine database transactions.
          </p>
        </div>

        {/* Date Range & Export */}
        <div className="flex items-center space-x-2.5">
          <div className="flex items-center space-x-1 bg-slate-900 border border-slate-800 rounded-2xl p-1">
            {(
              [
                ['TODAY', 'Today'],
                ['YESTERDAY', 'Yesterday'],
                ['LAST_7_DAYS', '7 Days'],
                ['LAST_30_DAYS', '30 Days'],
                ['ALL_TIME', 'All Time'],
              ] as [DateRangeOption, string][]
            ).map(([val, label]) => (
              <button
                key={val}
                onClick={() => setDateRange(val)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                  dateRange === val
                    ? 'bg-emerald-600 text-white shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <button
            id="export-sales-csv-button"
            onClick={handleExportCSV}
            disabled={filteredSales.length === 0}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 border border-slate-700 rounded-2xl text-xs font-semibold flex items-center space-x-1.5 transition"
            title="Download CSV report"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Total Revenue */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg">
          <span className="text-xs font-medium uppercase tracking-wider text-slate-400 block mb-1">
            Total Revenue ({dateRange.replace('_', ' ')})
          </span>
          <div className="text-2xl font-black text-emerald-400 font-mono">
            {totalRevenue.toFixed(3)} <span className="text-xs font-normal text-slate-400">{currency}</span>
          </div>
          <p className="text-xs text-slate-400 mt-2">
            Average transaction ticket: <strong className="text-white">{averageTicket.toFixed(3)} {currency}</strong>
          </p>
        </div>

        {/* Transactions */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg">
          <span className="text-xs font-medium uppercase tracking-wider text-slate-400 block mb-1">
            Orders Processed
          </span>
          <div className="text-2xl font-black text-white">
            {totalTransactions} <span className="text-xs font-normal text-slate-400">sales</span>
          </div>
          <p className="text-xs text-slate-400 mt-2">
            Generated by {employeePerformance.filter((e) => e.salesCount > 0).length} cashiers
          </p>
        </div>

        {/* Payment Breakdown Summary */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg">
          <span className="text-xs font-medium uppercase tracking-wider text-slate-400 block mb-1">
            Payment Mix
          </span>
          <div className="flex items-center space-x-3 mt-1">
            <div className="flex-1">
              <span className="text-xs text-slate-400 flex items-center space-x-1">
                <Banknote className="w-3.5 h-3.5 text-emerald-400" />
                <span>Cash: {cashPct}%</span>
              </span>
              <span className="text-sm font-bold font-mono text-white block">
                {cashTotal.toFixed(3)} {currency}
              </span>
            </div>
            <div className="h-8 w-px bg-slate-800" />
            <div className="flex-1">
              <span className="text-xs text-slate-400 flex items-center space-x-1">
                <CreditCard className="w-3.5 h-3.5 text-blue-400" />
                <span>KNET: {knetPct}%</span>
              </span>
              <span className="text-sm font-bold font-mono text-white block">
                {knetTotal.toFixed(3)} {currency}
              </span>
            </div>
          </div>
          {/* Progress split bar */}
          <div className="w-full h-2 rounded-full bg-slate-800 flex overflow-hidden mt-3">
            <div style={{ width: `${cashPct}%` }} className="bg-emerald-500 h-full" title="Cash" />
            <div style={{ width: `${knetPct}%` }} className="bg-blue-500 h-full" title="KNET" />
          </div>
        </div>
      </div>

      {/* Grid: Best-Sellers & Sales by Employee */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Best-Selling Products Leaderboard */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-white text-base flex items-center space-x-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <span>Top Best-Selling Items</span>
            </h3>
            <span className="text-xs text-slate-400">By quantity sold</span>
          </div>

          <div className="space-y-3 pt-2">
            {bestSellers.length === 0 ? (
              <div className="py-12 text-center text-slate-500 text-xs">
                No items sold in the selected time window.
              </div>
            ) : (
              bestSellers.map((item, idx) => {
                const widthPct = Math.round((item.units / maxUnits) * 100);
                return (
                  <div key={idx} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-slate-200 truncate max-w-[220px]">
                        #{idx + 1} {item.name}
                      </span>
                      <span className="font-mono text-emerald-400 font-semibold">
                        {item.units} sold ({item.revenue.toFixed(3)} {currency})
                      </span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                      <div
                        style={{ width: `${widthPct}%` }}
                        className="h-full bg-emerald-500 rounded-full transition-all"
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Sales by Employee Performance */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-white text-base flex items-center space-x-2">
              <Users className="w-4 h-4 text-purple-400" />
              <span>Sales by Employee</span>
            </h3>
            <span className="text-xs text-slate-400">Staff contribution</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="border-b border-slate-800 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                <tr>
                  <th className="py-2.5">Staff Member</th>
                  <th className="py-2.5 text-center">Orders</th>
                  <th className="py-2.5 text-right">Revenue</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {employeePerformance.length === 0 ? (
                  <tr>
                    <td colSpan={3} className="py-8 text-center text-slate-500">
                      No employee performance records found.
                    </td>
                  </tr>
                ) : (
                  employeePerformance.map((emp, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/40 transition">
                      <td className="py-2.5 font-medium text-white flex items-center space-x-2">
                        <div className="w-6 h-6 rounded-lg bg-purple-600/20 text-purple-300 font-bold text-[11px] flex items-center justify-center">
                          {emp.name.charAt(0).toUpperCase()}
                        </div>
                        <span>{emp.name}</span>
                      </td>
                      <td className="py-2.5 text-center font-mono">{emp.salesCount}</td>
                      <td className="py-2.5 text-right font-mono font-semibold text-emerald-400">
                        {emp.totalRevenue.toFixed(3)} {currency}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Low-Stock Section */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-white text-base flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span>Products Requiring Restock ({lowStockProducts.length})</span>
          </h3>
          <span className="text-xs text-slate-400">Threshold based on configured Minimum Stock</span>
        </div>

        {lowStockProducts.length === 0 ? (
          <div className="py-6 text-center text-slate-400 text-xs">
            All products are sufficiently stocked.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {lowStockProducts.map((p) => {
              const qty = p.quantity ?? p.stockQuantity ?? 0;
              const minAlert = p.minimumStock ?? p.minStockAlert ?? 5;
              return (
                <div
                  key={p.productId}
                  className="p-3 rounded-2xl bg-slate-800/60 border border-amber-800/40 flex items-center justify-between"
                >
                  <div className="truncate pr-2">
                    <p className="font-medium text-xs text-white truncate">{p.name}</p>
                    <p className="text-[11px] text-slate-400 font-mono">Code: {p.barcode || 'N/A'}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-sm font-bold text-amber-400">{qty}</span>
                    <span className="text-[10px] text-slate-400 block">Min: {minAlert}</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
