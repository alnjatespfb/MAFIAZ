import React, { useState, useEffect } from 'react';
import {
  DollarSign,
  ShoppingCart,
  Boxes,
  AlertTriangle,
  Users,
  Monitor,
  Smartphone,
  TrendingUp,
  ArrowUpRight,
  Plus,
  Store as PosIcon,
  Check,
  X,
  ShieldAlert,
  Clock,
  Sparkles,
  BarChart2,
} from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { subscribeToStoreProducts } from '../../firebase/services/productService';
import { subscribeToStoreSales } from '../../firebase/services/saleService';
import { subscribeToStoreEmployees } from '../../firebase/services/employeeService';
import { subscribeToStoreDevices, updateDeviceStatus } from '../../firebase/services/deviceService';
import { subscribeToAccessRequests, reviewAccessRequest } from '../../firebase/services/accessRequestService';
import { Product, Sale, Employee, Device, AccessRequest } from '../../types';

interface AdminDashboardProps {
  onNavigate: (tab: any) => void;
  onOpenCreateProduct?: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onNavigate,
  onOpenCreateProduct,
}) => {
  const { activeStore } = useStore();

  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [devices, setDevices] = useState<Device[]>([]);
  const [accessRequests, setAccessRequests] = useState<AccessRequest[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!activeStore) return;
    setLoading(true);

    const unsubProducts = subscribeToStoreProducts(activeStore.storeId, (p) => setProducts(p));
    const unsubSales = subscribeToStoreSales(activeStore.storeId, (s) => setSales(s));
    const unsubEmployees = subscribeToStoreEmployees(activeStore.storeId, (e) => setEmployees(e));
    const unsubDevices = subscribeToStoreDevices(activeStore.storeId, (d) => {
      setDevices(d);
      setLoading(false);
    });
    const unsubRequests = subscribeToAccessRequests(activeStore.storeId, (r) => setAccessRequests(r));

    return () => {
      unsubProducts();
      unsubSales();
      unsubEmployees();
      unsubDevices();
      unsubRequests();
    };
  }, [activeStore]);

  const currency = activeStore?.currency || 'KWD';

  // --- Real Database Calculations ---
  const todayStr = new Date().toDateString();
  const todaySales = sales.filter((s) => new Date(s.createdAt).toDateString() === todayStr);
  const todaySalesTotal = todaySales.reduce((acc, s) => acc + (s.total || 0), 0);
  const todayTransactionsCount = todaySales.length;

  // Inventory value (retail + cost)
  const currentInventoryRetailValue = products.reduce((acc, p) => {
    const qty = p.quantity ?? p.stockQuantity ?? 0;
    const price = p.sellingPrice ?? p.price ?? 0;
    return acc + qty * price;
  }, 0);

  const currentInventoryCostValue = products.reduce((acc, p) => {
    const qty = p.quantity ?? p.stockQuantity ?? 0;
    const cost = p.costPrice ?? 0;
    return acc + qty * cost;
  }, 0);

  // Low stock products
  const lowStockProducts = products.filter((p) => {
    const qty = p.quantity ?? p.stockQuantity ?? 0;
    const minAlert = p.minimumStock ?? p.minStockAlert ?? 5;
    return qty <= minAlert;
  });

  // Active employees count
  const activeEmployeesCount = employees.filter((e) => e.active !== false).length;

  // Active devices
  const activePosDevices = devices.filter(
    (d) => (d.type === 'POS' || d.deviceType === 'POS') && d.status === 'APPROVED'
  );
  const activeScannerDevices = devices.filter(
    (d) => (d.type === 'SCANNER' || d.deviceType === 'SCANNER') && d.status === 'APPROVED'
  );

  // Pending actions
  const pendingDevices = devices.filter((d) => d.status === 'PENDING');
  const pendingRequests = accessRequests.filter((r) => r.status === 'PENDING');

  // --- 7-Day Trend Calculation ---
  const last7Days: { label: string; dateStr: string; total: number; count: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const dateStr = d.toDateString();
    const dayName = i === 0 ? 'Today' : d.toLocaleDateString(undefined, { weekday: 'short' });
    const daySales = sales.filter((s) => new Date(s.createdAt).toDateString() === dateStr);
    const dayTotal = daySales.reduce((acc, s) => acc + (s.total || 0), 0);
    last7Days.push({
      label: dayName,
      dateStr,
      total: dayTotal,
      count: daySales.length,
    });
  }
  const maxDayTotal = Math.max(...last7Days.map((d) => d.total), 1);

  // --- Best-Selling Products Calculation ---
  const productSalesMap = new Map<string, { name: string; units: number; revenue: number }>();
  sales.forEach((s) => {
    s.items.forEach((item) => {
      const existing = productSalesMap.get(item.productId) || {
        name: item.name,
        units: 0,
        revenue: 0,
      };
      existing.units += item.quantity;
      existing.revenue += item.total || (item.price * item.quantity);
      productSalesMap.set(item.productId, existing);
    });
  });

  const bestSellers = Array.from(productSalesMap.values())
    .sort((a, b) => b.units - a.units)
    .slice(0, 5);
  const maxUnitsSold = Math.max(...bestSellers.map((b) => b.units), 1);

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner / Store Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800">
              Live Store
            </span>
            <span className="text-xs text-slate-400">
              ID: <span className="font-mono text-slate-300">{activeStore?.storeId}</span>
            </span>
          </div>
          <h1 className="text-2xl font-bold text-white mt-1.5">{activeStore?.name}</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            {activeStore?.country || 'Kuwait'} • Tax: {activeStore?.taxRate ?? 0}% • Base Currency:{' '}
            <span className="text-emerald-400 font-semibold">{currency}</span>
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            id="dashboard-open-pos-button"
            onClick={() => onNavigate('pos')}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl text-sm font-semibold shadow-lg shadow-emerald-950 flex items-center space-x-2 transition"
          >
            <PosIcon className="w-4 h-4" />
            <span>Open POS Register</span>
          </button>
          {onOpenCreateProduct && (
            <button
              onClick={onOpenCreateProduct}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-2xl text-sm font-medium border border-slate-700 flex items-center space-x-1.5 transition"
            >
              <Plus className="w-4 h-4 text-emerald-400" />
              <span>Add Product</span>
            </button>
          )}
        </div>
      </div>

      {/* Pending Approvals Banners */}
      {pendingDevices.length > 0 && (
        <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-800/80 text-amber-200 shadow-md">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center space-x-3">
              <div className="p-2 rounded-xl bg-amber-900/60 text-amber-300">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-bold text-white">
                  {pendingDevices.length} Hardware Device(s) Requesting Enrollment
                </p>
                <p className="text-xs text-amber-300">
                  {pendingDevices.map((d) => `${d.name} (${d.type})`).join(', ')}
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => onNavigate('devices')}
                className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-semibold shadow transition"
              >
                Review Devices
              </button>
            </div>
          </div>
        </div>
      )}

      {pendingRequests.length > 0 && (
        <div className="p-4 rounded-2xl bg-purple-950/40 border border-purple-800/80 text-purple-200 shadow-md">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center space-x-3">
              <div className="p-2 rounded-xl bg-purple-900/60 text-purple-300">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-bold text-white">
                  {pendingRequests.length} Admin Access Request(s) Pending
                </p>
                <p className="text-xs text-purple-300">
                  Staff requesting elevated permissions to sensitive operations.
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => onNavigate('devices')}
                className="px-3.5 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-semibold shadow transition"
              >
                Review Requests
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 7 Core Store Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Today's Sales */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider">Today's Sales</span>
            <div className="p-2 rounded-xl bg-emerald-950/70 border border-emerald-800/60 text-emerald-400">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white tracking-tight">
            {todaySalesTotal.toFixed(3)} <span className="text-xs font-normal text-emerald-400">{currency}</span>
          </div>
          <p className="text-xs text-slate-400 mt-2 flex items-center space-x-1">
            <Clock className="w-3 h-3 text-slate-500" />
            <span>Today from {todayTransactionsCount} transactions</span>
          </p>
        </div>

        {/* Metric 2: Number of Transactions */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider">Transactions Today</span>
            <div className="p-2 rounded-xl bg-blue-950/70 border border-blue-800/60 text-blue-400">
              <ShoppingCart className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white tracking-tight">
            {todayTransactionsCount} <span className="text-xs font-normal text-slate-400">orders</span>
          </div>
          <p className="text-xs text-slate-400 mt-2">
            Total historical: <span className="text-slate-200 font-semibold">{sales.length}</span>
          </p>
        </div>

        {/* Metric 3: Current Inventory Value */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider">Inventory Retail Value</span>
            <div className="p-2 rounded-xl bg-indigo-950/70 border border-indigo-800/60 text-indigo-400">
              <Boxes className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white tracking-tight">
            {currentInventoryRetailValue.toFixed(3)} <span className="text-xs font-normal text-indigo-400">{currency}</span>
          </div>
          <p className="text-xs text-slate-400 mt-2">
            Across {products.length} product SKUs
          </p>
        </div>

        {/* Metric 4: Low-Stock Products */}
        <div
          onClick={() => onNavigate('inventory')}
          className={`bg-slate-900 border rounded-3xl p-5 shadow-lg relative overflow-hidden cursor-pointer transition ${
            lowStockProducts.length > 0
              ? 'border-rose-800/80 hover:border-rose-600 bg-rose-950/10'
              : 'border-slate-800'
          }`}
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider">Low-Stock Alert</span>
            <div
              className={`p-2 rounded-xl ${
                lowStockProducts.length > 0
                  ? 'bg-rose-950 border border-rose-800 text-rose-400'
                  : 'bg-slate-800 text-slate-400'
              }`}
            >
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div
            className={`text-2xl font-black tracking-tight ${
              lowStockProducts.length > 0 ? 'text-rose-400' : 'text-white'
            }`}
          >
            {lowStockProducts.length} <span className="text-xs font-normal text-slate-400">items</span>
          </div>
          <p className="text-xs text-slate-400 mt-2 flex items-center justify-between">
            <span>Requires restocking</span>
            <ArrowUpRight className="w-3.5 h-3.5 text-slate-500" />
          </p>
        </div>
      </div>

      {/* Hardware & Staff Metric Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Metric 5: Number of Employees */}
        <div
          onClick={() => onNavigate('employees')}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 flex items-center justify-between cursor-pointer transition"
        >
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-slate-800 text-emerald-400">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Active Staff</p>
              <p className="text-lg font-bold text-white">{activeEmployeesCount} Employees</p>
            </div>
          </div>
          <ArrowUpRight className="w-4 h-4 text-slate-500" />
        </div>

        {/* Metric 6: Active POS Devices */}
        <div
          onClick={() => onNavigate('devices')}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 flex items-center justify-between cursor-pointer transition"
        >
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-slate-800 text-blue-400">
              <Monitor className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Active POS Terminals</p>
              <p className="text-lg font-bold text-white">{activePosDevices.length} Connected</p>
            </div>
          </div>
          <ArrowUpRight className="w-4 h-4 text-slate-500" />
        </div>

        {/* Metric 7: Active Scanner Devices */}
        <div
          onClick={() => onNavigate('devices')}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 flex items-center justify-between cursor-pointer transition"
        >
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-slate-800 text-purple-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Active Mobile Scanners</p>
              <p className="text-lg font-bold text-white">{activeScannerDevices.length} Paired</p>
            </div>
          </div>
          <ArrowUpRight className="w-4 h-4 text-slate-500" />
        </div>
      </div>

      {/* Visual Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart 1: 7-Day Sales Trend Bar Chart */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-white text-base flex items-center space-x-2">
                <BarChart2 className="w-4 h-4 text-emerald-400" />
                <span>7-Day Sales Trend</span>
              </h3>
              <p className="text-xs text-slate-400">Revenue over the last 7 calendar days</p>
            </div>
            <button
              onClick={() => onNavigate('reports')}
              className="text-xs text-emerald-400 hover:text-emerald-300 font-medium"
            >
              Full Reports →
            </button>
          </div>

          <div className="h-48 flex items-end justify-between gap-2 pt-6 border-b border-slate-800 pb-2">
            {last7Days.map((d, idx) => {
              const heightPct = Math.round((d.total / maxDayTotal) * 100);
              return (
                <div key={idx} className="flex-1 flex flex-col items-center h-full justify-end group">
                  <div className="text-[10px] text-slate-400 mb-1 opacity-0 group-hover:opacity-100 transition truncate max-w-full text-center">
                    {d.total > 0 ? d.total.toFixed(2) : '0'}
                  </div>
                  <div className="w-full max-w-[48px] bg-slate-800 rounded-t-xl overflow-hidden h-full flex items-end">
                    <div
                      style={{ height: `${Math.max(heightPct, 6)}%` }}
                      className={`w-full transition-all duration-300 rounded-t-xl ${
                        idx === 6 ? 'bg-emerald-500' : 'bg-emerald-600/70 group-hover:bg-emerald-500'
                      }`}
                    />
                  </div>
                  <span
                    className={`text-[11px] font-medium mt-2 ${
                      idx === 6 ? 'text-emerald-400 font-bold' : 'text-slate-400'
                    }`}
                  >
                    {d.label}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
            <span>Week Revenue: {last7Days.reduce((a, b) => a + b.total, 0).toFixed(3)} {currency}</span>
            <span>Week Orders: {last7Days.reduce((a, b) => a + b.count, 0)}</span>
          </div>
        </div>

        {/* Chart 2: Top Best-Selling Products */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-white text-base flex items-center space-x-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <span>Best-Selling Products</span>
              </h3>
              <p className="text-xs text-slate-400">By quantity sold</p>
            </div>
            <button
              onClick={() => onNavigate('products')}
              className="text-xs text-emerald-400 hover:text-emerald-300 font-medium"
            >
              Catalog →
            </button>
          </div>

          <div className="space-y-3 pt-2">
            {bestSellers.length === 0 ? (
              <div className="py-12 text-center text-slate-500 text-xs">
                No completed sales recorded yet. Process sales in the POS terminal to populate rankings.
              </div>
            ) : (
              bestSellers.map((item, idx) => {
                const widthPct = Math.round((item.units / maxUnitsSold) * 100);
                return (
                  <div key={idx} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-slate-200 truncate max-w-[150px]">
                        #{idx + 1} {item.name}
                      </span>
                      <span className="font-mono text-emerald-400 font-semibold">
                        {item.units} sold ({item.revenue.toFixed(3)} {currency})
                      </span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                      <div
                        style={{ width: `${widthPct}%` }}
                        className="h-full bg-emerald-500 rounded-full transition-all"
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Low Stock Warning Feed */}
      {lowStockProducts.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-white text-base flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              <span>Low-Stock Inventory Warnings</span>
            </h3>
            <button
              onClick={() => onNavigate('inventory')}
              className="text-xs font-semibold px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl transition"
            >
              Adjust Stock in Inventory →
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {lowStockProducts.slice(0, 4).map((p) => {
              const qty = p.quantity ?? p.stockQuantity ?? 0;
              const minAlert = p.minimumStock ?? p.minStockAlert ?? 5;
              return (
                <div
                  key={p.productId}
                  className="p-3.5 rounded-2xl bg-slate-800/60 border border-rose-900/40 flex items-center justify-between"
                >
                  <div className="min-w-0 pr-2">
                    <p className="font-medium text-xs text-white truncate">{p.name}</p>
                    <p className="text-[11px] text-slate-400 font-mono">
                      Barcode: {p.barcode || 'N/A'}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-sm font-bold text-rose-400">{qty}</span>
                    <span className="text-[10px] text-slate-400 block">Min: {minAlert}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
