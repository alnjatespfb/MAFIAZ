import React, { useState, useEffect, useRef } from 'react';
import {
  Store as StoreIcon,
  ChevronDown,
  Plus,
  Bell,
  Wifi,
  WifiOff,
  RefreshCw,
  LogOut,
  KeyRound,
  Check,
  X,
  AlertTriangle,
  Smartphone,
  ShieldAlert,
  Menu,
  CheckCircle2,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useStore } from '../../context/StoreContext';
import { useDevice } from '../../context/DeviceContext';
import { subscribeToStoreDevices, updateDeviceStatus } from '../../firebase/services/deviceService';
import { subscribeToAccessRequests, reviewAccessRequest } from '../../firebase/services/accessRequestService';
import { subscribeToStoreProducts } from '../../firebase/services/productService';
import { Device, AccessRequest, Product } from '../../types';
import { sendPasswordResetEmail } from 'firebase/auth';
import { auth } from '../../firebase/config';

interface TopBarProps {
  onOpenCreateStore: () => void;
  onOpenDeviceEnrollment: () => void;
  onNavigateToTab?: (tab: string) => void;
  onToggleSidebar?: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  onOpenCreateStore,
  onOpenDeviceEnrollment,
  onNavigateToTab,
  onToggleSidebar,
}) => {
  const { user, logout } = useAuth();
  const { stores, activeStore, setActiveStore } = useStore();
  const {
    currentDevice,
    deviceStatus,
    isOnline,
    offlineQueueCount,
    isSyncing,
    triggerOfflineSync,
  } = useDevice();

  const [storeDropdownOpen, setStoreDropdownOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [resetSent, setResetSent] = useState(false);
  const [resetError, setResetError] = useState<string | null>(null);

  const [devices, setDevices] = useState<Device[]>([]);
  const [accessRequests, setAccessRequests] = useState<AccessRequest[]>([]);
  const [lowStockProducts, setLowStockProducts] = useState<Product[]>([]);

  const notifRef = useRef<HTMLDivElement>(null);
  const storeRef = useRef<HTMLDivElement>(null);
  const userRef = useRef<HTMLDivElement>(null);

  // Subscribe to pending notifications for active store
  useEffect(() => {
    if (!activeStore) return;

    const unsubDevices = subscribeToStoreDevices(activeStore.storeId, (allDevices) => {
      setDevices(allDevices.filter((d) => d.status === 'PENDING'));
    });

    const unsubRequests = subscribeToAccessRequests(activeStore.storeId, (allRequests) => {
      setAccessRequests(allRequests.filter((r) => r.status === 'PENDING'));
    });

    const unsubProducts = subscribeToStoreProducts(activeStore.storeId, (allProducts) => {
      setLowStockProducts(
        allProducts.filter(
          (p) => (p.quantity ?? p.stockQuantity ?? 0) <= (p.minimumStock ?? p.minStockAlert ?? 5)
        )
      );
    });

    return () => {
      unsubDevices();
      unsubRequests();
      unsubProducts();
    };
  }, [activeStore]);

  // Click outside listeners
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setNotificationsOpen(false);
      }
      if (storeRef.current && !storeRef.current.contains(e.target as Node)) {
        setStoreDropdownOpen(false);
      }
      if (userRef.current && !userRef.current.contains(e.target as Node)) {
        setUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const totalNotifications = devices.length + accessRequests.length + lowStockProducts.length;

  const handleApproveDevice = async (deviceId: string) => {
    if (!activeStore) return;
    try {
      await updateDeviceStatus(activeStore.storeId, deviceId, 'APPROVED');
    } catch (e) {
      console.error('Failed to approve device:', e);
    }
  };

  const handleRejectDevice = async (deviceId: string) => {
    if (!activeStore) return;
    try {
      await updateDeviceStatus(activeStore.storeId, deviceId, 'REJECTED');
    } catch (e) {
      console.error('Failed to reject device:', e);
    }
  };

  const handleReviewAccess = async (requestId: string, status: 'APPROVED' | 'REJECTED') => {
    if (!activeStore) return;
    try {
      await reviewAccessRequest(activeStore.storeId, requestId, status);
    } catch (e) {
      console.error('Failed to review access request:', e);
    }
  };

  const handleSendPasswordReset = async () => {
    if (!user?.email) return;
    try {
      setResetError(null);
      await sendPasswordResetEmail(auth, user.email);
      setResetSent(true);
      setTimeout(() => setResetSent(false), 5000);
    } catch (err: any) {
      setResetError(err.message || 'Failed to send password reset email.');
    }
  };

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white select-none sticky top-0 z-40">
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Left: Mobile Menu Trigger + Current Store Dropdown */}
          <div className="flex items-center space-x-3">
            {onToggleSidebar && (
              <button
                id="sidebar-toggle-button"
                onClick={onToggleSidebar}
                className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden transition"
                title="Toggle Sidebar"
              >
                <Menu className="w-5 h-5" />
              </button>
            )}

            {/* Current Store Selector */}
            <div className="relative" ref={storeRef}>
              <button
                id="store-dropdown-button"
                onClick={() => setStoreDropdownOpen(!storeDropdownOpen)}
                className="flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 text-sm font-medium border border-slate-700/80 transition"
              >
                <div className="w-6 h-6 rounded-lg bg-emerald-600/20 text-emerald-400 flex items-center justify-center">
                  <StoreIcon className="w-3.5 h-3.5" />
                </div>
                <div className="flex flex-col text-left">
                  <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold leading-none">
                    Current Store
                  </span>
                  <span className="text-sm text-slate-100 font-medium truncate max-w-[150px] sm:max-w-[200px]">
                    {activeStore ? activeStore.name : 'No Store Selected'}
                  </span>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 ml-1" />
              </button>

              {storeDropdownOpen && (
                <div className="absolute left-0 mt-2 w-72 rounded-2xl bg-slate-800 border border-slate-700 shadow-2xl py-2 z-50 animate-in fade-in zoom-in-95 duration-100">
                  <div className="px-3.5 py-1 text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center justify-between">
                    <span>Your Stores ({stores.length})</span>
                  </div>

                  <div className="max-h-60 overflow-y-auto py-1">
                    {stores.length === 0 ? (
                      <div className="px-3.5 py-3 text-xs text-slate-400">No stores yet.</div>
                    ) : (
                      stores.map((s) => (
                        <button
                          key={s.storeId}
                          id={`select-store-${s.storeId}`}
                          onClick={() => {
                            setActiveStore(s);
                            setStoreDropdownOpen(false);
                          }}
                          className={`w-full text-left px-3.5 py-2.5 text-sm flex items-center justify-between transition ${
                            activeStore?.storeId === s.storeId
                              ? 'bg-emerald-600/20 text-emerald-300 font-medium'
                              : 'text-slate-200 hover:bg-slate-700/70'
                          }`}
                        >
                          <div className="flex flex-col truncate pr-2">
                            <span className="truncate font-medium">{s.name}</span>
                            <span className="text-[11px] text-slate-400">{s.country || 'Kuwait'}</span>
                          </div>
                          <span className="text-xs px-2 py-0.5 rounded-full bg-slate-900 border border-slate-700 text-slate-300 font-mono">
                            {s.currency}
                          </span>
                        </button>
                      ))
                    )}
                  </div>

                  <div className="border-t border-slate-700 mt-1 pt-1.5 px-2">
                    <button
                      id="create-new-store-button"
                      onClick={() => {
                        setStoreDropdownOpen(false);
                        onOpenCreateStore();
                      }}
                      className="w-full text-left px-3 py-2 text-sm text-emerald-400 hover:bg-slate-700/60 rounded-xl flex items-center space-x-2 font-medium transition"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Create New Store</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right: Network/Sync status + Notifications + User Account */}
          <div className="flex items-center space-x-3">
            {/* Online / Offline Status Badge */}
            <div className="flex items-center space-x-1.5">
              {isOnline ? (
                <div
                  className="flex items-center space-x-1.5 px-2.5 py-1 rounded-xl bg-emerald-950/40 border border-emerald-800/60 text-xs text-emerald-400"
                  title="Cloud connection active"
                >
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span className="hidden md:inline font-medium">Online</span>
                </div>
              ) : (
                <div
                  className="flex items-center space-x-1.5 px-2.5 py-1 rounded-xl bg-rose-950/60 border border-rose-800 text-xs text-rose-300 animate-pulse"
                  title="Working offline - sales will queue locally"
                >
                  <WifiOff className="w-3.5 h-3.5" />
                  <span className="font-medium">Offline</span>
                </div>
              )}

              {offlineQueueCount > 0 && (
                <button
                  id="sync-now-button"
                  onClick={triggerOfflineSync}
                  disabled={!isOnline || isSyncing}
                  className={`flex items-center space-x-1.5 px-2.5 py-1 rounded-xl text-xs font-medium border transition shadow-sm ${
                    isOnline
                      ? 'bg-amber-600 hover:bg-amber-500 text-white border-amber-500 cursor-pointer'
                      : 'bg-slate-800 text-slate-400 border-slate-700 cursor-not-allowed'
                  }`}
                  title={`${offlineQueueCount} offline transaction(s) pending sync to Firestore`}
                >
                  <RefreshCw className={`w-3 h-3 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span>{offlineQueueCount} Pending</span>
                </button>
              )}
            </div>

            {/* Notifications Center */}
            <div className="relative" ref={notifRef}>
              <button
                id="notifications-button"
                onClick={() => setNotificationsOpen(!notificationsOpen)}
                className="relative p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 border border-transparent hover:border-slate-700 transition"
                title="Notifications"
              >
                <Bell className="w-5 h-5" />
                {totalNotifications > 0 && (
                  <span className="absolute top-1 right-1 min-w-4 h-4 px-1 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center leading-none">
                    {totalNotifications > 9 ? '9+' : totalNotifications}
                  </span>
                )}
              </button>

              {notificationsOpen && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl p-4 z-50 animate-in fade-in zoom-in-95 duration-100">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <h3 className="font-semibold text-sm text-white flex items-center space-x-2">
                      <Bell className="w-4 h-4 text-emerald-400" />
                      <span>Notifications</span>
                    </h3>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                      {totalNotifications} new
                    </span>
                  </div>

                  <div className="max-h-80 overflow-y-auto py-2 space-y-3">
                    {totalNotifications === 0 ? (
                      <div className="py-6 text-center text-slate-400 text-xs">
                        <CheckCircle2 className="w-8 h-8 text-emerald-500/50 mx-auto mb-2" />
                        All caught up! No pending approvals or stock alerts.
                      </div>
                    ) : (
                      <>
                        {/* Pending Devices */}
                        {devices.map((d) => (
                          <div
                            key={d.deviceId}
                            className="p-3 rounded-xl bg-slate-800/80 border border-amber-800/40 text-xs space-y-2"
                          >
                            <div className="flex items-start justify-between">
                              <div className="flex items-center space-x-2">
                                <Smartphone className="w-4 h-4 text-amber-400 shrink-0" />
                                <div>
                                  <p className="font-medium text-white">Device Pairing Request</p>
                                  <p className="text-slate-300">{d.name} ({d.type})</p>
                                </div>
                              </div>
                              <span className="text-[10px] text-amber-400 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-800/60">
                                Pending
                              </span>
                            </div>
                            <div className="flex items-center space-x-2 pt-1">
                              <button
                                onClick={() => handleApproveDevice(d.deviceId)}
                                className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-medium flex items-center justify-center space-x-1"
                              >
                                <Check className="w-3.5 h-3.5" />
                                <span>Approve</span>
                              </button>
                              <button
                                onClick={() => handleRejectDevice(d.deviceId)}
                                className="flex-1 py-1.5 bg-rose-900/60 hover:bg-rose-800 text-rose-200 rounded-lg text-xs font-medium flex items-center justify-center space-x-1 border border-rose-800"
                              >
                                <X className="w-3.5 h-3.5" />
                                <span>Reject</span>
                              </button>
                            </div>
                          </div>
                        ))}

                        {/* Pending Access Requests */}
                        {accessRequests.map((r) => (
                          <div
                            key={r.requestId}
                            className="p-3 rounded-xl bg-slate-800/80 border border-purple-800/40 text-xs space-y-2"
                          >
                            <div className="flex items-start justify-between">
                              <div className="flex items-center space-x-2">
                                <ShieldAlert className="w-4 h-4 text-purple-400 shrink-0" />
                                <div>
                                  <p className="font-medium text-white">Admin Access Request</p>
                                  <p className="text-slate-300">
                                    {r.requesterName} on {r.deviceName}
                                  </p>
                                </div>
                              </div>
                            </div>
                            <p className="text-slate-400 text-[11px]">
                              Requested: <span className="text-slate-200">{r.requestedPermission}</span>
                            </p>
                            <div className="flex items-center space-x-2 pt-1">
                              <button
                                onClick={() => handleReviewAccess(r.requestId, 'APPROVED')}
                                className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-medium flex items-center justify-center space-x-1"
                              >
                                <Check className="w-3.5 h-3.5" />
                                <span>Approve</span>
                              </button>
                              <button
                                onClick={() => handleReviewAccess(r.requestId, 'REJECTED')}
                                className="flex-1 py-1.5 bg-rose-900/60 hover:bg-rose-800 text-rose-200 rounded-lg text-xs font-medium flex items-center justify-center space-x-1 border border-rose-800"
                              >
                                <X className="w-3.5 h-3.5" />
                                <span>Reject</span>
                              </button>
                            </div>
                          </div>
                        ))}

                        {/* Low Stock Alerts */}
                        {lowStockProducts.map((p) => (
                          <div
                            key={p.productId}
                            className="p-2.5 rounded-xl bg-slate-800/50 border border-rose-900/40 text-xs flex items-center justify-between"
                          >
                            <div className="flex items-center space-x-2">
                              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                              <div>
                                <p className="font-medium text-white">{p.name}</p>
                                <p className="text-rose-300 text-[11px]">
                                  Only {p.quantity ?? p.stockQuantity ?? 0} in stock (Min: {p.minimumStock ?? p.minStockAlert ?? 5})
                                </p>
                              </div>
                            </div>
                            {onNavigateToTab && (
                              <button
                                onClick={() => {
                                  onNavigateToTab('inventory');
                                  setNotificationsOpen(false);
                                }}
                                className="px-2 py-1 bg-slate-700 hover:bg-slate-600 text-white text-[11px] rounded-lg transition"
                              >
                                Restock
                              </button>
                            )}
                          </div>
                        ))}
                      </>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* User Account Menu */}
            <div className="relative" ref={userRef}>
              <button
                id="user-account-button"
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                className="flex items-center space-x-2 p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700/80 border border-slate-700/80 transition"
              >
                <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white font-bold text-xs flex items-center justify-center">
                  {(user?.displayName || user?.email || 'U').charAt(0).toUpperCase()}
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:inline" />
              </button>

              {userMenuOpen && (
                <div className="absolute right-0 mt-2 w-64 rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl p-3 z-50 animate-in fade-in zoom-in-95 duration-100">
                  <div className="px-2 py-2 border-b border-slate-800 mb-2">
                    <p className="font-semibold text-sm text-white truncate">
                      {user?.displayName || 'Store Administrator'}
                    </p>
                    <p className="text-xs text-slate-400 truncate">{user?.email}</p>
                    <span className="inline-block mt-1 text-[10px] font-semibold bg-emerald-950 border border-emerald-800 text-emerald-300 px-2 py-0.5 rounded-full">
                      Owner Account
                    </span>
                  </div>

                  {resetSent && (
                    <div className="p-2 mb-2 rounded-lg bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-xs">
                      Password reset email sent! Please check your inbox.
                    </div>
                  )}

                  {resetError && (
                    <div className="p-2 mb-2 rounded-lg bg-rose-950/60 border border-rose-800 text-rose-300 text-xs">
                      {resetError}
                    </div>
                  )}

                  <div className="space-y-1">
                    <button
                      onClick={handleSendPasswordReset}
                      className="w-full text-left px-3 py-2 text-xs text-slate-300 hover:text-white hover:bg-slate-800 rounded-xl flex items-center space-x-2 transition"
                    >
                      <KeyRound className="w-3.5 h-3.5 text-slate-400" />
                      <span>Send Password Reset Email</span>
                    </button>

                    <button
                      onClick={() => {
                        setUserMenuOpen(false);
                        onOpenDeviceEnrollment();
                      }}
                      className="w-full text-left px-3 py-2 text-xs text-slate-300 hover:text-white hover:bg-slate-800 rounded-xl flex items-center space-x-2 transition"
                    >
                      <Smartphone className="w-3.5 h-3.5 text-slate-400" />
                      <span>Manage Terminal Device</span>
                    </button>

                    <div className="border-t border-slate-800 my-1 pt-1">
                      <button
                        id="logout-button"
                        onClick={logout}
                        className="w-full text-left px-3 py-2 text-xs text-rose-400 hover:bg-rose-950/50 rounded-xl flex items-center space-x-2 transition font-medium"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        <span>Sign Out</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
