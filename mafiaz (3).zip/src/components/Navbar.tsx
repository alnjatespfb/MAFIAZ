import React, { useState } from 'react';
import {
  Store as StoreIcon,
  ChevronDown,
  Plus,
  Wifi,
  WifiOff,
  RefreshCw,
  Monitor,
  Smartphone,
  ShieldCheck,
  AlertTriangle,
  LogOut,
  User as UserIcon,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useStore } from '../context/StoreContext';
import { useDevice } from '../context/DeviceContext';

interface NavbarProps {
  currentTab: 'pos' | 'scanner' | 'inventory' | 'devices' | 'employees' | 'sales';
  onSelectTab: (tab: 'pos' | 'scanner' | 'inventory' | 'devices' | 'employees' | 'sales') => void;
  onOpenCreateStore: () => void;
  onOpenDeviceEnrollment: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  onOpenCreateStore,
  onOpenDeviceEnrollment,
}) => {
  const { user, logout } = useAuth();
  const { stores, activeStore, setActiveStore } = useStore();
  const {
    currentDevice,
    deviceStatus,
    deviceType,
    isOnline,
    offlineQueueCount,
    isSyncing,
    triggerOfflineSync,
  } = useDevice();

  const [storeDropdownOpen, setStoreDropdownOpen] = useState(false);

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white select-none sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand & Store Selector */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-9 h-9 rounded-lg bg-emerald-600 flex items-center justify-center font-bold text-white shadow-sm">
                POS
              </div>
              <span className="font-semibold text-lg tracking-tight hidden sm:inline-block">
                Multi-Store POS
              </span>
            </div>

            {/* Store Dropdown */}
            <div className="relative">
              <button
                id="store-dropdown-button"
                onClick={() => setStoreDropdownOpen(!storeDropdownOpen)}
                className="flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-sm font-medium border border-slate-700 transition"
              >
                <StoreIcon className="w-4 h-4 text-emerald-400" />
                <span className="max-w-[140px] truncate">
                  {activeStore ? activeStore.name : 'No Store Selected'}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {storeDropdownOpen && (
                <div className="absolute left-0 mt-2 w-64 rounded-xl bg-slate-800 border border-slate-700 shadow-xl py-2 z-50">
                  <div className="px-3 py-1 text-xs font-semibold text-slate-400 uppercase tracking-wider">
                    Your Stores ({stores.length})
                  </div>

                  <div className="max-h-56 overflow-y-auto py-1">
                    {stores.length === 0 ? (
                      <div className="px-3 py-2 text-xs text-slate-400">No stores yet.</div>
                    ) : (
                      stores.map((s) => (
                        <button
                          key={s.storeId}
                          id={`select-store-${s.storeId}`}
                          onClick={() => {
                            setActiveStore(s);
                            setStoreDropdownOpen(false);
                          }}
                          className={`w-full text-left px-3 py-2 text-sm flex items-center justify-between transition ${
                            activeStore?.storeId === s.storeId
                              ? 'bg-emerald-600/20 text-emerald-300 font-medium'
                              : 'text-slate-200 hover:bg-slate-700'
                          }`}
                        >
                          <span className="truncate">{s.name}</span>
                          <span className="text-xs px-1.5 py-0.5 rounded bg-slate-900 text-slate-400">
                            {s.currency}
                          </span>
                        </button>
                      ))
                    )}
                  </div>

                  <div className="border-t border-slate-700 mt-1 pt-1 px-2">
                    <button
                      id="create-new-store-button"
                      onClick={() => {
                        setStoreDropdownOpen(false);
                        onOpenCreateStore();
                      }}
                      className="w-full text-left px-3 py-2 text-sm text-emerald-400 hover:bg-slate-700/60 rounded-lg flex items-center space-x-2 font-medium transition"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Create New Store</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden md:flex items-center space-x-1 bg-slate-800/80 p-1 rounded-xl border border-slate-700/60">
            <button
              id="tab-pos"
              onClick={() => onSelectTab('pos')}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${
                currentTab === 'pos'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              POS Terminal
            </button>
            <button
              id="tab-scanner"
              onClick={() => onSelectTab('scanner')}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${
                currentTab === 'scanner'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              Mobile Scanner
            </button>
            <button
              id="tab-inventory"
              onClick={() => onSelectTab('inventory')}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${
                currentTab === 'inventory'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              Inventory
            </button>
            <button
              id="tab-devices"
              onClick={() => onSelectTab('devices')}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${
                currentTab === 'devices'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              Devices
            </button>
            <button
              id="tab-employees"
              onClick={() => onSelectTab('employees')}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${
                currentTab === 'employees'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              Employees
            </button>
            <button
              id="tab-sales"
              onClick={() => onSelectTab('sales')}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${
                currentTab === 'sales'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              Sales Audit
            </button>
          </nav>

          {/* Device & Connection Status Bar */}
          <div className="flex items-center space-x-3">
            {/* Device Identity & Status Badge */}
            <button
              id="device-status-badge"
              onClick={onOpenDeviceEnrollment}
              className={`flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-xs font-medium border transition ${
                deviceStatus === 'APPROVED'
                  ? 'bg-emerald-950/60 border-emerald-800/80 text-emerald-300'
                  : deviceStatus === 'PENDING'
                  ? 'bg-amber-950/60 border-amber-800/80 text-amber-300'
                  : deviceStatus === 'DISABLED' || deviceStatus === 'REJECTED'
                  ? 'bg-rose-950/60 border-rose-800/80 text-rose-300'
                  : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
              }`}
              title="Click to manage local device enrollment"
            >
              {deviceType === 'POS' ? (
                <Monitor className="w-3.5 h-3.5" />
              ) : (
                <Smartphone className="w-3.5 h-3.5" />
              )}
              <span className="hidden sm:inline">
                {currentDevice?.name || (deviceStatus === 'UNREGISTERED' ? 'Enroll Device' : 'Device')}
              </span>
              <span className="opacity-80">({deviceStatus})</span>
            </button>

            {/* Online / Offline & Sync Badge */}
            <div className="flex items-center space-x-1">
              {isOnline ? (
                <div
                  className="flex items-center space-x-1 px-2 py-1 rounded-lg bg-slate-800 border border-slate-700 text-xs text-emerald-400"
                  title="Network online"
                >
                  <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="hidden lg:inline">Online</span>
                </div>
              ) : (
                <div
                  className="flex items-center space-x-1 px-2 py-1 rounded-lg bg-rose-900/60 border border-rose-700 text-xs text-rose-300 animate-pulse"
                  title="Offline mode active"
                >
                  <WifiOff className="w-3.5 h-3.5" />
                  <span>Offline</span>
                </div>
              )}

              {offlineQueueCount > 0 && (
                <button
                  id="sync-now-button"
                  onClick={triggerOfflineSync}
                  disabled={!isOnline || isSyncing}
                  className={`flex items-center space-x-1 px-2 py-1 rounded-lg text-xs font-medium border transition ${
                    isOnline
                      ? 'bg-amber-600 hover:bg-amber-500 text-white border-amber-500 cursor-pointer'
                      : 'bg-slate-800 text-slate-400 border-slate-700 cursor-not-allowed'
                  }`}
                  title={`${offlineQueueCount} offline transaction(s) pending upload`}
                >
                  <RefreshCw className={`w-3 h-3 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span>{offlineQueueCount} Pending</span>
                </button>
              )}
            </div>

            {/* User Account / Logout */}
            <div className="flex items-center space-x-2 pl-2 border-l border-slate-800">
              <div
                className="hidden xl:flex flex-col text-right"
                title={user?.email || ''}
              >
                <span className="text-xs font-medium text-slate-200 truncate max-w-[120px]">
                  {user?.displayName || user?.email?.split('@')[0]}
                </span>
                <span className="text-[10px] text-slate-400">Admin</span>
              </div>
              <button
                id="logout-button"
                onClick={logout}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                title="Sign out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Row */}
        <div className="md:hidden flex items-center space-x-1 py-2 overflow-x-auto border-t border-slate-800 text-xs">
          <button
            onClick={() => onSelectTab('pos')}
            className={`px-2.5 py-1 rounded whitespace-nowrap font-medium ${
              currentTab === 'pos' ? 'bg-emerald-600 text-white' : 'text-slate-300'
            }`}
          >
            POS
          </button>
          <button
            onClick={() => onSelectTab('scanner')}
            className={`px-2.5 py-1 rounded whitespace-nowrap font-medium ${
              currentTab === 'scanner' ? 'bg-emerald-600 text-white' : 'text-slate-300'
            }`}
          >
            Scanner
          </button>
          <button
            onClick={() => onSelectTab('inventory')}
            className={`px-2.5 py-1 rounded whitespace-nowrap font-medium ${
              currentTab === 'inventory' ? 'bg-emerald-600 text-white' : 'text-slate-300'
            }`}
          >
            Inventory
          </button>
          <button
            onClick={() => onSelectTab('devices')}
            className={`px-2.5 py-1 rounded whitespace-nowrap font-medium ${
              currentTab === 'devices' ? 'bg-emerald-600 text-white' : 'text-slate-300'
            }`}
          >
            Devices
          </button>
          <button
            onClick={() => onSelectTab('employees')}
            className={`px-2.5 py-1 rounded whitespace-nowrap font-medium ${
              currentTab === 'employees' ? 'bg-emerald-600 text-white' : 'text-slate-300'
            }`}
          >
            Employees
          </button>
          <button
            onClick={() => onSelectTab('sales')}
            className={`px-2.5 py-1 rounded whitespace-nowrap font-medium ${
              currentTab === 'sales' ? 'bg-emerald-600 text-white' : 'text-slate-300'
            }`}
          >
            Sales
          </button>
        </div>
      </div>
    </header>
  );
};
