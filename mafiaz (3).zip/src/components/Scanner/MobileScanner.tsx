import React, { useState, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import { useDevice } from '../../context/DeviceContext';
import { Device, ScanEvent } from '../../types';
import { subscribeToStoreDevices } from '../../firebase/services/deviceService';
import { sendScanEvent } from '../../firebase/services/scannerService';
import {
  Smartphone,
  Barcode,
  Send,
  CheckCircle,
  AlertTriangle,
  Monitor,
  RefreshCw,
  Clock,
  Radio,
  Settings,
} from 'lucide-react';

interface MobileScannerProps {
  onOpenEnrollment: () => void;
}

export const MobileScanner: React.FC<MobileScannerProps> = ({ onOpenEnrollment }) => {
  const { activeStore } = useStore();
  const { currentDeviceId, currentDevice, deviceStatus, isOnline } = useDevice();

  const [barcodeInput, setBarcodeInput] = useState('');
  const [targetPosId, setTargetPosId] = useState(currentDevice?.pairedPosDeviceId || '');
  const [availablePosList, setAvailablePosList] = useState<Device[]>([]);
  const [recentScans, setRecentScans] = useState<{ barcode: string; time: string; success: boolean }[]>([]);
  const [transmitting, setTransmitting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  // Subscribe to available POS terminals in the store
  useEffect(() => {
    if (!activeStore) return;
    const unsub = subscribeToStoreDevices(activeStore.storeId, (devices) => {
      const posDevs = devices.filter((d) => d.type === 'POS' && d.status === 'APPROVED');
      setAvailablePosList(posDevs);
      if (posDevs.length > 0 && !targetPosId) {
        setTargetPosId(posDevs[0].deviceId);
      }
    });
    return () => unsub();
  }, [activeStore, targetPosId]);

  const handleSendScan = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanBarcode = barcodeInput.trim();
    if (!cleanBarcode || !activeStore) return;

    if (!targetPosId) {
      setStatusMessage('Please select a target POS Terminal to receive this scan.');
      return;
    }

    try {
      setTransmitting(true);
      setStatusMessage(null);

      await sendScanEvent(activeStore.storeId, currentDeviceId, targetPosId, cleanBarcode);

      setRecentScans((prev) => [
        { barcode: cleanBarcode, time: new Date().toLocaleTimeString(), success: true },
        ...prev.slice(0, 14),
      ]);
      setBarcodeInput('');
      setStatusMessage(`Dispatched "${cleanBarcode}" to POS terminal.`);
    } catch (err: any) {
      console.error('Scan transmission error:', err);
      setStatusMessage(`Scan failed: ${err.message}`);
      setRecentScans((prev) => [
        { barcode: cleanBarcode, time: new Date().toLocaleTimeString(), success: false },
        ...prev.slice(0, 14),
      ]);
    } finally {
      setTransmitting(false);
    }
  };

  if (!activeStore) {
    return (
      <div className="p-12 text-center text-slate-400">
        <Smartphone className="w-12 h-12 mx-auto text-slate-600 mb-3" />
        <p className="text-base font-medium">Please select or create a store first.</p>
      </div>
    );
  }

  // Device authorization enforcement (Rule 11 & 14)
  if (deviceStatus === 'UNREGISTERED') {
    return (
      <div className="max-w-md mx-auto my-12 p-8 bg-slate-900 border border-slate-800 rounded-2xl text-center space-y-4">
        <Smartphone className="w-12 h-12 mx-auto text-emerald-400" />
        <h2 className="text-lg font-bold text-white">Scanner Registration Required</h2>
        <p className="text-xs text-slate-400">
          This device is not enrolled as an authorized scanner in {activeStore.name}.
        </p>
        <button
          onClick={onOpenEnrollment}
          className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-sm font-semibold shadow transition"
        >
          Enroll This Device as Scanner
        </button>
      </div>
    );
  }

  if (deviceStatus === 'PENDING') {
    return (
      <div className="max-w-md mx-auto my-12 p-8 bg-amber-950/40 border border-amber-800/60 rounded-2xl text-center space-y-4">
        <Clock className="w-12 h-12 mx-auto text-amber-400 animate-pulse" />
        <h2 className="text-lg font-bold text-amber-200">Waiting for administrator approval</h2>
        <p className="text-xs text-amber-300/80">
          Device ID: <span className="font-mono text-white">{currentDeviceId}</span>
        </p>
        <p className="text-xs text-slate-400">
          An administrator must approve this scanner in the "Devices" tab before scans can be relayed to POS terminals.
        </p>
      </div>
    );
  }

  if (deviceStatus === 'DISABLED' || deviceStatus === 'REJECTED') {
    return (
      <div className="max-w-md mx-auto my-12 p-8 bg-rose-950/40 border border-rose-800/60 rounded-2xl text-center space-y-4">
        <AlertTriangle className="w-12 h-12 mx-auto text-rose-400" />
        <h2 className="text-lg font-bold text-rose-200">Device Unauthorized ({deviceStatus})</h2>
        <p className="text-xs text-slate-400">
          This device has been {deviceStatus.toLowerCase()} by the store administrator.
        </p>
      </div>
    );
  }

  const activeTargetPos = availablePosList.find((p) => p.deviceId === targetPosId);

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Target POS Terminal Pairing Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-lg bg-emerald-600/20 text-emerald-400">
              <Radio className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Live Scanner Bridge</h2>
              <p className="text-xs text-slate-400">Real-time Firestore scan relay to active POS register</p>
            </div>
          </div>

          <button
            onClick={onOpenEnrollment}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition"
            title="Device settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>

        {/* Target Selector */}
        <div>
          <label className="block text-xs font-medium text-slate-300 mb-1.5">
            Target POS Register
          </label>
          {availablePosList.length === 0 ? (
            <div className="p-3 bg-amber-950/30 border border-amber-800/40 rounded-xl text-xs text-amber-300 flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              <span>No approved POS terminals online in this store. Register a POS first.</span>
            </div>
          ) : (
            <div className="flex items-center space-x-3">
              <select
                id="scanner-target-pos-select"
                value={targetPosId}
                onChange={(e) => setTargetPosId(e.target.value)}
                className="flex-1 px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-emerald-500 transition"
              >
                {availablePosList.map((pos) => (
                  <option key={pos.deviceId} value={pos.deviceId}>
                    {pos.name} ({pos.deviceId.slice(-6)})
                  </option>
                ))}
              </select>

              <div className="flex items-center space-x-1.5 text-xs text-emerald-400 font-medium px-2.5 py-2 bg-emerald-950/40 border border-emerald-800/60 rounded-xl">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                <span>Linked</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Barcode Input & Dispatcher */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
        <form onSubmit={handleSendScan} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Scan Barcode / Enter UPC
            </label>
            <div className="relative">
              <Barcode className="w-5 h-5 text-slate-400 absolute left-3.5 top-3" />
              <input
                id="scanner-barcode-input"
                type="text"
                autoFocus
                value={barcodeInput}
                onChange={(e) => setBarcodeInput(e.target.value)}
                placeholder="Scan or enter barcode number..."
                className="w-full pl-11 pr-24 py-3 bg-slate-800 border border-slate-700 rounded-xl text-base font-mono text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition"
              />
              <button
                type="submit"
                id="send-barcode-scan-button"
                disabled={transmitting || !barcodeInput.trim() || !targetPosId}
                className="absolute right-2 top-2 bottom-2 px-4 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white rounded-lg text-xs font-semibold shadow flex items-center space-x-1.5 transition"
              >
                {transmitting ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5" />
                    <span>Send</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>

        {statusMessage && (
          <div
            className={`p-3 rounded-xl text-xs flex items-center space-x-2 ${
              statusMessage.includes('failed')
                ? 'bg-rose-950/60 border border-rose-800 text-rose-200'
                : 'bg-emerald-950/60 border border-emerald-800 text-emerald-200'
            }`}
          >
            <CheckCircle className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{statusMessage}</span>
          </div>
        )}
      </div>

      {/* Recent Dispatches Feed */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
        <h3 className="text-sm font-semibold text-white mb-3 flex items-center justify-between">
          <span>Recent Transmissions</span>
          <span className="text-xs text-slate-500 font-normal">History is local to session</span>
        </h3>

        {recentScans.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-500">
            No barcodes transmitted in this session yet.
          </div>
        ) : (
          <div className="divide-y divide-slate-800 max-h-64 overflow-y-auto">
            {recentScans.map((scan, idx) => (
              <div key={idx} className="py-2.5 flex items-center justify-between text-xs">
                <div className="flex items-center space-x-2 font-mono">
                  <Barcode className="w-4 h-4 text-emerald-400" />
                  <span className="text-white font-medium">{scan.barcode}</span>
                </div>
                <div className="flex items-center space-x-2 text-slate-500">
                  <span>{scan.time}</span>
                  <span
                    className={`px-1.5 py-0.2 rounded text-[10px] font-semibold ${
                      scan.success
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : 'bg-rose-950 text-rose-300 border border-rose-800'
                    }`}
                  >
                    {scan.success ? 'DELIVERED' : 'FAILED'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
