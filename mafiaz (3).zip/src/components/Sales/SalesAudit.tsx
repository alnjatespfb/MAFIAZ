import React, { useState, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import { Sale } from '../../types';
import { subscribeToStoreSales } from '../../firebase/services/saleService';
import {
  Receipt,
  Search,
  Calendar,
  CreditCard,
  Banknote,
  DollarSign,
  Clock,
  User,
  Monitor,
  CheckCircle2,
  AlertCircle,
  FileSpreadsheet,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

export const SalesAudit: React.FC = () => {
  const { activeStore } = useStore();
  const [sales, setSales] = useState<Sale[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedSaleId, setExpandedSaleId] = useState<string | null>(null);

  useEffect(() => {
    if (!activeStore) {
      setSales([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    const unsub = subscribeToStoreSales(
      activeStore.storeId,
      (salesList) => {
        setSales(salesList);
        setLoading(false);
      },
      (err) => {
        console.error('Sales subscription error:', err);
        setLoading(false);
      }
    );

    return () => unsub();
  }, [activeStore]);

  if (!activeStore) {
    return (
      <div className="p-12 text-center text-slate-400">
        <Receipt className="w-12 h-12 mx-auto text-slate-600 mb-3" />
        <p className="text-base font-medium">Please select or create a store first.</p>
      </div>
    );
  }

  const totalRevenue = sales.reduce((sum, s) => sum + s.total, 0);
  const totalTax = sales.reduce((sum, s) => sum + s.taxTotal, 0);
  const totalTransactions = sales.length;

  const filteredSales = sales.filter((s) => {
    const q = searchQuery.toLowerCase();
    return (
      s.transactionId.toLowerCase().includes(q) ||
      s.employeeName.toLowerCase().includes(q) ||
      s.deviceId.toLowerCase().includes(q) ||
      s.paymentMethod.toLowerCase().includes(q) ||
      s.items.some((i) => i.name.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2.5">
            <Receipt className="w-6 h-6 text-emerald-400" />
            <span>Sales & Transaction Audit Ledger</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Store: <span className="text-slate-200 font-semibold">{activeStore.name}</span> — Immutable real-time transactional records with full audit trail.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <div className="text-xs text-emerald-400 bg-emerald-950/60 border border-emerald-800/80 px-3 py-1.5 rounded-xl font-medium flex items-center space-x-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Audit-Locked Ledger</span>
          </div>
        </div>
      </div>

      {/* Financial Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs uppercase font-semibold tracking-wider">Gross Revenue</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">
            {activeStore.currency} {totalRevenue.toFixed(2)}
          </div>
          <div className="text-xs text-slate-500 mt-1">Across {totalTransactions} completed transactions</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs uppercase font-semibold tracking-wider">Tax Collected</span>
            <Receipt className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">
            {activeStore.currency} {totalTax.toFixed(2)}
          </div>
          <div className="text-xs text-slate-500 mt-1">Store rate: {activeStore.taxRate}%</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs uppercase font-semibold tracking-wider">Transactions Ring</span>
            <Clock className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">
            {totalTransactions}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            Avg: {activeStore.currency} {totalTransactions > 0 ? (totalRevenue / totalTransactions).toFixed(2) : '0.00'}
          </div>
        </div>
      </div>

      {/* Search Input */}
      <div className="relative max-w-md">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
        <input
          id="sales-search-input"
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Filter by transaction ID, cashier, terminal, or item..."
          className="w-full pl-9 pr-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
        />
      </div>

      {/* Transactions Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-400">Loading audit ledger...</div>
        ) : filteredSales.length === 0 ? (
          <div className="p-16 text-center text-slate-400">
            <Receipt className="w-12 h-12 mx-auto text-slate-600 mb-3" />
            <p className="text-base font-medium text-slate-300">
              {sales.length === 0 ? 'No sales yet.' : 'No transactions match filter.'}
            </p>
            {sales.length === 0 && (
              <p className="text-xs text-slate-500 mt-1">
                Completed sales processed at any POS terminal in {activeStore.name} will be permanently audited here.
              </p>
            )}
          </div>
        ) : (
          <div className="divide-y divide-slate-800">
            {filteredSales.map((sale) => {
              const isExpanded = expandedSaleId === sale.saleId;
              const dateObj = new Date(sale.createdAt);

              return (
                <div key={sale.saleId} className="hover:bg-slate-800/30 transition">
                  <div
                    onClick={() => setExpandedSaleId(isExpanded ? null : sale.saleId)}
                    className="px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer select-none"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className="font-mono text-sm font-semibold text-white">
                          {sale.transactionId}
                        </span>
                        {sale.offlineQueued && (
                          <span
                            className="px-1.5 py-0.5 text-[10px] font-semibold rounded bg-amber-950 text-amber-300 border border-amber-800"
                            title="Processed via offline queue synchronization"
                          >
                            OFFLINE SYNCED
                          </span>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400">
                        <div className="flex items-center space-x-1">
                          <Calendar className="w-3.5 h-3.5 text-slate-500" />
                          <span>{dateObj.toLocaleDateString()} {dateObj.toLocaleTimeString()}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <User className="w-3.5 h-3.5 text-slate-500" />
                          <span>Cashier: {sale.employeeName}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Monitor className="w-3.5 h-3.5 text-slate-500" />
                          <span>Terminal: {sale.deviceId.slice(-8)}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end space-x-4">
                      <div className="flex items-center space-x-2">
                        {sale.paymentMethod === 'CARD' ? (
                          <span className="flex items-center space-x-1 px-2.5 py-1 rounded bg-blue-950 text-blue-300 border border-blue-800 text-xs font-semibold">
                            <CreditCard className="w-3 h-3" />
                            <span>CARD</span>
                          </span>
                        ) : (
                          <span className="flex items-center space-x-1 px-2.5 py-1 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 text-xs font-semibold">
                            <Banknote className="w-3 h-3" />
                            <span>CASH</span>
                          </span>
                        )}
                        <span className="font-mono text-base font-bold text-white">
                          {activeStore.currency} {sale.total.toFixed(2)}
                        </span>
                      </div>

                      <button className="text-slate-400 hover:text-white p-1">
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Expanded Itemized Breakdown */}
                  {isExpanded && (
                    <div className="px-6 py-4 bg-slate-950/60 border-t border-slate-800/80 text-xs text-slate-300">
                      <div className="font-semibold text-slate-400 uppercase tracking-wider mb-2">
                        Line Items ({sale.items.length})
                      </div>
                      <div className="space-y-1.5 mb-3">
                        {sale.items.map((item, idx) => (
                          <div
                            key={idx}
                            className="flex items-center justify-between py-1 border-b border-slate-800/40"
                          >
                            <div>
                              <span className="font-medium text-white">{item.name}</span>
                              <span className="text-slate-500 ml-2 font-mono">
                                ({item.quantity} × {activeStore.currency} {item.price.toFixed(2)})
                              </span>
                            </div>
                            <div className="font-mono font-medium text-white">
                              {activeStore.currency} {item.total.toFixed(2)}
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className="flex justify-end pt-2">
                        <div className="w-56 space-y-1 text-right font-mono">
                          <div className="flex justify-between text-slate-400">
                            <span>Subtotal:</span>
                            <span>{activeStore.currency} {sale.subtotal.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between text-slate-400">
                            <span>Tax:</span>
                            <span>{activeStore.currency} {sale.taxTotal.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between font-bold text-sm text-emerald-400 border-t border-slate-800 pt-1">
                            <span>Total Paid:</span>
                            <span>{activeStore.currency} {sale.total.toFixed(2)}</span>
                          </div>
                          {sale.amountTendered !== undefined && (
                            <div className="flex justify-between text-[11px] text-slate-500 pt-0.5">
                              <span>Tendered / Change:</span>
                              <span>
                                {activeStore.currency} {sale.amountTendered.toFixed(2)} / {activeStore.currency} {sale.changeDue?.toFixed(2) || '0.00'}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
