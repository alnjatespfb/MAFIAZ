import React, { useState, useEffect } from 'react';
import { useDevice } from '../../context/DeviceContext';
import { useStore } from '../../context/StoreContext';
import { DeviceType, Device } from '../../types';
import { subscribeToStoreDevices } from '../../firebase/services/deviceService';
import { X, Monitor, Smartphone, CheckCircle, ShieldAlert, Cpu } from 'lucide-react';

interface DeviceEnrollmentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DeviceEnrollmentModal: React.FC<DeviceEnrollmentModalProps> = ({
  isOpen,
  onClose,
}) => {
  const {
    currentDeviceId,
    currentDevice,
    deviceType,
    deviceStatus,
    enrollDevice,
    setPairedPosDeviceId,
  } = useDevice();
  const { activeStore } = useStore();

  const [name, setName] = useState(currentDevice?.name || '');
  const [selectedType, setSelectedType] = useState<DeviceType>(deviceType);
  const [targetPosId, setTargetPosId] = useState(currentDevice?.pairedPosDeviceId || '');
  const [availablePosList, setAvailablePosList] = useState<Device[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (currentDevice) {
      setName(currentDevice.name);
      setSelectedType(currentDevice.type);
      setTargetPosId(currentDevice.pairedPosDeviceId || '');
    } else {
      setName(selectedType === 'POS' ? 'Front Counter Terminal' : 'Warehouse Scanner');
    }
  }, [currentDevice, selectedType]);

  // Fetch approved POS devices to pair with if scanner
  useEffect(() => {
    if (!activeStore) return;
    const unsub = subscribeToStoreDevices(activeStore.storeId, (devices) => {
      const posDevs = devices.filter((d) => d.type === 'POS' && d.status === 'APPROVED');
      setAvailablePosList(posDevs);
      if (posDevs.length > 0 && !targetPosId) {
        setTargetPosId(posDevs[0].deviceId);
      }
    });
    return () => unsub();
  }, [activeStore]);

  if (!isOpen) return null;

  const handleEnroll = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Device name is required');
      return;
    }

    try {
      setSubmitting(true);
      setError(null);
      await enrollDevice(name.trim(), selectedType, selectedType === 'SCANNER' ? targetPosId : undefined);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to enroll device.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-lg bg-emerald-600/20 text-emerald-400">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-white">Device Enrollment</h2>
              <p className="text-xs text-slate-400">Configure this terminal's hardware identity</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current State Info */}
        <div className="px-6 py-3 bg-slate-800/40 border-b border-slate-800/80 flex items-center justify-between text-xs">
          <div className="text-slate-400">
            Hardware ID: <span className="font-mono text-slate-200">{currentDeviceId}</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="text-slate-400">Status:</span>
            <span
              className={`px-2 py-0.5 rounded font-semibold ${
                deviceStatus === 'APPROVED'
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                  : deviceStatus === 'PENDING'
                  ? 'bg-amber-950 text-amber-300 border border-amber-800'
                  : deviceStatus === 'UNREGISTERED'
                  ? 'bg-slate-800 text-slate-300'
                  : 'bg-rose-950 text-rose-300 border border-rose-800'
              }`}
            >
              {deviceStatus}
            </span>
          </div>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3 rounded-xl bg-rose-950/60 border border-rose-800 text-rose-200 text-xs flex items-center space-x-2">
            <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleEnroll} className="p-6 space-y-4">
          {/* Device Role Selection */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-2">Device Function</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                id="role-pos-button"
                onClick={() => setSelectedType('POS')}
                className={`flex flex-col items-center p-3.5 rounded-xl border text-center transition ${
                  selectedType === 'POS'
                    ? 'bg-emerald-600/20 border-emerald-500 text-white'
                    : 'bg-slate-800/70 border-slate-700 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Monitor className="w-6 h-6 text-emerald-400 mb-1.5" />
                <span className="text-sm font-semibold">POS Terminal</span>
                <span className="text-[11px] text-slate-400 mt-0.5">Rings sales and manages register</span>
              </button>

              <button
                type="button"
                id="role-scanner-button"
                onClick={() => setSelectedType('SCANNER')}
                className={`flex flex-col items-center p-3.5 rounded-xl border text-center transition ${
                  selectedType === 'SCANNER'
                    ? 'bg-emerald-600/20 border-emerald-500 text-white'
                    : 'bg-slate-800/70 border-slate-700 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Smartphone className="w-6 h-6 text-emerald-400 mb-1.5" />
                <span className="text-sm font-semibold">Mobile Scanner</span>
                <span className="text-[11px] text-slate-400 mt-0.5">Dispatches live scans to POS</span>
              </button>
            </div>
          </div>

          {/* Friendly Name */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">Friendly Name</label>
            <input
              id="device-name-input"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Register 1 or Mobile Scanner #2"
              className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
            />
          </div>

          {/* Target POS selection if Scanner */}
          {selectedType === 'SCANNER' && (
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Pair with POS Terminal
              </label>
              {availablePosList.length === 0 ? (
                <div className="p-3 bg-slate-800/60 border border-slate-700 rounded-xl text-xs text-amber-300">
                  No approved POS terminals available in this store. Please register and approve a POS terminal first.
                </div>
              ) : (
                <select
                  id="paired-pos-select"
                  value={targetPosId}
                  onChange={(e) => {
                    setTargetPosId(e.target.value);
                    if (currentDevice) {
                      setPairedPosDeviceId(e.target.value);
                    }
                  }}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-emerald-500 transition"
                >
                  <option value="">Select target POS terminal...</option>
                  {availablePosList.map((pos) => (
                    <option key={pos.deviceId} value={pos.deviceId}>
                      {pos.name} ({pos.deviceId.slice(-6)})
                    </option>
                  ))}
                </select>
              )}
            </div>
          )}

          <div className="pt-3 flex items-center justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
            >
              Cancel
            </button>
            <button
              id="submit-device-enrollment"
              type="submit"
              disabled={submitting}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-sm font-medium rounded-xl shadow transition flex items-center space-x-2"
            >
              <CheckCircle className="w-4 h-4" />
              <span>{currentDevice ? 'Update Registration' : 'Register Device'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
