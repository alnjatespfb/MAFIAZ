import React, { useState, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import { useDevice } from '../../context/DeviceContext';
import { Device, DeviceStatus, Product } from '../../types';
import {
  subscribeToStoreDevices,
  updateDeviceStatus,
  deleteDevice,
} from '../../firebase/services/deviceService';
import { broadcastBarcodeScan } from '../../firebase/services/scannerService';
import { subscribeToStoreProducts } from '../../firebase/services/productService';
import { playChime } from '../../utils/feedback';
import {
  Cpu,
  Monitor,
  Smartphone,
  Trash2,
  Plus,
  Clock,
  AlertCircle,
  Radio,
  Send,
  Check,
  Zap,
} from 'lucide-react';

interface DeviceManagerProps {
  onOpenEnrollment: () => void;
}

export const DeviceManager: React.FC<DeviceManagerProps> = ({ onOpenEnrollment }) => {
  const { activeStore } = useStore();
  const { currentDeviceId } = useDevice();
  const [devices, setDevices] = useState<Device[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionError, setActionError] = useState<string | null>(null);

  // Live Mobile Scanner Test Bench
  const [testBarcode, setTestBarcode] = useState('');
  const [targetPosId, setTargetPosId] = useState('');
  const [testSending, setTestSending] = useState(false);
  const [testSuccess, setTestSuccess] = useState<string | null>(null);

  useEffect(() => {
    if (!activeStore) {
      setDevices([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    const unsub = subscribeToStoreDevices(
      activeStore.storeId,
      (devList) => {
        setDevices(devList);
        setLoading(false);

        // Auto-select current or first POS device as target if not selected
        const posDevs = devList.filter((d) => d.type === 'POS' && d.status === 'APPROVED');
        if (posDevs.length > 0 && !targetPosId) {
          const matchCurrent = posDevs.find((d) => d.deviceId === currentDeviceId);
          setTargetPosId(matchCurrent ? matchCurrent.deviceId : posDevs[0].deviceId);
        }
      },
      (err) => {
        console.error('Error fetching devices:', err);
        setActionError(err.message || 'Failed to load devices.');
        setLoading(false);
      }
    );

    const unsubProducts = subscribeToStoreProducts(activeStore.storeId, (prods) => {
      setProducts(prods);
      if (prods.length > 0 && !testBarcode) {
        setTestBarcode(prods[0].barcode || prods[0].sku || '');
      }
    });

    return () => {
      unsub();
      unsubProducts();
    };
  }, [activeStore, currentDeviceId]);

  const handleStatusChange = async (deviceId: string, status: DeviceStatus) => {
    if (!activeStore) return;
    try {
      setActionError(null);
      await updateDeviceStatus(activeStore.storeId, deviceId, status);
      playChime('success');
    } catch (err: any) {
      setActionError(err.message || 'Failed to update device status.');
    }
  };

  const handleDelete = async (deviceId: string, name: string) => {
    if (!activeStore) return;
    const confirmed = window.confirm(`Are you sure you want to remove device "${name}"?`);
    if (!confirmed) return;

    try {
      setActionError(null);
      await deleteDevice(activeStore.storeId, deviceId);
      playChime('success');
    } catch (err: any) {
      setActionError(err.message || 'Failed to delete device.');
    }
  };

  const handleSendTestScan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeStore || !testBarcode.trim()) return;

    try {
      setTestSending(true);
      setActionError(null);

      await broadcastBarcodeScan(
        activeStore.storeId,
        'simulated_android_scanner',
        testBarcode.trim(),
        targetPosId || currentDeviceId
      );

      playChime('beep');
      setTestSuccess(`Dispatched barcode "${testBarcode}" to POS terminal!`);
      setTimeout(() => setTestSuccess(null), 3000);
    } catch (err: any) {
      setActionError(err.message || 'Failed to broadcast scan event.');
    } finally {
      setTestSending(false);
    }
  };

  if (!activeStore) {
    return (
      <div className="p-8 text-center text-slate-400">
        <AlertCircle className="w-12 h-12 mx-auto text-slate-600 mb-3" />
        <p className="text-base font-medium">Please select or create a store first.</p>
      </div>
    );
  }

  const approvedPosList = devices.filter((d) => d.type === 'POS' && d.status === 'APPROVED');

  return (
    <div className="space-y-6 animate-in fade-in duration-150">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-sm">
        <div>
          <h1 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2.5">
            <Cpu className="w-6 h-6 text-emerald-400" />
            <span>Authorized Hardware & Devices</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Store: <span className="text-slate-200 font-semibold">{activeStore.name}</span> — Manage POS terminals, pairing, and Android phone scanners.
          </p>
        </div>

        <button
          id="enroll-new-device-button"
          onClick={onOpenEnrollment}
          className="flex items-center space-x-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-lg transition shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Enroll / Configure Current Device</span>
        </button>
      </div>

      {actionError && (
        <div className="p-4 rounded-2xl bg-rose-950/60 border border-rose-800 text-rose-200 text-xs flex items-center space-x-2">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{actionError}</span>
        </div>
      )}

      {/* Devices List Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl shadow-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <h2 className="text-sm font-bold text-white">Registered Store Terminals ({devices.length})</h2>
          <span className="text-xs text-slate-500 font-mono">
            Active Store: {activeStore.storeId.slice(0, 8)}...
          </span>
        </div>

        {loading ? (
          <div className="p-12 text-center text-slate-400">Loading devices...</div>
        ) : devices.length === 0 ? (
          <div className="p-16 text-center text-slate-400">
            <Cpu className="w-12 h-12 mx-auto text-slate-600 mb-3" />
            <p className="text-base font-medium text-slate-300">No devices registered yet.</p>
            <p className="text-xs text-slate-500 mt-1">
              Click "Enroll / Configure Current Device" to register this hardware as a POS or Scanner.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-300">
              <thead className="bg-slate-800/60 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="px-6 py-3.5">Device Name</th>
                  <th className="px-6 py-3.5">Function</th>
                  <th className="px-6 py-3.5">Hardware ID</th>
                  <th className="px-6 py-3.5">Pairing Target</th>
                  <th className="px-6 py-3.5">Authorization</th>
                  <th className="px-6 py-3.5">Last Heartbeat</th>
                  <th className="px-6 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-xs">
                {devices.map((device) => {
                  const isThisDevice = device.deviceId === currentDeviceId;
                  return (
                    <tr
                      key={device.deviceId}
                      className={`hover:bg-slate-800/40 transition ${
                        isThisDevice ? 'bg-emerald-950/20' : ''
                      }`}
                    >
                      <td className="px-6 py-4 font-medium text-white flex items-center space-x-2.5">
                        {device.type === 'POS' ? (
                          <div className="p-1.5 rounded-xl bg-blue-600/20 text-blue-400">
                            <Monitor className="w-4 h-4" />
                          </div>
                        ) : (
                          <div className="p-1.5 rounded-xl bg-emerald-600/20 text-emerald-400">
                            <Smartphone className="w-4 h-4" />
                          </div>
                        )}
                        <div>
                          <div className="flex items-center space-x-1.5">
                            <span className="font-semibold">{device.name}</span>
                            {isThisDevice && (
                              <span className="px-1.5 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-semibold rounded-md">
                                THIS BROWSER
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      <td className="px-6 py-4 font-mono text-xs">
                        <span
                          className={`px-2 py-0.5 rounded-md text-xs font-semibold ${
                            device.type === 'POS'
                              ? 'bg-blue-900/40 text-blue-300 border border-blue-800'
                              : 'bg-purple-900/40 text-purple-300 border border-purple-800'
                          }`}
                        >
                          {device.type}
                        </span>
                      </td>

                      <td className="px-6 py-4 font-mono text-xs text-slate-400">
                        {device.deviceId}
                      </td>

                      <td className="px-6 py-4 text-xs text-slate-400">
                        {device.type === 'SCANNER' ? (
                          device.pairedPosDeviceId ? (
                            <span className="font-mono text-slate-300">
                              POS: {device.pairedPosDeviceId.slice(-8)}
                            </span>
                          ) : (
                            <span className="text-amber-400">Unpaired</span>
                          )
                        ) : (
                          <span className="text-slate-600">—</span>
                        )}
                      </td>

                      <td className="px-6 py-4">
                        <span
                          className={`inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-[11px] font-bold border ${
                            device.status === 'APPROVED'
                              ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                              : device.status === 'PENDING'
                              ? 'bg-amber-950 text-amber-300 border-amber-800 animate-pulse'
                              : device.status === 'DISABLED'
                              ? 'bg-slate-800 text-slate-400 border-slate-700'
                              : 'bg-rose-950 text-rose-300 border-rose-800'
                          }`}
                        >
                          <span>{device.status}</span>
                        </span>
                      </td>

                      <td className="px-6 py-4 text-xs text-slate-400">
                        <div className="flex items-center space-x-1">
                          <Clock className="w-3.5 h-3.5 text-slate-500" />
                          <span>
                            {device.lastActiveAt
                              ? new Date(device.lastActiveAt).toLocaleTimeString([], {
                                  hour: '2-digit',
                                  minute: '2-digit',
                                  second: '2-digit',
                                })
                              : 'Never'}
                          </span>
                        </div>
                      </td>

                      <td className="px-6 py-4 text-right space-x-1.5 whitespace-nowrap">
                        {device.status !== 'APPROVED' && (
                          <button
                            id={`approve-device-${device.deviceId}`}
                            onClick={() => handleStatusChange(device.deviceId, 'APPROVED')}
                            className="px-2.5 py-1 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-700/60 rounded-lg text-xs font-semibold transition"
                            title="Approve device for operations"
                          >
                            Approve
                          </button>
                        )}

                        {device.status === 'APPROVED' && (
                          <button
                            id={`disable-device-${device.deviceId}`}
                            onClick={() => handleStatusChange(device.deviceId, 'DISABLED')}
                            className="px-2.5 py-1 bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-700/60 rounded-lg text-xs font-semibold transition"
                            title="Disable device"
                          >
                            Disable
                          </button>
                        )}

                        {device.status === 'PENDING' && (
                          <button
                            id={`reject-device-${device.deviceId}`}
                            onClick={() => handleStatusChange(device.deviceId, 'REJECTED')}
                            className="px-2.5 py-1 bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-700/60 rounded-lg text-xs font-semibold transition"
                            title="Reject device"
                          >
                            Reject
                          </button>
                        )}

                        <button
                          id={`delete-device-${device.deviceId}`}
                          onClick={() => handleDelete(device.deviceId, device.name)}
                          className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition"
                          title="Remove device"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Live Mobile Scanner Test Bench (Simulates Android Phone sending scans) */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-xl bg-purple-600/20 text-purple-400">
            <Radio className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white leading-none">
              Mobile Barcode Scanner Live Bridge Test Bench
            </h2>
            <p className="text-[11px] text-slate-400 mt-1">
              Broadcasts a real barcode scan event from a simulated Android phone scanner into Firestore, testing the live POS cart listener.
            </p>
          </div>
        </div>

        {testSuccess && (
          <div className="p-3 rounded-2xl bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-xs flex items-center space-x-2 animate-in fade-in">
            <Check className="w-4 h-4" />
            <span>{testSuccess} Check the POS Terminal tab to see it added to the active cart!</span>
          </div>
        )}

        <form onSubmit={handleSendTestScan} className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">
              Barcode / SKU to Broadcast
            </label>
            <input
              type="text"
              required
              value={testBarcode}
              onChange={(e) => setTestBarcode(e.target.value)}
              placeholder="e.g. 628100123456"
              className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">
              Target POS Register
            </label>
            <select
              value={targetPosId}
              onChange={(e) => setTargetPosId(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
            >
              {approvedPosList.map((p) => (
                <option key={p.deviceId} value={p.deviceId}>
                  {p.name} ({p.deviceId.slice(-6)}) {p.deviceId === currentDeviceId ? '★ Current' : ''}
                </option>
              ))}
              <option value={currentDeviceId}>Current Browser ({currentDeviceId.slice(-6)})</option>
            </select>
          </div>

          <div className="flex items-end">
            <button
              type="submit"
              disabled={testSending || !testBarcode.trim()}
              className="w-full py-2.5 bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white rounded-xl text-xs font-bold shadow transition flex items-center justify-center space-x-2"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{testSending ? 'Broadcasting...' : 'Broadcast Phone Scan'}</span>
            </button>
          </div>
        </form>

        {products.length > 0 && (
          <div className="pt-2 border-t border-slate-800/80 flex items-center space-x-2 text-xs overflow-x-auto">
            <span className="text-slate-500 text-[11px] whitespace-nowrap">Quick Barcodes:</span>
            {products.slice(0, 5).map((p) => (
              <button
                key={p.productId}
                type="button"
                onClick={() => setTestBarcode(p.barcode || p.sku || '')}
                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded-lg text-[11px] font-mono whitespace-nowrap transition"
              >
                {p.name.slice(0, 14)}: {p.barcode || p.sku}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
