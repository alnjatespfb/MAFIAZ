import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { Store } from '../types';
import { createStore, fetchUserStores, updateStore as apiUpdateStore, deleteStore as apiDeleteStore } from '../firebase/services/storeService';
import { useAuth } from './AuthContext';

export interface CreateStoreInput {
  name: string;
  country?: string;
  currency?: string;
  taxRate?: number;
  address?: string;
  phone?: string;
  logo?: string;
}

interface StoreContextType {
  stores: Store[];
  activeStore: Store | null;
  loading: boolean;
  error: string | null;
  setActiveStore: (store: Store) => void;
  createNewStore: (nameOrInput: string | CreateStoreInput, currency?: string, taxRate?: number) => Promise<Store>;
  updateActiveStore: (updates: Partial<Store>) => Promise<void>;
  deleteActiveStore: (storeId: string) => Promise<void>;
  refreshStores: () => Promise<void>;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);
const ACTIVE_STORE_STORAGE_KEY = 'pos_active_store_id';

export const StoreProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [stores, setStores] = useState<Store[]>([]);
  const [activeStore, setActiveStoreState] = useState<Store | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refreshStores = async () => {
    if (!user) {
      setStores([]);
      setActiveStoreState(null);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const userStores = await fetchUserStores();
      setStores(userStores);

      if (userStores.length > 0) {
        const savedStoreId = localStorage.getItem(ACTIVE_STORE_STORAGE_KEY);
        const match = userStores.find((s) => s.storeId === savedStoreId);
        const selected = match || userStores[0];
        setActiveStoreState(selected);
        localStorage.setItem(ACTIVE_STORE_STORAGE_KEY, selected.storeId);
      } else {
        setActiveStoreState(null);
        localStorage.removeItem(ACTIVE_STORE_STORAGE_KEY);
      }
    } catch (err: any) {
      console.error('Failed to load stores:', err);
      setError(err.message || 'Failed to fetch stores.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshStores();
  }, [user]);

  const setActiveStore = (store: Store) => {
    setActiveStoreState(store);
    localStorage.setItem(ACTIVE_STORE_STORAGE_KEY, store.storeId);
  };

  const createNewStore = async (
    nameOrInput: string | CreateStoreInput,
    currencyArg: string = 'KWD',
    taxRateArg: number = 0
  ) => {
    try {
      setError(null);
      let input: CreateStoreInput;
      if (typeof nameOrInput === 'string') {
        input = {
          name: nameOrInput,
          currency: currencyArg,
          taxRate: taxRateArg,
        };
      } else {
        input = nameOrInput;
      }

      const newStore = await createStore(input);
      setStores((prev) => [...prev, newStore]);
      setActiveStore(newStore);
      return newStore;
    } catch (err: any) {
      setError(err.message || 'Failed to create store.');
      throw err;
    }
  };

  const updateActiveStore = async (updates: Partial<Store>) => {
    if (!activeStore) return;
    try {
      setError(null);
      await apiUpdateStore(activeStore.storeId, updates);
      const updated = { ...activeStore, ...updates, updatedAt: new Date().toISOString() };
      setActiveStoreState(updated);
      setStores((prev) => prev.map((s) => (s.storeId === activeStore.storeId ? updated : s)));
    } catch (err: any) {
      setError(err.message || 'Failed to update store.');
      throw err;
    }
  };

  const deleteActiveStore = async (storeId: string) => {
    try {
      setError(null);
      await apiDeleteStore(storeId);
      const remaining = stores.filter((s) => s.storeId !== storeId);
      setStores(remaining);
      if (remaining.length > 0) {
        setActiveStore(remaining[0]);
      } else {
        setActiveStoreState(null);
        localStorage.removeItem(ACTIVE_STORE_STORAGE_KEY);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to delete store.');
      throw err;
    }
  };

  return (
    <StoreContext.Provider
      value={{
        stores,
        activeStore,
        loading,
        error,
        setActiveStore,
        createNewStore,
        updateActiveStore,
        deleteActiveStore,
        refreshStores,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export function useStore(): StoreContextType {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
}
