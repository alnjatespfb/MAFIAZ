import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { Device, DeviceStatus, DeviceType } from '../types';
import { useStore } from './StoreContext';
import {
  registerDevice,
  subscribeToStoreDevices,
  updateDeviceHeartbeat,
} from '../firebase/services/deviceService';
import {
  getOfflineSalesQueue,
  syncOfflineSales,
} from '../firebase/services/saleService';

interface DeviceContextType {
  currentDeviceId: string;
  currentDevice: Device | null;
  deviceType: DeviceType;
  deviceStatus: DeviceStatus | 'UNREGISTERED';
  isOnline: boolean;
  offlineQueueCount: number;
  isSyncing: boolean;
  enrollDevice: (name: string, type: DeviceType, pairedPosDeviceId?: string) => Promise<Device>;
  setPairedPosDeviceId: (posId: string) => Promise<void>;
  triggerOfflineSync: () => Promise<{ synced: number; failed: number }>;
}

const DeviceContext = createContext<DeviceContextType | undefined>(undefined);
const DEVICE_ID_KEY = 'pos_local_device_id';
const DEVICE_TYPE_KEY = 'pos_local_device_type';

export const DeviceProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { activeStore } = useStore();

  // Generate or retrieve persistent local device ID
  const [currentDeviceId] = useState<string>(() => {
    let id = localStorage.getItem(DEVICE_ID_KEY);
    if (!id) {
      id = `dev_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 6)}`;
      localStorage.setItem(DEVICE_ID_KEY, id);
    }
    return id;
  });

  const [deviceType, setDeviceType] = useState<DeviceType>(() => {
    return (localStorage.getItem(DEVICE_TYPE_KEY) as DeviceType) || 'POS';
  });

  const [currentDevice, setCurrentDevice] = useState<Device | null>(null);
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [offlineQueueCount, setOfflineQueueCount] = useState<number>(0);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Monitor network status
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      // Trigger automatic synchronization when connection returns
      if (activeStore) {
        triggerOfflineSync();
      }
    };
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [activeStore]);

  // Keep offline queue count updated
  const refreshQueueCount = () => {
    if (!activeStore) {
      setOfflineQueueCount(0);
      return;
    }
    const q = getOfflineSalesQueue(activeStore.storeId);
    setOfflineQueueCount(q.length);
  };

  useEffect(() => {
    refreshQueueCount();
    const interval = setInterval(refreshQueueCount, 3000);
    return () => clearInterval(interval);
  }, [activeStore]);

  // Subscribe to devices in activeStore to track current device authorization status
  useEffect(() => {
    if (!activeStore) {
      setCurrentDevice(null);
      return;
    }

    const unsubscribe = subscribeToStoreDevices(activeStore.storeId, (devices) => {
      const found = devices.find((d) => d.deviceId === currentDeviceId);
      setCurrentDevice(found || null);
      if (found) {
        setDeviceType(found.type);
        localStorage.setItem(DEVICE_TYPE_KEY, found.type);
      }
    });

    return () => unsubscribe();
  }, [activeStore, currentDeviceId]);

  // Periodic heartbeat when approved and online
  useEffect(() => {
    if (!activeStore || !currentDevice || currentDevice.status !== 'APPROVED' || !isOnline) {
      return;
    }

    const interval = setInterval(() => {
      updateDeviceHeartbeat(activeStore.storeId, currentDeviceId).catch(() => {});
    }, 60000); // 1 minute heartbeat

    return () => clearInterval(interval);
  }, [activeStore, currentDevice, currentDeviceId, isOnline]);

  const enrollDevice = async (name: string, type: DeviceType, pairedPosDeviceId?: string): Promise<Device> => {
    if (!activeStore) throw new Error('No active store selected');
    setDeviceType(type);
    localStorage.setItem(DEVICE_TYPE_KEY, type);

    const dev = await registerDevice(activeStore.storeId, {
      deviceId: currentDeviceId,
      name,
      type,
      pairedPosDeviceId,
    });
    setCurrentDevice(dev);
    return dev;
  };

  const setPairedPosDeviceId = async (posId: string) => {
    if (!activeStore || !currentDevice) return;
    await updateDeviceHeartbeat(activeStore.storeId, currentDeviceId, posId);
    setCurrentDevice((prev) => (prev ? { ...prev, pairedPosDeviceId: posId } : null));
  };

  const triggerOfflineSync = async () => {
    if (!activeStore || !isOnline || isSyncing) {
      return { synced: 0, failed: 0 };
    }

    try {
      setIsSyncing(true);
      const res = await syncOfflineSales(activeStore.storeId);
      refreshQueueCount();
      return res;
    } finally {
      setIsSyncing(false);
    }
  };

  const deviceStatus: DeviceStatus | 'UNREGISTERED' = currentDevice ? currentDevice.status : 'UNREGISTERED';

  return (
    <DeviceContext.Provider
      value={{
        currentDeviceId,
        currentDevice,
        deviceType,
        deviceStatus,
        isOnline,
        offlineQueueCount,
        isSyncing,
        enrollDevice,
        setPairedPosDeviceId,
        triggerOfflineSync,
      }}
    >
      {children}
    </DeviceContext.Provider>
  );
};

export function useDevice(): DeviceContextType {
  const context = useContext(DeviceContext);
  if (!context) {
    throw new Error('useDevice must be used within a DeviceProvider');
  }
  return context;
}
