plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.printstudio"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.printstudio"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    androidResources { localeFilters += listOf("en", "ar") }
}

dependencies {
    // Deliberately no AndroidX / Compose: the app uses only the Android framework + Kotlin stdlib.
    testImplementation("junit:junit:4.13.2")
}
