# no special rules needed (no reflection, no third-party libraries)
