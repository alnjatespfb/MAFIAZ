package app.printstudio.ui

import android.app.AlertDialog
import android.view.View
import android.widget.*
import app.printstudio.android.*
import app.printstudio.core.*

private fun MainActivity.sectionCard(title: String, block: LinearLayout.() -> Unit): View = card(this) {
    addView(label(this@sectionCard, title, 16f, true).apply { setPadding(0, 0, 0, dp(6)) })
    block()
}.also { it.layoutParams = lp(-1, -2, bottom = 12, ctx = this) }

private fun LinearLayout.gap(ctx: MainActivity, h: Int = 8) = addView(spacer(ctx, h))

// ====================================================================== OPTIONS
internal fun MainActivity.optionsTab(): View = page {
    val c = this@optionsTab
    val s = settings
    addView(label(c, t("Print options", "خيارات الطباعة"), 22f, true))
    addView(sub(c, t("Preset: ", "الإعداد: ") + when (s.preset) {
        Preset.EVERYDAY -> t("Everyday", "يومي"); Preset.ECONOMY -> t("Economy", "اقتصادي"); Preset.BOOK -> t("Book", "كتاب")
        Preset.BOOKLET -> t("Booklet", "كتيّب"); Preset.HIGH_QUALITY -> t("High quality", "جودة عالية"); Preset.CUSTOM -> t("Custom", "مخصص") }))
    addView(spacer(c, 8))
    addView(card(c) {
        addView(label(c, t("What this app can and can't control", "ما يمكن للتطبيق التحكم به وما لا يمكنه"), 14f, true))
        addView(sub(c, t("Layout, page order, two-sided logic, booklets, scaling, grayscale/black-and-white, contrast, darkness and the software draft mode are done here, before the file reaches Android. Resolution, tray, real hardware duplex and any driver toner-save switch belong to the print service and appear only in Android's print dialog — this app cannot set them.", "التخطيط وترتيب الصفحات ومنطق الوجهين والكتيّب والتحجيم والتدرج الرمادي/الأبيض والأسود والتباين والكثافة ووضع المسودة البرمجي تتم هنا قبل وصول الملف لأندرويد. أما الدقة والصينية والدوبلكس الفعلي وأي خيار توفير حبر في التعريف فتخص خدمة الطباعة وتظهر فقط في نافذة الطباعة — لا يستطيع التطبيق ضبطها.")))
    }.also { it.layoutParams = lp(-1, -2, bottom = 12, ctx = c) })

    // ---- paper & layout
    addView(sectionCard(t("Paper & layout", "الورق والتخطيط")) {
        addView(sub(c, t("Paper size", "حجم الورق")))
        addView(chips(c, PaperSize.values().map { it.id.let { n -> (if (n == "LETTER") "Letter" else if (n == "LEGAL") "Legal" else n) } to it }, s.paper) { v -> update({ it.copy(paper = v) }) })
        gap(c)
        addView(sub(c, t("Orientation", "الاتجاه")))
        addView(chips(c, listOf(t("Auto", "تلقائي") to Orientation.AUTO, t("Portrait", "عمودي") to Orientation.PORTRAIT, t("Landscape", "أفقي") to Orientation.LANDSCAPE), s.orientation) { v -> update({ it.copy(orientation = v) }) })
        gap(c)
        addView(sliderRow(c, t("Margins", "الهوامش"), 0, 30, s.marginMm.toInt(), { "$it mm" }) { v, done -> update({ it.copy(marginMm = v.toDouble()) }, done) })
        addView(sliderRow(c, t("Binding margin (extra)", "هامش التجليد (إضافي)"), 0, 25, s.gutterMm.toInt(), { "$it mm" }) { v, done -> update({ it.copy(gutterMm = v.toDouble()) }, done) })
        gap(c)
        addView(sub(c, t("Pages per sheet", "صفحات في الورقة")))
        addView(chips(c, NUP_VALUES.map { "$it" to it }, if (s.booklet) 2 else s.pagesPerSheet) { v -> update({ it.copy(pagesPerSheet = v) }) })
        if (s.booklet) addView(sub(c, t("Booklet mode always puts 2 pages per side.", "وضع الكتيّب يضع صفحتين في كل وجه دائمًا.")))
        addView(switchRow(c, t("Draw a border around pages", "رسم إطار حول الصفحات"), null, s.pageBorder) { v -> update({ it.copy(pageBorder = v) }) })
        addView(switchRow(c, t("Right-to-left document (Arabic)", "مستند من اليمين لليسار (عربي)"), t("Reverses page order on multi-page sheets and puts the binding margin on the right", "يعكس ترتيب الصفحات ويضع هامش التجليد يمينًا"), s.nUpRtl && s.bookletRtl) { v -> update({ it.copy(nUpRtl = v, bookletRtl = v) }) })
        addView(switchRow(c, t("Auto-rotate pages to fit", "تدوير الصفحات تلقائيًا للملاءمة"), null, s.autoRotatePages) { v -> update({ it.copy(autoRotatePages = v) }) })
    })

    // ---- scaling
    addView(sectionCard(t("Scaling", "التحجيم")) {
        addView(chips(c, listOf(t("Fit to page", "ملاءمة الصفحة") to ScaleMode.FIT, t("Actual size", "الحجم الفعلي") to ScaleMode.ACTUAL, t("Custom %", "نسبة مخصصة") to ScaleMode.CUSTOM), s.scale) { v -> update({ it.copy(scale = v) }) })
        if (s.scale == ScaleMode.CUSTOM) addView(sliderRow(c, t("Scale", "النسبة"), 10, 400, s.customScalePercent, { "$it%" }) { v, done -> update({ it.copy(customScalePercent = v) }, done) })
        if (s.scale != ScaleMode.FIT) addView(sub(c, t("Content larger than the printable area is clipped. Ignored when several pages share a sheet.", "المحتوى الأكبر من منطقة الطباعة يُقصّ. يُتجاهل عند وضع عدة صفحات في ورقة.")))
    })

    // ---- copies
    addView(sectionCard(t("Copies", "النسخ")) {
        addView(stepperRow(c, t("Copies", "عدد النسخ"), s.copies, 1, 99) { v -> update({ it.copy(copies = v) }) })
        addView(switchRow(c, t("Collate", "ترتيب النسخ (تجميع)"), t("1,2,3 · 1,2,3 instead of 1,1 · 2,2 · 3,3", "1,2,3 · 1,2,3 بدلًا من 1,1 · 2,2 · 3,3"), s.collate, s.copies > 1) { v -> update({ it.copy(collate = v) }) })
        addView(sub(c, t("Copies are produced by this app so manual two-sided stays in sync. Keep “Copies = 1” in Android's dialog.", "النسخ ينتجها التطبيق ليبقى الوجهان اليدوي متزامنًا. أبقِ “النسخ = 1” في نافذة أندرويد.")))
    })

    // ---- pages
    addView(sectionCard(t("Which pages", "أي صفحات")) {
        val d = doc
        val tf = textInput(c, s.rangeText, t("e.g. 1-3, 5, 8-", "مثال: 1-3, 5, 8-")) { txt -> update({ it.copy(rangeText = txt.trim()) }, false) }
        val msg = label(c, "", 13f, false, pal.danger)
        fun check() {
            if (d == null) { msg.text = ""; return }
            val r = PageSelection.parseRanges(settings.rangeText, d.pageCount)
            msg.text = if (r is RangeResult.Error) (if (r.reason == RangeResult.Reason.OUT_OF_RANGE) t("Out of range (document has ${d.pageCount} pages): ${r.token}", "خارج النطاق (المستند ${d.pageCount} صفحة): ${r.token}") else t("Can't read “${r.token}”", "تعذرت قراءة “${r.token}”")) else ""
        }
        tf.addTextChangedListener(object : android.text.TextWatcher { override fun beforeTextChanged(a: CharSequence?, b: Int, c2: Int, d2: Int) {}; override fun onTextChanged(a: CharSequence?, b: Int, c2: Int, d2: Int) {}; override fun afterTextChanged(e: android.text.Editable?) { check() } })
        check()
        addView(sub(c, t("Custom page range", "نطاق صفحات مخصص"))); addView(tf); addView(msg)
        gap(c)
        addView(sub(c, t("Odd / even (by page number in the document)", "فردي / زوجي (حسب رقم الصفحة في المستند)")))
        addView(chips(c, listOf(t("All", "الكل") to Parity.ALL, t("Odd pages", "الفردية") to Parity.ODD, t("Even pages", "الزوجية") to Parity.EVEN), s.parity) { v -> update({ it.copy(parity = v) }) })
        addView(switchRow(c, t("Only the pages I selected in the Pages tab", "فقط الصفحات التي حددتها في تبويب الصفحات"), if (doc != null) t("${selected.size} selected", "${selected.size} محددة") else null, s.selectedOnly) { v -> update({ it.copy(selectedOnly = v) }) })
        addView(switchRow(c, t("Skip blank pages", "تخطي الصفحات الفارغة"), t("Only pages that are completely white are skipped. Light scans or faint watermarks are kept.", "تُتخطى فقط الصفحات البيضاء تمامًا. تبقى الصفحات الباهتة أو ذات العلامات المائية الخفيفة."), s.skipBlank) { v -> update({ it.copy(skipBlank = v) }) })
        addView(switchRow(c, t("Reverse order", "عكس الترتيب"), null, s.reverse && !s.booklet, !s.booklet) { v -> update({ it.copy(reverse = v) }) })
    })

    // ---- two-sided
    addView(sectionCard(t("Two-sided & booklet", "الوجهان والكتيّب")) {
        addView(chips(c, listOf(t("Off", "إيقاف") to DuplexMode.OFF, t("Manual (flip paper)", "يدوي (اقلب الورق)") to DuplexMode.MANUAL, t("Automatic (printer)", "تلقائي (الطابعة)") to DuplexMode.AUTO), s.duplex) { v -> update({ it.copy(duplex = v) }) })
        if (s.duplex == DuplexMode.AUTO) addView(sub(c, t("Only works if your printer has a duplex unit — HP Laser 107w does not (manual only). Android then requests two-sided from the print service; it may be ignored.", "تعمل فقط إن كانت الطابعة تدعم الطباعة على وجهين — HP Laser 107w لا تدعمها (يدوي فقط). يطلب أندرويد ذلك من خدمة الطباعة وقد يتجاهله.")))
        if (s.duplex == DuplexMode.MANUAL || s.booklet) {
            gap(c)
            addView(sub(c, t("Binding (which edge you turn the sheet on)", "التجليد (أي حافة تقلب عليها الورقة)")))
            addView(chips(c, listOf(t("Book — long edge", "كتاب — الحافة الطويلة") to Binding.BOOK, t("Notepad — short edge", "دفتر — الحافة القصيرة") to Binding.NOTEPAD), if (s.booklet) Binding.BOOK else s.binding) { v -> update({ it.copy(binding = v) }) })
            if (s.booklet) addView(sub(c, t("Booklets always fold like a book.", "الكتيّب يُطوى دائمًا كالكتاب.")))
            addView(switchRow(c, t("Back sides: reverse order", "الأوجه الخلفية: ترتيب معكوس"), t("On = stack goes back into the tray as it came out (typical face-down output)", "تشغيل = تُعاد الرزمة للصينية كما خرجت (إخراج بوجه لأسفل عادةً)"), s.reverseSecondJob) { v -> update({ it.copy(reverseSecondJob = v) }) })
            addView(sub(c, t("How the paper turns when you reload it", "كيف يدور الورق عند إعادة تحميله")))
            addView(chips(c, listOf(t("Over the long edge", "فوق الحافة الطويلة") to ReloadFlip.LONG_EDGE, t("Over the short edge", "فوق الحافة القصيرة") to ReloadFlip.SHORT_EDGE), s.reloadFlip) { v -> update({ it.copy(reloadFlip = v) }) })
            addView(button(c, t("Run calibration test (2 sheets)", "تشغيل اختبار المعايرة (ورقتان)")) { startCalibration() }, lp(-1, -2, top = 8, ctx = c))
            if (!store.calibrated) addView(sub(c, t("Not calibrated yet. Calibrate once for your printer — it avoids upside-down backs and reversed stacks.", "لم تتم المعايرة بعد. عايِر مرة واحدة لطابعتك — لتجنب الأوجه المقلوبة وعكس الرزمة.")))
        }
        gap(c, 12)
        addView(switchRow(c, t("Booklet (fold in half)", "كتيّب (يُطوى للنصف)"), t("Imposes pages in folding order, adds blank pages when the count isn't a multiple of 4", "يرتب الصفحات بترتيب الطي ويضيف صفحات فارغة إن لم يكن العدد من مضاعفات 4"), s.booklet) { v -> update({ it.copy(booklet = v, duplex = if (v && it.duplex == DuplexMode.OFF) DuplexMode.MANUAL else it.duplex) }) })
        if (s.booklet) {
            addView(stepperRow(c, t("Sheets per signature (0 = one fold)", "أوراق في الملزمة (0 = طية واحدة)"), s.bookletSignatureSheets, 0, 20) { v -> update({ it.copy(bookletSignatureSheets = v) }) })
            addView(sub(c, t("Use signatures (e.g. 4) for thick booklets: each group of sheets is folded and stacked separately.", "استخدم الملازم (مثلًا 4) للكتيبات السميكة: كل مجموعة أوراق تُطوى وتُكدّس منفصلة.")))
        }
    })

    // ---- quality
    addView(sectionCard(t("Quality & tone", "الجودة والتدرج")) {
        addView(sub(c, t("Rendering quality (how this app prepares the page)", "جودة التجهيز (كيف يجهز التطبيق الصفحة)")))
        addView(chips(c, listOf("${t("Draft", "مسودة")} · 150 dpi" to QualityMode.DRAFT, "${t("Normal", "عادي")} · 200 dpi" to QualityMode.NORMAL, "${t("High", "عالٍ")} · 300 dpi" to QualityMode.HIGH), s.quality) { v -> update({ it.copy(quality = v) }) })
        addView(sub(c, t("The printer's own resolution (e.g. 600/1200 dpi) is chosen in Android's print dialog if the print service offers it.", "دقة الطابعة نفسها (مثل 600/1200) تُختار في نافذة الطباعة إن عرضتها خدمة الطباعة.")))
        gap(c)
        addView(sub(c, t("Colour", "اللون")))
        addView(chips(c, listOf(t("Colour", "ملوّن") to ColorMode.COLOR, t("Grayscale", "رمادي") to ColorMode.GRAYSCALE, t("Black & white", "أبيض وأسود") to ColorMode.BLACK_WHITE), s.color) { v -> update({ it.copy(color = v) }) })
        addView(sliderRow(c, t("Contrast", "التباين"), -50, 50, s.contrast, { if (it > 0) "+$it" else "$it" }) { v, done -> update({ it.copy(contrast = v) }, done) })
        addView(sliderRow(c, t("Darkness", "الكثافة (الغمق)"), -50, 50, s.darkness, { if (it > 0) "+$it" else "$it" }) { v, done -> update({ it.copy(darkness = v) }, done) })
        addView(switchRow(c, t("Optimise images (smaller, JPEG)", "تحسين الصور (أصغر، JPEG)"), t("Off = lossless but much larger spool files", "إيقاف = بدون فقد لكن الملفات أكبر بكثير"), s.optimizeImages, s.color != ColorMode.BLACK_WHITE) { v -> update({ it.copy(optimizeImages = v) }) })
    })

    // ---- eco
    addView(sectionCard(t("Toner saving", "توفير الحبر")) {
        addView(card(c) {
            addView(label(c, t("Hardware toner-save: not available from Android", "توفير الحبر في الطابعة: غير متاح من أندرويد"), 14f, true))
            addView(sub(c, t("A driver's own toner-save switch can't be set through Android's print API, and this app never claims to change it. Check Printer → Inspect to see what your printer advertises.", "مفتاح توفير الحبر في تعريف الطابعة لا يمكن ضبطه عبر واجهة الطباعة في أندرويد، والتطبيق لا يدّعي تغييره. افتح الطابعة ← فحص لرؤية ما تعلنه طابعتك.")))
        })
        gap(c)
        addView(label(c, t("Software draft mode (this app)", "وضع المسودة البرمجي (هذا التطبيق)"), 14f, true))
        addView(chips(c, listOf(t("Off", "إيقاف") to EcoMode.OFF, t("Lighten pages", "تفتيح الصفحات") to EcoMode.SOFTWARE_DRAFT), s.eco) { v -> update({ it.copy(eco = v) }) })
        if (s.eco == EcoMode.SOFTWARE_DRAFT) {
            addView(sliderRow(c, t("Strength", "القوة"), 0, 90, s.ecoStrength, { "$it%" }) { v, done -> update({ it.copy(ecoStrength = v) }, done) })
            addView(chips(c, listOf(t("Keep text sharp", "إبقاء النص حادًا") to EcoStyle.KEEP_TEXT_EDGES, t("Lighten everything", "تفتيح كل شيء") to EcoStyle.LIGHTEN_ALL), s.ecoStyle) { v -> update({ it.copy(ecoStyle = v) }) })
            addView(sub(c, t("Pages are rasterised and lightened before sending, so less toner is laid down — but text can look greyer/rougher. Check the preview first. This is a software effect only.", "تُحوَّل الصفحات إلى صور وتُفتَّح قبل الإرسال فيقل الحبر المستخدم — لكن قد يبدو النص أفتح/أخشن. راجع المعاينة أولًا. هذا تأثير برمجي فقط.")))
        }
    })
    addView(spacer(c, 24))
}

// ====================================================================== PRINTER
internal fun MainActivity.printerTab(): View = page {
    val c = this@printerTab
    addView(label(c, t("Printer", "الطابعة"), 22f, true))
    addView(spacer(c, 8))

    addView(sectionCard("HP Laser 107w") {
        addView(sub(c, t("From HP's published specification (not read from your printer):", "من مواصفات HP المنشورة (ليست مقروءة من طابعتك):")))
        listOf(
            t("Page language: SPL only — no PDF, PCL or PostScript. So this app never sends raw PDF to it.", "لغة الصفحة: SPL فقط — لا PDF ولا PCL ولا PostScript. لذلك لا يرسل التطبيق PDF خامًا إليها."),
            t("Mobile printing: Apple AirPrint and Mopria-certified → Android's Mopria/Default print service converts pages to a raster format the printer understands.", "الطباعة من الجوال: AirPrint وMopria → خدمة Mopria/الافتراضية في أندرويد تحول الصفحات لصيغة نقطية تفهمها الطابعة."),
            t("Two-sided: manual only (no duplex unit) → this app provides manual two-sided.", "الوجهان: يدوي فقط (لا وحدة دوبلكس) → يوفر التطبيق الوجهين اليدوي."),
            t("Resolution up to 1200 × 1200 dpi · A4, A5, B5, Oficio, envelopes; custom 76×127 to 216×356 mm (covers Letter).", "الدقة حتى 1200×1200 · A4 وA5 وB5 وOficio والمظاريف؛ مخصص 76×127 إلى 216×356 مم (يشمل Letter)."),
            t("Wi-Fi 802.11 b/g/n. HP's spec lists no toner-save feature, so Economy uses this app's software draft mode.", "واي فاي 802.11 b/g/n. مواصفات HP لا تذكر توفير حبر، لذا الوضع الاقتصادي يستخدم وضع المسودة البرمجي."),
        ).forEach { addView(label(c, "• $it", 13f).apply { setPadding(0, dp(4), 0, 0) }) }
        addView(sub(c, t("Source: HP Laser 107w (4ZB78A) product specifications, hp.com.", "المصدر: مواصفات HP Laser 107w (4ZB78A) على hp.com.")).apply { setPadding(0, dp(6), 0, 0) })
    })

    addView(sectionCard(t("Print services on this phone", "خدمات الطباعة في هذا الهاتف")) {
        val list = Inspector.printServices(c)
        if (list.isEmpty()) addView(label(c, t("None found (or hidden by Android). Open the system print settings to add/enable one.", "لم يُعثر على أي خدمة (أو أخفاها أندرويد). افتح إعدادات الطباعة لإضافة/تفعيل خدمة."), 13f, false, pal.warn))
        list.forEach { addView(label(c, "• ${it.label} — ${if (it.enabled) t("on", "مفعّلة") else t("off / unknown", "متوقفة/غير معروفة")}", 14f)) }
        addView(sub(c, t("Samsung phones include “Samsung Print Service Plugin”/“Default Print Service” (Mopria). Make sure one is ON.", "هواتف سامسونج تتضمن “Samsung Print Service Plugin”/“Default Print Service” (Mopria). تأكد أن إحداها مفعّلة.")).apply { setPadding(0, dp(4), 0, dp(8)) })
        addView(button(c, t("Open system print settings", "فتح إعدادات الطباعة في النظام")) { try { startActivity(Inspector.systemPrintSettingsIntent()) } catch (e: Exception) { toast(t("Can't open settings", "تعذر فتح الإعدادات")) } })
    })

    addView(sectionCard(t("Inspect printer capabilities (IPP)", "فحص إمكانات الطابعة (IPP)")) {
        addView(sub(c, t("Asks your printer over Wi-Fi what it says it supports (document formats, duplex, resolutions, toner level). Read-only: nothing is printed. Phone and printer must be on the same Wi-Fi.", "يسأل طابعتك عبر الواي فاي عمّا تعلن دعمه (صيغ المستندات، الوجهين، الدقة، مستوى الحبر). للقراءة فقط: لا يُطبع شيء. يجب أن يكون الهاتف والطابعة على نفس الشبكة.")))
        gap(c)
        val host = textInput(c, store.ippHost, t("Printer IP address, e.g. 192.168.1.50", "عنوان IP للطابعة، مثل 192.168.1.50")) { store.ippHost = it.trim() }
        val port = textInput(c, "631", "Port", true) {}
        val path = textInput(c, "ipp/print", "Path") {}
        addView(host); gap(c, 6)
        addView(row(c) { addView(port, lp(0, -2, 1f, end = 8, ctx = c)); addView(path, lp(0, -2, 2f)) })
        gap(c)
        val found = col(c)
        foundPrinters.forEach { fp ->
            found.addView(button(c, "${fp.name}  ·  ${fp.host}") { host.setText(fp.host); path.setText(fp.rp); store.ippHost = fp.host }.apply { gravity = android.view.Gravity.START or android.view.Gravity.CENTER_VERTICAL })
            val pdl = fp.txt["pdl"]; if (pdl != null) found.addView(sub(c, "pdl = $pdl"))
        }
        val out = label(c, inspectorResult, 13f)
        addView(row(c) {
            addView(button(c, t("Find printers", "البحث عن طابعات")) {
                discovery?.stop(); foundPrinters.clear()
                discovery = PrinterDiscovery(c, { fp -> runOnUiThread { if (foundPrinters.none { it.host == fp.host }) { foundPrinters.add(fp); if (tab == 4) render() } } }, { e -> runOnUiThread { toast(e) } }).also { it.start() }
                toast(t("Searching… printers appear below.", "جارٍ البحث… ستظهر الطابعات أدناه."))
            }, lp(0, -2, 1f, end = 8, ctx = c))
            addView(button(c, t("Inspect", "فحص"), true, !inspectorBusy) {
                val h = host.text.toString().trim(); if (h.isEmpty()) { toast(t("Enter the printer's IP address first.", "أدخل عنوان IP للطابعة أولًا.")); return@button }
                inspectorBusy = true; inspectorResult = t("Asking the printer…", "جارٍ سؤال الطابعة…"); render()
                val p = port.text.toString().toIntOrNull() ?: 631; val pa = path.text.toString()
                Thread {
                    var text: String
                    try {
                        var resp: IppResponse? = null; var last: Exception? = null
                        for (cand in listOf(pa, "ipp/print", "ipp", "ipp/printer").distinct()) { try { resp = Ipp.query(h, p, cand); break } catch (e: Exception) { last = e } }
                        text = if (resp == null) t("Couldn't reach an IPP service at $h:$p (${last?.message}). The printer may use another path/port, or be on a different network.", "تعذر الوصول إلى خدمة IPP على $h:$p (${last?.message}). قد تستخدم الطابعة مسارًا/منفذًا آخر، أو تكون على شبكة مختلفة.") else describe(Ipp.report(resp))
                    } catch (e: Exception) { text = e.message ?: "error" }
                    runOnUiThread { inspectorBusy = false; inspectorResult = text; if (tab == 4) render() }
                }.start()
            })
        })
        addView(found); addView(out)
    })

    addView(sectionCard(t("Manual two-sided calibration", "معايرة الوجهين اليدوي")) {
        addView(sub(c, t("Prints 2 test sheets so the app learns how YOUR printer outputs and re-feeds paper (back-side rotation and order). Do it once.", "تطبع ورقتي اختبار ليتعلم التطبيق كيف تُخرج طابعتك الورق وتعيد تغذيته (دوران الوجه الخلفي وترتيبه). افعلها مرة واحدة.")))
        addView(button(c, t("Start calibration", "بدء المعايرة"), true) { startCalibration() }, lp(-1, -2, top = 8, ctx = c))
    })

    addView(sectionCard(t("App", "التطبيق")) {
        addView(sub(c, t("Language", "اللغة")))
        addView(chips(c, listOf(t("System", "النظام") to "system", "English" to "en", "العربية" to "ar"), store.language) { v -> store.language = v; recreate() })
        gap(c)
        addView(sub(c, t("Theme", "المظهر")))
        addView(chips(c, listOf(t("System", "النظام") to "system", t("Light", "فاتح") to "light", t("Dark", "داكن") to "dark"), store.theme) { v -> store.theme = v; recreate() })
        gap(c, 12)
        addView(label(c, t("Limits you should know", "حدود يجب أن تعرفها"), 14f, true))
        listOf(
            t("Android's print API doesn't expose desktop-driver options. Settings that need the driver stay in the system dialog.", "واجهة الطباعة في أندرويد لا تكشف خيارات تعريفات سطح المكتب. الخيارات التي تحتاج التعريف تبقى في نافذة النظام."),
            t("Each pass opens Android's print dialog; Android can't pre-select the printer or skip the dialog.", "كل مرحلة تفتح نافذة الطباعة؛ ولا يستطيع أندرويد اختيار الطابعة مسبقًا أو تخطي النافذة."),
            t("“Completed” comes from the print service. It can't tell that paper was jammed or reloaded, so the app asks you to confirm.", "“اكتملت” تأتي من خدمة الطباعة، ولا تعرف بانحشار الورق أو إعادة تحميله، لذلك يطلب التطبيق تأكيدك."),
            t("Pages are rasterised (200 dpi default) before sending; very large or many-page documents take longer.", "تُحوَّل الصفحات إلى صور (200 نقطة/بوصة افتراضيًا) قبل الإرسال؛ والمستندات الكبيرة تستغرق وقتًا أطول."),
        ).forEach { addView(label(c, "• $it", 13f).apply { setPadding(0, dp(4), 0, 0) }) }
        addView(sub(c, "Print Studio 1.0").apply { setPadding(0, dp(8), 0, 0) })
    })
    addView(spacer(c, 24))
}

private fun describe(r: PrinterReport): String {
    val sb = StringBuilder()
    sb.append("✔ ${r.makeModel}  (${t("state", "الحالة")}: ${r.state})\n\n")
    sb.append(t("Accepts PDF directly: ", "تقبل PDF مباشرة: ")).append(if (r.acceptsPdf) t("yes", "نعم") else t("NO — the app never sends raw PDF", "لا — التطبيق لا يرسل PDF خامًا")).append('\n')
    sb.append(t("Raster formats (what Android's service uses): ", "صيغ نقطية (تستخدمها خدمة أندرويد): ")).append(if (r.acceptsRaster) t("yes", "نعم") else t("not advertised", "غير معلنة")).append('\n')
    sb.append(t("Automatic two-sided: ", "وجهان تلقائي: ")).append(if (r.hasAutoDuplex) t("yes (${r.sides.joinToString()})", "نعم (${r.sides.joinToString()})") else t("no → use manual two-sided", "لا ← استخدم الوجهين اليدوي")).append('\n')
    sb.append(t("Draft print quality advertised (IPP): ", "جودة مسودة معلنة (IPP): ")).append(if (r.hasDraftQuality) t("yes — but Android's print API can't select it; use the app's software draft mode", "نعم — لكن واجهة أندرويد لا تتيح اختيارها؛ استخدم وضع المسودة البرمجي") else t("no", "لا")).append("\n\n")
    if (r.formats.isNotEmpty()) sb.append(t("Document formats: ", "صيغ المستندات: ")).append(r.formats.joinToString()).append('\n')
    if (r.resolutions.isNotEmpty()) sb.append(t("Resolutions: ", "الدقة: ")).append(r.resolutions.joinToString()).append('\n')
    if (r.qualities.isNotEmpty()) sb.append(t("Quality levels: ", "مستويات الجودة: ")).append(r.qualities.joinToString()).append('\n')
    if (r.colorModes.isNotEmpty()) sb.append(t("Colour modes: ", "أوضاع اللون: ")).append(r.colorModes.joinToString()).append('\n')
    if (r.media.isNotEmpty()) sb.append(t("Paper: ", "الورق: ")).append(r.media.take(12).joinToString()).append('\n')
    if (r.markers.isNotEmpty()) sb.append(t("Supplies: ", "المستهلكات: ")).append(r.markers.joinToString()).append('\n')
    return sb.toString().trimEnd()
}
