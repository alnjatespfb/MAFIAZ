package app.printstudio.core

import java.io.ByteArrayOutputStream
import java.util.zip.Deflater
import java.util.zip.DeflaterOutputStream

class PixelBuffer(val width: Int, val height: Int, val argb: IntArray)

object ImageFilters {
    private fun luma(p: Int): Int {
        val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
        return (r * 299 + g * 587 + b * 114) / 1000
    }
    private fun clamp(v: Int) = if (v < 0) 0 else if (v > 255) 255 else v

    /** Contrast factor curve identical for each channel. */
    private fun contrastLut(c: Int, darkness: Int): IntArray {
        val cc = c * 2.55
        val f = (259.0 * (cc + 255.0)) / (255.0 * (259.0 - cc))
        val shift = -darkness * 2.55
        return IntArray(256) { clamp((f * (it - 128) + 128 + shift).toInt()) }
    }

    /** Apply colour mode, contrast, darkness and (optionally) software eco lightening. Returns a new buffer. */
    fun apply(src: PixelBuffer, s: PrintSettings): PixelBuffer {
        val w = src.width; val h = src.height
        val lut = contrastLut(s.contrast, s.darkness)
        val out = IntArray(w * h)
        for (i in out.indices) {
            val p = src.argb[i]
            if (s.color == ColorMode.COLOR) {
                out[i] = (0xFF shl 24) or (lut[(p shr 16) and 255] shl 16) or (lut[(p shr 8) and 255] shl 8) or lut[p and 255]
            } else {
                val l = lut[luma(p)]
                out[i] = (0xFF shl 24) or (l shl 16) or (l shl 8) or l
            }
        }
        if (s.eco == EcoMode.SOFTWARE_DRAFT && s.ecoStrength > 0) ecoLighten(out, w, h, s.ecoStrength, s.ecoStyle)
        if (s.color == ColorMode.BLACK_WHITE) {
            for (i in out.indices) {
                val v = if ((out[i] and 255) < 140) 0 else 255
                out[i] = (0xFF shl 24) or (v shl 16) or (v shl 8) or v
            }
        }
        return PixelBuffer(w, h, out)
    }

    /**
     * Software draft: lightens ink. LIGHTEN_ALL maps every pixel toward white.
     * KEEP_TEXT_EDGES only lightens "interior" dark pixels (all 4 neighbours dark), so thin text strokes and
     * outlines stay crisp while solid fills / heavy areas use less toner.
     */
    fun ecoLighten(px: IntArray, w: Int, h: Int, strengthPct: Int, style: EcoStyle) {
        val k = strengthPct.coerceIn(0, 90) / 100.0
        fun lighten(v: Int) = clamp((v + (255 - v) * k).toInt())
        fun mix(p: Int): Int {
            val r = lighten((p shr 16) and 255); val g = lighten((p shr 8) and 255); val b = lighten(p and 255)
            return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
        when (style) {
            EcoStyle.LIGHTEN_ALL -> for (i in px.indices) px[i] = mix(px[i])
            EcoStyle.KEEP_TEXT_EDGES -> {
                val dark = BooleanArray(w * h) { luma(px[it]) < 128 }
                // interior = dark and all four neighbours dark (computed from the original mask)
                for (y in 0 until h) for (x in 0 until w) {
                    val i = y * w + x
                    val interior = dark[i] && x > 0 && y > 0 && x < w - 1 && y < h - 1 &&
                        dark[i - 1] && dark[i + 1] && dark[i - w] && dark[i + w]
                    if (interior) px[i] = mix(px[i])
                    else if (!dark[i]) px[i] = mix(px[i]) // already-light pixels (greys) lighten too; white stays white
                }
            }
        }
    }

    /** Average ink coverage 0..1 (1 = solid black). Used for the honest "estimated coverage" readout. */
    fun inkCoverage(b: PixelBuffer): Double {
        if (b.argb.isEmpty()) return 0.0
        var sum = 0L
        for (p in b.argb) sum += 255 - luma(p)
        return sum.toDouble() / (255.0 * b.argb.size)
    }
}

object BlankDetector {
    /**
     * Conservative: a page is blank only if virtually every pixel is near-white.
     * Faint watermarks, light scans or noise => NOT blank (never silently drops content).
     */
    fun isBlank(b: PixelBuffer, whiteThreshold: Int = 238, maxInkFraction: Double = 0.0004): Boolean {
        if (b.argb.isEmpty()) return false
        var ink = 0
        for (p in b.argb) {
            val l = (((p shr 16) and 255) * 299 + ((p shr 8) and 255) * 587 + (p and 255) * 114) / 1000
            if (l < whiteThreshold) ink++
        }
        return ink.toDouble() / b.argb.size <= maxInkFraction
    }
}

enum class PdfImageKind { JPEG_RGB, FLATE_RGB, FLATE_GRAY, FLATE_MONO }

class PdfImage(val width: Int, val height: Int, val kind: PdfImageKind, val data: ByteArray)

/** Platform-provided JPEG encoder (Bitmap.compress on Android, ImageIO in tests). */
fun interface JpegEncoder { fun encode(b: PixelBuffer, quality: Int): ByteArray }

object ImageEncoder {
    private fun deflate(raw: ByteArray): ByteArray {
        val bos = ByteArrayOutputStream(raw.size / 3 + 64)
        DeflaterOutputStream(bos, Deflater(6)).use { it.write(raw) }
        return bos.toByteArray()
    }

    fun encode(b: PixelBuffer, s: PrintSettings, jpeg: JpegEncoder): PdfImage {
        val w = b.width; val h = b.height
        return when {
            s.color == ColorMode.BLACK_WHITE -> {
                val rowBytes = (w + 7) / 8
                val raw = ByteArray(rowBytes * h)
                for (y in 0 until h) for (x in 0 until w) {
                    if ((b.argb[y * w + x] and 255) >= 128) raw[y * rowBytes + (x shr 3)] = (raw[y * rowBytes + (x shr 3)].toInt() or (0x80 shr (x and 7))).toByte()
                }
                PdfImage(w, h, PdfImageKind.FLATE_MONO, deflate(raw))
            }
            !s.optimizeImages && s.color == ColorMode.GRAYSCALE -> {
                val raw = ByteArray(w * h) { (b.argb[it] and 255).toByte() }
                PdfImage(w, h, PdfImageKind.FLATE_GRAY, deflate(raw))
            }
            !s.optimizeImages -> {
                val raw = ByteArray(w * h * 3)
                for (i in 0 until w * h) {
                    val p = b.argb[i]
                    raw[i * 3] = (p shr 16).toByte(); raw[i * 3 + 1] = (p shr 8).toByte(); raw[i * 3 + 2] = p.toByte()
                }
                PdfImage(w, h, PdfImageKind.FLATE_RGB, deflate(raw))
            }
            else -> PdfImage(w, h, PdfImageKind.JPEG_RGB, jpeg.encode(b, s.quality.jpegQuality))
        }
    }
}
