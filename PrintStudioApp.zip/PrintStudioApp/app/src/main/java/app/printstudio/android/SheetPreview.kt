package app.printstudio.android

import android.content.Context
import android.graphics.*
import android.view.View
import app.printstudio.core.*

/** Draws one planned side exactly as the PDF writer will lay it out (same planner + same geometry). */
class SheetPreview(ctx: Context) : View(ctx) {
    private var plan: JobPlan? = null
    private var side: SideInstance? = null
    private var settings = PrintSettings()
    private var thumbs: Thumbs? = null
    private val filtered = HashMap<Int, Bitmap>()
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    var coverage: Pair<Double, Double>? = null; private set
    var onCoverage: () -> Unit = {}

    fun set(plan: JobPlan?, side: SideInstance?, s: PrintSettings, thumbs: Thumbs?) {
        if (s != settings) { filtered.clear(); coverage = null }
        this.plan = plan; this.side = side; settings = s; this.thumbs = thumbs
        invalidate()
    }

    private fun prepared(page: Int): Bitmap? {
        filtered[page]?.let { return it }
        val raw = thumbs?.peek(page)
        if (raw == null) { thumbs?.load(page, 360) { invalidate() }; return null }
        val px = IntArray(raw.width * raw.height); raw.getPixels(px, 0, raw.width, 0, 0, raw.width, raw.height)
        val src = PixelBuffer(raw.width, raw.height, px)
        val out = ImageFilters.apply(src, settings)
        if (coverage == null) {
            coverage = ImageFilters.inkCoverage(ImageFilters.apply(src, settings.copy(eco = EcoMode.OFF))) to ImageFilters.inkCoverage(out)
            post { onCoverage() }
        }
        return Bitmap.createBitmap(out.argb, out.width, out.height, Bitmap.Config.ARGB_8888).also { filtered[page] = it }
    }

    override fun onDraw(c: Canvas) {
        val p = plan ?: return; val sd = side ?: return
        val sw = p.sheet.widthPt; val sh = p.sheet.heightPt
        val k = minOf((width - 8f) / sw, (height - 8f) / sh).toDouble()
        val ox = (width - sw * k) / 2; val oy = (height - sh * k) / 2
        val sheetRect = RectF(ox.toFloat(), oy.toFloat(), (ox + sw * k).toFloat(), (oy + sh * k).toFloat())
        paint.style = Paint.Style.FILL; paint.color = Color.WHITE; c.drawRect(sheetRect, paint)
        paint.style = Paint.Style.STROKE; paint.color = UI.pal.outline; paint.strokeWidth = 2f; c.drawRect(sheetRect, paint)
        val m = Affine(k, 0.0, 0.0, -k, ox, oy + sh * k).after(Geometry.layoutToPdf(p.layoutW, p.layoutH, sw, sh, sd.rotate180))
        val mat = Matrix().apply { setValues(floatArrayOf(m.a.toFloat(), m.c.toFloat(), m.e.toFloat(), m.b.toFloat(), m.d.toFloat(), m.f.toFloat(), 0f, 0f, 1f)) }
        c.save(); c.concat(mat)
        for (pl in sd.side.placements) {
            c.save()
            if (pl.clip) c.clipRect(pl.slot.x.toFloat(), pl.slot.y.toFloat(), pl.slot.right.toFloat(), pl.slot.bottom.toFloat())
            c.translate(pl.center.first.toFloat(), pl.center.second.toFloat())
            if (pl.rotated90) c.rotate(90f)
            val dst = RectF((-pl.drawW / 2).toFloat(), (-pl.drawH / 2).toFloat(), (pl.drawW / 2).toFloat(), (pl.drawH / 2).toFloat())
            val bmp = prepared(pl.sourcePage)
            if (bmp != null) c.drawBitmap(bmp, null, dst, paint)
            else { paint.style = Paint.Style.FILL; paint.color = 0xFFE4E7EE.toInt(); c.drawRect(dst, paint) }
            c.restore()
            if (pl.border) { paint.style = Paint.Style.STROKE; paint.color = Color.GRAY; paint.strokeWidth = 1f / k.toFloat(); c.drawRect(pl.slot.x.toFloat(), pl.slot.y.toFloat(), pl.slot.right.toFloat(), pl.slot.bottom.toFloat(), paint) }
        }
        c.restore()
    }
}
