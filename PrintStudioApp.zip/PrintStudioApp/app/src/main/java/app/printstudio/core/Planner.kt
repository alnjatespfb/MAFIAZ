package app.printstudio.core

import kotlin.math.max
import kotlin.math.min

/** One printed face. [pages] is slot order (row-major, null = blank). */
data class Side(
    val pages: List<Int?>,
    val placements: List<Placement>,
    val isBack: Boolean,
) { val isBlank get() = pages.all { it == null } }

data class SideInstance(val side: Side, val rotate180: Boolean)

enum class PartKind { SINGLE, AUTO_DUPLEX, FRONTS, BACKS }
data class JobPart(val kind: PartKind, val sides: List<SideInstance>)

enum class PlanWarning {
    BOOKLET_NEEDS_DUPLEX, REVERSE_IGNORED_BOOKLET, ACTUAL_IGNORED_NUP, BLANK_PAGES_ADDED, ODD_SIDE_BLANK_BACK, GUTTER_IGNORED_BOOKLET
}
enum class PlanError { NO_PAGES, RANGE_SYNTAX, RANGE_OUT_OF_RANGE }

data class JobPlan(
    val selection: List<Int>,
    val parts: List<JobPart>,
    val layoutW: Double,
    val layoutH: Double,
    val sheet: SheetSpec,
    val grid: GridChoice,
    val physicalSheets: Int,
    val duplexMode: DuplexMode,
    /** For DuplexMode.AUTO: which paper edge to request from the printer (true = long edge). */
    val autoDuplexLongEdge: Boolean,
    val warnings: List<PlanWarning> = emptyList(),
    val warningDetail: Int = 0,
    val error: PlanError? = null,
    val errorToken: String? = null,
) {
    val layoutLandscape get() = layoutW > layoutH
    val ok get() = error == null
}

object Planner {
    /** Everything needed to know the sheet layout; pure and deterministic. */
    fun plan(
        pageCount: Int,
        pageSize: (Int) -> Pair<Double, Double>,
        s: PrintSettings,
        sheet: SheetSpec,
        blankPages: Set<Int> = emptySet(),
        selected: Set<Int>? = null,
    ): JobPlan {
        val warnings = ArrayList<PlanWarning>()
        var warnDetail = 0
        val sel = when (val r = PageSelection.select(pageCount, s, blankPages, selected)) {
            is RangeResult.Error -> return emptyPlan(sheet, s, if (r.reason == RangeResult.Reason.SYNTAX) PlanError.RANGE_SYNTAX else PlanError.RANGE_OUT_OF_RANGE, r.token)
            is RangeResult.Ok -> r.pages
        }
        if (sel.isEmpty()) return emptyPlan(sheet, s, PlanError.NO_PAGES, null)
        if (s.reverse && s.booklet) warnings.add(PlanWarning.REVERSE_IGNORED_BOOKLET)

        var duplex = s.duplex
        if (s.booklet && duplex == DuplexMode.OFF) { duplex = DuplexMode.MANUAL; warnings.add(PlanWarning.BOOKLET_NEEDS_DUPLEX) }
        val n = if (s.booklet) 2 else s.pagesPerSheet
        if (!s.booklet && n > 1 && (s.scale == ScaleMode.ACTUAL || s.scale == ScaleMode.CUSTOM)) warnings.add(PlanWarning.ACTUAL_IGNORED_NUP)
        if (s.booklet && s.gutterMm > 0) warnings.add(PlanWarning.GUTTER_IGNORED_BOOKLET)

        val (fw, fh) = pageSize(sel.first())
        val marginPt = max(s.marginMm * Layout.MM, sheet.minMarginPt)
        val grid = if (s.booklet) GridChoice(2, 1, true)
        else Layout.chooseGrid(n, fw, fh, sheet.widthPt, sheet.heightPt, s.orientation, marginPt, s.autoRotatePages)
        val longS = max(sheet.widthPt, sheet.heightPt); val shortS = min(sheet.widthPt, sheet.heightPt)
        val lw = if (grid.landscape) longS else shortS
        val lh = if (grid.landscape) shortS else longS
        val gap = if (n > 1) Layout.GUTTER_PT else 0.0
        val rtl = if (s.booklet) s.bookletRtl else s.nUpRtl

        fun makeSide(slots: List<Int?>, isBack: Boolean): Side {
            var m = Margins(marginPt, marginPt, marginPt, marginPt)
            val g = if (s.booklet) 0.0 else s.gutterMm * Layout.MM
            if (g > 0) {
                val edge = when {
                    duplex != DuplexMode.OFF && s.binding == Binding.NOTEPAD && !s.booklet -> 'T'
                    duplex != DuplexMode.OFF && isBack -> if (rtl) 'L' else 'R'
                    else -> if (rtl) 'R' else 'L'
                }
                m = when (edge) {
                    'T' -> m.copy(top = m.top + g)
                    'L' -> m.copy(left = m.left + g)
                    else -> m.copy(right = m.right + g)
                }
            }
            val cells = Layout.cells(lw, lh, grid.cols, grid.rows, m, gap)
            val pl = ArrayList<Placement>()
            slots.forEachIndexed { i, p ->
                if (p != null) {
                    val (pw, ph) = pageSize(p)
                    pl.add(Layout.place(p, pw, ph, cells[i], s, allowRotate = !s.booklet, multi = n > 1 || s.booklet))
                }
            }
            return Side(slots, pl, isBack)
        }

        // ---- logical slot lists, in reading order
        val sheetsSlots: List<Pair<List<Int?>, List<Int?>?>>  // (front, back?)
        if (s.booklet) {
            val chunkSize = if (s.bookletSignatureSheets <= 0) Int.MAX_VALUE else s.bookletSignatureSheets * 4
            val out = ArrayList<Pair<List<Int?>, List<Int?>?>>()
            var added = 0
            for (chunk in sel.chunked(min(chunkSize, max(sel.size, 1)))) {
                val m = ((chunk.size + 3) / 4) * 4
                added += m - chunk.size
                val padded: List<Int?> = chunk + List(m - chunk.size) { null }
                for (i in 0 until m / 4) {
                    var front = listOf(padded[m - 1 - 2 * i], padded[2 * i])
                    var back = listOf(padded[2 * i + 1], padded[m - 2 - 2 * i])
                    if (rtl) { front = front.reversed(); back = back.reversed() }
                    out.add(front to back)
                }
            }
            if (added > 0) { warnings.add(PlanWarning.BLANK_PAGES_ADDED); warnDetail = added }
            sheetsSlots = out
        } else {
            val sides = sel.chunked(n).map { ch ->
                val slots: MutableList<Int?> = ch.toMutableList<Int?>()
                while (slots.size < n) slots.add(null)
                if (s.nUpRtl && grid.cols > 1) slots.chunked(grid.cols).flatMap { it.reversed() } else slots.toList()
            }
            sheetsSlots = if (duplex == DuplexMode.OFF) sides.map { it to null }
            else {
                if (sides.size % 2 == 1) warnings.add(PlanWarning.ODD_SIDE_BLANK_BACK)
                sides.chunked(2).map { it[0] to (it.getOrNull(1) ?: List<Int?>(n) { null }) }
            }
        }

        // ---- copies expansion over sheets
        val copies = s.copies.coerceAtLeast(1)
        val expanded: List<Pair<List<Int?>, List<Int?>?>> =
            if (s.collate) (1..copies).flatMap { sheetsSlots } else sheetsSlots.flatMap { sh -> List(copies) { sh } }

        // ---- flip geometry
        val layoutRotatedInFeed = grid.landscape
        val bookStyle = s.booklet || s.binding == Binding.BOOK
        val needVertical = if (layoutRotatedInFeed) !bookStyle else bookStyle   // paper axis the sheet must turn around
        val reloadVertical = s.reloadFlip == ReloadFlip.LONG_EDGE
        val backRot = needVertical != reloadVertical

        val fronts = expanded.map { SideInstance(makeSide(it.first, false), false) }
        val parts: List<JobPart> = when (duplex) {
            DuplexMode.OFF -> listOf(JobPart(PartKind.SINGLE, fronts))
            DuplexMode.AUTO -> {
                val flat = ArrayList<SideInstance>()
                expanded.forEachIndexed { idx, sh ->
                    flat.add(fronts[idx])
                    val last = idx == expanded.lastIndex
                    val back = makeSide(sh.second!!, true)
                    if (!(last && back.isBlank)) flat.add(SideInstance(back, false))
                }
                listOf(JobPart(PartKind.AUTO_DUPLEX, flat))
            }
            DuplexMode.MANUAL -> {
                val backs = expanded.map { SideInstance(makeSide(it.second!!, true), backRot) }
                listOf(JobPart(PartKind.FRONTS, fronts), JobPart(PartKind.BACKS, if (s.reverseSecondJob) backs.reversed() else backs))
            }
        }
        return JobPlan(sel, parts, lw, lh, sheet, grid, expanded.size, duplex, needVertical, warnings, warnDetail)
    }

    private fun emptyPlan(sheet: SheetSpec, s: PrintSettings, e: PlanError, token: String?) = JobPlan(
        emptyList(), emptyList(), sheet.widthPt, sheet.heightPt, sheet, GridChoice(1, 1, false), 0, s.duplex, true,
        error = e, errorToken = token)

    /** Paper size (portrait dims) used to seed the system print dialog. */
    fun seedSheet(s: PrintSettings): SheetSpec = SheetSpec(
        min(s.paper.widthPt, s.paper.heightPt), max(s.paper.widthPt, s.paper.heightPt))
}
