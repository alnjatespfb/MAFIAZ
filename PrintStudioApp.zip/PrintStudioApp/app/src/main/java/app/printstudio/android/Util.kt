package app.printstudio.android

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

/** Tiny bilingual helper: every user-visible string is given in English and Arabic at the call site. */
object Lang {
    @Volatile var isAr = false
}
fun t(en: String, ar: String) = if (Lang.isAr) ar else en

class Pal(
    val dark: Boolean, val bg: Int, val surface: Int, val card: Int, val text: Int, val sub: Int,
    val accent: Int, val onAccent: Int, val outline: Int, val danger: Int, val ok: Int, val warn: Int,
) {
    companion object {
        val light = Pal(false, 0xFFF4F6FA.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0xFF14181F.toInt(), 0xFF566074.toInt(),
            0xFF1457D9.toInt(), Color.WHITE, 0xFFD3D9E4.toInt(), 0xFFB3261E.toInt(), 0xFF1B7F3B.toInt(), 0xFF8A5A00.toInt())
        val dark = Pal(true, 0xFF0E1116.toInt(), 0xFF171B22.toInt(), 0xFF1C212A.toInt(), 0xFFEDF0F5.toInt(), 0xFFA3ADBF.toInt(),
            0xFF7AA7FF.toInt(), 0xFF0A1220.toInt(), 0xFF38404E.toInt(), 0xFFFF8A80.toInt(), 0xFF6FD08C.toInt(), 0xFFF0B84A.toInt())
    }
}

object UI {
    lateinit var pal: Pal
}

fun Context.dp(v: Int): Int = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()
fun Context.dpf(v: Float): Float = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics)

fun roundRect(ctx: Context, fill: Int, radiusDp: Int = 14, stroke: Int = 0, strokeDp: Int = 1): GradientDrawable =
    GradientDrawable().apply {
        setColor(fill); cornerRadius = ctx.dpf(radiusDp.toFloat())
        if (stroke != 0) setStroke(ctx.dp(strokeDp), stroke)
    }

fun withRipple(ctx: Context, base: GradientDrawable): RippleDrawable =
    RippleDrawable(ColorStateList.valueOf(if (UI.pal.dark) 0x33FFFFFF else 0x22000000), base, null)

fun LinearLayout.add(v: View, lp: LinearLayout.LayoutParams? = null): View { addView(v, lp ?: LinearLayout.LayoutParams(-1, -2)); return v }

fun lp(w: Int = -1, h: Int = -2, weight: Float = 0f, top: Int = 0, bottom: Int = 0, start: Int = 0, end: Int = 0, ctx: Context? = null): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(w, h, weight)
    if (ctx != null) { p.topMargin = ctx.dp(top); p.bottomMargin = ctx.dp(bottom); p.marginStart = ctx.dp(start); p.marginEnd = ctx.dp(end) }
    return p
}

fun col(ctx: Context, pad: Int = 0, block: LinearLayout.() -> Unit = {}): LinearLayout =
    LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; if (pad > 0) setPadding(ctx.dp(pad), ctx.dp(pad), ctx.dp(pad), ctx.dp(pad)); block() }

fun row(ctx: Context, block: LinearLayout.() -> Unit = {}): LinearLayout =
    LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; block() }

fun label(ctx: Context, s: CharSequence, sizeSp: Float = 15f, bold: Boolean = false, color: Int = UI.pal.text): TextView =
    TextView(ctx).apply {
        text = s; setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp); setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        textAlignment = View.TEXT_ALIGNMENT_VIEW_START
    }

fun sub(ctx: Context, s: CharSequence) = label(ctx, s, 13f, false, UI.pal.sub)

fun card(ctx: Context, block: LinearLayout.() -> Unit): LinearLayout = col(ctx, 14) {
    background = roundRect(ctx, UI.pal.card, 16, UI.pal.outline)
    block()
}

fun heading(ctx: Context, s: String) = label(ctx, s, 17f, true).apply {
    setPadding(0, ctx.dp(6), 0, ctx.dp(8))
    accessibilityHeading()
}

private fun View.accessibilityHeading() { if (android.os.Build.VERSION.SDK_INT >= 28) isAccessibilityHeading = true }

fun button(ctx: Context, text: String, primary: Boolean = false, enabled: Boolean = true, onClick: () -> Unit): Button =
    Button(ctx).apply {
        this.text = text; isAllCaps = false; setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        minHeight = ctx.dp(48); minimumHeight = ctx.dp(48)
        setPadding(ctx.dp(16), 0, ctx.dp(16), 0)
        stateListAnimator = null
        val fill = if (primary) UI.pal.accent else UI.pal.surface
        setTextColor(if (primary) UI.pal.onAccent else UI.pal.accent)
        background = withRipple(ctx, roundRect(ctx, fill, 24, if (primary) 0 else UI.pal.outline))
        isEnabled = enabled; alpha = if (enabled) 1f else 0.45f
        setOnClickListener { onClick() }
    }

/** Wrapping chip row (single choice). */
fun <T> chips(ctx: Context, options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit): FlowLayout =
    FlowLayout(ctx).apply {
        options.forEach { (name, v) ->
            val on = v == selected
            addView(TextView(ctx).apply {
                text = name; setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f); gravity = Gravity.CENTER
                minHeight = ctx.dp(44); minimumHeight = ctx.dp(44)
                setPadding(ctx.dp(14), 0, ctx.dp(14), 0)
                setTextColor(if (on) UI.pal.onAccent else UI.pal.text)
                background = withRipple(ctx, roundRect(ctx, if (on) UI.pal.accent else UI.pal.surface, 22, if (on) 0 else UI.pal.outline))
                isClickable = true; isFocusable = true
                contentDescription = name + if (on) t(", selected", "، محدد") else ""
                setOnClickListener { if (!on) onSelect(v) }
            })
        }
    }

fun switchRow(ctx: Context, title: String, hint: String?, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit): View =
    row(ctx) {
        minimumHeight = ctx.dp(52)
        val texts = col(ctx) {
            addView(label(ctx, title))
            if (hint != null) addView(sub(ctx, hint))
        }
        addView(texts, lp(0, -2, 1f))
        addView(Switch(ctx).apply {
            isChecked = checked; isEnabled = enabled
            contentDescription = title
            setOnCheckedChangeListener { _, v -> onChange(v) }
        })
        alpha = if (enabled) 1f else 0.5f
    }

fun sliderRow(ctx: Context, title: String, min: Int, max: Int, value: Int, fmt: (Int) -> String, onChange: (Int, Boolean) -> Unit): View =
    col(ctx) {
        val valueLabel = label(ctx, fmt(value), 14f, true, UI.pal.accent)
        addView(row(ctx) {
            addView(label(ctx, title), lp(0, -2, 1f)); addView(valueLabel)
        })
        addView(SeekBar(ctx).apply {
            this.max = max - min; progress = value - min
            minimumHeight = ctx.dp(44)
            contentDescription = title
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { valueLabel.text = fmt(p + min); if (fromUser) onChange(p + min, false) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { onChange(progress + min, true) }
            })
        })
    }

fun stepperRow(ctx: Context, title: String, value: Int, min: Int, max: Int, onChange: (Int) -> Unit): View = row(ctx) {
    minimumHeight = ctx.dp(52)
    addView(label(ctx, title), lp(0, -2, 1f))
    fun b(sym: String, desc: String, d: Int) = button(ctx, sym) { onChange((value + d).coerceIn(min, max)) }.apply {
        contentDescription = desc; minWidth = ctx.dp(48); minimumWidth = ctx.dp(48); setPadding(0, 0, 0, 0)
    }
    addView(b("−", t("Decrease", "إنقاص"), -1), LinearLayout.LayoutParams(ctx.dp(48), ctx.dp(48)))
    addView(label(ctx, value.toString(), 17f, true).apply { gravity = Gravity.CENTER; minWidth = ctx.dp(44) })
    addView(b("+", t("Increase", "زيادة"), 1), LinearLayout.LayoutParams(ctx.dp(48), ctx.dp(48)))
}

fun textInput(ctx: Context, value: String, hint: String, numeric: Boolean = false, onText: (String) -> Unit): EditText =
    EditText(ctx).apply {
        setText(value); this.hint = hint; setTextColor(UI.pal.text); setHintTextColor(UI.pal.sub)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f); setSingleLine()
        inputType = if (numeric) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT
        minHeight = ctx.dp(48)
        setPadding(ctx.dp(12), 0, ctx.dp(12), 0)
        background = roundRect(ctx, UI.pal.surface, 12, UI.pal.outline)
        contentDescription = hint
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { onText(s?.toString() ?: "") }
        })
    }

fun spacer(ctx: Context, h: Int) = View(ctx).apply { layoutParams = LinearLayout.LayoutParams(-1, ctx.dp(h)) }

/** Left-to-right (or right-to-left in RTL) wrapping layout. */
class FlowLayout(ctx: Context) : ViewGroup(ctx) {
    private val gap = ctx.dp(8)
    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val maxW = MeasureSpec.getSize(wSpec) - paddingLeft - paddingRight
        var x = 0; var y = 0; var lineH = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i); if (c.visibility == GONE) continue
            c.measure(MeasureSpec.makeMeasureSpec(maxW, MeasureSpec.AT_MOST), MeasureSpec.UNSPECIFIED)
            if (x > 0 && x + c.measuredWidth > maxW) { x = 0; y += lineH + gap; lineH = 0 }
            x += c.measuredWidth + gap; lineH = maxOf(lineH, c.measuredHeight)
        }
        setMeasuredDimension(MeasureSpec.getSize(wSpec), y + lineH + paddingTop + paddingBottom)
    }
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val rtl = layoutDirection == LAYOUT_DIRECTION_RTL
        val maxW = r - l - paddingLeft - paddingRight
        var x = 0; var y = paddingTop; var lineH = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i); if (c.visibility == GONE) continue
            if (x > 0 && x + c.measuredWidth > maxW) { x = 0; y += lineH + gap; lineH = 0 }
            val left = if (rtl) paddingLeft + maxW - x - c.measuredWidth else paddingLeft + x
            c.layout(left, y, left + c.measuredWidth, y + c.measuredHeight)
            x += c.measuredWidth + gap; lineH = maxOf(lineH, c.measuredHeight)
        }
    }
}
