package app.printstudio.core

import java.io.OutputStream
import java.util.Locale

/** Minimal streaming PDF 1.4 writer: constant memory, images shared across pages (copies cost nothing extra). */
class PdfStreamWriter(private val raw: OutputStream) {
    private var pos = 0L
    private val offsets = ArrayList<Long>()      // index = objNum-1
    private val pageObjs = ArrayList<Int>()
    private var finished = false

    private fun write(s: String) = write(s.toByteArray(Charsets.ISO_8859_1))
    private fun write(b: ByteArray) { raw.write(b); pos += b.size }

    private fun newObj(): Int { offsets.add(pos); return offsets.size }
    private fun reserve(): Int { offsets.add(-1); return offsets.size }
    private fun begin(n: Int) { offsets[n - 1] = pos; write("$n 0 obj\n") }

    private val pagesObj: Int

    init {
        write("%PDF-1.4\n%âãÏÓ\n")
        reserve() // 1 = catalog
        pagesObj = reserve() // 2 = pages
    }

    private fun num(d: Double) = String.format(Locale.US, "%.3f", d).trimEnd('0').trimEnd('.').ifEmpty { "0" }

    fun addImage(img: PdfImage): Int {
        val n = newObj().also { write("$it 0 obj\n") }
        val (cs, bpc, filter) = when (img.kind) {
            PdfImageKind.JPEG_RGB -> Triple("/DeviceRGB", 8, "/DCTDecode")
            PdfImageKind.FLATE_RGB -> Triple("/DeviceRGB", 8, "/FlateDecode")
            PdfImageKind.FLATE_GRAY -> Triple("/DeviceGray", 8, "/FlateDecode")
            PdfImageKind.FLATE_MONO -> Triple("/DeviceGray", 1, "/FlateDecode")
        }
        write("<< /Type /XObject /Subtype /Image /Width ${img.width} /Height ${img.height} /ColorSpace $cs " +
            "/BitsPerComponent $bpc /Filter $filter /Length ${img.data.size} >>\nstream\n")
        write(img.data); write("\nendstream\nendobj\n")
        return n
    }

    /** [content] is the page content stream; [xobjects] maps resource name -> image object. */
    fun addPage(widthPt: Double, heightPt: Double, content: String, xobjects: Map<String, Int>) {
        val c = newObj().also { write("$it 0 obj\n") }
        val bytes = content.toByteArray(Charsets.ISO_8859_1)
        write("<< /Length ${bytes.size} >>\nstream\n"); write(bytes); write("\nendstream\nendobj\n")
        val p = newObj().also { write("$it 0 obj\n") }
        val xo = xobjects.entries.joinToString(" ") { "/${it.key} ${it.value} 0 R" }
        write("<< /Type /Page /Parent $pagesObj 0 R /MediaBox [0 0 ${num(widthPt)} ${num(heightPt)}] " +
            "/Resources << /XObject << $xo >> >> /Contents $c 0 R >>\nendobj\n")
        pageObjs.add(p)
    }

    fun finish() {
        if (finished) return
        finished = true
        begin(pagesObj)
        write("<< /Type /Pages /Count ${pageObjs.size} /Kids [${pageObjs.joinToString(" ") { "$it 0 R" }}] >>\nendobj\n")
        begin(1); write("<< /Type /Catalog /Pages $pagesObj 0 R >>\nendobj\n")
        val xref = pos
        write("xref\n0 ${offsets.size + 1}\n0000000000 65535 f \n")
        for (o in offsets) write(String.format(Locale.US, "%010d 00000 n \n", o))
        write("trailer\n<< /Size ${offsets.size + 1} /Root 1 0 R >>\nstartxref\n$xref\n%%EOF\n")
        raw.flush()
    }

    companion object {
        fun n(d: Double) = String.format(Locale.US, "%.4f", d)
    }
}

/** Supplies page pixels. Android: PdfRenderer / BitmapFactory. Tests: synthetic. */
interface PageImageProvider {
    /** Natural page size in points (upright). */
    fun pageSize(page: Int): Pair<Double, Double>
    /** Render the upright page to a w x h pixel buffer (white background). */
    fun render(page: Int, widthPx: Int, heightPx: Int): PixelBuffer
}

class CancelledException : RuntimeException("cancelled")

/** Renders a JobPart's sides to a PDF stream. */
class PartPdfWriter(
    private val plan: JobPlan,
    private val s: PrintSettings,
    private val provider: PageImageProvider,
    private val jpeg: JpegEncoder,
    private val maxDpi: Int = 0,
) {
    val dpi: Int get() = if (maxDpi > 0) minOf(s.quality.dpi, maxDpi) else s.quality.dpi

    /** Writes sides[outputIndexes] (0-based, in order). */
    fun write(
        part: JobPart, outputIndexes: List<Int>, out: OutputStream,
        isCancelled: () -> Boolean = { false }, progress: (Int, Int) -> Unit = { _, _ -> },
    ) {
        val w = PdfStreamWriter(out)
        val imageCache = HashMap<String, Int>()
        val sheetW = plan.sheet.widthPt; val sheetH = plan.sheet.heightPt
        outputIndexes.forEachIndexed { n, idx ->
            if (isCancelled()) throw CancelledException()
            val inst = part.sides[idx]
            val toPdf = Geometry.layoutToPdf(plan.layoutW, plan.layoutH, sheetW, sheetH, inst.rotate180)
            val sb = StringBuilder()
            val xo = LinkedHashMap<String, Int>()
            for (pl in inst.side.placements) {
                if (isCancelled()) throw CancelledException()
                val wpx = (pl.drawW / 72.0 * dpi).toInt().coerceAtLeast(8)
                val hpx = (pl.drawH / 72.0 * dpi).toInt().coerceAtLeast(8)
                val key = "${pl.sourcePage}:$wpx:$hpx"
                val obj = imageCache.getOrPut(key) {
                    val px = ImageFilters.apply(provider.render(pl.sourcePage, wpx, hpx), s)
                    w.addImage(ImageEncoder.encode(px, s, jpeg))
                }
                val name = "Im$obj"
                xo[name] = obj
                sb.append("q\n")
                val slotPdf = toPdf.mapRect(pl.slot)
                if (pl.clip) sb.append("${PdfStreamWriter.n(slotPdf.x)} ${PdfStreamWriter.n(slotPdf.y)} ${PdfStreamWriter.n(slotPdf.w)} ${PdfStreamWriter.n(slotPdf.h)} re W n\n")
                val m = toPdf.after(Geometry.imageToLayout(pl.center.first, pl.center.second, pl.drawW, pl.drawH, pl.rotated90))
                sb.append("${PdfStreamWriter.n(m.a)} ${PdfStreamWriter.n(m.b)} ${PdfStreamWriter.n(m.c)} ${PdfStreamWriter.n(m.d)} ${PdfStreamWriter.n(m.e)} ${PdfStreamWriter.n(m.f)} cm\n/$name Do\nQ\n")
                if (pl.border) {
                    sb.append("q 0.5 w 0.4 G ${PdfStreamWriter.n(slotPdf.x)} ${PdfStreamWriter.n(slotPdf.y)} ${PdfStreamWriter.n(slotPdf.w)} ${PdfStreamWriter.n(slotPdf.h)} re S Q\n")
                }
            }
            w.addPage(sheetW, sheetH, sb.toString(), xo)
            progress(n + 1, outputIndexes.size)
        }
        w.finish()
    }
}
