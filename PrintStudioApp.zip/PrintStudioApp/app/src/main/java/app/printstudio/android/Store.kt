package app.printstudio.android

import android.content.Context
import android.content.SharedPreferences
import app.printstudio.core.PrintSettings
import org.json.JSONArray
import org.json.JSONObject

class Store(ctx: Context) {
    private val sp: SharedPreferences = ctx.applicationContext.getSharedPreferences("printstudio", Context.MODE_PRIVATE)

    var settings: PrintSettings
        get() {
            val m = HashMap<String, String>()
            for ((k, v) in sp.all) if (k.startsWith("s.") && v is String) m[k.substring(2)] = v
            return PrintSettings.fromMap(m)
        }
        set(v) { val e = sp.edit(); for ((k, x) in v.toMap()) e.putString("s.$k", x); e.apply() }

    var language: String get() = sp.getString("lang", "system") ?: "system"; set(v) { sp.edit().putString("lang", v).apply() }
    var theme: String get() = sp.getString("theme", "system") ?: "system"; set(v) { sp.edit().putString("theme", v).apply() }
    var lastDocId: String? get() = sp.getString("lastDoc", null); set(v) { sp.edit().putString("lastDoc", v).apply() }
    var ippHost: String get() = sp.getString("ippHost", "") ?: ""; set(v) { sp.edit().putString("ippHost", v).apply() }
    var calibrated: Boolean get() = sp.getBoolean("calibrated", false); set(v) { sp.edit().putBoolean("calibrated", v).apply() }

    // ---- job records
    fun loadJobs(): MutableList<JobRecord> {
        val s = sp.getString("jobs", null) ?: return ArrayList()
        return try {
            val a = JSONArray(s); (0 until a.length()).map { JobRecord.fromJson(a.getJSONObject(it)) }.toMutableList()
        } catch (e: Exception) { ArrayList() }
    }
    fun saveJobs(jobs: List<JobRecord>) {
        val a = JSONArray(); jobs.takeLast(50).forEach { a.put(it.toJson()) }
        sp.edit().putString("jobs", a.toString()).apply()
    }
}

enum class PartState { PENDING, SUBMITTING, ACTIVE, DONE, FAILED, CANCELED, UNCERTAIN }

class PartRecord(
    var label: String,
    var state: PartState = PartState.PENDING,
    var systemJobId: String? = null,
    var detail: String = "",
    var sides: Int = 0,
    var startedOnce: Boolean = false,
) {
    fun toJson() = JSONObject().put("label", label).put("state", state.name).put("sys", systemJobId ?: JSONObject.NULL)
        .put("detail", detail).put("sides", sides).put("started", startedOnce)
    companion object {
        fun fromJson(o: JSONObject) = PartRecord(o.getString("label"), PartState.valueOf(o.getString("state")),
            if (o.isNull("sys")) null else o.getString("sys"), o.optString("detail"), o.optInt("sides"), o.optBoolean("started"))
    }
}

class JobRecord(
    val id: String, val name: String, val createdAt: Long, val docId: String, val settings: Map<String, String>,
    val selected: List<Int>?, val blank: List<Int>, val calibration: Boolean,
    val parts: MutableList<PartRecord>, var warning: String = "", var firstSheetMils: String = "",
    var calibrationDone: Boolean = false,
) {
    fun toJson() = JSONObject().put("id", id).put("name", name).put("created", createdAt).put("doc", docId)
        .put("settings", JSONObject(settings)).put("selected", selected?.let { JSONArray(it) } ?: JSONObject.NULL)
        .put("blank", JSONArray(blank)).put("cal", calibration).put("parts", JSONArray(parts.map { it.toJson() }))
        .put("warning", warning).put("sheet", firstSheetMils).put("calDone", calibrationDone)

    companion object {
        fun fromJson(o: JSONObject): JobRecord {
            val sm = o.getJSONObject("settings"); val m = HashMap<String, String>()
            sm.keys().forEach { m[it] = sm.getString(it) }
            val sel = if (o.isNull("selected")) null else o.getJSONArray("selected").let { a -> (0 until a.length()).map { a.getInt(it) } }
            val bl = o.getJSONArray("blank").let { a -> (0 until a.length()).map { a.getInt(it) } }
            val ps = o.getJSONArray("parts").let { a -> (0 until a.length()).map { PartRecord.fromJson(a.getJSONObject(it)) } }
            return JobRecord(o.getString("id"), o.getString("name"), o.getLong("created"), o.getString("doc"), m, sel, bl,
                o.optBoolean("cal"), ps.toMutableList(), o.optString("warning"), o.optString("sheet"), o.optBoolean("calDone"))
        }
    }
}
