package app.printstudio.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.Configuration
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import app.printstudio.android.*
import app.printstudio.core.*
import java.util.Locale

class MainActivity : Activity() {
    internal lateinit var store: Store
    internal lateinit var jobs: JobManager
    internal lateinit var pal: Pal
    internal var doc: LoadedDocument? = null
    internal var thumbs: Thumbs? = null
    internal var settings = PrintSettings()
    internal val selected = LinkedHashSet<Int>()
    internal var tab = 0
    internal var previewIdx = 0
    internal var discovery: PrinterDiscovery? = null
    internal var inspectorResult = ""
    internal var inspectorBusy = false
    internal val foundPrinters = ArrayList<FoundPrinter>()
    private lateinit var content: FrameLayout
    private lateinit var tabBar: LinearLayout
    private var resumed = false
    private var pendingFlip: JobRecord? = null
    private var pendingCalibration: JobRecord? = null
    private var preview: SheetPreview? = null
    private var gridAdapter: PagesAdapter? = null
    private val REQ_PICK = 41

    override fun attachBaseContext(base: Context) {
        val lang = Store(base).language
        val loc = when (lang) { "ar" -> Locale("ar"); "en" -> Locale.ENGLISH; else -> null }
        if (loc == null) { super.attachBaseContext(base); return }
        val cfg = Configuration(base.resources.configuration); cfg.setLocale(loc); cfg.setLayoutDirection(loc)
        super.attachBaseContext(base.createConfigurationContext(cfg))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        store = Store(this)
        val nightSystem = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val dark = when (store.theme) { "dark" -> true; "light" -> false; else -> nightSystem }
        setTheme(if (dark) android.R.style.Theme_DeviceDefault_NoActionBar else android.R.style.Theme_DeviceDefault_Light_NoActionBar)
        super.onCreate(savedInstanceState)
        pal = if (dark) Pal.dark else Pal.light; UI.pal = pal
        Lang.isAr = resources.configuration.locales[0].language == "ar"
        @Suppress("DEPRECATION")
        window.apply {
            statusBarColor = pal.bg; navigationBarColor = pal.bg
            decorView.systemUiVisibility = if (dark) 0 else (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        }
        settings = store.settings
        jobs = JobManager(applicationContext, store)
        jobs.host = this
        jobs.onChange = { runOnUiThread { if (tab == 2) render() else refreshBadge() } }
        jobs.onFlipNeeded = { j -> runOnUiThread { if (resumed) showFlipDialog(j) else pendingFlip = j } }
        jobs.onCalibrationReady = { j -> runOnUiThread { if (resumed) showCalibrationResult(j) else pendingCalibration = j } }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(pal.bg); fitsSystemWindows = true }
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        tabBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(pal.surface); elevation = dpf(8f) }
        root.addView(tabBar, LinearLayout.LayoutParams(-1, dp(60)))
        setContentView(root)

        store.lastDocId?.let { id -> LoadedDocument.load(this, id)?.let { attach(it) } }
        render()
    }

    override fun onResume() {
        super.onResume(); resumed = true; jobs.host = this
        pendingFlip?.let { pendingFlip = null; showFlipDialog(it) }
        pendingCalibration?.let { pendingCalibration = null; showCalibrationResult(it) }
    }
    override fun onPause() { super.onPause(); resumed = false }
    override fun onDestroy() { super.onDestroy(); if (jobs.host === this) jobs.host = null; if (isFinishing) thumbs?.close() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (tab != 0) { tab = 0; render() } else super.onBackPressed() }

    // ------------------------------------------------------------------ state helpers

    internal fun update(block: (PrintSettings) -> PrintSettings, rebuild: Boolean = true) {
        val n = block(settings)
        settings = n.copy(preset = Presets.detect(n)); store.settings = settings
        if (rebuild) render() else refreshPreview()
    }

    internal fun planSettings() = settings
    internal fun selectedForPlan(): Set<Int>? = if (settings.selectedOnly) selected else null

    internal fun currentPlan(): JobPlan? = doc?.let {
        Planner.plan(it.pageCount, it::pageSize, settings, Planner.seedSheet(settings), it.blank, selectedForPlan())
    }

    private fun attach(d: LoadedDocument) {
        thumbs?.close()
        doc = d; selected.clear(); selected.addAll(1..d.pageCount); previewIdx = 0
        thumbs = Thumbs(this, d).also { th -> th.scanBlank { if (tab == 1) gridAdapter?.notifyDataSetChanged() else if (tab == 0) refreshPreview() } }
        store.lastDocId = d.id
        if (settings.selectedOnly) update({ it.copy(selectedOnly = false) }, false)
    }

    internal fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ------------------------------------------------------------------ import
    internal fun pickFiles() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/pdf", "image/*"))
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        @Suppress("DEPRECATION") startActivityForResult(i, REQ_PICK)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<android.net.Uri>()
        data.clipData?.let { cd -> for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri) }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }
        if (uris.isEmpty()) return
        val dlg = AlertDialog.Builder(this).setMessage(t("Importing…", "جارٍ الاستيراد…")).setCancelable(false).show()
        Thread {
            val res = try { LoadedDocument.import(applicationContext, uris) } catch (e: ImportException) { e } catch (e: Exception) { e }
            runOnUiThread {
                dlg.dismiss()
                when (res) {
                    is LoadedDocument -> { attach(res); tab = 0; render() }
                    is ImportException -> toast(when (res.kind) {
                        ImportException.Kind.PASSWORD -> t("This PDF is password-protected. Remove the password first.", "ملف PDF محمي بكلمة مرور. أزل كلمة المرور أولًا.")
                        ImportException.Kind.CORRUPT -> t("The file could not be read (damaged PDF?).", "تعذرت قراءة الملف (ربما تالف).")
                        ImportException.Kind.UNSUPPORTED -> t("Unsupported file type.", "نوع ملف غير مدعوم.")
                        ImportException.Kind.EMPTY -> t("The document has no pages.", "المستند لا يحتوي على صفحات.")
                    })
                    else -> toast(t("Import failed: ", "فشل الاستيراد: ") + (res as Exception).message)
                }
            }
        }.start()
    }

    // ------------------------------------------------------------------ chrome
    internal fun render() {
        val sv = content.getChildAt(0) as? ScrollView
        val y = sv?.scrollY ?: 0
        content.removeAllViews(); preview = null; gridAdapter = null
        if (tab != 4) { discovery?.stop(); discovery = null }
        val v: View = when (tab) { 0 -> printTab(); 1 -> pagesTab(); 2 -> queueTab(); 3 -> optionsTab(); else -> printerTab() }
        content.addView(v, FrameLayout.LayoutParams(-1, -1))
        if (v is ScrollView) v.post { v.scrollTo(0, y) }
        buildTabs()
    }

    private fun buildTabs() {
        tabBar.removeAllViews()
        val names = listOf(t("Print", "طباعة"), t("Pages", "الصفحات"), t("Queue", "الطابور"), t("Options", "الخيارات"), t("Printer", "الطابعة"))
        val glyph = listOf("🖨", "▦", "☰", "⚙", "ⓘ")
        names.forEachIndexed { i, n ->
            val on = i == tab
            val badge = if (i == 2 && jobs.hasActive()) " •" else ""
            tabBar.addView(TextView(this).apply {
                text = "${glyph[i]}\n$n$badge"; gravity = Gravity.CENTER; textSize = 11f
                setTextColor(if (on) pal.accent else pal.sub)
                if (on) setTypeface(typeface, android.graphics.Typeface.BOLD)
                contentDescription = n + if (on) t(", selected", "، محدد") else ""
                setBackgroundColor(if (on) (if (pal.dark) 0x1A7AA7FF else 0x141457D9) else Color.TRANSPARENT)
                setOnClickListener { if (tab != i) { tab = i; render() } }
            }, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }
    private fun refreshBadge() = buildTabs()

    internal fun page(block: LinearLayout.() -> Unit): ScrollView {
        val inner = col(this, 16) { block() }
        return ScrollView(this).apply { isFillViewport = false; addView(inner, ViewGroup.LayoutParams(-1, -2)); clipToPadding = false }
    }

    // ------------------------------------------------------------------ PRINT TAB
    private fun warningText(p: JobPlan): List<String> = p.warnings.map {
        when (it) {
            PlanWarning.BOOKLET_NEEDS_DUPLEX -> t("Booklets need two-sided printing, so manual two-sided was switched on.", "الكتيّب يحتاج طباعة وجهين، لذا تم تفعيل الوجهين اليدوي.")
            PlanWarning.REVERSE_IGNORED_BOOKLET -> t("“Reverse order” is ignored in booklet mode.", "“عكس الترتيب” مُتجاهَل في وضع الكتيّب.")
            PlanWarning.ACTUAL_IGNORED_NUP -> t("Actual size / custom scale is ignored when several pages share a sheet (fit is used).", "الحجم الفعلي/المخصص مُتجاهَل عند وضع عدة صفحات في ورقة (يُستخدم الملاءمة).")
            PlanWarning.BLANK_PAGES_ADDED -> t("${p.warningDetail} blank page(s) added so the booklet folds correctly.", "أُضيفت ${p.warningDetail} صفحة فارغة ليُطوى الكتيّب بشكل صحيح.")
            PlanWarning.ODD_SIDE_BLANK_BACK -> t("Odd number of sides: the last sheet's back stays blank (it is still fed through so the stack stays in order).", "عدد الأوجه فردي: يبقى خلف آخر ورقة فارغًا (يمرّ عبر الطابعة للحفاظ على ترتيب الرزمة).")
            PlanWarning.GUTTER_IGNORED_BOOKLET -> t("Binding margin is ignored in booklet mode (the fold is the binding).", "هامش التجليد مُتجاهَل في وضع الكتيّب (الطيّة هي التجليد).")
        }
    }

    internal fun previewSides(p: JobPlan): List<Pair<String, SideInstance>> {
        val out = ArrayList<Pair<String, SideInstance>>()
        for (part in p.parts) {
            val n = part.sides.size
            part.sides.forEachIndexed { i, s ->
                val l = when (part.kind) {
                    PartKind.SINGLE -> t("Sheet ${i + 1} of $n", "ورقة ${i + 1} من $n")
                    PartKind.AUTO_DUPLEX -> t("Side ${i + 1} of $n", "وجه ${i + 1} من $n")
                    PartKind.FRONTS -> t("Pass 1 · front ${i + 1} of $n", "المرحلة 1 · أمامي ${i + 1} من $n")
                    PartKind.BACKS -> t("Pass 2 · back ${i + 1} of $n", "المرحلة 2 · خلفي ${i + 1} من $n")
                }
                out.add(l to s)
            }
        }
        return out
    }

    private fun printTab(): View = page {
        val ctx = this@MainActivity
        addView(label(ctx, "Print Studio", 26f, true))
        addView(sub(ctx, t("Prints through Android's own print system — works with HP Laser 107w and other Android-compatible printers.", "تطبع عبر نظام الطباعة في أندرويد — تعمل مع HP Laser 107w وغيرها من الطابعات المتوافقة.")))
        addView(spacer(ctx, 12))
        val d = doc
        addView(card(ctx) {
            if (d == null) {
                addView(label(ctx, t("Start by choosing a document", "ابدأ باختيار مستند"), 16f, true))
                addView(sub(ctx, t("PDF files or images (JPG, PNG, …). You can pick several images to print them as one job.", "ملفات PDF أو صور (JPG, PNG, …). يمكنك اختيار عدة صور وطباعتها كمهمة واحدة.")))
                addView(spacer(ctx, 10))
                addView(button(ctx, t("Choose PDF or images", "اختيار PDF أو صور"), true) { pickFiles() }, lp(-1, -2))
            } else {
                addView(label(ctx, d.name, 17f, true))
                val blankNote = if (d.blank.isNotEmpty()) t(" · ${d.blank.size} blank", " · ${d.blank.size} فارغة") else ""
                addView(sub(ctx, t("${d.pageCount} pages · ${selected.size} selected$blankNote", "${d.pageCount} صفحة · ${selected.size} محددة$blankNote")))
                addView(spacer(ctx, 10))
                addView(row(ctx) {
                    addView(button(ctx, t("Change file", "تغيير الملف")) { pickFiles() }, lp(0, -2, 1f, ctx = ctx, end = 8))
                    addView(button(ctx, t("Choose pages", "اختيار الصفحات")) { tab = 1; render() }, lp(0, -2, 1f))
                })
            }
        }.also { it.layoutParams = lp(-1, -2, bottom = 12, ctx = ctx) })

        addView(heading(ctx, t("Preset", "إعداد جاهز")))
        addView(chips(ctx, listOf(
            t("Everyday", "يومي") to Preset.EVERYDAY, t("Economy", "اقتصادي") to Preset.ECONOMY, t("Book", "كتاب") to Preset.BOOK,
            t("Booklet", "كتيّب") to Preset.BOOKLET, t("High quality", "جودة عالية") to Preset.HIGH_QUALITY, t("Custom", "مخصص") to Preset.CUSTOM),
            settings.preset) { p -> settings = Presets.apply(p, settings); store.settings = settings; render() })
        addView(spacer(ctx, 12))

        if (d == null) return@page
        val plan = currentPlan()
        addView(card(ctx) {
            if (plan == null || !plan.ok) {
                val msg = when (plan?.error) {
                    PlanError.NO_PAGES -> t("No pages match the current selection.", "لا توجد صفحات مطابقة للتحديد.")
                    PlanError.RANGE_OUT_OF_RANGE -> t("Page range is outside the document: ${plan.errorToken}", "نطاق الصفحات خارج المستند: ${plan.errorToken}")
                    else -> t("Invalid page range: ${plan?.errorToken}", "نطاق صفحات غير صالح: ${plan?.errorToken}")
                }
                addView(label(ctx, msg, 15f, true, pal.danger))
                addView(button(ctx, t("Fix in Options", "تعديل في الخيارات")) { tab = 3; render() })
            } else {
                val sheets = if (plan.duplexMode == DuplexMode.OFF) plan.parts[0].sides.size else plan.physicalSheets
                addView(label(ctx, t("${plan.selection.size} pages → $sheets sheet(s) of paper", "${plan.selection.size} صفحة ← $sheets ورقة"), 16f, true))
                val mode = when (plan.duplexMode) {
                    DuplexMode.OFF -> t("One-sided", "وجه واحد")
                    DuplexMode.AUTO -> t("Automatic two-sided (needs printer support)", "وجهان تلقائي (يتطلب دعم الطابعة)")
                    DuplexMode.MANUAL -> t("Manual two-sided: 2 passes, you flip the paper", "وجهان يدوي: مرحلتان، وتقلب الورق بنفسك")
                }
                addView(sub(ctx, "$mode · ${settings.paper.id} · ${if (plan.layoutLandscape) t("landscape", "أفقي") else t("portrait", "عمودي")} · ${plan.grid.cols * plan.grid.rows} ${t("page(s)/sheet", "صفحة/ورقة")}"))
                warningText(plan).forEach { addView(label(ctx, "• $it", 13f, false, pal.warn).apply { setPadding(0, dp(4), 0, 0) }) }
            }
        }.also { it.layoutParams = lp(-1, -2, bottom = 12, ctx = ctx) })

        if (plan != null && plan.ok) {
            val sides = previewSides(plan)
            if (previewIdx >= sides.size) previewIdx = 0
            addView(heading(ctx, t("Preview", "معاينة")))
            val pv = SheetPreview(ctx).also { preview = it }
            addView(pv, lp(-1, dp(360), bottom = 6, ctx = ctx))
            val cov = label(ctx, "", 12f, false, pal.sub)
            pv.onCoverage = { pv.coverage?.let { (a, b) -> if (settings.eco == EcoMode.SOFTWARE_DRAFT) cov.text = t("Estimated ink coverage of this page (software estimate): ${"%.1f".format(a * 100)}% → ${"%.1f".format(b * 100)}%", "تقدير تغطية الحبر لهذه الصفحة (تقدير برمجي): ${"%.1f".format(a * 100)}% ← ${"%.1f".format(b * 100)}%") else cov.text = "" } }
            val cap = label(ctx, sides[previewIdx].first, 14f, true).apply { gravity = Gravity.CENTER }
            addView(row(ctx) {
                addView(button(ctx, "‹") { if (previewIdx > 0) { previewIdx--; render() } }.apply { contentDescription = t("Previous sheet", "الورقة السابقة") }, LinearLayout.LayoutParams(dp(56), dp(48)))
                addView(cap, lp(0, -2, 1f))
                addView(button(ctx, "›") { if (previewIdx < sides.size - 1) { previewIdx++; render() } }.apply { contentDescription = t("Next sheet", "الورقة التالية") }, LinearLayout.LayoutParams(dp(56), dp(48)))
            })
            addView(cov)
            pv.set(plan, sides[previewIdx].second, settings, thumbs)
            addView(sub(ctx, t("The preview uses the same layout engine as the real print. Back sides in manual two-sided are shown as they will be sent (including any 180° turn).", "المعاينة تستخدم نفس محرك التخطيط للطباعة الفعلية. تُعرض الأوجه الخلفية كما ستُرسل (بما فيها أي دوران 180°).")))
            addView(spacer(ctx, 12))
            val first = plan.parts.first().kind
            val label = when (first) { PartKind.FRONTS -> t("Print side 1 (fronts)", "اطبع الوجه الأول (الأمامي)"); else -> t("Print", "طباعة") }
            addView(button(ctx, label, true) { startPrint() }, lp(-1, dp(56)))
            addView(spacer(ctx, 8))
            addView(sub(ctx, t("Android will show its print dialog next. Pick your printer there and tap Print. Leave “Copies” at 1 in that dialog — copies are set here.", "سيعرض أندرويد نافذة الطباعة. اختر طابعتك واضغط طباعة. اترك “النسخ” = 1 هناك — النسخ تُضبط هنا.")))
        }
    }

    internal fun refreshPreview() {
        val plan = currentPlan() ?: return
        if (!plan.ok) return
        val sides = previewSides(plan); if (sides.isEmpty()) return
        if (previewIdx >= sides.size) previewIdx = 0
        preview?.set(plan, sides[previewIdx].second, settings, thumbs)
    }

    internal fun startPrint() {
        val d = doc ?: return
        if (settings.selectedOnly && selected.isEmpty()) { toast(t("Select at least one page.", "اختر صفحة واحدة على الأقل.")); return }
        val go = {
            jobs.host = this
            val err = jobs.submit(d, settings, d.blank, selectedForPlan())
            if (err != null) toast(err) else { tab = 2; render() }
        }
        if (jobs.hasActive()) AlertDialog.Builder(this).setMessage(t("A print job is already in progress. Start another one?", "توجد مهمة طباعة قيد التنفيذ. هل تبدأ مهمة أخرى؟"))
            .setPositiveButton(t("Start another", "ابدأ أخرى")) { _, _ -> go() }.setNegativeButton(t("Cancel", "إلغاء"), null).show()
        else go()
    }

    // ------------------------------------------------------------------ PAGES TAB
    private fun pagesTab(): View {
        val ctx = this
        val d = doc
        val root = col(ctx, 12)
        if (d == null) {
            root.addView(label(ctx, t("Pages", "الصفحات"), 22f, true))
            root.addView(sub(ctx, t("Import a document first.", "استورد مستندًا أولًا.")))
            root.addView(spacer(ctx, 8)); root.addView(button(ctx, t("Choose PDF or images", "اختيار PDF أو صور"), true) { pickFiles() })
            return root
        }
        val info = label(ctx, "", 13f, false, pal.sub)
        fun refreshInfo() {
            val b = if (d.blankScanDone) t("${d.blank.size} blank page(s) detected", "تم اكتشاف ${d.blank.size} صفحة فارغة") else t("scanning for blank pages…", "جارٍ البحث عن صفحات فارغة…")
            info.text = t("${selected.size} of ${d.pageCount} selected · $b", "${selected.size} من ${d.pageCount} محددة · $b")
        }
        refreshInfo()
        fun sel(block: () -> Unit) { block(); update({ it.copy(selectedOnly = selected.size != d.pageCount) }, false); gridAdapter?.notifyDataSetChanged(); refreshInfo() }
        root.addView(label(ctx, t("Pages", "الصفحات"), 22f, true))
        root.addView(info)
        val tools = FlowLayout(ctx)
        fun tb(name: String, f: () -> Unit) = tools.addView(button(ctx, name) { sel(f) }.apply { minHeight = dp(40); minimumHeight = dp(40) })
        tb(t("All", "الكل")) { selected.clear(); selected.addAll(1..d.pageCount) }
        tb(t("None", "لا شيء")) { selected.clear() }
        tb(t("Odd", "الفردية")) { selected.clear(); selected.addAll((1..d.pageCount).filter { it % 2 == 1 }) }
        tb(t("Even", "الزوجية")) { selected.clear(); selected.addAll((1..d.pageCount).filter { it % 2 == 0 }) }
        tb(t("Invert", "عكس")) { val n = (1..d.pageCount).filter { it !in selected }; selected.clear(); selected.addAll(n) }
        tb(t("Drop blanks", "استبعاد الفارغة")) { selected.removeAll(d.blank) }
        root.addView(tools, lp(-1, -2, top = 6, bottom = 6, ctx = ctx))
        val grid = GridView(ctx)
        val colW = dp(104)
        grid.numColumns = GridView.AUTO_FIT; grid.columnWidth = colW; grid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        grid.horizontalSpacing = dp(8); grid.verticalSpacing = dp(8); grid.clipToPadding = false
        val ad = PagesAdapter(d, colW) { p -> sel { if (!selected.add(p)) selected.remove(p) } }
        gridAdapter = ad; grid.adapter = ad
        grid.setOnItemLongClickListener { _, _, pos, _ -> showPagePreview(pos + 1); true }
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(sub(ctx, t("Tap to select/deselect · long-press to preview a page.", "اضغط للتحديد/إلغاء التحديد · اضغط مطولًا لمعاينة الصفحة.")))
        return root
    }

    inner class PagesAdapter(private val d: LoadedDocument, private val colW: Int, private val onTap: (Int) -> Unit) : BaseAdapter() {
        override fun getCount() = d.pageCount
        override fun getItem(p: Int) = p + 1
        override fun getItemId(p: Int) = (p + 1).toLong()
        override fun getView(pos: Int, convert: View?, parent: ViewGroup): View {
            val page = pos + 1
            val ctx = this@MainActivity
            val v = FrameLayout(ctx)
            val (pw, ph) = d.pageSize(page)
            val h = (colW * ph / pw).toInt().coerceIn(dp(60), dp(220))
            v.layoutParams = AbsListView.LayoutParams(colW, h + dp(22))
            val on = page in selected
            v.background = roundRect(ctx, if (on) (if (pal.dark) 0x337AA7FF else 0x221457D9) else pal.surface, 10, if (on) pal.accent else pal.outline, if (on) 2 else 1)
            val img = ImageView(ctx).apply { scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(Color.WHITE); contentDescription = t("Page $page", "الصفحة $page") }
            v.addView(img, FrameLayout.LayoutParams(-1, h).apply { setMargins(dp(4), dp(4), dp(4), 0) })
            thumbs?.let { th ->
                th.peek(page)?.let { img.setImageBitmap(it) } ?: th.load(page, 200) { b -> if (b != null && img.isAttachedToWindow || b != null) img.setImageBitmap(b) }
            }
            val num = label(ctx, (if (on) "✓ " else "") + page + if (page in d.blank) "  " + t("blank", "فارغة") else "", 12f, on, if (on) pal.accent else pal.sub)
            v.addView(num, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(3) })
            v.setOnClickListener { onTap(page) }
            return v
        }
    }

    private fun showPagePreview(page: Int) {
        val d = doc ?: return
        val img = ImageView(this).apply { setBackgroundColor(Color.WHITE); scaleType = ImageView.ScaleType.FIT_CENTER; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        val dlg = AlertDialog.Builder(this).setTitle(t("Page $page of ${d.pageCount}", "الصفحة $page من ${d.pageCount}")).setView(img)
            .setPositiveButton(t("Close", "إغلاق"), null).create()
        dlg.show()
        Thread {
            val prov = DocProvider(d)
            try {
                val (pw, ph) = d.pageSize(page)
                val w = (resources.displayMetrics.widthPixels * 0.9).toInt(); val px = prov.render(page, w, (w * ph / pw).toInt())
                val bmp = android.graphics.Bitmap.createBitmap(px.argb, px.width, px.height, android.graphics.Bitmap.Config.ARGB_8888)
                runOnUiThread { img.setImageBitmap(bmp) }
            } catch (e: Exception) { } finally { prov.close() }
        }.start()
    }

    // ------------------------------------------------------------------ QUEUE TAB
    private fun partStateText(p: PartRecord): Pair<String, Int> = when (p.state) {
        PartState.PENDING -> t("Waiting", "بالانتظار") to pal.sub
        PartState.SUBMITTING -> t("Sending…", "جارٍ الإرسال…") to pal.accent
        PartState.ACTIVE -> t("In progress", "قيد التنفيذ") to pal.accent
        PartState.DONE -> t("Done", "تمّت") to pal.ok
        PartState.FAILED -> t("Failed", "فشلت") to pal.danger
        PartState.CANCELED -> t("Cancelled", "أُلغيت") to pal.warn
        PartState.UNCERTAIN -> t("Unknown — check printer", "غير معروفة — تحقق من الطابعة") to pal.warn
    }

    private fun queueTab(): View = page {
        val ctx = this@MainActivity
        addView(label(ctx, t("Print queue", "طابور الطباعة"), 22f, true))
        addView(sub(ctx, t("Jobs sent by this app. Android reports completion from the print service; for manual two-sided you always confirm paper reloading yourself.", "مهام أُرسلت من هذا التطبيق. أندرويد يبلّغ الإكمال من خدمة الطباعة؛ وفي الوجهين اليدوي تؤكد أنت إعادة الورق دائمًا.")))
        addView(spacer(ctx, 10))
        if (jobs.jobs.isEmpty()) addView(sub(ctx, t("No jobs yet.", "لا توجد مهام بعد.")))
        for (j in jobs.jobs.reversed()) addView(card(ctx) {
            addView(label(ctx, j.name, 16f, true))
            val df = java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT, java.text.DateFormat.SHORT)
            addView(sub(ctx, df.format(java.util.Date(j.createdAt))))
            if (j.warning.isNotEmpty()) addView(label(ctx, "⚠ " + j.warning, 13f, false, pal.warn))
            j.parts.forEachIndexed { i, p ->
                val (txt, col) = partStateText(p)
                addView(row(ctx) {
                    setPadding(0, dp(8), 0, 0)
                    addView(label(ctx, "${i + 1}. ${p.label}"), lp(0, -2, 1f))
                    addView(label(ctx, txt, 13f, true, col))
                })
                val pr = jobs.progress[j.id + ":" + i]
                if (p.state == PartState.ACTIVE && pr != null && pr.second > 0)
                    addView(ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply { max = pr.second; progress = pr.first }, lp(-1, dp(12), top = 4, ctx = ctx))
                if (p.state == PartState.ACTIVE && pr != null) addView(sub(ctx, t("Preparing page ${pr.first} of ${pr.second}", "تجهيز الصفحة ${pr.first} من ${pr.second}")))
                if (p.detail.isNotEmpty()) addView(sub(ctx, p.detail))
                if (p.state == PartState.FAILED || p.state == PartState.CANCELED || p.state == PartState.UNCERTAIN) {
                    addView(button(ctx, if (p.state == PartState.UNCERTAIN) t("Reprint anyway…", "أعد الطباعة رغم ذلك…") else t("Retry", "إعادة المحاولة")) { confirmRetry(j, i, p) }, lp(-1, -2, top = 6, ctx = ctx))
                }
                if (p.state == PartState.UNCERTAIN)
                    addView(button(ctx, t("It printed — mark done", "طُبعت — اعتبرها منتهية")) { jobs.markDoneByUser(j, i) }, lp(-1, -2, top = 6, ctx = ctx))
            }
            if (jobs.waitingForFlip(j)) {
                addView(spacer(ctx, 8))
                addView(label(ctx, t("Waiting for you: reload the paper for side 2.", "بانتظارك: أعد تحميل الورق للوجه الثاني."), 14f, true, pal.accent))
                addView(button(ctx, t("Show instructions & continue", "عرض التعليمات والمتابعة"), true) { showFlipDialog(j) })
            }
            addView(row(ctx) {
                setPadding(0, dp(8), 0, 0)
                if (j.parts.any { it.state == PartState.ACTIVE || it.state == PartState.SUBMITTING || it.state == PartState.PENDING })
                    addView(button(ctx, t("Cancel job", "إلغاء المهمة")) { jobs.cancel(j) }, lp(0, -2, 1f, end = 8, ctx = ctx))
                else addView(button(ctx, t("Remove", "حذف")) { jobs.remove(j) }, lp(0, -2, 1f))
            })
        }.also { it.layoutParams = lp(-1, -2, bottom = 12, ctx = ctx) })
    }

    private fun confirmRetry(j: JobRecord, i: Int, p: PartRecord) {
        val risky = p.state == PartState.UNCERTAIN || p.startedOnce
        val msg = if (risky) t("This step may already have printed (fully or partly). Check the printer's output first. Print it again?", "قد تكون هذه الخطوة طُبعت بالفعل (كليًا أو جزئيًا). تحقق من مخرجات الطابعة أولًا. هل تطبعها مجددًا؟")
        else t("Send this step to the printer again?", "إرسال هذه الخطوة إلى الطابعة مجددًا؟")
        AlertDialog.Builder(this).setMessage(msg)
            .setPositiveButton(t("Print again", "اطبع مجددًا")) { _, _ -> jobs.host = this; jobs.retry(j, i)?.let { toast(it) } }
            .setNegativeButton(t("Not now", "ليس الآن"), null).show()
    }

    // ------------------------------------------------------------------ dialogs for manual duplex
    internal fun showFlipDialog(j: JobRecord) {
        if (!jobs.waitingForFlip(j)) return
        val s = PrintSettings.fromMap(j.settings)
        val n = j.parts.getOrNull(1)?.sides ?: 0
        val steps = StringBuilder()
        steps.append(t("1. Wait until the printer has finished and every page is in the output tray.\n", "1. انتظر حتى تنتهي الطابعة وتصبح كل الصفحات في صينية الإخراج.\n"))
        steps.append(t("2. Take the whole stack out. Don't shuffle or remove sheets.\n", "2. أخرج الرزمة كاملة. لا تخلط الأوراق ولا تسحب أي ورقة.\n"))
        steps.append(t("3. Put the stack back in the input tray with the blank side up (the side to be printed), turned the same way you found it to work in the calibration test.\n", "3. أعد الرزمة إلى صينية الإدخال والوجه الفارغ لأعلى (الوجه المراد الطباعة عليه)، بنفس الطريقة التي نجحت معك في اختبار المعايرة.\n"))
        steps.append(if (s.reverseSecondJob) t("4. The back sides are sent in REVERSE order so the finished stack comes out in the right order. Don't re-order the stack.\n", "4. تُرسل الأوجه الخلفية بترتيب معكوس لتخرج الرزمة النهائية بالترتيب الصحيح. لا تعِد ترتيب الرزمة.\n")
        else t("4. The back sides are sent in the same order as the fronts.\n", "4. تُرسل الأوجه الخلفية بنفس ترتيب الأمامية.\n"))
        steps.append(t("5. Expect $n sheet(s). In the next print dialog keep the same paper size and orientation, choose your printer and tap Print.\n\n", "5. توقع $n ورقة. في نافذة الطباعة التالية أبقِ نفس حجم واتجاه الورق، اختر الطابعة واضغط طباعة.\n\n"))
        steps.append(t("Android cannot tell whether you actually reloaded the paper, so nothing is sent until you confirm.\nNot sure about the direction? Run the calibration test in the Printer tab first.", "لا يستطيع أندرويد معرفة ما إذا أعدت الورق فعلًا، لذا لا يُرسل شيء حتى تؤكد.\nلست متأكدًا من الاتجاه؟ شغّل اختبار المعايرة من تبويب الطابعة أولًا."))
        AlertDialog.Builder(this).setTitle(t("Turn the paper over", "اقلب الورق"))
            .setMessage(steps.toString())
            .setPositiveButton(t("I reloaded the paper — print side 2", "أعدت الورق — اطبع الوجه الثاني")) { _, _ -> jobs.host = this; jobs.continueNext(j)?.let { toast(it) } }
            .setNeutralButton(t("Cancel job", "إلغاء المهمة")) { _, _ -> jobs.cancel(j) }
            .setNegativeButton(t("Later", "لاحقًا"), null).setCancelable(false).show()
    }

    internal fun startCalibration() {
        val s = settings.copy(pagesPerSheet = 1, booklet = false, duplex = DuplexMode.MANUAL, binding = Binding.BOOK, marginMm = 10.0, gutterMm = 0.0,
            scale = ScaleMode.FIT, orientation = Orientation.PORTRAIT, color = ColorMode.GRAYSCALE, quality = QualityMode.DRAFT, eco = EcoMode.OFF,
            copies = 1, rangeText = "", parity = Parity.ALL, skipBlank = false, selectedOnly = false, reverse = false, preset = Preset.CUSTOM)
        AlertDialog.Builder(this).setTitle(t("Manual two-sided calibration", "معايرة الوجهين اليدوي"))
            .setMessage(t("This prints 2 test sheets (4 sides) using the current reload settings. Use plain paper you don't mind wasting. You'll print side 1, reload the stack, print side 2, then tell the app what you see.", "تطبع هذه الخطوة ورقتي اختبار (4 أوجه) بإعدادات إعادة التحميل الحالية. استخدم ورقًا عاديًا. ستطبع الوجه الأول، ثم تعيد الرزمة، ثم تطبع الوجه الثاني، وبعدها تخبر التطبيق بما رأيت."))
            .setPositiveButton(t("Start", "ابدأ")) { _, _ -> jobs.host = this; jobs.submit(CalibrationDoc(), s, emptySet(), null, calibration = true)?.let { toast(it) } ?: run { tab = 2; render() } }
            .setNegativeButton(t("Cancel", "إلغاء"), null).show()
    }

    internal fun showCalibrationResult(j: JobRecord) {
        var upside = false; var reversed = false
        val box = col(this, 16) {
            addView(label(this@MainActivity, t("Take sheet 1. Turn it over like a page of a book (around its left edge) and compare front and back.", "خذ الورقة 1 واقلبها كصفحة كتاب (حول حافتها اليسرى) وقارن الأمامي بالخلفي."), 14f))
            addView(switchRow(this@MainActivity, t("The back is upside-down compared to the front", "الوجه الخلفي مقلوب مقارنةً بالأمامي"), t("The ▲ on the back points the other way", "السهم ▲ في الخلف يشير للاتجاه المعاكس"), false) { upside = it })
            addView(switchRow(this@MainActivity, t("Sheets are in the wrong order", "الأوراق بترتيب خاطئ"), t("Behind FRONT “SHEET 1” you see BACK “SHEET 2”", "خلف الأمامي “SHEET 1” ترى الخلفي “SHEET 2”"), false) { reversed = it })
        }
        AlertDialog.Builder(this).setTitle(t("What did you see?", "ماذا رأيت؟")).setView(box).setCancelable(false)
            .setPositiveButton(t("Save", "حفظ")) { _, _ ->
                update({ var n = it
                    if (upside) n = n.copy(reloadFlip = if (n.reloadFlip == ReloadFlip.LONG_EDGE) ReloadFlip.SHORT_EDGE else ReloadFlip.LONG_EDGE)
                    if (reversed) n = n.copy(reverseSecondJob = !n.reverseSecondJob)
                    n }, false)
                j.calibrationDone = true; store.calibrated = true; store.saveJobs(jobs.jobs)
                toast(if (!upside && !reversed) t("Great — your current settings are correct.", "ممتاز — إعداداتك الحالية صحيحة.") else t("Saved. Run the test once more to confirm.", "تم الحفظ. أعد الاختبار مرة للتأكد."))
                render()
            }.show()
    }
}
