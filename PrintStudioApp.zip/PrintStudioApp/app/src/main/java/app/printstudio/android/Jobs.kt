package app.printstudio.android

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.print.PrintAttributes
import android.print.PrintJob
import android.print.PrintJobInfo
import android.print.PrintManager
import app.printstudio.core.*
import java.util.UUID

/**
 * Print queue + manual-duplex state machine.
 *
 * Duplicate protection: a part is persisted as SUBMITTING *before* PrintManager.print() is called. If the process dies in
 * between, or Android reports a state we cannot interpret, the part becomes UNCERTAIN and is NEVER re-sent automatically;
 * the user must confirm a reprint explicitly (the printer may already have printed it).
 */
class JobManager(private val app: Context, private val store: Store) {
    val jobs: MutableList<JobRecord> = store.loadJobs()
    var host: Activity? = null
    var onChange: () -> Unit = {}
    var onFlipNeeded: (JobRecord) -> Unit = {}
    var onCalibrationReady: (JobRecord) -> Unit = {}

    private val main = Handler(Looper.getMainLooper())
    private val handles = HashMap<String, PrintJob>()
    private val misses = HashMap<String, Int>()
    private val inFlight = HashSet<String>()
    private val prompted = HashSet<String>()
    val progress = HashMap<String, Pair<Int, Int>>()
    private var polling = false

    init {
        for (j in jobs) for (p in j.parts) if (p.state == PartState.SUBMITTING) {
            p.state = PartState.UNCERTAIN; p.detail = t("The app was closed while sending. Check the printer before reprinting.", "تم إغلاق التطبيق أثناء الإرسال. تحقق من الطابعة قبل إعادة الطباعة.")
        }
        store.saveJobs(jobs)
        if (jobs.any { j -> j.parts.any { it.state == PartState.ACTIVE } }) startPolling()
    }

    private val tick = object : Runnable {
        override fun run() {
            poll()
            if (jobs.any { j -> j.parts.any { it.state == PartState.ACTIVE } }) main.postDelayed(this, 1200) else polling = false
        }
    }
    private fun startPolling() { if (!polling) { polling = true; main.postDelayed(tick, 800) } }
    private fun save() { store.saveJobs(jobs); onChange() }

    private fun pm(): PrintManager? = host?.getSystemService(Context.PRINT_SERVICE) as? PrintManager

    private fun findHandle(id: String): PrintJob? {
        handles[id]?.let { return it }
        val found = try { pm()?.printJobs?.firstOrNull { it.id.toString() == id } } catch (e: Exception) { null }
        if (found != null) handles[id] = found
        return found
    }

    private fun poll() {
        for (j in jobs.toList()) for ((i, p) in j.parts.withIndex()) {
            if (p.state != PartState.ACTIVE) continue
            val id = p.systemJobId ?: continue
            val h = findHandle(id)
            val st = try { h?.info?.state } catch (e: Exception) { null }
            if (st == null) {
                val n = (misses[id] ?: 0) + 1; misses[id] = n
                if (n >= 4) { p.state = PartState.UNCERTAIN; p.detail = t("Lost track of this job. It may or may not have printed.", "فُقد تتبّع هذه المهمة. قد تكون طُبعت أو لا."); save() }
                continue
            }
            misses[id] = 0
            when (st) {
                PrintJobInfo.STATE_COMPLETED -> { p.state = PartState.DONE; p.detail = ""; save(); afterPartDone(j, i) }
                PrintJobInfo.STATE_FAILED -> { p.state = PartState.FAILED; p.detail = t("The print service reported a failure.", "أبلغت خدمة الطباعة عن فشل."); save() }
                PrintJobInfo.STATE_CANCELED -> { p.state = PartState.CANCELED; p.detail = ""; cancelRest(j); save() }
                PrintJobInfo.STATE_BLOCKED -> { p.detail = t("Blocked — check the printer (paper, cover, toner).", "متوقفة — تحقق من الطابعة (ورق، غطاء، حبر)."); onChange() }
                PrintJobInfo.STATE_STARTED -> { p.detail = t("Printing…", "جارٍ الطباعة…"); onChange() }
                PrintJobInfo.STATE_QUEUED -> { p.detail = t("Queued…", "في قائمة الانتظار…"); onChange() }
                else -> { p.detail = t("Waiting in the system print dialog…", "بانتظار نافذة الطباعة…"); onChange() }
            }
        }
    }

    private fun cancelRest(j: JobRecord) { j.parts.filter { it.state == PartState.PENDING }.forEach { it.state = PartState.CANCELED } }

    private fun afterPartDone(j: JobRecord, i: Int) {
        val next = j.parts.getOrNull(i + 1)
        if (next != null && next.state == PartState.PENDING) {
            if (prompted.add(j.id + ":" + (i + 1))) onFlipNeeded(j)
        } else if (j.calibration && j.parts.all { it.state == PartState.DONE } && !j.calibrationDone) onCalibrationReady(j)
    }

    /** Returns an error message, or null if the first part was handed to the system print dialog. */
    fun submit(doc: DocModel, s: PrintSettings, blank: Set<Int>, selected: Set<Int>?, calibration: Boolean = false): String? {
        val plan = Planner.plan(doc.pageCount, doc::pageSize, s, Planner.seedSheet(s), blank, selected)
        if (!plan.ok) return when (plan.error) {
            PlanError.NO_PAGES -> t("No pages match the current selection.", "لا توجد صفحات مطابقة للتحديد الحالي.")
            PlanError.RANGE_OUT_OF_RANGE -> t("Page range is outside the document: ${plan.errorToken}", "نطاق الصفحات خارج المستند: ${plan.errorToken}")
            else -> t("Invalid page range: ${plan.errorToken}", "نطاق صفحات غير صالح: ${plan.errorToken}")
        }
        val labels = plan.parts.map {
            when (it.kind) {
                PartKind.SINGLE -> t("Print", "طباعة")
                PartKind.AUTO_DUPLEX -> t("Print (automatic two-sided)", "طباعة (وجهين تلقائي)")
                PartKind.FRONTS -> t("Side 1 — fronts", "الوجه الأول — الأمامي")
                PartKind.BACKS -> t("Side 2 — backs", "الوجه الثاني — الخلفي")
            }
        }
        val rec = JobRecord(UUID.randomUUID().toString(), doc.name, System.currentTimeMillis(), doc.id, s.toMap(),
            selected?.toList(), blank.toList(), calibration, plan.parts.mapIndexed { i, p -> PartRecord(labels[i], sides = p.sides.size) }.toMutableList())
        jobs.add(rec); save()
        return printPart(rec, 0)
    }

    fun printPart(rec: JobRecord, idx: Int): String? {
        val part = rec.parts.getOrNull(idx) ?: return "?"
        val key = rec.id + ":" + idx
        if (part.state != PartState.PENDING || !inFlight.add(key)) return t("This step was already sent.", "هذه الخطوة أُرسلت بالفعل.")
        try {
            if (idx > 0 && rec.parts[idx - 1].state != PartState.DONE) return t("Finish the previous step first.", "أنهِ الخطوة السابقة أولًا.")
            val doc: DocModel = if (rec.calibration) CalibrationDoc() else LoadedDocument.load(app, rec.docId)
                ?: run { part.state = PartState.FAILED; part.detail = t("The imported document is no longer available — import it again.", "المستند لم يعد متاحًا — استورده مرة أخرى."); save(); return part.detail }
            val s = PrintSettings.fromMap(rec.settings)
            val manager = pm() ?: return t("No screen available to show the print dialog.", "لا توجد شاشة لعرض نافذة الطباعة.")
            val listener = object : AdapterListener {
                override fun onSheet(part: Int, widthMils: Int, heightMils: Int) {
                    val v = "${widthMils}x$heightMils"
                    if (part == 0 || rec.firstSheetMils.isEmpty()) rec.firstSheetMils = v
                    else if (rec.firstSheetMils != v) { rec.warning = t("Paper size/orientation in the second dialog differs from the first. Both sides must use identical settings.", "حجم/اتجاه الورق في النافذة الثانية يختلف عن الأولى. يجب أن يكون الوجهان بنفس الإعدادات."); save() }
                }
                override fun onProgress(part: Int, done: Int, total: Int) { progress[rec.id + ":" + part] = done to total; onChange() }
                override fun onWritten(part: Int) { rec.parts[part].startedOnce = true; progress.remove(rec.id + ":" + part); save() }
                override fun onFailed(part: Int, message: String) { rec.parts[part].state = PartState.FAILED; rec.parts[part].detail = message; save() }
            }
            val adapter = PlanPrintAdapter(app, doc, s, idx, rec.name + " · " + part.label, rec.blank.toSet(), rec.selected?.toSet(), listener)
            val plan = Planner.plan(doc.pageCount, doc::pageSize, s, Planner.seedSheet(s), rec.blank.toSet(), rec.selected?.toSet())
            val b = PrintAttributes.Builder()
                .setMediaSize(when (s.paper) {
                    PaperSize.A4 -> PrintAttributes.MediaSize.ISO_A4
                    PaperSize.LETTER -> PrintAttributes.MediaSize.NA_LETTER
                    PaperSize.LEGAL -> PrintAttributes.MediaSize.NA_LEGAL
                    PaperSize.A5 -> PrintAttributes.MediaSize.ISO_A5
                    PaperSize.B5 -> PrintAttributes.MediaSize.ISO_B5
                })
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .setColorMode(if (s.color == ColorMode.COLOR) PrintAttributes.COLOR_MODE_COLOR else PrintAttributes.COLOR_MODE_MONOCHROME)
                .setDuplexMode(if (plan.duplexMode == DuplexMode.AUTO)
                    (if (plan.autoDuplexLongEdge) PrintAttributes.DUPLEX_MODE_LONG_EDGE else PrintAttributes.DUPLEX_MODE_SHORT_EDGE)
                else PrintAttributes.DUPLEX_MODE_NONE)
            part.state = PartState.SUBMITTING; part.detail = ""; save()          // persisted BEFORE the call
            val pj = try { manager.print(rec.name + " · " + part.label, adapter, b.build()) } catch (e: Exception) { null }
            if (pj == null) { part.state = PartState.FAILED; part.detail = t("Android refused to start the print job.", "رفض النظام بدء مهمة الطباعة."); save(); return part.detail }
            part.systemJobId = pj.id.toString(); part.state = PartState.ACTIVE
            part.detail = t("Waiting in the system print dialog…", "بانتظار نافذة الطباعة…")
            handles[part.systemJobId!!] = pj
            save(); startPolling()
            return null
        } finally { inFlight.remove(key) }
    }

    /** User confirmed the paper was re-inserted. */
    fun continueNext(rec: JobRecord): String? {
        val i = rec.parts.indexOfFirst { it.state == PartState.PENDING }
        if (i <= 0) return null
        return printPart(rec, i)
    }

    /** Explicit user-confirmed reprint of a failed / cancelled / uncertain step. */
    fun retry(rec: JobRecord, idx: Int): String? {
        val p = rec.parts[idx]
        if (p.state !in setOf(PartState.FAILED, PartState.CANCELED, PartState.UNCERTAIN)) return null
        p.state = PartState.PENDING; p.systemJobId = null; p.detail = ""; prompted.remove(rec.id + ":" + idx)
        return printPart(rec, idx)
    }

    fun cancel(rec: JobRecord) {
        for (p in rec.parts) {
            if (p.state == PartState.ACTIVE) {
                p.systemJobId?.let { id -> try { findHandle(id)?.cancel() } catch (e: Exception) { } }
                p.state = PartState.CANCELED; p.detail = t("Cancelled by you. If the printer already started, press Cancel on the printer too.", "ألغيتها. إن كانت الطابعة بدأت، اضغط إلغاء على الطابعة أيضًا.")
            } else if (p.state == PartState.PENDING) p.state = PartState.CANCELED
        }
        save()
    }

    fun markDoneByUser(rec: JobRecord, idx: Int) {
        rec.parts[idx].state = PartState.DONE; rec.parts[idx].detail = t("Confirmed by you.", "أكدتَ ذلك بنفسك."); save(); afterPartDone(rec, idx)
    }

    fun remove(rec: JobRecord) { if (rec.parts.none { it.state == PartState.ACTIVE || it.state == PartState.SUBMITTING }) { jobs.remove(rec); save() } }

    fun waitingForFlip(rec: JobRecord): Boolean {
        val i = rec.parts.indexOfFirst { it.state == PartState.PENDING }
        return i > 0 && rec.parts[i - 1].state == PartState.DONE && rec.parts.none { it.state == PartState.ACTIVE || it.state == PartState.SUBMITTING }
    }
    fun hasActive() = jobs.any { j -> j.parts.any { it.state == PartState.ACTIVE || it.state == PartState.SUBMITTING } }
}
