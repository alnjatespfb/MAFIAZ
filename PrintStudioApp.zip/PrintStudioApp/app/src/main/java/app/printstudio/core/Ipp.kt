package app.printstudio.core

import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer

/** Minimal IPP/1.1 Get-Printer-Attributes client. Used ONLY to inspect a printer; never to send documents. */
data class IppAttr(val name: String, val values: List<String>)

data class IppResponse(val statusCode: Int, val attrs: Map<String, List<String>>) {
    operator fun get(n: String) = attrs[n].orEmpty()
    val ok get() = statusCode < 0x0100
}

data class PrinterReport(
    val makeModel: String,
    val state: String,
    val formats: List<String>,
    val sides: List<String>,
    val resolutions: List<String>,
    val qualities: List<String>,
    val colorModes: List<String>,
    val media: List<String>,
    val markers: List<String>,
    val acceptsPdf: Boolean,
    val acceptsRaster: Boolean,
    val hasAutoDuplex: Boolean,
    val hasDraftQuality: Boolean,
    val rawCount: Int,
)

object Ipp {
    private val REQUESTED = listOf(
        "printer-make-and-model", "printer-info", "printer-state", "printer-state-reasons", "document-format-supported",
        "sides-supported", "print-color-mode-supported", "print-quality-supported", "printer-resolution-supported",
        "printer-resolution-default", "media-supported", "media-default", "marker-names", "marker-levels",
        "marker-types", "urf-supported", "pwg-raster-document-resolution-supported", "pwg-raster-document-type-supported",
        "copies-supported", "number-up-supported", "print-content-optimize-supported", "ipp-versions-supported",
        "printer-device-id", "output-bin-supported")

    fun buildGetPrinterAttributes(printerUri: String, requestId: Int = 1): ByteArray {
        val bos = ByteArrayOutputStream()
        val o = DataOutputStream(bos)
        o.writeByte(1); o.writeByte(1)           // IPP 1.1
        o.writeShort(0x000B)                       // Get-Printer-Attributes
        o.writeInt(requestId)
        o.writeByte(0x01)                          // operation-attributes-tag
        fun attr(tag: Int, name: String, value: String) {
            o.writeByte(tag); o.writeShort(name.length); o.write(name.toByteArray())
            o.writeShort(value.toByteArray().size); o.write(value.toByteArray())
        }
        attr(0x47, "attributes-charset", "utf-8")
        attr(0x48, "attributes-natural-language", "en")
        attr(0x45, "printer-uri", printerUri)
        REQUESTED.forEachIndexed { i, r ->
            o.writeByte(0x44)
            if (i == 0) { o.writeShort("requested-attributes".length); o.write("requested-attributes".toByteArray()) } else o.writeShort(0)
            o.writeShort(r.length); o.write(r.toByteArray())
        }
        o.writeByte(0x03)
        return bos.toByteArray()
    }

    fun parse(data: ByteArray): IppResponse {
        val b = ByteBuffer.wrap(data)
        b.get(); b.get()
        val status = b.short.toInt() and 0xFFFF
        b.int
        val out = LinkedHashMap<String, MutableList<String>>()
        var depth = 0
        var lastName: String? = null
        while (b.hasRemaining()) {
            val tag = b.get().toInt() and 0xFF
            if (tag == 0x03) break
            if (tag <= 0x0F) { lastName = null; continue } // group delimiter
            val nameLen = b.short.toInt() and 0xFFFF
            val name = if (nameLen > 0) String(ByteArray(nameLen).also { b.get(it) }, Charsets.UTF_8) else null
            val valLen = b.short.toInt() and 0xFFFF
            val v = ByteArray(valLen).also { b.get(it) }
            if (tag == 0x34) { depth++; continue }
            if (tag == 0x37) { depth--; continue }
            if (depth > 0 || tag == 0x4A) continue
            val key = name ?: lastName ?: continue
            if (name != null) lastName = name
            out.getOrPut(key) { ArrayList() }.add(decode(tag, v))
        }
        return IppResponse(status, out)
    }

    private fun decode(tag: Int, v: ByteArray): String = when (tag) {
        0x21, 0x23 -> if (v.size == 4) ByteBuffer.wrap(v).int.toString() else v.joinToString("") { "%02x".format(it) }
        0x22 -> if (v.isNotEmpty() && v[0].toInt() != 0) "true" else "false"
        0x32 -> if (v.size >= 9) { val bb = ByteBuffer.wrap(v); val x = bb.int; val y = bb.int; val u = bb.get().toInt(); "${x}x${y}" + (if (u == 3) " dpi" else " dpcm") } else "?"
        0x33 -> if (v.size >= 8) { val bb = ByteBuffer.wrap(v); "${bb.int}-${bb.int}" } else "?"
        else -> String(v, Charsets.UTF_8)
    }

    fun report(r: IppResponse): PrinterReport {
        val formats = r["document-format-supported"]
        val sides = r["sides-supported"]
        val raster = formats.any { it.contains("urf") || it.contains("pwg-raster") || it.contains("pclm") } ||
            r["urf-supported"].isNotEmpty() || r["pwg-raster-document-resolution-supported"].isNotEmpty()
        val markerNames = r["marker-names"]; val levels = r["marker-levels"]
        val markers = markerNames.mapIndexed { i, n -> "$n: ${levels.getOrNull(i) ?: "?"}%" }
        return PrinterReport(
            makeModel = r["printer-make-and-model"].firstOrNull() ?: r["printer-info"].firstOrNull() ?: "?",
            state = r["printer-state"].firstOrNull()?.let { when (it) { "3" -> "idle"; "4" -> "processing"; "5" -> "stopped"; else -> it } } ?: "?",
            formats = formats, sides = sides, resolutions = r["printer-resolution-supported"],
            qualities = r["print-quality-supported"].map { when (it) { "3" -> "draft"; "4" -> "normal"; "5" -> "high"; else -> it } },
            colorModes = r["print-color-mode-supported"], media = r["media-supported"], markers = markers,
            acceptsPdf = formats.any { it == "application/pdf" },
            acceptsRaster = raster,
            hasAutoDuplex = sides.any { it.startsWith("two-sided") },
            hasDraftQuality = r["print-quality-supported"].contains("3"),
            rawCount = r.attrs.size)
    }

    /** Network call (call off the main thread). Tries the given path, returns response or throws. */
    fun query(host: String, port: Int, path: String, timeoutMs: Int = 6000): IppResponse {
        val p = path.trim('/')
        val body = buildGetPrinterAttributes("ipp://$host:$port/$p")
        val conn = URL("http://$host:$port/$p").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"; conn.doOutput = true
            conn.connectTimeout = timeoutMs; conn.readTimeout = timeoutMs
            conn.setRequestProperty("Content-Type", "application/ipp")
            conn.outputStream.use { it.write(body) }
            if (conn.responseCode != 200) throw java.io.IOException("HTTP ${conn.responseCode}")
            return parse(conn.inputStream.use { it.readBytes() })
        } finally { conn.disconnect() }
    }
}
