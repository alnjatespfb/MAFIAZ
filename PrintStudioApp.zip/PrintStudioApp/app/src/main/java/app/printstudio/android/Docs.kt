package app.printstudio.android

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.util.LruCache
import app.printstudio.core.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.Closeable
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

interface CloseableProvider : PageImageProvider, Closeable

interface DocModel {
    val id: String
    val name: String
    val pageCount: Int
    fun pageSize(p: Int): Pair<Double, Double>
    fun openProvider(ctx: Context): CloseableProvider
}

class SourceFile(val fileName: String, val isPdf: Boolean, val sizes: List<Pair<Double, Double>>)

class ImportException(val kind: Kind, msg: String = "") : Exception(msg) {
    enum class Kind { PASSWORD, CORRUPT, UNSUPPORTED, EMPTY }
}

class LoadedDocument(val dir: File, override val id: String, override val name: String, val sources: List<SourceFile>) : DocModel {
    private val index: List<Pair<Int, Int>> = sources.flatMapIndexed { si, s -> s.sizes.indices.map { si to it } }
    override val pageCount get() = index.size
    fun ref(p: Int) = index[p - 1]
    override fun pageSize(p: Int): Pair<Double, Double> { val (s, i) = ref(p); return sources[s].sizes[i] }
    val blank: MutableSet<Int> = ConcurrentHashMap.newKeySet()
    @Volatile var blankScanDone = false

    fun fileOf(src: Int) = File(dir, sources[src].fileName)
    override fun openProvider(ctx: Context): CloseableProvider = DocProvider(this)

    fun save() {
        val o = JSONObject().put("id", id).put("name", name).put("sources", JSONArray(sources.map { s ->
            JSONObject().put("f", s.fileName).put("pdf", s.isPdf).put("sizes", JSONArray(s.sizes.map { JSONArray(listOf(it.first, it.second)) }))
        }))
        File(dir, "doc.json").writeText(o.toString())
    }

    companion object {
        fun root(ctx: Context) = File(ctx.cacheDir, "docs").apply { mkdirs() }
        fun load(ctx: Context, id: String): LoadedDocument? = try {
            val dir = File(root(ctx), id); val o = JSONObject(File(dir, "doc.json").readText())
            val srcs = o.getJSONArray("sources").let { a -> (0 until a.length()).map { a.getJSONObject(it) } }.map { s ->
                SourceFile(s.getString("f"), s.getBoolean("pdf"), s.getJSONArray("sizes").let { a -> (0 until a.length()).map { a.getJSONArray(it).let { p -> p.getDouble(0) to p.getDouble(1) } } })
            }
            if (srcs.any { !File(dir, it.fileName).exists() }) null else LoadedDocument(dir, id, o.getString("name"), srcs)
        } catch (e: Exception) { null }

        /** Copies the picked files into app storage and reads page sizes. Call off the main thread. */
        fun import(ctx: Context, uris: List<Uri>): LoadedDocument {
            val id = System.currentTimeMillis().toString(36)
            val dir = File(root(ctx), id).apply { mkdirs() }
            val srcs = ArrayList<SourceFile>()
            var name = ""
            try {
                uris.forEachIndexed { i, uri ->
                    val mime = ctx.contentResolver.getType(uri) ?: ""
                    val disp = ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: "document"
                    if (i == 0) name = disp
                    val isPdf = mime == "application/pdf" || disp.lowercase().endsWith(".pdf")
                    val f = File(dir, "src$i." + if (isPdf) "pdf" else "img")
                    ctx.contentResolver.openInputStream(uri)?.use { ins -> f.outputStream().use { ins.copyTo(it) } } ?: throw ImportException(ImportException.Kind.CORRUPT)
                    if (isPdf) srcs.add(SourceFile(f.name, true, pdfSizes(f)))
                    else {
                        val (w, h) = imageSize(f) ?: throw ImportException(ImportException.Kind.UNSUPPORTED, disp)
                        srcs.add(SourceFile(f.name, false, listOf(w * 72.0 / 150 to h * 72.0 / 150)))
                    }
                }
                if (uris.size > 1) name = "$name +${uris.size - 1}"
                if (srcs.sumOf { it.sizes.size } == 0) throw ImportException(ImportException.Kind.EMPTY)
                return LoadedDocument(dir, id, name, srcs).also { it.save() }
            } catch (e: Exception) { dir.deleteRecursively(); throw e }
        }

        private fun pdfSizes(f: File): List<Pair<Double, Double>> {
            try {
                ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                    PdfRenderer(pfd).use { r ->
                        return (0 until r.pageCount).map { i -> r.openPage(i).use { it.width.toDouble() to it.height.toDouble() } }
                    }
                }
            } catch (e: SecurityException) { throw ImportException(ImportException.Kind.PASSWORD) }
            catch (e: java.io.IOException) { throw ImportException(ImportException.Kind.CORRUPT) }
        }

        fun exifRotation(f: File): Int = try {
            when (android.media.ExifInterface(f.absolutePath).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90
                android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180
                android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        } catch (e: Exception) { 0 }

        private fun imageSize(f: File): Pair<Int, Int>? {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.absolutePath, o)
            if (o.outWidth <= 0) return null
            return if (exifRotation(f) % 180 == 90) o.outHeight to o.outWidth else o.outWidth to o.outHeight
        }
    }
}

/** Renders pages of a LoadedDocument. PdfRenderer allows one open page at a time, so everything is synchronized. */
class DocProvider(private val doc: LoadedDocument) : CloseableProvider {
    private val renderers = HashMap<Int, Pair<PdfRenderer, ParcelFileDescriptor>>()
    private val lock = Any()
    override fun pageSize(page: Int) = doc.pageSize(page)

    override fun render(page: Int, widthPx: Int, heightPx: Int): PixelBuffer {
        var w = widthPx; var h = heightPx
        val maxPx = 24_000_000.0
        if (w.toDouble() * h > maxPx) { val k = Math.sqrt(maxPx / (w.toDouble() * h)); w = (w * k).toInt(); h = (h * k).toInt() }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        val (si, pi) = doc.ref(page)
        if (doc.sources[si].isPdf) {
            synchronized(lock) {
                val r = renderers.getOrPut(si) {
                    val pfd = ParcelFileDescriptor.open(doc.fileOf(si), ParcelFileDescriptor.MODE_READ_ONLY)
                    PdfRenderer(pfd) to pfd
                }.first
                r.openPage(pi).use { it.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT) }
            }
        } else drawImage(doc.fileOf(si), bmp)
        val px = IntArray(w * h); bmp.getPixels(px, 0, w, 0, 0, w, h); bmp.recycle()
        return if (w == widthPx && h == heightPx) PixelBuffer(w, h, px) else scaleUp(PixelBuffer(w, h, px), widthPx, heightPx)
    }

    private fun scaleUp(b: PixelBuffer, w: Int, h: Int): PixelBuffer {
        val src = Bitmap.createBitmap(b.argb, b.width, b.height, Bitmap.Config.ARGB_8888)
        val dst = Bitmap.createScaledBitmap(src, w, h, true)
        val px = IntArray(w * h); dst.getPixels(px, 0, w, 0, 0, w, h); src.recycle(); dst.recycle()
        return PixelBuffer(w, h, px)
    }

    private fun drawImage(f: File, dst: Bitmap) {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.absolutePath, o)
        var sample = 1
        while (o.outWidth / (sample * 2) >= dst.width && o.outHeight / (sample * 2) >= dst.height) sample *= 2
        val raw = BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return
        val rot = LoadedDocument.exifRotation(f)
        val m = Matrix().apply { if (rot != 0) postRotate(rot.toFloat()) }
        val oriented = if (rot != 0) Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true) else raw
        Canvas(dst).drawBitmap(oriented, null, Rect(0, 0, dst.width, dst.height), Paint(Paint.FILTER_BITMAP_FLAG))
        if (oriented !== raw) oriented.recycle(); raw.recycle()
    }

    override fun close() { synchronized(lock) { renderers.values.forEach { runCatching { it.first.close() }; runCatching { it.second.close() } }; renderers.clear() } }
}

val AndroidJpeg = JpegEncoder { b, q ->
    val bmp = Bitmap.createBitmap(b.argb, b.width, b.height, Bitmap.Config.ARGB_8888)
    val bos = ByteArrayOutputStream(b.width * b.height / 8)
    bmp.compress(Bitmap.CompressFormat.JPEG, q, bos); bmp.recycle(); bos.toByteArray()
}

/** Thumbnails + blank page scan, shared by the pages grid and the sheet preview. */
class Thumbs(private val ctx: Context, private val doc: LoadedDocument) {
    private val cache = object : LruCache<Int, Bitmap>(24 * 1024 * 1024) { override fun sizeOf(k: Int, v: Bitmap) = v.byteCount }
    private val pool = Executors.newFixedThreadPool(2)
    private val scanPool = Executors.newSingleThreadExecutor()
    private val provider by lazy { DocProvider(doc) }
    private val pending = ConcurrentHashMap.newKeySet<Int>()
    @Volatile private var closed = false

    fun peek(page: Int): Bitmap? = cache.get(page)

    fun load(page: Int, widthPx: Int, done: (Bitmap?) -> Unit) {
        cache.get(page)?.let { done(it); return }
        if (!pending.add(page)) return
        pool.execute {
            var bmp: Bitmap? = null
            if (!closed) try {
                val (pw, ph) = doc.pageSize(page)
                val h = (widthPx * ph / pw).toInt().coerceAtLeast(8)
                val px = provider.render(page, widthPx, h)
                bmp = Bitmap.createBitmap(px.argb, px.width, px.height, Bitmap.Config.ARGB_8888)
                cache.put(page, bmp)
            } catch (e: Exception) { }
            pending.remove(page)
            android.os.Handler(android.os.Looper.getMainLooper()).post { done(bmp) }
        }
    }

    fun scanBlank(onProgress: () -> Unit) {
        scanPool.execute {
            for (p in 1..doc.pageCount) {
                if (closed) return@execute
                try {
                    val (pw, ph) = doc.pageSize(p)
                    val px = provider.render(p, 100, (100 * ph / pw).toInt().coerceAtLeast(8))
                    if (BlankDetector.isBlank(px)) doc.blank.add(p)
                } catch (e: Exception) { }
                if (p % 8 == 0) android.os.Handler(android.os.Looper.getMainLooper()).post { onProgress() }
            }
            doc.blankScanDone = true
            android.os.Handler(android.os.Looper.getMainLooper()).post { onProgress() }
        }
    }

    fun close() { closed = true; pool.shutdownNow(); scanPool.shutdownNow(); cache.evictAll(); runCatching { provider.close() } }
}

/** Synthetic 4-page document for the manual-duplex calibration test: SHEET 1 front/back, SHEET 2 front/back. */
class CalibrationDoc : DocModel {
    override val id = "calibration"
    override val name = "Duplex calibration"
    override val pageCount = 4
    override fun pageSize(p: Int) = 595.2756 to 841.8898
    override fun openProvider(ctx: Context): CloseableProvider = object : CloseableProvider {
        override fun pageSize(page: Int) = this@CalibrationDoc.pageSize(page)
        override fun render(page: Int, widthPx: Int, heightPx: Int): PixelBuffer {
            val bmp = Bitmap.createBitmap(widthPx, heightPx, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp); c.drawColor(Color.WHITE)
            val sheet = (page + 1) / 2; val front = page % 2 == 1
            val u = widthPx / 100f
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = u * 1.2f }
            c.drawRect(u, u, widthPx - u, heightPx - u, p)
            p.style = Paint.Style.FILL
            c.drawRect(u * 8, u * 2, widthPx - u * 8, u * 7, p)                       // thick bar on the TOP edge
            p.textAlign = Paint.Align.CENTER; p.textSize = u * 16; p.color = Color.BLACK
            c.drawText(if (front) "FRONT" else "BACK", widthPx / 2f, heightPx * 0.30f, p)
            p.textSize = u * 34; c.drawText("SHEET $sheet", widthPx / 2f, heightPx * 0.46f, p)
            p.textSize = u * 70; c.drawText("▲", widthPx / 2f, heightPx * 0.68f, p)
            p.textSize = u * 12; c.drawText("TOP", widthPx / 2f, heightPx * 0.75f, p)
            p.textAlign = Paint.Align.LEFT; p.textSize = u * 10; c.drawText("L", u * 4, heightPx / 2f, p)
            p.textAlign = Paint.Align.RIGHT; c.drawText("R", widthPx - u * 4, heightPx / 2f, p)
            val px = IntArray(widthPx * heightPx); bmp.getPixels(px, 0, widthPx, 0, 0, widthPx, heightPx); bmp.recycle()
            return PixelBuffer(widthPx, heightPx, px)
        }
        override fun close() {}
    }
}
