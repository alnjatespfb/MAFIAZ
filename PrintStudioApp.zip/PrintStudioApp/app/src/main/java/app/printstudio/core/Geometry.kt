package app.printstudio.core

/** PDF-style affine: x' = a*x + c*y + e ; y' = b*x + d*y + f */
data class Affine(val a: Double, val b: Double, val c: Double, val d: Double, val e: Double, val f: Double) {
    /** this ∘ inner  (inner applied first) */
    fun after(i: Affine) = Affine(
        a * i.a + c * i.b, b * i.a + d * i.b,
        a * i.c + c * i.d, b * i.c + d * i.d,
        a * i.e + c * i.f + e, b * i.e + d * i.f + f)

    fun map(x: Double, y: Double) = (a * x + c * y + e) to (b * x + d * y + f)

    fun mapRect(r: RectD): RectD {
        val pts = listOf(map(r.x, r.y), map(r.right, r.y), map(r.x, r.bottom), map(r.right, r.bottom))
        val x0 = pts.minOf { it.first }; val x1 = pts.maxOf { it.first }
        val y0 = pts.minOf { it.second }; val y1 = pts.maxOf { it.second }
        return RectD(x0, y0, x1 - x0, y1 - y0)
    }

    companion object {
        val IDENTITY = Affine(1.0, 0.0, 0.0, 1.0, 0.0, 0.0)
    }
}

object Geometry {
    /**
     * Maps a side's layout frame (points, origin top-left, y down) to PDF page space (origin bottom-left, y up).
     * [rotate180] turns the whole side upside-down (back sides of manual duplex);
     * if the layout orientation differs from the sheet orientation the layout is turned 90° clockwise onto the sheet.
     */
    fun layoutToPdf(layoutW: Double, layoutH: Double, sheetW: Double, sheetH: Double, rotate180: Boolean): Affine {
        var m = Affine.IDENTITY
        if (rotate180) m = Affine(-1.0, 0.0, 0.0, -1.0, layoutW, layoutH).after(m)
        val layoutLandscape = layoutW > layoutH
        val sheetLandscape = sheetW > sheetH
        if (layoutLandscape != sheetLandscape) {
            // clockwise quarter turn: sx = layoutH - y, sy = x
            m = Affine(0.0, 1.0, -1.0, 0.0, layoutH, 0.0).after(m)
        }
        // y-down -> PDF y-up
        return Affine(1.0, 0.0, 0.0, -1.0, 0.0, sheetH).after(m)
    }

    /** Image-space (unit square, v up) -> layout frame for a page of drawW x drawH centred at (cx,cy). */
    fun imageToLayout(cx: Double, cy: Double, dw: Double, dh: Double, rotated90: Boolean): Affine =
        if (!rotated90) Affine(dw, 0.0, 0.0, -dh, cx - dw / 2, cy + dh / 2)
        else Affine(0.0, dw, dh, 0.0, cx - dh / 2, cy - dw / 2)
}
