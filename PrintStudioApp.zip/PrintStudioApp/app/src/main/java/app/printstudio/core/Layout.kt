package app.printstudio.core

import kotlin.math.max
import kotlin.math.min

data class RectD(val x: Double, val y: Double, val w: Double, val h: Double) {
    val right get() = x + w
    val bottom get() = y + h
    val cx get() = x + w / 2
    val cy get() = y + h / 2
}

/** One page drawn on a side. Coordinates are in the side's layout frame (points, origin top-left, y down). */
data class Placement(
    val sourcePage: Int,           // 1-based
    val slot: RectD,               // clip + border rect
    val drawW: Double,             // size of the upright page after scaling
    val drawH: Double,
    val center: Pair<Double, Double>,
    val rotated90: Boolean,        // page turned 90 degrees clockwise inside slot
    val clip: Boolean,
    val border: Boolean,
)

data class SheetSpec(val widthPt: Double, val heightPt: Double, val minMarginPt: Double = 0.0) {
    val landscape get() = widthPt > heightPt
}

data class GridChoice(val cols: Int, val rows: Int, val landscape: Boolean)

object Layout {
    const val MM = 72.0 / 25.4
    const val GUTTER_PT = 6.0

    fun factorPairs(n: Int): List<Pair<Int, Int>> = (1..n).filter { n % it == 0 }.map { it to n / it }

    /** Slot size (pt) for a grid on a sheet of [w]x[h] minus margins. */
    fun slotSize(w: Double, h: Double, cols: Int, rows: Int, margin: Double, gap: Double): Pair<Double, Double> =
        ((w - 2 * margin - gap * (cols - 1)) / cols) to ((h - 2 * margin - gap * (rows - 1)) / rows)

    /** Best sheet orientation + grid for N pages of aspect pw:ph (points). */
    fun chooseGrid(
        n: Int, pageW: Double, pageH: Double, paperW: Double, paperH: Double, orientation: Orientation,
        marginPt: Double, autoRotate: Boolean,
    ): GridChoice {
        val shortS = min(paperW, paperH); val longS = max(paperW, paperH)
        val orients = when (orientation) {
            Orientation.PORTRAIT -> listOf(false)
            Orientation.LANDSCAPE -> listOf(true)
            Orientation.AUTO -> listOf(false, true)
        }
        var best: GridChoice? = null
        var bestScore = -1.0
        for (land in orients) {
            val w = if (land) longS else shortS
            val h = if (land) shortS else longS
            for ((c, r) in factorPairs(n)) {
                val (sw, sh) = slotSize(w, h, c, r, marginPt, if (n > 1) GUTTER_PT else 0.0)
                if (sw <= 0 || sh <= 0) continue
                // score with un-rotated pages: a layout that needs no page rotation is always preferred
                val sc = min(sw / pageW, sh / pageH)
                // tie-break: keep the orientation of the page itself (landscape pages stay landscape)
                val score = sc + (if (land == (pageW > pageH)) 1e-9 else 0.0)
                if (score > bestScore) { bestScore = score; best = GridChoice(c, r, land) }
            }
        }
        return best ?: GridChoice(1, 1, orientation == Orientation.LANDSCAPE)
    }

    /** Grid cell rectangles in row-major order (left->right, top->bottom). */
    fun cells(w: Double, h: Double, cols: Int, rows: Int, margins: Margins, gap: Double): List<RectD> {
        val x0 = margins.left; val y0 = margins.top
        val cw = (w - margins.left - margins.right - gap * (cols - 1)) / cols
        val ch = (h - margins.top - margins.bottom - gap * (rows - 1)) / rows
        val out = ArrayList<RectD>()
        for (r in 0 until rows) for (c in 0 until cols)
            out.add(RectD(x0 + c * (cw + gap), y0 + r * (ch + gap), cw, ch))
        return out
    }

    fun place(
        page: Int, pw: Double, ph: Double, slot: RectD, s: PrintSettings, allowRotate: Boolean, multi: Boolean,
    ): Placement {
        val rotate: Boolean
        val scale: Double
        var clip = false
        when {
            s.scale == ScaleMode.ACTUAL && !multi -> { scale = 1.0; rotate = false; clip = true }
            s.scale == ScaleMode.CUSTOM && !multi -> { scale = s.customScalePercent / 100.0; rotate = false; clip = true }
            else -> {
                val straight = min(slot.w / pw, slot.h / ph)
                val turned = min(slot.w / ph, slot.h / pw)
                if (allowRotate && s.autoRotatePages && turned > straight * 1.0001) { rotate = true; scale = turned }
                else { rotate = false; scale = straight }
            }
        }
        return Placement(page, slot, pw * scale, ph * scale, slot.cx to slot.cy, rotate, clip, s.pageBorder)
    }
}

data class Margins(val left: Double, val top: Double, val right: Double, val bottom: Double)
