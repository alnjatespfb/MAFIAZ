package app.printstudio.android

import android.content.Context
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import app.printstudio.core.*
import java.io.BufferedOutputStream
import java.io.FileOutputStream
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

interface AdapterListener {
    fun onSheet(part: Int, widthMils: Int, heightMils: Int)
    fun onProgress(part: Int, done: Int, total: Int)
    fun onWritten(part: Int)
    fun onFailed(part: Int, message: String)
}

/**
 * One adapter = one print job = one part of the plan (single pass, front sides, or back sides).
 * The system hands us the REAL media size / margins / resolution chosen in its print dialog; we plan against those.
 * We write a raster PDF that the print service (e.g. Mopria / Samsung Default Print Service) converts for the printer.
 */
class PlanPrintAdapter(
    private val ctx: Context,
    private val doc: DocModel,
    private val settings: PrintSettings,
    private val partIndex: Int,
    private val jobName: String,
    private val blank: Set<Int>,
    private val selected: Set<Int>?,
    private val listener: AdapterListener,
) : PrintDocumentAdapter() {
    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    @Volatile private var plan: JobPlan? = null
    @Volatile private var dpiCap = 0
    private var lastAttrs: PrintAttributes? = null
    private var provider: CloseableProvider? = null

    override fun onLayout(old: PrintAttributes?, new: PrintAttributes, cancel: CancellationSignal, cb: LayoutResultCallback, extras: Bundle?) {
        if (cancel.isCanceled) { cb.onLayoutCancelled(); return }
        val ms = new.mediaSize
        val w = (ms?.widthMils ?: 8268) * 72.0 / 1000.0
        val h = (ms?.heightMils ?: 11692) * 72.0 / 1000.0
        val mm = new.minMargins
        val minMil = if (mm == null) 0 else maxOf(mm.leftMils, mm.topMils, mm.rightMils, mm.bottomMils)
        val sheet = SheetSpec(w, h, minMil * 72.0 / 1000.0)
        dpiCap = new.resolution?.horizontalDpi ?: 0
        val p = Planner.plan(doc.pageCount, doc::pageSize, settings, sheet, blank, selected)
        if (!p.ok) { cb.onLayoutFailed(p.error.toString()); return }
        val part = p.parts.getOrNull(partIndex)
        if (part == null) { cb.onLayoutFailed("no such part"); return }
        plan = p
        listener.onSheet(partIndex, ms?.widthMils ?: 0, ms?.heightMils ?: 0)
        val info = PrintDocumentInfo.Builder(jobName)
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
            .setPageCount(part.sides.size).build()
        cb.onLayoutFinished(info, old == null || old != new || lastAttrs != new)
        lastAttrs = new
    }

    override fun onWrite(pages: Array<out PageRange>, dest: ParcelFileDescriptor, cancel: CancellationSignal, cb: WriteResultCallback) {
        val p = plan
        val part = p?.parts?.getOrNull(partIndex)
        if (p == null || part == null) { cb.onWriteFailed("not laid out"); return }
        val cancelled = AtomicBoolean(false)
        cancel.setOnCancelListener { cancelled.set(true) }
        val total = part.sides.size
        val idx = ArrayList<Int>()
        for (r in pages) {
            if (r == PageRange.ALL_PAGES) { idx.clear(); idx.addAll(0 until total); break }
            for (i in r.start..r.end) if (i in 0 until total && i !in idx) idx.add(i)
        }
        exec.execute {
            try {
                val prov = provider ?: doc.openProvider(ctx).also { provider = it }
                FileOutputStream(dest.fileDescriptor).use { fos ->
                    BufferedOutputStream(fos, 64 * 1024).use { out ->
                        PartPdfWriter(p, settings, prov, AndroidJpeg, dpiCap)
                            .write(part, idx, out, { cancelled.get() || cancel.isCanceled }) { d, n -> main.post { listener.onProgress(partIndex, d, n) } }
                    }
                }
                main.post { listener.onWritten(partIndex); cb.onWriteFinished(pages as Array<PageRange>) }
            } catch (e: CancelledException) {
                main.post { cb.onWriteCancelled() }
            } catch (e: Throwable) {
                val msg = (e.message ?: e.javaClass.simpleName)
                main.post { listener.onFailed(partIndex, msg); cb.onWriteFailed(msg) }
            }
        }
    }

    override fun onFinish() { exec.execute { runCatching { provider?.close() } }; exec.shutdown() }
}
