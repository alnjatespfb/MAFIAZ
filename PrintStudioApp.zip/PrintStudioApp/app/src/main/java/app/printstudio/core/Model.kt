package app.printstudio.core

/** Pure-Kotlin domain model. No android.* imports so everything here is unit-testable on the JVM. */

enum class PaperSize(val id: String, val widthMm: Double, val heightMm: Double) {
    A4("A4", 210.0, 297.0),
    LETTER("LETTER", 215.9, 279.4),
    LEGAL("LEGAL", 215.9, 355.6),
    A5("A5", 148.0, 210.0),
    B5("B5", 176.0, 250.0);
    val widthPt get() = widthMm / 25.4 * 72.0
    val heightPt get() = heightMm / 25.4 * 72.0
}

enum class Orientation { AUTO, PORTRAIT, LANDSCAPE }
enum class ScaleMode { FIT, ACTUAL, CUSTOM }
enum class Parity { ALL, ODD, EVEN }
enum class DuplexMode { OFF, AUTO, MANUAL }
/** BOOK = flip like a book page (binding on the left of the page as read). NOTEPAD = flip upwards (binding on top). */
enum class Binding { BOOK, NOTEPAD }
/** How the paper physically turns over when the user re-inserts it (found with the calibration test). */
enum class ReloadFlip { LONG_EDGE, SHORT_EDGE }
enum class ColorMode { COLOR, GRAYSCALE, BLACK_WHITE }
enum class QualityMode(val dpi: Int, val jpegQuality: Int) { DRAFT(150, 72), NORMAL(200, 86), HIGH(300, 93) }
enum class EcoMode { OFF, SOFTWARE_DRAFT }
enum class EcoStyle { LIGHTEN_ALL, KEEP_TEXT_EDGES }
enum class Preset { EVERYDAY, ECONOMY, BOOK, BOOKLET, HIGH_QUALITY, CUSTOM }

data class PrintSettings(
    val paper: PaperSize = PaperSize.A4,
    val orientation: Orientation = Orientation.AUTO,
    val marginMm: Double = 8.0,
    val gutterMm: Double = 0.0,
    val copies: Int = 1,
    val collate: Boolean = true,
    val parity: Parity = Parity.ALL,
    val rangeText: String = "",
    val reverse: Boolean = false,
    val skipBlank: Boolean = false,
    val selectedOnly: Boolean = false,
    val pagesPerSheet: Int = 1,
    val pageBorder: Boolean = false,
    val nUpRtl: Boolean = false,
    val autoRotatePages: Boolean = true,
    val scale: ScaleMode = ScaleMode.FIT,
    val customScalePercent: Int = 100,
    val duplex: DuplexMode = DuplexMode.OFF,
    val binding: Binding = Binding.BOOK,
    // calibration results (manual duplex)
    val reverseSecondJob: Boolean = true,
    val reloadFlip: ReloadFlip = ReloadFlip.LONG_EDGE,
    // booklet
    val booklet: Boolean = false,
    val bookletRtl: Boolean = false,
    /** 0 = one nested fold; N = N sheets per signature */
    val bookletSignatureSheets: Int = 0,
    // quality
    val quality: QualityMode = QualityMode.NORMAL,
    val color: ColorMode = ColorMode.GRAYSCALE,
    val contrast: Int = 0,
    val darkness: Int = 0,
    val optimizeImages: Boolean = true,
    val eco: EcoMode = EcoMode.OFF,
    val ecoStrength: Int = 40,
    val ecoStyle: EcoStyle = EcoStyle.KEEP_TEXT_EDGES,
    val preset: Preset = Preset.EVERYDAY,
) {
    fun toMap(): Map<String, String> = mapOf(
        "paper" to paper.name, "orientation" to orientation.name, "marginMm" to marginMm.toString(),
        "gutterMm" to gutterMm.toString(), "copies" to copies.toString(), "collate" to collate.toString(),
        "parity" to parity.name, "rangeText" to rangeText, "reverse" to reverse.toString(),
        "skipBlank" to skipBlank.toString(), "selectedOnly" to selectedOnly.toString(),
        "pagesPerSheet" to pagesPerSheet.toString(), "pageBorder" to pageBorder.toString(),
        "nUpRtl" to nUpRtl.toString(), "autoRotatePages" to autoRotatePages.toString(),
        "scale" to scale.name, "customScalePercent" to customScalePercent.toString(),
        "duplex" to duplex.name, "binding" to binding.name,
        "reverseSecondJob" to reverseSecondJob.toString(), "reloadFlip" to reloadFlip.name,
        "booklet" to booklet.toString(), "bookletRtl" to bookletRtl.toString(),
        "bookletSignatureSheets" to bookletSignatureSheets.toString(),
        "quality" to quality.name, "color" to color.name, "contrast" to contrast.toString(),
        "darkness" to darkness.toString(), "optimizeImages" to optimizeImages.toString(),
        "eco" to eco.name, "ecoStrength" to ecoStrength.toString(), "ecoStyle" to ecoStyle.name,
        "preset" to preset.name,
    )

    companion object {
        private inline fun <reified E : Enum<E>> Map<String, String>.en(k: String, d: E): E =
            this[k]?.let { v -> enumValues<E>().firstOrNull { it.name == v } } ?: d

        fun fromMap(m: Map<String, String>, d: PrintSettings = PrintSettings()): PrintSettings = PrintSettings(
            paper = m.en("paper", d.paper), orientation = m.en("orientation", d.orientation),
            marginMm = m["marginMm"]?.toDoubleOrNull() ?: d.marginMm,
            gutterMm = m["gutterMm"]?.toDoubleOrNull() ?: d.gutterMm,
            copies = m["copies"]?.toIntOrNull()?.coerceIn(1, 99) ?: d.copies,
            collate = m["collate"]?.toBooleanStrictOrNull() ?: d.collate,
            parity = m.en("parity", d.parity), rangeText = m["rangeText"] ?: d.rangeText,
            reverse = m["reverse"]?.toBooleanStrictOrNull() ?: d.reverse,
            skipBlank = m["skipBlank"]?.toBooleanStrictOrNull() ?: d.skipBlank,
            selectedOnly = m["selectedOnly"]?.toBooleanStrictOrNull() ?: d.selectedOnly,
            pagesPerSheet = m["pagesPerSheet"]?.toIntOrNull()?.takeIf { it in NUP_VALUES } ?: d.pagesPerSheet,
            pageBorder = m["pageBorder"]?.toBooleanStrictOrNull() ?: d.pageBorder,
            nUpRtl = m["nUpRtl"]?.toBooleanStrictOrNull() ?: d.nUpRtl,
            autoRotatePages = m["autoRotatePages"]?.toBooleanStrictOrNull() ?: d.autoRotatePages,
            scale = m.en("scale", d.scale),
            customScalePercent = m["customScalePercent"]?.toIntOrNull()?.coerceIn(10, 400) ?: d.customScalePercent,
            duplex = m.en("duplex", d.duplex), binding = m.en("binding", d.binding),
            reverseSecondJob = m["reverseSecondJob"]?.toBooleanStrictOrNull() ?: d.reverseSecondJob,
            reloadFlip = m.en("reloadFlip", d.reloadFlip),
            booklet = m["booklet"]?.toBooleanStrictOrNull() ?: d.booklet,
            bookletRtl = m["bookletRtl"]?.toBooleanStrictOrNull() ?: d.bookletRtl,
            bookletSignatureSheets = m["bookletSignatureSheets"]?.toIntOrNull()?.coerceIn(0, 40) ?: d.bookletSignatureSheets,
            quality = m.en("quality", d.quality), color = m.en("color", d.color),
            contrast = m["contrast"]?.toIntOrNull()?.coerceIn(-50, 50) ?: d.contrast,
            darkness = m["darkness"]?.toIntOrNull()?.coerceIn(-50, 50) ?: d.darkness,
            optimizeImages = m["optimizeImages"]?.toBooleanStrictOrNull() ?: d.optimizeImages,
            eco = m.en("eco", d.eco), ecoStrength = m["ecoStrength"]?.toIntOrNull()?.coerceIn(0, 90) ?: d.ecoStrength,
            ecoStyle = m.en("ecoStyle", d.ecoStyle), preset = m.en("preset", d.preset),
        )
    }
}

val NUP_VALUES = listOf(1, 2, 4, 6, 9, 16)

object Presets {
    fun apply(p: Preset, base: PrintSettings): PrintSettings = when (p) {
        Preset.EVERYDAY -> base.copy(
            preset = p, pagesPerSheet = 1, booklet = false, duplex = DuplexMode.OFF, quality = QualityMode.NORMAL,
            color = ColorMode.GRAYSCALE, eco = EcoMode.OFF, scale = ScaleMode.FIT, marginMm = 8.0, gutterMm = 0.0,
            optimizeImages = true, contrast = 0, darkness = 0)
        Preset.ECONOMY -> base.copy(
            preset = p, pagesPerSheet = 1, booklet = false, duplex = DuplexMode.MANUAL, binding = Binding.BOOK,
            quality = QualityMode.DRAFT, color = ColorMode.GRAYSCALE, eco = EcoMode.SOFTWARE_DRAFT, ecoStrength = 40,
            ecoStyle = EcoStyle.KEEP_TEXT_EDGES, scale = ScaleMode.FIT, marginMm = 8.0, gutterMm = 0.0)
        Preset.BOOK -> base.copy(
            preset = p, pagesPerSheet = 1, booklet = false, duplex = DuplexMode.MANUAL, binding = Binding.BOOK,
            quality = QualityMode.NORMAL, color = ColorMode.GRAYSCALE, eco = EcoMode.OFF, scale = ScaleMode.FIT,
            marginMm = 12.0, gutterMm = 8.0)
        Preset.BOOKLET -> base.copy(
            preset = p, booklet = true, pagesPerSheet = 1, duplex = DuplexMode.MANUAL, binding = Binding.BOOK,
            quality = QualityMode.NORMAL, color = ColorMode.GRAYSCALE, eco = EcoMode.OFF, marginMm = 8.0, gutterMm = 0.0)
        Preset.HIGH_QUALITY -> base.copy(
            preset = p, pagesPerSheet = 1, booklet = false, duplex = DuplexMode.OFF, quality = QualityMode.HIGH,
            optimizeImages = false, eco = EcoMode.OFF, scale = ScaleMode.FIT, marginMm = 6.0, gutterMm = 0.0)
        Preset.CUSTOM -> base.copy(preset = p)
    }

    /** After the user edits a single control, mark as CUSTOM unless it still equals the preset it came from. */
    fun detect(s: PrintSettings): Preset {
        if (s.preset == Preset.CUSTOM) return Preset.CUSTOM
        val ref = apply(s.preset, s)
        return if (ref.copy(preset = s.preset) == s) s.preset else Preset.CUSTOM
    }
}
