package app.printstudio.core

sealed class RangeResult {
    data class Ok(val pages: List<Int>) : RangeResult()
    data class Error(val token: String, val reason: Reason) : RangeResult()
    enum class Reason { SYNTAX, OUT_OF_RANGE }
}

object PageSelection {
    /** Parses "1-3, 5, 8-" (1-based). Empty text => all pages. Result is sorted & de-duplicated. */
    fun parseRanges(text: String, pageCount: Int): RangeResult {
        val t = text.trim()
        if (t.isEmpty()) return RangeResult.Ok((1..pageCount).toList())
        val out = sortedSetOf<Int>()
        for (raw in t.split(',', ';', '،')) {
            val tok = raw.trim().replace(" ", "")
            if (tok.isEmpty()) continue
            val parts = tok.split('-', '–')
            if (parts.size > 2) return RangeResult.Error(tok, RangeResult.Reason.SYNTAX)
            val a: Int; val b: Int
            if (parts.size == 1) {
                a = parts[0].toIntOrNull() ?: return RangeResult.Error(tok, RangeResult.Reason.SYNTAX)
                b = a
            } else {
                a = if (parts[0].isEmpty()) 1 else parts[0].toIntOrNull() ?: return RangeResult.Error(tok, RangeResult.Reason.SYNTAX)
                b = if (parts[1].isEmpty()) pageCount else parts[1].toIntOrNull() ?: return RangeResult.Error(tok, RangeResult.Reason.SYNTAX)
            }
            if (a < 1 || b < 1 || a > pageCount || b > pageCount) return RangeResult.Error(tok, RangeResult.Reason.OUT_OF_RANGE)
            val lo = minOf(a, b); val hi = maxOf(a, b)
            for (p in lo..hi) out.add(p)
        }
        if (out.isEmpty()) return RangeResult.Error(t, RangeResult.Reason.SYNTAX)
        return RangeResult.Ok(out.toList())
    }

    /**
     * Pipeline: ranges -> parity (on source page numbers) -> blank skip -> selected-only -> reverse.
     * Returns 1-based source page numbers in print order.
     */
    fun select(
        pageCount: Int, s: PrintSettings, blankPages: Set<Int>, selected: Set<Int>?,
    ): RangeResult {
        val base = when (val r = parseRanges(s.rangeText, pageCount)) {
            is RangeResult.Error -> return r
            is RangeResult.Ok -> r.pages
        }
        var p = base
        p = when (s.parity) {
            Parity.ALL -> p
            Parity.ODD -> p.filter { it % 2 == 1 }
            Parity.EVEN -> p.filter { it % 2 == 0 }
        }
        if (s.skipBlank) p = p.filter { it !in blankPages }
        if (s.selectedOnly && !selected.isNullOrEmpty()) p = p.filter { it in selected }
        if (s.reverse && !s.booklet) p = p.reversed()
        return RangeResult.Ok(p)
    }
}
