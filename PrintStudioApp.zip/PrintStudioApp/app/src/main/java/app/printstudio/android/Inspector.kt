package app.printstudio.android

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.provider.Settings

data class PrintServiceInfo(val label: String, val pkg: String, val enabled: Boolean)
data class FoundPrinter(val name: String, val host: String, val port: Int, val rp: String, val txt: Map<String, String>)

object Inspector {
    /** Print services installed on this phone (the things that actually talk to the printer). */
    fun printServices(ctx: Context): List<PrintServiceInfo> {
        val pm = ctx.packageManager
        val enabled = try { Settings.Secure.getString(ctx.contentResolver, "enabled_print_services") ?: "" } catch (e: Exception) { "" }
        val set = enabled.split(':').filter { it.isNotBlank() }.toSet()
        return try {
            pm.queryIntentServices(Intent("android.printservice.PrintService"), 0).map {
                val cn = ComponentName(it.serviceInfo.packageName, it.serviceInfo.name)
                PrintServiceInfo(it.loadLabel(pm).toString(), it.serviceInfo.packageName, cn.flattenToString() in set || cn.flattenToShortString() in set)
            }
        } catch (e: Exception) { emptyList() }
    }

    fun systemPrintSettingsIntent() = Intent(Settings.ACTION_PRINT_SETTINGS)
}

/** mDNS/Bonjour discovery of IPP printers (read-only; used to fill in the inspector). */
class PrinterDiscovery(ctx: Context, private val onFound: (FoundPrinter) -> Unit, private val onError: (String) -> Unit) {
    private val nsd = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val queue = ArrayDeque<NsdServiceInfo>()
    private var resolving = false
    private var listener: NsdManager.DiscoveryListener? = null

    private fun resolveNext() {
        if (resolving) return
        val next = queue.removeFirstOrNull() ?: return
        resolving = true
        @Suppress("DEPRECATION")
        nsd.resolveService(next, object : NsdManager.ResolveListener {
            override fun onResolveFailed(s: NsdServiceInfo?, code: Int) { resolving = false; resolveNext() }
            override fun onServiceResolved(s: NsdServiceInfo) {
                resolving = false
                val txt = s.attributes.mapValues { String(it.value ?: ByteArray(0), Charsets.UTF_8) }
                @Suppress("DEPRECATION")
                val host = s.host?.hostAddress
                if (host != null) onFound(FoundPrinter(s.serviceName, host, s.port, txt["rp"] ?: "ipp/print", txt))
                resolveNext()
            }
        })
    }

    fun start() {
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String?) {}
            override fun onDiscoveryStopped(t: String?) {}
            override fun onStartDiscoveryFailed(t: String?, code: Int) { onError("mDNS error $code") }
            override fun onStopDiscoveryFailed(t: String?, code: Int) {}
            override fun onServiceLost(s: NsdServiceInfo?) {}
            override fun onServiceFound(s: NsdServiceInfo) { queue.add(s); resolveNext() }
        }
        listener = l
        try { nsd.discoverServices("_ipp._tcp", NsdManager.PROTOCOL_DNS_SD, l) } catch (e: Exception) { onError(e.message ?: "error") }
    }

    fun stop() { listener?.let { try { nsd.stopServiceDiscovery(it) } catch (e: Exception) { } }; listener = null }
}
