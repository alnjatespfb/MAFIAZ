package app.printstudio.core

import java.awt.image.BufferedImage
import java.io.ByteArrayOutputStream
import javax.imageio.IIOImage
import javax.imageio.ImageIO
import javax.imageio.ImageWriteParam

val A4 = SheetSpec(595.2756, 841.8898)
fun portraitSize(@Suppress("UNUSED_PARAMETER") p: Int) = 595.2756 to 841.8898

class FakeProvider(val sizes: (Int) -> Pair<Double, Double> = ::portraitSize) : PageImageProvider {
    val rendered = ArrayList<Int>()
    override fun pageSize(page: Int) = sizes(page)
    override fun render(page: Int, widthPx: Int, heightPx: Int): PixelBuffer {
        rendered.add(page)
        val px = IntArray(widthPx * heightPx) { 0xFFFFFFFF.toInt() }
        for (y in heightPx / 4 until heightPx / 4 + 6) for (x in widthPx / 4 until widthPx * 3 / 4) px[y * widthPx + x] = 0xFF000000.toInt()
        return PixelBuffer(widthPx, heightPx, px)
    }
}

val TestJpeg = JpegEncoder { b, q ->
    val img = BufferedImage(b.width, b.height, BufferedImage.TYPE_INT_RGB)
    img.setRGB(0, 0, b.width, b.height, b.argb, 0, b.width)
    val w = ImageIO.getImageWritersByFormatName("jpeg").next()
    val p = w.defaultWriteParam; p.compressionMode = ImageWriteParam.MODE_EXPLICIT; p.compressionQuality = q / 100f
    val bos = ByteArrayOutputStream()
    ImageIO.createImageOutputStream(bos).use { ios -> w.output = ios; w.write(null, IIOImage(img, null, null), p) }
    w.dispose(); bos.toByteArray()
}

fun plan(pages: Int, s: PrintSettings, blank: Set<Int> = emptySet(), selected: Set<Int>? = null, size: (Int) -> Pair<Double, Double> = ::portraitSize) =
    Planner.plan(pages, size, s, A4, blank, selected)

fun JobPart.pageLists() = sides.map { it.side.pages }
