package app.printstudio.core

import org.junit.Assert.*
import org.junit.Test

class PageSelectionTest {
    @Test fun rangesParse() {
        assertEquals((1..5).toList(), (PageSelection.parseRanges("", 5) as RangeResult.Ok).pages)
        assertEquals(listOf(1, 2, 3, 5, 8, 9, 10), (PageSelection.parseRanges("1-3, 5, 8-", 10) as RangeResult.Ok).pages)
        assertEquals(listOf(2, 3, 4), (PageSelection.parseRanges("4-2", 10) as RangeResult.Ok).pages)
        assertEquals(listOf(1, 2, 3), (PageSelection.parseRanges("-3", 10) as RangeResult.Ok).pages)
        assertEquals(listOf(3), (PageSelection.parseRanges("3,3,3", 10) as RangeResult.Ok).pages)
    }
    @Test fun rangeErrors() {
        assertTrue(PageSelection.parseRanges("abc", 10) is RangeResult.Error)
        assertEquals(RangeResult.Reason.OUT_OF_RANGE, (PageSelection.parseRanges("1-11", 10) as RangeResult.Error).reason)
        assertEquals(RangeResult.Reason.OUT_OF_RANGE, (PageSelection.parseRanges("0", 10) as RangeResult.Error).reason)
        assertEquals(RangeResult.Reason.SYNTAX, (PageSelection.parseRanges("1-2-3", 10) as RangeResult.Error).reason)
    }
    @Test fun oddEvenReverseBlankSelected() {
        fun sel(s: PrintSettings, blank: Set<Int> = emptySet(), selected: Set<Int>? = null) =
            (PageSelection.select(10, s, blank, selected) as RangeResult.Ok).pages
        assertEquals(listOf(1, 3, 5, 7, 9), sel(PrintSettings(parity = Parity.ODD)))
        assertEquals(listOf(2, 4, 6, 8, 10), sel(PrintSettings(parity = Parity.EVEN)))
        assertEquals(listOf(9, 7, 5, 3, 1), sel(PrintSettings(parity = Parity.ODD, reverse = true)))
        assertEquals(listOf(4, 6), sel(PrintSettings(parity = Parity.EVEN, rangeText = "3-7")))
        assertEquals(listOf(1, 2, 4, 5, 6, 7, 8, 9, 10), sel(PrintSettings(skipBlank = true), blank = setOf(3)))
        assertEquals(listOf(3), sel(PrintSettings(skipBlank = false), blank = setOf(3), selected = null).filter { it == 3 })
        assertEquals(listOf(2, 5), sel(PrintSettings(selectedOnly = true), selected = setOf(5, 2)))
        assertEquals((1..10).toList(), sel(PrintSettings(selectedOnly = true), selected = emptySet()))
    }
}

class SimplexAndNUpTest {
    @Test fun oneUp() {
        val p = plan(3, PrintSettings())
        assertEquals(listOf(listOf(1), listOf(2), listOf(3)), p.parts.single().pageLists())
        assertEquals(PartKind.SINGLE, p.parts.single().kind)
    }
    @Test fun nUpPaddingAndOrder() {
        for (n in NUP_VALUES.filter { it > 1 }) {
            val p = plan(20, PrintSettings(pagesPerSheet = n))
            val sides = p.parts.single().pageLists()
            assertEquals("n=$n sides", (20 + n - 1) / n, sides.size)
            assertEquals((1..20).toList(), sides.flatten().filterNotNull())
            assertTrue(sides.all { it.size == n })
            assertEquals(p.grid.cols * p.grid.rows, n)
        }
    }
    @Test fun nUpRtlMirrorsRows() {
        val p = plan(4, PrintSettings(pagesPerSheet = 4, nUpRtl = true, orientation = Orientation.PORTRAIT))
        assertEquals(listOf(listOf(2, 1, 4, 3)), p.parts.single().pageLists())
    }
    @Test fun twoUpPicksLandscapeForPortraitPages() {
        val p = plan(4, PrintSettings(pagesPerSheet = 2))
        assertTrue(p.layoutLandscape); assertEquals(2, p.grid.cols)
    }
    @Test fun landscapeDocStaysLandscapeOneUp() {
        val p = plan(2, PrintSettings(), size = { 841.89 to 595.28 })
        assertTrue(p.layoutLandscape)
    }
    @Test fun portraitDocPortrait() { assertFalse(plan(2, PrintSettings()).layoutLandscape) }
    @Test fun forcedOrientation() {
        assertTrue(plan(2, PrintSettings(orientation = Orientation.LANDSCAPE)).layoutLandscape)
        assertFalse(plan(2, PrintSettings(orientation = Orientation.PORTRAIT, pagesPerSheet = 2)).layoutLandscape)
    }
    @Test fun fitScaleAndActualSize() {
        val fit = plan(1, PrintSettings(marginMm = 0.0)).parts.single().sides.single().side.placements.single()
        assertEquals(595.2756, fit.drawW, 0.01); assertFalse(fit.clip)
        val actual = plan(1, PrintSettings(scale = ScaleMode.ACTUAL, marginMm = 10.0)).parts.single().sides.single().side.placements.single()
        assertEquals(595.2756, actual.drawW, 0.001); assertTrue(actual.clip)
        val custom = plan(1, PrintSettings(scale = ScaleMode.CUSTOM, customScalePercent = 50)).parts.single().sides.single().side.placements.single()
        assertEquals(595.2756 / 2, custom.drawW, 0.001)
        val nup = plan(4, PrintSettings(scale = ScaleMode.ACTUAL, pagesPerSheet = 4))
        assertTrue(PlanWarning.ACTUAL_IGNORED_NUP in nup.warnings)
    }
    @Test fun marginsAndHardwareMinimum() {
        val s = PrintSettings(marginMm = 1.0)
        val p = Planner.plan(1, ::portraitSize, s, SheetSpec(595.2756, 841.8898, minMarginPt = 12.0))
        val slot = p.parts.single().sides.single().side.placements.single().slot
        assertEquals(12.0, slot.x, 0.001)
    }
    @Test fun emptyAndErrors() {
        assertEquals(PlanError.NO_PAGES, plan(3, PrintSettings(rangeText = "2", parity = Parity.ODD)).error)
        assertEquals(PlanError.RANGE_OUT_OF_RANGE, plan(3, PrintSettings(rangeText = "9")).error)
        assertEquals(PlanError.RANGE_SYNTAX, plan(3, PrintSettings(rangeText = "x")).error)
    }
    @Test fun copiesCollated() {
        val p = plan(3, PrintSettings(copies = 2, collate = true))
        assertEquals(listOf(1, 2, 3, 1, 2, 3), p.parts.single().pageLists().flatten())
        val u = plan(3, PrintSettings(copies = 2, collate = false))
        assertEquals(listOf(1, 1, 2, 2, 3, 3), u.parts.single().pageLists().flatten())
    }
}

class ManualDuplexTest {
    private val manual = PrintSettings(duplex = DuplexMode.MANUAL)
    @Test fun oddCountFrontsAndReversedBacks() {
        val p = plan(5, manual)
        assertEquals(2, p.parts.size)
        assertEquals(listOf(listOf(1), listOf(3), listOf(5)), p.parts[0].pageLists())
        // 5 pages => back of sheet 3 is a BLANK page that must still be sent so the stack stays in sync
        assertEquals(listOf(listOf(null), listOf(4), listOf(2)), p.parts[1].pageLists())
        assertEquals(3, p.physicalSheets)
    }
    @Test fun evenCountBacks() {
        val p = plan(6, manual)
        assertEquals(listOf(listOf(1), listOf(3), listOf(5)), p.parts[0].pageLists())
        assertEquals(listOf(listOf(6), listOf(4), listOf(2)), p.parts[1].pageLists())
    }
    @Test fun forwardSecondJob() {
        val p = plan(6, manual.copy(reverseSecondJob = false))
        assertEquals(listOf(listOf(2), listOf(4), listOf(6)), p.parts[1].pageLists())
    }
    @Test fun oddEvenSheetRelation() {
        // every sheet: front page n is physically behind back page n+1
        val p = plan(8, manual.copy(reverseSecondJob = false))
        p.parts[0].pageLists().zip(p.parts[1].pageLists()).forEach { (f, b) -> assertEquals(f[0]!! + 1, b[0]) }
    }
    @Test fun copiesCollatedDuplex() {
        val p = plan(4, manual.copy(copies = 2))
        assertEquals(listOf(1, 3, 1, 3), p.parts[0].pageLists().flatten())
        assertEquals(listOf(4, 2, 4, 2), p.parts[1].pageLists().flatten())
    }
    @Test fun copiesUncollatedDuplex() {
        val p = plan(4, manual.copy(copies = 2, collate = false))
        assertEquals(listOf(1, 1, 3, 3), p.parts[0].pageLists().flatten())
        assertEquals(listOf(4, 4, 2, 2), p.parts[1].pageLists().flatten())
    }
    @Test fun twoUpDuplex() {
        val p = plan(9, manual.copy(pagesPerSheet = 2))
        // sides: [1,2][3,4][5,6][7,8][9,_] -> sheets (s1,s2)(s3,s4)(s5,blank)
        assertEquals(listOf(listOf(1, 2), listOf(5, 6), listOf(9, null)), p.parts[0].pageLists())
        assertEquals(listOf(listOf(null, null), listOf(7, 8), listOf(3, 4)), p.parts[1].pageLists())
    }
    @Test fun backRotationBookVsNotepad() {
        val book = plan(4, manual.copy(binding = Binding.BOOK, reloadFlip = ReloadFlip.LONG_EDGE))
        assertTrue(book.parts[1].sides.none { it.rotate180 }); assertTrue(book.parts[0].sides.none { it.rotate180 })
        val note = plan(4, manual.copy(binding = Binding.NOTEPAD, reloadFlip = ReloadFlip.LONG_EDGE))
        assertTrue(note.parts[1].sides.all { it.rotate180 })
        val noteShort = plan(4, manual.copy(binding = Binding.NOTEPAD, reloadFlip = ReloadFlip.SHORT_EDGE))
        assertTrue(noteShort.parts[1].sides.none { it.rotate180 })
        val bookShort = plan(4, manual.copy(binding = Binding.BOOK, reloadFlip = ReloadFlip.SHORT_EDGE))
        assertTrue(bookShort.parts[1].sides.all { it.rotate180 })
    }
    @Test fun landscapeLayoutSwapsFlipAxis() {
        // landscape layout + book binding => paper turns on its SHORT edge. With reload=SHORT no extra rotation.
        val l = plan(4, manual.copy(orientation = Orientation.LANDSCAPE, binding = Binding.BOOK, reloadFlip = ReloadFlip.SHORT_EDGE))
        assertTrue(l.parts[1].sides.none { it.rotate180 })
        val l2 = plan(4, manual.copy(orientation = Orientation.LANDSCAPE, binding = Binding.BOOK, reloadFlip = ReloadFlip.LONG_EDGE))
        assertTrue(l2.parts[1].sides.all { it.rotate180 })
    }
    @Test fun gutterSides() {
        val p = plan(2, manual.copy(gutterMm = 10.0, marginMm = 10.0))
        val front = p.parts[0].sides[0].side.placements[0].slot
        val back = p.parts[1].sides[0].side.placements[0].slot
        assertTrue(front.x > back.x)                       // front gutter on the left
        assertTrue(front.right > back.right - 0.001 || back.right < front.right + 1) // back gutter on the right
        assertEquals(front.w, back.w, 0.001)
    }
    @Test fun autoDuplexSequenceAndBlankDrop() {
        val p = plan(5, PrintSettings(duplex = DuplexMode.AUTO))
        assertEquals(1, p.parts.size)
        assertEquals(listOf(1, 2, 3, 4, 5), p.parts[0].pageLists().flatten().filterNotNull())
        assertEquals(5, p.parts[0].sides.size)           // trailing blank back not sent
    }
}

class BookletTest {
    private fun booklet(n: Int, extra: PrintSettings.() -> PrintSettings = { this }) =
        plan(n, PrintSettings(booklet = true, duplex = DuplexMode.MANUAL).extra())

    @Test fun eightPageImposition() {
        val p = booklet(8, { copy(reverseSecondJob = false) })
        assertEquals(listOf(listOf(8, 1), listOf(6, 3)), p.parts[0].pageLists().map { it.toList() })
        assertEquals(listOf(listOf(2, 7), listOf(4, 5)), p.parts[1].pageLists().map { it.toList() })
        assertTrue(p.layoutLandscape)
    }
    @Test fun reversedBackJob() {
        val p = booklet(8)
        assertEquals(listOf(listOf(4, 5), listOf(2, 7)), p.parts[1].pageLists())
    }
    @Test fun blankPaddingForNonMultipleOfFour() {
        val p = booklet(5, { copy(reverseSecondJob = false) })
        // 5 pages -> 8 slots; blanks are pages 6..8 => nulls
        assertEquals(listOf(listOf(null, 1), listOf(null, 3)), p.parts[0].pageLists())
        assertEquals(listOf(listOf(2, null), listOf(4, 5)), p.parts[1].pageLists())
        assertTrue(PlanWarning.BLANK_PAGES_ADDED in p.warnings); assertEquals(3, p.warningDetail)
        // every page appears exactly once
        val all = (p.parts[0].pageLists() + p.parts[1].pageLists()).flatten().filterNotNull().sorted()
        assertEquals(listOf(1, 2, 3, 4, 5), all)
    }
    @Test fun singlePage() {
        val p = booklet(1, { copy(reverseSecondJob = false) })
        assertEquals(1, p.physicalSheets)
        assertEquals(listOf(listOf(null, 1)), p.parts[0].pageLists())
        assertEquals(listOf(listOf(null, null)), p.parts[1].pageLists())
    }
    @Test fun rtlBooklet() {
        val p = booklet(4, { copy(bookletRtl = true, reverseSecondJob = false) })
        assertEquals(listOf(listOf(1, 4)), p.parts[0].pageLists())
        assertEquals(listOf(listOf(3, 2)), p.parts[1].pageLists())
    }
    @Test fun signatures() {
        val p = booklet(16, { copy(bookletSignatureSheets = 2, reverseSecondJob = false) })
        // 2 sheets per signature = 8 pages per signature
        assertEquals(listOf(listOf(8, 1), listOf(6, 3), listOf(16, 9), listOf(14, 11)), p.parts[0].pageLists())
        assertEquals(4, p.physicalSheets)
    }
    @Test fun signaturePadsEachChunk() {
        val p = booklet(10, { copy(bookletSignatureSheets = 2, reverseSecondJob = false) })
        // chunk1 = 1..8, chunk2 = 9,10 padded to 12-> 4 slots
        assertEquals(listOf(listOf(8, 1), listOf(6, 3), listOf(null, 9)), p.parts[0].pageLists())
        assertEquals(3, p.physicalSheets)
    }
    @Test fun everyPageOnceFoldPairsSumToNPlus1() {
        for (n in 1..40) {
            val p = booklet(n, { copy(reverseSecondJob = false) })
            val m = ((n + 3) / 4) * 4
            val sheets = p.parts[0].pageLists().zip(p.parts[1].pageLists())
            val seen = ArrayList<Int>()
            for ((f, b) in sheets) {
                seen += (f + b).filterNotNull()
                // physically adjacent (same side of fold): left-front with right-back and right-front with left-back
                // fold pairs: the two pages on one side always add up to m+1 (single nested fold)
                if (f[0] != null && f[1] != null) assertEquals("n=$n front", m + 1, f[0]!! + f[1]!!)
                if (b[0] != null && b[1] != null) assertEquals("n=$n back", m + 1, b[0]!! + b[1]!!)
                // right page of the front is physically behind the left page of the back
                if (f[1] != null && b[0] != null) assertEquals(f[1]!! + 1, b[0])
            }
            assertEquals((1..n).toList(), seen.sorted())
        }
    }
    @Test fun bookletNeedsDuplexWarning() {
        val p = plan(8, PrintSettings(booklet = true, duplex = DuplexMode.OFF))
        assertTrue(PlanWarning.BOOKLET_NEEDS_DUPLEX in p.warnings)
        assertEquals(2, p.parts.size)
    }
    @Test fun reverseIgnoredInBooklet() {
        val a = booklet(8, { copy(reverse = true, reverseSecondJob = false) })
        assertTrue(PlanWarning.REVERSE_IGNORED_BOOKLET in a.warnings)
        assertEquals(listOf(8, 1), a.parts[0].pageLists()[0].toList())
    }
    @Test fun bookletBackFlipIsBookStyleOnLandscapeLayout() {
        // landscape layout + book style => paper turns on the SHORT edge; default reload is LONG -> back rotated 180
        val p = booklet(8)
        assertTrue(p.parts[1].sides.all { it.rotate180 })
        val q = booklet(8, { copy(reloadFlip = ReloadFlip.SHORT_EDGE) })
        assertTrue(q.parts[1].sides.none { it.rotate180 })
    }
}

class GeometryTest {
    @Test fun portraitIdentityMapsTopLeftToPdfTopLeft() {
        val m = Geometry.layoutToPdf(595.0, 842.0, 595.0, 842.0, false)
        assertEquals(0.0 to 842.0, m.map(0.0, 0.0))
        assertEquals(595.0 to 0.0, m.map(595.0, 842.0))
    }
    @Test fun rotate180() {
        val m = Geometry.layoutToPdf(595.0, 842.0, 595.0, 842.0, true)
        assertEquals(595.0 to 0.0, m.map(0.0, 0.0))
    }
    @Test fun landscapeLayoutTurnsClockwiseOntoPortraitSheet() {
        val m = Geometry.layoutToPdf(842.0, 595.0, 595.0, 842.0, false)
        // layout top-left (0,0) -> sheet top-right
        assertEquals(595.0 to 842.0, m.map(0.0, 0.0))
        // layout top-right (842,0) -> sheet bottom-right
        assertEquals(595.0 to 0.0, m.map(842.0, 0.0))
        // layout bottom-left (0,595) -> sheet top-left
        assertEquals(0.0 to 842.0, m.map(0.0, 595.0))
    }
    @Test fun imageUnrotatedCornersMatchRect() {
        val a = Geometry.imageToLayout(100.0, 200.0, 50.0, 80.0, false)
        assertEquals(75.0 to 240.0, a.map(0.0, 0.0))   // image bottom-left -> layout (x0, y bottom)
        assertEquals(125.0 to 160.0, a.map(1.0, 1.0))  // image top-right
    }
    @Test fun imageRotatedTopPointsRight() {
        val a = Geometry.imageToLayout(100.0, 100.0, 50.0, 80.0, true)
        val top = a.map(0.5, 1.0); val bottom = a.map(0.5, 0.0)
        assertTrue(top.first > bottom.first)             // top of the page now points to the right
    }
}

class ImagingAndPdfTest {
    private fun solid(w: Int, h: Int, c: Int) = PixelBuffer(w, h, IntArray(w * h) { c })
    @Test fun blankDetection() {
        assertTrue(BlankDetector.isBlank(solid(100, 140, 0xFFFFFFFF.toInt())))
        assertTrue(BlankDetector.isBlank(solid(100, 140, 0xFFF5F5F5.toInt())))
        assertFalse(BlankDetector.isBlank(solid(100, 140, 0xFFE0E0E0.toInt())))      // light grey scan => keep
        val px = IntArray(100 * 140) { 0xFFFFFFFF.toInt() }; for (i in 0 until 50) px[i] = 0xFF000000.toInt()
        assertFalse(BlankDetector.isBlank(PixelBuffer(100, 140, px)))
    }
    @Test fun grayscaleBwAndEco() {
        val red = solid(2, 2, 0xFFFF0000.toInt())
        val g = ImageFilters.apply(red, PrintSettings(color = ColorMode.GRAYSCALE))
        assertTrue((g.argb[0] shr 16 and 255) == (g.argb[0] and 255))
        val bw = ImageFilters.apply(solid(2, 2, 0xFF404040.toInt()), PrintSettings(color = ColorMode.BLACK_WHITE))
        assertEquals(0xFF000000.toInt(), bw.argb[0])
        val bw2 = ImageFilters.apply(solid(2, 2, 0xFFC0C0C0.toInt()), PrintSettings(color = ColorMode.BLACK_WHITE))
        assertEquals(0xFFFFFFFF.toInt(), bw2.argb[0])
    }
    @Test fun ecoReducesCoverageAndKeepsTextEdges() {
        // 20x20 black block (a fill) on white
        val w = 40; val px = IntArray(w * w) { 0xFFFFFFFF.toInt() }
        for (y in 10 until 30) for (x in 10 until 30) px[y * w + x] = 0xFF000000.toInt()
        val src = PixelBuffer(w, w, px)
        val base = PrintSettings(color = ColorMode.GRAYSCALE)
        val before = ImageFilters.inkCoverage(ImageFilters.apply(src, base))
        val eco = ImageFilters.apply(src, base.copy(eco = EcoMode.SOFTWARE_DRAFT, ecoStrength = 60, ecoStyle = EcoStyle.KEEP_TEXT_EDGES))
        assertTrue(ImageFilters.inkCoverage(eco) < before * 0.6)
        assertEquals(0xFF000000.toInt(), eco.argb[10 * w + 10])                // edge pixel stays solid black
        assertTrue((eco.argb[20 * w + 20] and 255) > 100)                       // interior lightened
        // thin 1px line is entirely edge => untouched
        val line = IntArray(w * w) { 0xFFFFFFFF.toInt() }; for (x in 5 until 35) line[20 * w + x] = 0xFF000000.toInt()
        val l = ImageFilters.apply(PixelBuffer(w, w, line), base.copy(eco = EcoMode.SOFTWARE_DRAFT, ecoStrength = 60))
        assertEquals(0xFF000000.toInt(), l.argb[20 * w + 20])
        val all = ImageFilters.apply(PixelBuffer(w, w, line), base.copy(eco = EcoMode.SOFTWARE_DRAFT, ecoStrength = 60, ecoStyle = EcoStyle.LIGHTEN_ALL))
        assertTrue((all.argb[20 * w + 20] and 255) > 100)
        assertEquals(before, ImageFilters.inkCoverage(ImageFilters.apply(src, base.copy(eco = EcoMode.OFF))), 1e-9)
    }
    @Test fun contrastAndDarkness() {
        val d = ImageFilters.apply(solid(1, 1, 0xFF808080.toInt()), PrintSettings(darkness = 30))
        assertTrue((d.argb[0] and 255) < 0x80)
        val l = ImageFilters.apply(solid(1, 1, 0xFF808080.toInt()), PrintSettings(darkness = -30))
        assertTrue((l.argb[0] and 255) > 0x80)
    }

    private fun render(pages: Int, s: PrintSettings, partIdx: Int = 0, fake: FakeProvider = FakeProvider()): Pair<ByteArray, JobPlan> {
        val p = plan(pages, s)
        val part = p.parts[partIdx]
        val bos = java.io.ByteArrayOutputStream()
        PartPdfWriter(p, s, fake, TestJpeg).write(part, part.sides.indices.toList(), bos)
        return bos.toByteArray() to p
    }
    private fun count(b: ByteArray, needle: String) = String(b, Charsets.ISO_8859_1).split(needle).size - 1

    @Test fun pdfStructure() {
        val (b, _) = render(5, PrintSettings(pagesPerSheet = 2))
        val txt = String(b, Charsets.ISO_8859_1)
        assertTrue(txt.startsWith("%PDF-1.4")); assertTrue(txt.trimEnd().endsWith("%%EOF"))
        assertEquals(3, count(b, "/Type /Page "))
        assertTrue(txt.contains("/Count 3"))
    }
    @Test fun copiesReuseRenderedImages() {
        val f = FakeProvider()
        val (b, _) = render(2, PrintSettings(copies = 3), fake = f)
        assertEquals(6, count(b, "/Type /Page "))
        assertEquals(2, f.rendered.size)                                  // 2 distinct pages rendered once each
        assertEquals(2, count(b, "/Subtype /Image"))
    }
    @Test fun bwUsesOneBitFlate() {
        val (b, _) = render(1, PrintSettings(color = ColorMode.BLACK_WHITE))
        assertTrue(String(b, Charsets.ISO_8859_1).contains("/BitsPerComponent 1"))
    }
    @Test fun cancellationStopsRenderingAndThrows() {
        val s = PrintSettings(); val p = plan(10, s); val f = FakeProvider(); var calls = 0
        val bos = java.io.ByteArrayOutputStream()
        try {
            PartPdfWriter(p, s, f, TestJpeg).write(p.parts[0], p.parts[0].sides.indices.toList(), bos, isCancelled = { ++calls > 7 })
            fail("expected cancellation")
        } catch (e: CancelledException) { }
        assertTrue(f.rendered.size < 10)
        assertFalse(String(bos.toByteArray(), Charsets.ISO_8859_1).trimEnd().endsWith("%%EOF")) // never finalised
    }
    @Test fun subsetOfOutputPagesForSystemPageRanges() {
        val s = PrintSettings(); val p = plan(6, s); val bos = java.io.ByteArrayOutputStream()
        PartPdfWriter(p, s, FakeProvider(), TestJpeg).write(p.parts[0], listOf(1, 3), bos)
        assertEquals(2, count(bos.toByteArray(), "/Type /Page "))
    }
}

class IppTest {
    private fun tlv(tag: Int, name: String, value: ByteArray): ByteArray {
        val o = java.io.ByteArrayOutputStream(); val d = java.io.DataOutputStream(o)
        d.writeByte(tag); d.writeShort(name.length); d.write(name.toByteArray()); d.writeShort(value.size); d.write(value); return o.toByteArray()
    }
    @Test fun requestIsWellFormed() {
        val r = Ipp.buildGetPrinterAttributes("ipp://1.2.3.4:631/ipp/print")
        assertEquals(1, r[0].toInt()); assertEquals(0x0B, r[3].toInt()); assertEquals(0x03, r.last().toInt())
    }
    @Test fun parsesResponseLikeASplMopriaPrinter() {
        val o = java.io.ByteArrayOutputStream(); val d = java.io.DataOutputStream(o)
        d.writeByte(1); d.writeByte(1); d.writeShort(0); d.writeInt(1); d.writeByte(0x04)
        o.write(tlv(0x41, "printer-make-and-model", "HP Laser 107w".toByteArray()))
        o.write(tlv(0x49, "document-format-supported", "image/urf".toByteArray()))
        o.write(tlv(0x49, "", "image/pwg-raster".toByteArray()))
        o.write(tlv(0x44, "sides-supported", "one-sided".toByteArray()))
        o.write(tlv(0x23, "printer-state", byteArrayOf(0, 0, 0, 3)))
        o.write(tlv(0x32, "printer-resolution-supported", byteArrayOf(0, 0, 2, 0x58, 0, 0, 2, 0x58, 3)))
        o.write(tlv(0x34, "media-col-default", ByteArray(0))); o.write(tlv(0x44, "", "ignored".toByteArray())); o.write(tlv(0x37, "", ByteArray(0)))
        d.writeByte(0x03); d.flush()
        val rep = Ipp.report(Ipp.parse(o.toByteArray()))
        assertEquals("HP Laser 107w", rep.makeModel)
        assertEquals(listOf("image/urf", "image/pwg-raster"), rep.formats)
        assertFalse(rep.acceptsPdf); assertTrue(rep.acceptsRaster); assertFalse(rep.hasAutoDuplex)
        assertEquals("idle", rep.state); assertEquals(listOf("600x600 dpi"), rep.resolutions)
    }
}

class SettingsAndPresetsTest {
    @Test fun roundTrip() {
        val s = PrintSettings(copies = 3, pagesPerSheet = 6, booklet = true, eco = EcoMode.SOFTWARE_DRAFT, rangeText = "1-3,5", binding = Binding.NOTEPAD)
        assertEquals(s, PrintSettings.fromMap(s.toMap()))
    }
    @Test fun badValuesFallBackToDefaults() {
        val s = PrintSettings.fromMap(mapOf("pagesPerSheet" to "7", "copies" to "-5", "paper" to "NOPE"))
        assertEquals(1, s.pagesPerSheet); assertEquals(1, s.copies); assertEquals(PaperSize.A4, s.paper)
    }
    @Test fun presetsAndDetect() {
        val b = Presets.apply(Preset.BOOKLET, PrintSettings())
        assertTrue(b.booklet); assertEquals(Preset.BOOKLET, Presets.detect(b))
        assertEquals(Preset.CUSTOM, Presets.detect(b.copy(booklet = false)))
        val e = Presets.apply(Preset.ECONOMY, PrintSettings())
        assertEquals(EcoMode.SOFTWARE_DRAFT, e.eco)
        assertEquals(Preset.ECONOMY, Presets.detect(e.copy(copies = 4)))
    }
}
