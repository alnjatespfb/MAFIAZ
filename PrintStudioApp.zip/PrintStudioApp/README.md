# Print Studio — native Android printing app (Kotlin, Android 10+)

## الحصول على الـ APK (أسهل طريقة، بدون Android Studio)
1. أنشئ مستودعًا جديدًا (Private) على github.com وارفع محتويات هذا المجلد كما هي (مع مجلد `.github`).
2. افتح تبويب **Actions** ← **Build APK** ← انتظر ~5 دقائق.
3. من صفحة التشغيل نزّل **PrintStudio-debug-apk** (ملف zip فيه `app-debug.apk`) وثبّته على الهاتف
   (اسمح بالتثبيت من مصدر غير معروف).

## البناء بـ Android Studio
Open the folder → let Gradle sync → Run, or `./gradlew assembleDebug`
(JDK 17, Android SDK 35). APK: `app/build/outputs/apk/debug/app-debug.apk`. Tests: `./gradlew testDebugUnitTest`.

## Architecture
- `core/` pure Kotlin (no android.*) — page selection, N-up layout, manual-duplex + booklet planner, geometry,
  image filters (grayscale/B&W/contrast/darkness/eco), streaming PDF writer, IPP inspector. Unit-tested on the JVM.
- `android/` PrintManager adapter (`PlanPrintAdapter`), job queue/state machine, SAF import + PdfRenderer, thumbnails, mDNS discovery.
- `ui/` framework-Views UI (no AndroidX), English + Arabic RTL, light/dark.

## HP Laser 107w printing path (decision)
HP's spec lists **SPL** as the only page language (no PDF/PCL/PS) plus AirPrint and Mopria certification.
So: the app renders pages itself and hands a PDF to Android's PrintManager; the phone's print service (Mopria /
Samsung Default Print Service) converts it to a raster format for the printer. No raw PDF is ever sent to the printer,
no custom SPL driver (undocumented), no assumption of generic IPP. The *Printer → Inspect* tool queries the real printer
over IPP (read-only) so you can see what it actually advertises.

## Manual two-sided
Two separate jobs: fronts, then (after YOU confirm reloading) backs. Back order and 180° rotation are configurable and
learned with a 2-sheet calibration test, because paper path differs per printer. Odd page counts keep a blank back so the stack stays in sync.

## Not possible / alternatives
- Hardware toner-save, tray, real duplex, printer resolution: not settable via Android's print API → shown only as notes;
  *software draft mode* is provided and labelled as software.
- Android can't pre-select the printer or skip its dialog; each pass shows it.
- Job "completed" = reported by the print service; paper reloading can't be detected → explicit confirmation.
- Not yet verified on a physical HP Laser 107w (no printer in the build sandbox).
