package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.crypto.CryptoEngine
import com.example.data.local.MeshTalkDatabase
import com.example.data.local.OutboxEntity
import com.example.data.local.SeenPacketEntity
import com.example.data.model.MeshPacket
import com.example.data.model.PacketType
import com.example.mesh.PacketCodec
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `verify app name string resource is MeshTalk`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("MeshTalk", appName)
    }

    @Test
    fun `verify random mesh handle and shareable identity generation`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val engine = CryptoEngine(context)

        val handle1 = engine.generateRandomMeshHandle()
        assertNotNull(handle1)
        assertTrue(handle1.contains("-"))

        val shareText = engine.getShareableIdentityText()
        assertTrue(shareText.contains("MeshTalk"))
        assertTrue(shareText.contains("Node ID:"))
        assertTrue(shareText.contains("Key Fingerprint:"))
    }

    @Test
    fun `verify end-to-end encryption with ECDH and AES-GCM`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val nodeA = CryptoEngine(context)

        val nodeB = CryptoEngine(context)
        val nodeBPublicKey = nodeB.getPublicKeyBase64()

        val secretMessage = "Confidential Mesh Message across Nodes A -> B -> C"

        // Node A encrypts for Node B
        val encResult = nodeA.encryptForRecipient(secretMessage, nodeBPublicKey)
        assertNotNull(encResult.ciphertextBase64)
        assertNotEquals(secretMessage, encResult.ciphertextBase64)

        // Node B decrypts
        val decResult = nodeB.decryptFromSender(
            encResult.ciphertextBase64,
            encResult.nonceIvBase64,
            encResult.ephemeralPublicKeyBase64
        )
        assertTrue(decResult.isSuccess)
        assertEquals(secretMessage, decResult.getOrNull())
    }

    @Test
    fun `verify packet JSON serialization and deserialization`() {
        val packet = MeshPacket(
            packetId = "pkt_test_12345",
            type = PacketType.DATA,
            senderNodeId = "node_alpha",
            senderDisplayName = "Node Alpha",
            recipientNodeId = "node_bravo",
            payloadCiphertext = "dGVzdF9jaXBoZXI=",
            nonceIv = "aXYxMjM0NQ==",
            senderEphemeralPubKey = "ZXBoX3B1YmtleQ==",
            timestamp = 1700000000L,
            hopCount = 2,
            maxTtl = 5,
            signature = "sig_valid_123",
            routeTrace = listOf("node_alpha", "node_relay_1")
        )

        val json = PacketCodec.serialize(packet)
        val deserialized = PacketCodec.deserialize(json)

        assertNotNull(deserialized)
        assertEquals(packet.packetId, deserialized?.packetId)
        assertEquals(packet.type, deserialized?.type)
        assertEquals(packet.senderNodeId, deserialized?.senderNodeId)
        assertEquals(packet.recipientNodeId, deserialized?.recipientNodeId)
        assertEquals(packet.hopCount, deserialized?.hopCount)
        assertEquals(packet.routeTrace, deserialized?.routeTrace)
    }

    @Test
    fun `verify loop prevention and duplicate packet suppression in Room`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = MeshTalkDatabase.getDatabase(context)
        val seenDao = db.seenPacketDao()

        val packetId = "pkt_loop_test_" + UUID.randomUUID().toString().take(8)

        // Initially not seen
        assertFalse(seenDao.hasSeenPacket(packetId))

        // Mark seen
        seenDao.markPacketSeen(SeenPacketEntity(packetId, System.currentTimeMillis()))

        // Subsequent check must return true
        assertTrue(seenDao.hasSeenPacket(packetId))
    }

    @Test
    fun `verify store and forward outbox queue`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = MeshTalkDatabase.getDatabase(context)
        val outboxDao = db.outboxDao()

        val packetId = "pkt_outbox_" + UUID.randomUUID().toString().take(8)
        outboxDao.enqueue(
            OutboxEntity(
                packetId = packetId,
                recipientNodeId = "node_offline_target",
                packetJson = "{}",
                createdAtTimestamp = System.currentTimeMillis()
            )
        )

        val pending = outboxDao.getAllPendingPackets()
        assertTrue(pending.any { it.packetId == packetId })

        outboxDao.dequeue(packetId)
        val pendingAfter = outboxDao.getAllPendingPackets()
        assertFalse(pendingAfter.any { it.packetId == packetId })
    }
}
