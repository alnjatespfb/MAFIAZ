package com.example.transport.wifi

import android.content.Context
import android.content.pm.PackageManager
import android.net.wifi.aware.AttachCallback
import android.net.wifi.aware.DiscoverySessionCallback
import android.net.wifi.aware.PeerHandle
import android.net.wifi.aware.PublishConfig
import android.net.wifi.aware.PublishDiscoverySession
import android.net.wifi.aware.SubscribeConfig
import android.net.wifi.aware.SubscribeDiscoverySession
import android.net.wifi.aware.WifiAwareManager
import android.net.wifi.aware.WifiAwareSession
import android.os.Build
import com.example.crypto.CryptoEngine
import com.example.data.model.MeshPacket
import com.example.data.model.MeshPeer
import com.example.data.model.TransportProtocol
import com.example.mesh.PacketCodec
import com.example.transport.MeshTransport
import com.example.transport.RadioStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap

class WifiAwareTransport(
    private val context: Context,
    private val cryptoEngine: CryptoEngine
) : MeshTransport {

    companion object {
        const val SERVICE_NAME = "meshtalk_mesh_nan_service"
    }

    override val protocol: TransportProtocol = TransportProtocol.WIFI_AWARE

    private val awareManager: WifiAwareManager? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        context.getSystemService(Context.WIFI_AWARE_SERVICE) as? WifiAwareManager
    } else {
        null
    }

    override val isSupportedOnDevice: Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        context.packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI_AWARE) && awareManager?.isAvailable == true
    } else {
        false
    }

    private val _radioStatus = MutableStateFlow<RadioStatus>(RadioStatus.Disabled)
    override val radioStatus: StateFlow<RadioStatus> = _radioStatus.asStateFlow()

    private val _discoveredPeers = MutableStateFlow<List<MeshPeer>>(emptyList())
    override val discoveredPeers: StateFlow<List<MeshPeer>> = _discoveredPeers.asStateFlow()

    private val _incomingPackets = MutableSharedFlow<MeshPacket>(extraBufferCapacity = 64)

    private var awareSession: WifiAwareSession? = null
    private var publishSession: PublishDiscoverySession? = null
    private var subscribeSession: SubscribeDiscoverySession? = null
    private val knownPeerHandles = ConcurrentHashMap<String, PeerHandle>()

    override suspend fun start() {
        if (!isSupportedOnDevice || awareManager == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            _radioStatus.value = RadioStatus.Error("Wi-Fi Aware not supported on device")
            return
        }

        try {
            awareManager.attach(object : AttachCallback() {
                override fun onAttached(session: WifiAwareSession) {
                    awareSession = session
                    _radioStatus.value = RadioStatus.Ready
                    startPublishAndSubscribe(session)
                }

                override fun onAttachFailed() {
                    _radioStatus.value = RadioStatus.Error("Wi-Fi Aware attach failed")
                }
            }, null)
        } catch (e: Exception) {
            _radioStatus.value = RadioStatus.Error(e.message ?: "Wi-Fi Aware error")
        }
    }

    private fun startPublishAndSubscribe(session: WifiAwareSession) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

        val myNodeId = cryptoEngine.getOrCreateNodeId()
        val publishConfig = PublishConfig.Builder()
            .setServiceName(SERVICE_NAME)
            .setServiceSpecificInfo(myNodeId.toByteArray(Charsets.UTF_8))
            .build()

        session.publish(publishConfig, object : DiscoverySessionCallback() {
            override fun onPublishStarted(session: PublishDiscoverySession) {
                publishSession = session
                _radioStatus.value = RadioStatus.Active(connectedPeersCount = knownPeerHandles.size)
            }

            override fun onMessageReceived(peerHandle: PeerHandle, message: ByteArray) {
                val jsonStr = String(message, Charsets.UTF_8)
                val packet = PacketCodec.deserialize(jsonStr)
                if (packet != null) {
                    _incomingPackets.tryEmit(packet)
                }
            }
        }, null)

        val subscribeConfig = SubscribeConfig.Builder()
            .setServiceName(SERVICE_NAME)
            .build()

        session.subscribe(subscribeConfig, object : DiscoverySessionCallback() {
            override fun onSubscribeStarted(session: SubscribeDiscoverySession) {
                subscribeSession = session
            }

            override fun onServiceDiscovered(peerHandle: PeerHandle, serviceSpecificInfo: ByteArray?, matchFilter: MutableList<ByteArray>?) {
                val peerNodeId = if (serviceSpecificInfo != null) String(serviceSpecificInfo, Charsets.UTF_8) else "node_aware_${peerHandle.hashCode()}"
                knownPeerHandles[peerNodeId] = peerHandle

                val peer = MeshPeer(
                    nodeId = peerNodeId,
                    displayName = "Wi-Fi Aware Peer (${peerNodeId.takeLast(4)})",
                    publicKeyBase64 = "",
                    transport = TransportProtocol.WIFI_AWARE,
                    isConnected = true,
                    hopDistance = 1
                )
                _discoveredPeers.value = _discoveredPeers.value.filter { it.nodeId != peerNodeId } + peer
            }
        }, null)
    }

    override suspend fun stop() {
        publishSession?.close()
        subscribeSession?.close()
        awareSession?.close()
        _radioStatus.value = RadioStatus.Disabled
    }

    override suspend fun discoverPeers() {
        // Automatic via NAN subscribe callback
    }

    override suspend fun connectToPeer(peer: MeshPeer): Result<Unit> {
        return Result.success(Unit) // Direct L2 message exchange
    }

    override suspend fun disconnectFromPeer(peer: MeshPeer) {
        knownPeerHandles.remove(peer.nodeId)
    }

    override suspend fun broadcastPacket(packet: MeshPacket): Result<Int> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return Result.success(0)
        val serialized = PacketCodec.serialize(packet).toByteArray(Charsets.UTF_8)
        var count = 0

        knownPeerHandles.forEach { (nodeId, peerHandle) ->
            try {
                publishSession?.sendMessage(peerHandle, 0, serialized)
                count++
            } catch (_: Exception) {}
        }
        return Result.success(count)
    }

    override fun observeIncomingPackets(): Flow<MeshPacket> {
        return _incomingPackets.asSharedFlow()
    }
}
