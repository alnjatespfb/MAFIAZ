package com.example.transport.wifi

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.NetworkInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pDeviceList
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import com.example.crypto.CryptoEngine
import com.example.data.model.MeshPacket
import com.example.data.model.MeshPeer
import com.example.data.model.TransportProtocol
import com.example.mesh.PacketCodec
import com.example.transport.MeshTransport
import com.example.transport.RadioStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap

@SuppressLint("MissingPermission")
class WifiDirectTransport(
    private val context: Context,
    private val cryptoEngine: CryptoEngine
) : MeshTransport {

    companion object {
        const val P2P_PORT = 8988
        private const val SOCKET_TIMEOUT_MS = 5000
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override val protocol: TransportProtocol = TransportProtocol.WIFI_DIRECT

    private val p2pManager: WifiP2pManager? = context.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
    private var channel: WifiP2pManager.Channel? = null

    override val isSupportedOnDevice: Boolean = p2pManager != null

    private val _radioStatus = MutableStateFlow<RadioStatus>(RadioStatus.Disabled)
    override val radioStatus: StateFlow<RadioStatus> = _radioStatus.asStateFlow()

    private val _discoveredPeers = MutableStateFlow<List<MeshPeer>>(emptyList())
    override val discoveredPeers: StateFlow<List<MeshPeer>> = _discoveredPeers.asStateFlow()

    private val _incomingPackets = MutableSharedFlow<MeshPacket>(extraBufferCapacity = 64)

    private var serverSocket: ServerSocket? = null
    private val activeSockets = ConcurrentHashMap<String, Socket>()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                    val state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1)
                    if (state == WifiP2pManager.WIFI_P2P_STATE_ENABLED) {
                        _radioStatus.value = RadioStatus.Ready
                    } else {
                        _radioStatus.value = RadioStatus.Disabled
                    }
                }
                WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> {
                    p2pManager?.requestPeers(channel) { peersList: WifiP2pDeviceList? ->
                        updateDiscoveredPeers(peersList?.deviceList ?: emptyList())
                    }
                }
                WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> {
                    val networkInfo = intent.getParcelableExtra<NetworkInfo>(WifiP2pManager.EXTRA_NETWORK_INFO)
                    if (networkInfo?.isConnected == true) {
                        p2pManager?.requestConnectionInfo(channel) { info: WifiP2pInfo? ->
                            info?.let { handleConnectionInfo(it) }
                        }
                    } else {
                        _radioStatus.value = RadioStatus.Ready
                    }
                }
            }
        }
    }

    override suspend fun start() {
        if (!isSupportedOnDevice || p2pManager == null) {
            _radioStatus.value = RadioStatus.Error("Wi-Fi Direct not supported on this device hardware")
            return
        }

        channel = p2pManager.initialize(context, context.mainLooper, null)

        val filter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
        }

        try {
            context.registerReceiver(receiver, filter)
        } catch (_: Exception) {}

        startServerSocket()
        discoverPeers()
        _radioStatus.value = RadioStatus.Ready
    }

    override suspend fun stop() {
        try {
            context.unregisterReceiver(receiver)
        } catch (_: Exception) {}

        try {
            serverSocket?.close()
            activeSockets.values.forEach { it.close() }
            activeSockets.clear()
        } catch (_: Exception) {}

        _radioStatus.value = RadioStatus.Disabled
    }

    private fun startServerSocket() {
        scope.launch {
            try {
                serverSocket = ServerSocket(P2P_PORT)
                _radioStatus.value = RadioStatus.Active(connectedPeersCount = activeSockets.size, isGroupOwner = true)

                while (isActive && serverSocket?.isClosed == false) {
                    val clientSocket = serverSocket?.accept() ?: break
                    val clientIp = clientSocket.inetAddress.hostAddress ?: "unknown"
                    activeSockets[clientIp] = clientSocket
                    _radioStatus.value = RadioStatus.Active(connectedPeersCount = activeSockets.size)

                    // Listen to incoming stream from this connected client
                    scope.launch {
                        handleSocketInputStream(clientSocket, clientIp)
                    }
                }
            } catch (e: Exception) {
                // Server socket closed or port occupied
            }
        }
    }

    private suspend fun handleSocketInputStream(socket: Socket, peerAddress: String) = withContext(Dispatchers.IO) {
        try {
            val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
            while (isActive && socket.isConnected && !socket.isClosed) {
                val line = reader.readLine() ?: break
                val packet = PacketCodec.deserialize(line)
                if (packet != null) {
                    _incomingPackets.emit(packet)
                }
            }
        } catch (e: Exception) {
            // Socket disconnected
        } finally {
            activeSockets.remove(peerAddress)
            _radioStatus.value = RadioStatus.Active(connectedPeersCount = activeSockets.size)
        }
    }

    override suspend fun discoverPeers() {
        p2pManager?.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {}
            override fun onFailure(reason: Int) {}
        })
    }

    private fun updateDiscoveredPeers(devices: Collection<WifiP2pDevice>) {
        val list = devices.map { dev ->
            val nodeId = "node_p2p_" + dev.deviceAddress.replace(":", "").takeLast(8)
            MeshPeer(
                nodeId = nodeId,
                displayName = dev.deviceName.ifBlank { "Nearby P2P Node" },
                publicKeyBase64 = "",
                transport = TransportProtocol.WIFI_DIRECT,
                address = dev.deviceAddress,
                port = P2P_PORT,
                isConnected = dev.status == WifiP2pDevice.CONNECTED,
                hopDistance = 1
            )
        }
        _discoveredPeers.value = list
    }

    override suspend fun connectToPeer(peer: MeshPeer): Result<Unit> = withContext(Dispatchers.IO) {
        val mgr = p2pManager ?: return@withContext Result.failure(Exception("Wi-Fi Direct not initialized"))
        val ch = channel ?: return@withContext Result.failure(Exception("Wi-Fi Direct channel not ready"))

        val config = WifiP2pConfig().apply {
            deviceAddress = peer.address
        }

        var result: Result<Unit> = Result.success(Unit)
        mgr.connect(ch, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                result = Result.success(Unit)
            }
            override fun onFailure(reason: Int) {
                result = Result.failure(Exception("Failed to connect via Wi-Fi P2P (code $reason)"))
            }
        })
        result
    }

    override suspend fun disconnectFromPeer(peer: MeshPeer) {
        p2pManager?.cancelConnect(channel, null)
    }

    private fun handleConnectionInfo(info: WifiP2pInfo) {
        if (info.groupFormed) {
            if (info.isGroupOwner) {
                _radioStatus.value = RadioStatus.Active(connectedPeersCount = activeSockets.size, isGroupOwner = true)
            } else {
                // Client: Connect to Group Owner's IP
                val goHost = info.groupOwnerAddress.hostAddress ?: return
                scope.launch {
                    connectSocketToGroupOwner(goHost)
                }
            }
        }
    }

    private suspend fun connectSocketToGroupOwner(goHost: String) = withContext(Dispatchers.IO) {
        try {
            val socket = Socket()
            socket.connect(InetSocketAddress(goHost, P2P_PORT), SOCKET_TIMEOUT_MS)
            activeSockets[goHost] = socket
            _radioStatus.value = RadioStatus.Active(connectedPeersCount = activeSockets.size, isGroupOwner = false)

            handleSocketInputStream(socket, goHost)
        } catch (e: Exception) {
            // Retry later
        }
    }

    override suspend fun broadcastPacket(packet: MeshPacket): Result<Int> = withContext(Dispatchers.IO) {
        val serialized = PacketCodec.serialize(packet)
        var count = 0

        activeSockets.forEach { (_, socket) ->
            try {
                if (socket.isConnected && !socket.isClosed) {
                    val writer = PrintWriter(socket.getOutputStream(), true)
                    writer.println(serialized)
                    count++
                }
            } catch (e: Exception) {
                // Ignore socket write error for this peer
            }
        }

        Result.success(count)
    }

    override fun observeIncomingPackets(): Flow<MeshPacket> {
        return _incomingPackets.asSharedFlow()
    }
}
