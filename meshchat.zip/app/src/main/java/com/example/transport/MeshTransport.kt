package com.example.transport

import com.example.data.model.MeshPacket
import com.example.data.model.MeshPeer
import com.example.data.model.TransportProtocol
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

sealed interface RadioStatus {
    data object Disabled : RadioStatus
    data object Ready : RadioStatus
    data class Active(val connectedPeersCount: Int, val isGroupOwner: Boolean = false) : RadioStatus
    data class Error(val errorMsg: String) : RadioStatus
}

interface MeshTransport {
    val protocol: TransportProtocol
    val isSupportedOnDevice: Boolean
    val radioStatus: StateFlow<RadioStatus>
    val discoveredPeers: StateFlow<List<MeshPeer>>

    suspend fun start()
    suspend fun stop()
    suspend fun discoverPeers()
    suspend fun connectToPeer(peer: MeshPeer): Result<Unit>
    suspend fun disconnectFromPeer(peer: MeshPeer)
    suspend fun broadcastPacket(packet: MeshPacket): Result<Int> // Returns count of directly reached neighbors
    fun observeIncomingPackets(): Flow<MeshPacket>
}
