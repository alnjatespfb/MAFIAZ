package com.example.transport.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.BluetoothLeAdvertiser
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.ParcelUuid
import com.example.crypto.CryptoEngine
import com.example.data.model.MeshPacket
import com.example.data.model.MeshPeer
import com.example.data.model.TransportProtocol
import com.example.transport.MeshTransport
import com.example.transport.RadioStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

@SuppressLint("MissingPermission")
class BleTransport(
    private val context: Context,
    private val cryptoEngine: CryptoEngine
) : MeshTransport {

    companion object {
        val MESH_SERVICE_UUID: UUID = UUID.fromString("0000FEAA-0000-1000-8000-00805F9B34FB")
    }

    override val protocol: TransportProtocol = TransportProtocol.BLE

    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    override val isSupportedOnDevice: Boolean = bluetoothAdapter != null

    private val _radioStatus = MutableStateFlow<RadioStatus>(RadioStatus.Disabled)
    override val radioStatus: StateFlow<RadioStatus> = _radioStatus.asStateFlow()

    private val _discoveredPeers = MutableStateFlow<List<MeshPeer>>(emptyList())
    override val discoveredPeers: StateFlow<List<MeshPeer>> = _discoveredPeers.asStateFlow()

    private val _incomingPackets = MutableSharedFlow<MeshPacket>(extraBufferCapacity = 64)

    private var advertiser: BluetoothLeAdvertiser? = null
    private var scanner: BluetoothLeScanner? = null

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val scanRecord = result.scanRecord
            val serviceData = scanRecord?.getServiceData(ParcelUuid(MESH_SERVICE_UUID))

            val peerNodeId = if (serviceData != null && serviceData.isNotEmpty()) {
                String(serviceData, Charsets.UTF_8)
            } else {
                "node_ble_" + device.address.replace(":", "").takeLast(8)
            }

            val peer = MeshPeer(
                nodeId = peerNodeId,
                displayName = device.name ?: "Nearby BLE Peer",
                publicKeyBase64 = "",
                transport = TransportProtocol.BLE,
                address = device.address,
                rssi = result.rssi,
                isConnected = true,
                hopDistance = 1
            )

            _discoveredPeers.value = _discoveredPeers.value.filter { it.nodeId != peerNodeId } + peer
        }
    }

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
            _radioStatus.value = RadioStatus.Active(connectedPeersCount = _discoveredPeers.value.size)
        }

        override fun onStartFailure(errorCode: Int) {
            _radioStatus.value = RadioStatus.Error("BLE Advertise failed: code $errorCode")
        }
    }

    override suspend fun start() {
        if (!isSupportedOnDevice || bluetoothAdapter?.isEnabled != true) {
            _radioStatus.value = RadioStatus.Disabled
            return
        }

        advertiser = bluetoothAdapter.bluetoothLeAdvertiser
        scanner = bluetoothAdapter.bluetoothLeScanner

        startAdvertising()
        discoverPeers()
        _radioStatus.value = RadioStatus.Ready
    }

    private fun startAdvertising() {
        val adv = advertiser ?: return
        val myNodeId = cryptoEngine.getOrCreateNodeId().take(8)

        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setConnectable(true)
            .setTimeout(0)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
            .build()

        val data = AdvertiseData.Builder()
            .addServiceUuid(ParcelUuid(MESH_SERVICE_UUID))
            .addServiceData(ParcelUuid(MESH_SERVICE_UUID), myNodeId.toByteArray(Charsets.UTF_8))
            .setIncludeDeviceName(true)
            .build()

        try {
            adv.startAdvertising(settings, data, advertiseCallback)
        } catch (_: Exception) {}
    }

    override suspend fun stop() {
        try {
            advertiser?.stopAdvertising(advertiseCallback)
            scanner?.stopScan(scanCallback)
        } catch (_: Exception) {}
        _radioStatus.value = RadioStatus.Disabled
    }

    override suspend fun discoverPeers() {
        val scn = scanner ?: return
        val filter = ScanFilter.Builder()
            .setServiceUuid(ParcelUuid(MESH_SERVICE_UUID))
            .build()

        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        try {
            scn.startScan(listOf(filter), settings, scanCallback)
        } catch (_: Exception) {}
    }

    override suspend fun connectToPeer(peer: MeshPeer): Result<Unit> {
        return Result.success(Unit)
    }

    override suspend fun disconnectFromPeer(peer: MeshPeer) {}

    override suspend fun broadcastPacket(packet: MeshPacket): Result<Int> {
        return Result.success(0)
    }

    override fun observeIncomingPackets(): Flow<MeshPacket> {
        return _incomingPackets.asSharedFlow()
    }
}
