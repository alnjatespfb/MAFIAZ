package com.example

import android.app.Application
import com.example.crypto.CryptoEngine
import com.example.data.local.MeshTalkDatabase
import com.example.mesh.MeshRouter
import com.example.transport.TransportManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class MeshTalkApp : Application() {

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    lateinit var cryptoEngine: CryptoEngine
        private set

    lateinit var database: MeshTalkDatabase
        private set

    lateinit var transportManager: TransportManager
        private set

    lateinit var meshRouter: MeshRouter
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        cryptoEngine = CryptoEngine(this)
        database = MeshTalkDatabase.getDatabase(this)
        transportManager = TransportManager(this, cryptoEngine)

        meshRouter = MeshRouter(
            cryptoEngine = cryptoEngine,
            transportManager = transportManager,
            conversationDao = database.conversationDao(),
            messageDao = database.messageDao(),
            outboxDao = database.outboxDao(),
            seenPacketDao = database.seenPacketDao()
        )

        // Automatically start hardware and mesh radios
        applicationScope.launch {
            transportManager.startAllTransports()
        }
    }

    override fun onTerminate() {
        super.onTerminate()
        applicationScope.launch {
            transportManager.stopAllTransports()
        }
    }

    companion object {
        lateinit var instance: MeshTalkApp
            private set
    }
}
