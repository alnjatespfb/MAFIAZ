package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Mesh Accent Colors
val CyanMesh = Color(0xFF00E5FF)
val CyanMeshVariant = Color(0xFF00B4D8)
val TealAccent = Color(0xFF06D6A0)
val EmeraldConnected = Color(0xFF10B981)
val AmberRelaying = Color(0xFFF59E0B)
val RoseOffline = Color(0xFFEF4444)

// Dark Theme Surfaces
val DarkNavyBackground = Color(0xFF0B132B)
val DarkNavySurface = Color(0xFF1C2541)
val DarkNavySurfaceVariant = Color(0xFF243257)
val DarkNavyCard = Color(0xFF131F37)
val DarkBorder = Color(0xFF2E406B)

// Light Theme Surfaces
val LightBackground = Color(0xFFF4F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2E8F0)
val LightBorder = Color(0xFFCBD5E1)
val PrimaryLight = Color(0xFF0077B6)

// Text Colors
val TextWhitePrimary = Color(0xFFF8FAFC)
val TextNavyPrimary = Color(0xFF0F172A)
val TextMutedDark = Color(0xFF94A3B8)
val TextMutedLight = Color(0xFF64748B)

// Chat Bubbles
val BubbleOutgoingDark = Color(0xFF005F73)
val BubbleOutgoingLight = Color(0xFF0A9396)
val BubbleIncomingDark = Color(0xFF1C2541)
val BubbleIncomingLight = Color(0xFFE2E8F0)
