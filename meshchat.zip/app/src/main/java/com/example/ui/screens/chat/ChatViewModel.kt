package com.example.ui.screens.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ConversationDao
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.mesh.MeshRouter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatUiState(
    val conversation: Conversation? = null,
    val inputText: String = "",
    val isSending: Boolean = false,
    val selectedMessageToInspect: ChatMessage? = null
)

class ChatViewModel(
    private val conversationId: String,
    private val meshRouter: MeshRouter,
    private val conversationDao: ConversationDao
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    val messages: StateFlow<List<ChatMessage>> = meshRouter.getMessagesForConversation(conversationId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        loadConversation()
        markRead()
    }

    private fun loadConversation() {
        viewModelScope.launch {
            val conv = conversationDao.getConversationById(conversationId)
            if (conv != null) {
                _uiState.update { it.copy(conversation = conv.toDomain()) }
            }
        }
    }

    private fun markRead() {
        viewModelScope.launch {
            meshRouter.markConversationRead(conversationId)
        }
    }

    fun onInputTextChanged(text: String) {
        _uiState.update { it.copy(inputText = text) }
    }

    fun sendMessage() {
        val text = _uiState.value.inputText.trim()
        val conv = _uiState.value.conversation ?: return
        if (text.isBlank()) return

        _uiState.update { it.copy(inputText = "", isSending = true) }

        viewModelScope.launch {
            meshRouter.sendOutgoingMessage(
                conversationId = conv.id,
                recipientNodeId = conv.peerNodeId,
                recipientPublicKeyBase64 = conv.peerPublicKeyBase64,
                plainText = text
            )
            _uiState.update { it.copy(isSending = false) }
        }
    }

    fun selectMessageForInspection(message: ChatMessage) {
        _uiState.update { it.copy(selectedMessageToInspect = message) }
    }

    fun dismissPacketInspector() {
        _uiState.update { it.copy(selectedMessageToInspect = null) }
    }
}
