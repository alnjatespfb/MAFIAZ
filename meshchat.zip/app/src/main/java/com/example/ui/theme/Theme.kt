package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = CyanMesh,
    onPrimary = DarkNavyBackground,
    primaryContainer = Color(0xFF00364F),
    onPrimaryContainer = CyanMesh,
    secondary = TealAccent,
    onSecondary = Color(0xFF003822),
    secondaryContainer = Color(0xFF005234),
    onSecondaryContainer = TealAccent,
    tertiary = AmberRelaying,
    onTertiary = Color(0xFF452B00),
    background = DarkNavyBackground,
    onBackground = TextWhitePrimary,
    surface = DarkNavySurface,
    onSurface = TextWhitePrimary,
    surfaceVariant = DarkNavySurfaceVariant,
    onSurfaceVariant = TextMutedDark,
    outline = DarkBorder,
    outlineVariant = Color(0xFF1F2C4C)
)

private val LightColorScheme = lightColorScheme(
    primary = PrimaryLight,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCBE6FF),
    onPrimaryContainer = Color(0xFF001E30),
    secondary = TealAccent,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFBCF3E6),
    onSecondaryContainer = Color(0xFF002014),
    tertiary = AmberRelaying,
    onTertiary = Color.White,
    background = LightBackground,
    onBackground = TextNavyPrimary,
    surface = LightSurface,
    onSurface = TextNavyPrimary,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = TextMutedLight,
    outline = LightBorder,
    outlineVariant = Color(0xFFE2E8F0)
)

@Composable
fun MeshChatTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep bespoke mesh theme for distinctive aesthetic
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
