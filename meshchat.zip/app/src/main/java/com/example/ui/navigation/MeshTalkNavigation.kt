package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.MeshTalkApp
import com.example.ui.screens.chat.ChatScreen
import com.example.ui.screens.chat.ChatViewModel
import com.example.ui.screens.main.MainScreen
import com.example.ui.screens.main.MainViewModel
import com.example.ui.screens.setup.SetupScreen
import com.example.ui.screens.setup.SetupViewModel

object MeshTalkDestinations {
    const val SETUP = "setup"
    const val MAIN = "main"
    const val CHAT = "chat/{conversationId}"

    fun chatRoute(conversationId: String) = "chat/$conversationId"
}

@Composable
fun MeshTalkNavHost(
    navController: NavHostController = rememberNavController()
) {
    val app = MeshTalkApp.instance
    val currentName = app.cryptoEngine.getDisplayName()
    val isInitiallyConfigured = currentName.isNotBlank() && currentName != "Mesh Node"
    val startDestination = if (isInitiallyConfigured) MeshTalkDestinations.MAIN else MeshTalkDestinations.SETUP

    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable(MeshTalkDestinations.SETUP) {
            val setupViewModel = viewModel {
                SetupViewModel(app.cryptoEngine)
            }
            SetupScreen(
                viewModel = setupViewModel,
                onSetupComplete = {
                    navController.navigate(MeshTalkDestinations.MAIN) {
                        popUpTo(MeshTalkDestinations.SETUP) { inclusive = true }
                    }
                }
            )
        }

        composable(MeshTalkDestinations.MAIN) {
            val mainViewModel = viewModel {
                MainViewModel(
                    cryptoEngine = app.cryptoEngine,
                    transportManager = app.transportManager,
                    meshRouter = app.meshRouter
                )
            }
            MainScreen(
                viewModel = mainViewModel,
                onNavigateToChat = { convId ->
                    navController.navigate(MeshTalkDestinations.chatRoute(convId))
                }
            )
        }

        composable(
            route = MeshTalkDestinations.CHAT,
            arguments = listOf(
                navArgument("conversationId") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val conversationId = backStackEntry.arguments?.getString("conversationId") ?: ""
            val chatViewModel = viewModel {
                ChatViewModel(
                    conversationId = conversationId,
                    meshRouter = app.meshRouter,
                    conversationDao = app.database.conversationDao()
                )
            }
            ChatScreen(
                viewModel = chatViewModel,
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}
