package com.example.ui.screens.setup

import androidx.lifecycle.ViewModel
import com.example.crypto.CryptoEngine
import com.example.data.model.DeviceIdentity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class SetupUiState(
    val deviceNameInput: String = "",
    val nodeId: String = "",
    val keyFingerprint: String = "",
    val isInitialized: Boolean = false
)

class SetupViewModel(
    private val cryptoEngine: CryptoEngine
) : ViewModel() {

    private val _uiState = MutableStateFlow(SetupUiState())
    val uiState: StateFlow<SetupUiState> = _uiState.asStateFlow()

    init {
        val nodeId = cryptoEngine.getOrCreateNodeId()
        val pubKey = cryptoEngine.getPublicKeyBase64()
        val fingerprint = cryptoEngine.computeKeyFingerprint(pubKey)
        val initialHandle = cryptoEngine.getDisplayName()

        _uiState.update {
            it.copy(
                deviceNameInput = initialHandle,
                nodeId = nodeId,
                keyFingerprint = fingerprint
            )
        }
    }

    fun onDeviceNameChanged(name: String) {
        _uiState.update { it.copy(deviceNameInput = name) }
    }

    fun generateNewRandomHandle() {
        val newHandle = cryptoEngine.generateRandomMeshHandle()
        _uiState.update { it.copy(deviceNameInput = newHandle) }
    }

    fun getShareableIdentityText(): String {
        return cryptoEngine.getShareableIdentityText()
    }

    fun completeSetup(onComplete: () -> Unit) {
        val name = _uiState.value.deviceNameInput.trim().ifBlank { cryptoEngine.generateRandomMeshHandle() }
        cryptoEngine.setDisplayName(name)
        _uiState.update { it.copy(isInitialized = true) }
        onComplete()
    }
}
