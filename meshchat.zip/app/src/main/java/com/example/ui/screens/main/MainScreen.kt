package com.example.ui.screens.main

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.outlined.Chat
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.NearMe
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun MainScreen(
    viewModel: MainViewModel,
    onNavigateToChat: (String) -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val peers by viewModel.discoveredPeers.collectAsStateWithLifecycle()
    val conversations by viewModel.conversations.collectAsStateWithLifecycle()
    val pendingOutboxCount by viewModel.pendingOutboxCount.collectAsStateWithLifecycle()

    val wifiDirectStatus by viewModel.wifiDirectStatus.collectAsStateWithLifecycle()
    val wifiAwareStatus by viewModel.wifiAwareStatus.collectAsStateWithLifecycle()
    val bleStatus by viewModel.bleStatus.collectAsStateWithLifecycle()

    val localDeviceIdentity = remember(uiState) { viewModel.getLocalDeviceIdentity() }
    val shareableIdentityText = remember(uiState) { viewModel.getShareableIdentityText() }

    var manualNodeIdInput by remember { mutableStateOf("") }
    var manualNodeNameInput by remember { mutableStateOf("") }

    if (uiState.isAddDirectPeerDialogOpen) {
        AlertDialog(
            onDismissRequest = { viewModel.setAddDirectPeerDialogVisible(false) },
            title = { Text("Start Chat via Friend's ID") },
            text = {
                Column {
                    Text(
                        text = "Enter your friend's Mesh Handle or Node ID to send encrypted messages over the offline mesh network.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    OutlinedTextField(
                        value = manualNodeIdInput,
                        onValueChange = { manualNodeIdInput = it },
                        label = { Text("Friend's Mesh ID or Handle") },
                        placeholder = { Text("e.g. Cyber-Falcon-8419 or mesh_38a9b") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("manual_node_id_input"),
                        shape = RoundedCornerShape(10.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = manualNodeNameInput,
                        onValueChange = { manualNodeNameInput = it },
                        label = { Text("Display Name (Optional)") },
                        placeholder = { Text("e.g. Ahmed") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("manual_node_name_input"),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (manualNodeIdInput.isNotBlank()) {
                            viewModel.startDirectChat(manualNodeIdInput, manualNodeNameInput) { convId ->
                                manualNodeIdInput = ""
                                manualNodeNameInput = ""
                                onNavigateToChat(convId)
                            }
                        }
                    },
                    enabled = manualNodeIdInput.isNotBlank(),
                    modifier = Modifier.testTag("confirm_add_peer_button")
                ) {
                    Text("Start Chat")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.setAddDirectPeerDialogVisible(false) }) {
                    Text("Cancel")
                }
            }
        )
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars),
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("bottom_nav_bar"),
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = uiState.currentTab == MainNavTab.PEERS,
                    onClick = { viewModel.selectTab(MainNavTab.PEERS) },
                    icon = {
                        Icon(
                            imageVector = if (uiState.currentTab == MainNavTab.PEERS) Icons.Filled.NearMe else Icons.Outlined.NearMe,
                            contentDescription = "Nearby Peers"
                        )
                    },
                    label = { Text("Peers", fontWeight = FontWeight.Medium) },
                    modifier = Modifier.testTag("tab_peers"),
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    )
                )

                NavigationBarItem(
                    selected = uiState.currentTab == MainNavTab.CHATS,
                    onClick = { viewModel.selectTab(MainNavTab.CHATS) },
                    icon = {
                        Icon(
                            imageVector = if (uiState.currentTab == MainNavTab.CHATS) Icons.AutoMirrored.Filled.Chat else Icons.AutoMirrored.Outlined.Chat,
                            contentDescription = "Chats"
                        )
                    },
                    label = { Text("Chats", fontWeight = FontWeight.Medium) },
                    modifier = Modifier.testTag("tab_chats"),
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    )
                )

                NavigationBarItem(
                    selected = uiState.currentTab == MainNavTab.SETTINGS,
                    onClick = { viewModel.selectTab(MainNavTab.SETTINGS) },
                    icon = {
                        Icon(
                            imageVector = if (uiState.currentTab == MainNavTab.SETTINGS) Icons.Filled.Settings else Icons.Outlined.Settings,
                            contentDescription = "Settings"
                        )
                    },
                    label = { Text("Settings", fontWeight = FontWeight.Medium) },
                    modifier = Modifier.testTag("tab_settings"),
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (uiState.currentTab) {
                MainNavTab.PEERS -> {
                    PeersTab(
                        peers = peers,
                        deviceIdentity = localDeviceIdentity,
                        shareableIdentityText = shareableIdentityText,
                        isScanning = uiState.isScanning,
                        onScanRequested = { viewModel.discoverPeers() },
                        onPeerConnect = { viewModel.connectToPeer(it) },
                        onPeerMessage = { peer ->
                            viewModel.openChatWithPeer(peer) { convId ->
                                onNavigateToChat(convId)
                            }
                        },
                        onAddManualPeer = { viewModel.setAddDirectPeerDialogVisible(true) }
                    )
                }
                MainNavTab.CHATS -> {
                    ChatsTab(
                        conversations = conversations,
                        pendingOutboxCount = pendingOutboxCount,
                        searchQuery = uiState.searchQuery,
                        onSearchQueryChanged = { viewModel.setSearchQuery(it) },
                        onConversationClicked = onNavigateToChat,
                        onStartNewChatClicked = { viewModel.setAddDirectPeerDialogVisible(true) },
                        onDeleteConversation = { viewModel.deleteConversation(it) },
                        onViewPeersClicked = { viewModel.selectTab(MainNavTab.PEERS) }
                    )
                }
                MainNavTab.SETTINGS -> {
                    SettingsTab(
                        deviceIdentity = localDeviceIdentity,
                        shareableIdentityText = shareableIdentityText,
                        pendingOutboxCount = pendingOutboxCount,
                        wifiDirectStatus = wifiDirectStatus,
                        wifiAwareStatus = wifiAwareStatus,
                        bleStatus = bleStatus,
                        onDeviceNameUpdated = { viewModel.updateDeviceDisplayName(it) }
                    )
                }
            }
        }
    }
}
