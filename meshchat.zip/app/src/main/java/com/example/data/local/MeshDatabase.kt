package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.MessageDeliveryStatus
import kotlinx.coroutines.flow.Flow

@Entity(
    tableName = "conversations",
    indices = [Index(value = ["peerNodeId"], unique = true)]
)
data class ConversationEntity(
    @PrimaryKey val id: String,
    val peerNodeId: String,
    val peerDisplayName: String,
    val peerPublicKeyBase64: String,
    val lastMessageText: String,
    val lastMessageTimestamp: Long,
    val unreadCount: Int = 0,
    val isDirectPeerOnline: Boolean = false,
    val currentHopDistance: Int = 1
) {
    fun toDomain(): Conversation = Conversation(
        id = id,
        peerNodeId = peerNodeId,
        peerDisplayName = peerDisplayName,
        peerPublicKeyBase64 = peerPublicKeyBase64,
        lastMessageText = lastMessageText,
        lastMessageTimestamp = lastMessageTimestamp,
        unreadCount = unreadCount,
        isDirectPeerOnline = isDirectPeerOnline,
        currentHopDistance = currentHopDistance
    )

    companion object {
        fun fromDomain(c: Conversation): ConversationEntity = ConversationEntity(
            id = c.id,
            peerNodeId = c.peerNodeId,
            peerDisplayName = c.peerDisplayName,
            peerPublicKeyBase64 = c.peerPublicKeyBase64,
            lastMessageText = c.lastMessageText,
            lastMessageTimestamp = c.lastMessageTimestamp,
            unreadCount = c.unreadCount,
            isDirectPeerOnline = c.isDirectPeerOnline,
            currentHopDistance = c.currentHopDistance
        )
    }
}

@Entity(
    tableName = "messages",
    indices = [
        Index(value = ["conversationId"]),
        Index(value = ["packetId"]),
        Index(value = ["timestamp"])
    ]
)
data class MessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val senderNodeId: String,
    val recipientNodeId: String,
    val text: String,
    val timestamp: Long,
    val isOutgoing: Boolean,
    val status: String,
    val hopCount: Int,
    val packetId: String,
    val routeTraceRaw: String
) {
    fun toDomain(): ChatMessage = ChatMessage(
        id = id,
        conversationId = conversationId,
        senderNodeId = senderNodeId,
        recipientNodeId = recipientNodeId,
        text = text,
        timestamp = timestamp,
        isOutgoing = isOutgoing,
        status = try { MessageDeliveryStatus.valueOf(status) } catch (e: Exception) { MessageDeliveryStatus.SENDING },
        hopCount = hopCount,
        packetId = packetId,
        routeTrace = if (routeTraceRaw.isBlank()) emptyList() else routeTraceRaw.split(" -> ")
    )

    companion object {
        fun fromDomain(m: ChatMessage): MessageEntity = MessageEntity(
            id = m.id,
            conversationId = m.conversationId,
            senderNodeId = m.senderNodeId,
            recipientNodeId = m.recipientNodeId,
            text = m.text,
            timestamp = m.timestamp,
            isOutgoing = m.isOutgoing,
            status = m.status.name,
            hopCount = m.hopCount,
            packetId = m.packetId,
            routeTraceRaw = m.routeTrace.joinToString(" -> ")
        )
    }
}

/**
 * Store-and-Forward Outbox queue.
 * Packets waiting for a route or peer to become available.
 */
@Entity(tableName = "mesh_outbox")
data class OutboxEntity(
    @PrimaryKey val packetId: String,
    val recipientNodeId: String,
    val packetJson: String,
    val createdAtTimestamp: Long,
    val retryCount: Int = 0
)

/**
 * Seen Packet IDs to prevent loops and duplicate processing.
 */
@Entity(tableName = "seen_packets")
data class SeenPacketEntity(
    @PrimaryKey val packetId: String,
    val firstSeenTimestamp: Long
)

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations ORDER BY lastMessageTimestamp DESC")
    fun getAllConversations(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE id = :id LIMIT 1")
    suspend fun getConversationById(id: String): ConversationEntity?

    @Query("SELECT * FROM conversations WHERE peerNodeId = :peerNodeId LIMIT 1")
    suspend fun getConversationByPeerNodeId(peerNodeId: String): ConversationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(conversation: ConversationEntity)

    @Query("UPDATE conversations SET unreadCount = 0 WHERE id = :id")
    suspend fun markAsRead(id: String)

    @Query("DELETE FROM conversations WHERE id = :id")
    suspend fun deleteConversation(id: String)
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    fun getMessagesForConversation(conversationId: String): Flow<List<MessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity)

    @Update
    suspend fun updateMessage(message: MessageEntity)

    @Query("UPDATE messages SET status = :status WHERE packetId = :packetId")
    suspend fun updateStatusByPacketId(packetId: String, status: String)

    @Query("DELETE FROM messages WHERE id = :id")
    suspend fun deleteMessage(id: String)

    @Query("DELETE FROM messages WHERE conversationId = :conversationId")
    suspend fun deleteAllMessagesInConversation(conversationId: String)
}

@Dao
interface OutboxDao {
    @Query("SELECT * FROM mesh_outbox ORDER BY createdAtTimestamp ASC")
    suspend fun getAllPendingPackets(): List<OutboxEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun enqueue(outbox: OutboxEntity)

    @Query("DELETE FROM mesh_outbox WHERE packetId = :packetId")
    suspend fun dequeue(packetId: String)

    @Query("SELECT COUNT(*) FROM mesh_outbox")
    fun getPendingCount(): Flow<Int>
}

@Dao
interface SeenPacketDao {
    @Query("SELECT EXISTS(SELECT 1 FROM seen_packets WHERE packetId = :packetId)")
    suspend fun hasSeenPacket(packetId: String): Boolean

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun markPacketSeen(seenPacket: SeenPacketEntity)

    @Query("DELETE FROM seen_packets WHERE firstSeenTimestamp < :cutoffTimestamp")
    suspend fun purgeOldPackets(cutoffTimestamp: Long)
}

@Database(
    entities = [ConversationEntity::class, MessageEntity::class, OutboxEntity::class, SeenPacketEntity::class],
    version = 1,
    exportSchema = false
)
abstract class MeshTalkDatabase : RoomDatabase() {
    abstract fun conversationDao(): ConversationDao
    abstract fun messageDao(): MessageDao
    abstract fun outboxDao(): OutboxDao
    abstract fun seenPacketDao(): SeenPacketDao

    companion object {
        @Volatile
        private var INSTANCE: MeshTalkDatabase? = null

        fun getDatabase(context: Context): MeshTalkDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MeshTalkDatabase::class.java,
                    "meshtalk_db"
                ).fallbackToDestructiveMigration(true).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
