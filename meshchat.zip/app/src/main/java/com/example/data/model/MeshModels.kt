package com.example.data.model

import java.util.UUID

enum class PacketType {
    DATA,
    ACK,
    NODE_ANNOUNCE,
    ROUTE_BEACON
}

enum class MessageDeliveryStatus {
    SENDING,
    RELAYING,
    DELIVERED,
    FAILED
}

enum class TransportProtocol(val label: String) {
    WIFI_DIRECT("Wi-Fi Direct"),
    WIFI_AWARE("Wi-Fi Aware (NAN)"),
    BLE("Bluetooth LE"),
    LOOPBACK_SIMULATOR("Local Loopback")
}

data class DeviceIdentity(
    val nodeId: String,
    val displayName: String,
    val publicKeyBase64: String,
    val keyFingerprint: String,
    val createdTimestamp: Long = System.currentTimeMillis()
)

data class MeshPeer(
    val nodeId: String,
    val displayName: String,
    val publicKeyBase64: String,
    val transport: TransportProtocol = TransportProtocol.WIFI_DIRECT,
    val address: String = "", // IP address or MAC address
    val port: Int = 8988,
    val rssi: Int = -60,
    val isConnected: Boolean = false,
    val isGroupOwner: Boolean = false,
    val hopDistance: Int = 1,
    val lastSeenTimestamp: Long = System.currentTimeMillis()
)

data class MeshPacket(
    val packetId: String = "pkt_" + UUID.randomUUID().toString().replace("-", "").take(16),
    val type: PacketType = PacketType.DATA,
    val senderNodeId: String,
    val senderDisplayName: String = "Node",
    val recipientNodeId: String, // Or "*" for broadcast
    val payloadCiphertext: String = "", // Base64 encrypted with AES-256-GCM
    val nonceIv: String = "", // Base64 12-byte IV for GCM
    val senderEphemeralPubKey: String = "", // Base64 for ECDH derivation
    val plainTextAckForPacketId: String = "", // Used when type == ACK
    val timestamp: Long = System.currentTimeMillis(),
    val hopCount: Int = 1,
    val maxTtl: Int = 5,
    val signature: String = "", // ECDSA signature over packet headers + payload
    val routeTrace: List<String> = emptyList() // List of Node IDs visited
) {
    companion object {
        const val BROADCAST_RECIPIENT = "*"
        const val DEFAULT_MAX_TTL = 5
    }
}

data class ChatMessage(
    val id: String,
    val conversationId: String,
    val senderNodeId: String,
    val recipientNodeId: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isOutgoing: Boolean,
    val status: MessageDeliveryStatus = MessageDeliveryStatus.SENDING,
    val hopCount: Int = 1,
    val packetId: String,
    val routeTrace: List<String> = emptyList(),
    val isEncryptedAtRest: Boolean = true
)

data class Conversation(
    val id: String,
    val peerNodeId: String,
    val peerDisplayName: String,
    val peerPublicKeyBase64: String,
    val lastMessageText: String,
    val lastMessageTimestamp: Long,
    val unreadCount: Int = 0,
    val isDirectPeerOnline: Boolean = false,
    val currentHopDistance: Int = 1
)
