package com.example.mesh

import com.example.data.model.MeshPacket
import com.example.data.model.PacketType
import org.json.JSONArray
import org.json.JSONObject

object PacketCodec {

    fun serialize(packet: MeshPacket): String {
        val json = JSONObject()
        json.put("packetId", packet.packetId)
        json.put("type", packet.type.name)
        json.put("senderNodeId", packet.senderNodeId)
        json.put("senderDisplayName", packet.senderDisplayName)
        json.put("recipientNodeId", packet.recipientNodeId)
        json.put("payloadCiphertext", packet.payloadCiphertext)
        json.put("nonceIv", packet.nonceIv)
        json.put("senderEphemeralPubKey", packet.senderEphemeralPubKey)
        json.put("plainTextAckForPacketId", packet.plainTextAckForPacketId)
        json.put("timestamp", packet.timestamp)
        json.put("hopCount", packet.hopCount)
        json.put("maxTtl", packet.maxTtl)
        json.put("signature", packet.signature)

        val routeArr = JSONArray()
        packet.routeTrace.forEach { routeArr.put(it) }
        json.put("routeTrace", routeArr)

        return json.toString()
    }

    fun deserialize(jsonString: String): MeshPacket? {
        return try {
            val json = JSONObject(jsonString)
            val routeTraceList = mutableListOf<String>()
            val routeArr = json.optJSONArray("routeTrace")
            if (routeArr != null) {
                for (i in 0 until routeArr.length()) {
                    routeTraceList.add(routeArr.getString(i))
                }
            }

            MeshPacket(
                packetId = json.getString("packetId"),
                type = try { PacketType.valueOf(json.getString("type")) } catch (e: Exception) { PacketType.DATA },
                senderNodeId = json.getString("senderNodeId"),
                senderDisplayName = json.optString("senderDisplayName", "Node"),
                recipientNodeId = json.getString("recipientNodeId"),
                payloadCiphertext = json.optString("payloadCiphertext", ""),
                nonceIv = json.optString("nonceIv", ""),
                senderEphemeralPubKey = json.optString("senderEphemeralPubKey", ""),
                plainTextAckForPacketId = json.optString("plainTextAckForPacketId", ""),
                timestamp = json.optLong("timestamp", System.currentTimeMillis()),
                hopCount = json.optInt("hopCount", 1),
                maxTtl = json.optInt("maxTtl", MeshPacket.DEFAULT_MAX_TTL),
                signature = json.optString("signature", ""),
                routeTrace = routeTraceList
            )
        } catch (e: Exception) {
            null
        }
    }
}
